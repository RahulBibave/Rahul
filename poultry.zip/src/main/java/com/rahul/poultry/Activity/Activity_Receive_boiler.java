package com.rahul.poultry.Activity;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.rahul.poultry.Data.CommonApi;
import com.rahul.poultry.Data.CommonUI;
import com.rahul.poultry.Data.Driver;
import com.rahul.poultry.Data.FarmerList;

import com.rahul.poultry.Data.Shop;
import com.rahul.poultry.Data.Vehicle;
import com.rahul.poultry.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

/**
 * Created by rahul on 9/3/18.
 */

public class Activity_Receive_boiler extends AppCompatActivity implements View.OnClickListener {
    private ArrayList<FarmerList> mFarmerLists;
    private ArrayList<Vehicle> mVehicleArrayList;
    private ArrayList<Shop> mShopArrayList;
    private ArrayList<Driver> mDriverArrayList;
    private TextView mTxtFarmerCode, mTxtTempoNo, mTxtDriverNo;
    private TextView mTxtAlertTitle, txt_ToolboxHeader;
    private RelativeLayout mLinFarmerCode, mLinTempoNo, mLinDriverNo;
    private boolean bFarmerList, bTempoList, bDriverList, bShopList;

    private TextView txtHeadRece, txtHeadWt, txtHeadQt, txtHeadTray;
    private LinearLayout linRec, linWt, linQt, linTray;

    private TextView mTxtPaperRate, mTxtDailyRate, mEdtReceiveAmount;
    private EditText mEdtReceiveBirds, mEdtBirdsWeight, mEdtReceiveSerial, mEdtChallanNumber, mEdtReceiveQt, mEdtReceiveTray;
    private String data;

    private RelativeLayout mBtnSubmit;
    private RequestQueue mRequestQueue;
    private HashMap<String, String> mHashMap;
    float daily_rate ;
    float x;
    float amount;
    String farmerCode,tempoCode,driverCode;
    private ImageView mBtnBack;

    double latitude, longitude;
    private static final int PERMISSION_REQUEST_CODE = 200;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_boiler);
             initViews();

            ontouchListner();
            mEdtBirdsWeight.addTextChangedListener(new TextWatcher() {

                @Override
                public void afterTextChanged(Editable s) {
                }

                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {
                    if (s.length() != 0)
                        x = Float.parseFloat(mEdtBirdsWeight.getText().toString());
                    amount = daily_rate * x;
                    mEdtReceiveAmount.setText(amount + "");
                    if (mEdtBirdsWeight.getText().toString() == null) {
                        mEdtReceiveAmount.setText("");
                    }
                }
            });

            mEdtReceiveQt.addTextChangedListener(new TextWatcher() {

                @Override
                public void afterTextChanged(Editable s) {
                }

                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {
                    if (s.length() != 0)
                        x = Integer.parseInt(mEdtReceiveQt.getText().toString());
                    amount = daily_rate * x;
                    mEdtReceiveAmount.setText(amount + "");
                    if (mEdtReceiveQt.getText().toString() == null) {
                        mEdtReceiveAmount.setText("");
                    }
                }
            });


        }


    private void ontouchListner() {
        mLinFarmerCode.setOnClickListener(this);
        mLinTempoNo.setOnClickListener(this);
        mLinDriverNo.setOnClickListener(this);
        mBtnSubmit.setOnClickListener(this);
        mBtnBack.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.rv_FarmerCode:
                mEdtBirdsWeight.setText("");
                mEdtReceiveAmount.setText("");
                mEdtReceiveQt.setText("");
                if (bFarmerList==false){
                    if (CommonApi.farmerList == null || CommonApi.farmerList.size() <= 0){
                        bFarmerList=true;
                       // showFarmerCodeAlertDialog();
                        /*CallFARMERCODEAPI callFARMERCODEAPI=new CallFARMERCODEAPI();
                        callFARMERCODEAPI.execute();*/
                    }
                    else {
                       showFarmerCodeAlertDialog();
                    }

                }


                break;

            case R.id.lin_TempoNo:
                if (bTempoList==false){
                    if (CommonApi.vehicleArrayList==null||CommonApi.vehicleArrayList.size()<=0){
                        bTempoList=true;
                       // showTempoCodeAlertDialog();
                       /* CalltempoCODEAPI calltempoCODEAPI=new CalltempoCODEAPI();
                        calltempoCODEAPI.execute();*/
                    }
                    else {
                       showTempoCodeAlertDialog();
                    }
                }

                break;

            case R.id.lin_driver_no:
                if (bDriverList==false){
                    if (CommonApi.driverArrayList==null||CommonApi.driverArrayList.size()<=0){
                        bDriverList=true;
                       /* CallDriverCodeAPI callDriverCodeAPI=new CallDriverCodeAPI();
                        callDriverCodeAPI.execute();*/
                       //showDriverCodeAlertDialog();

                    }
                    else {
                        showDriverCodeAlertDialog();
                    }
                }

                break;

            case R.id.relative_button:
                if (data.equalsIgnoreCase("Receive Boiler")||data.equalsIgnoreCase("Receive Gavran")){
                    if (validation()){

                        if (CommonApi.isNetworkAvailable(Activity_Receive_boiler.this)) {
                            CallReceivedBoilerApi callReceivedBoilerApi=new CallReceivedBoilerApi(farmerCode,tempoCode,driverCode);
                            callReceivedBoilerApi.execute();

                        }else {
                            CommonUI.showAlert(Activity_Receive_boiler.this,"Poultry",getString(R.string.network_error));

                        }

                    }

                }
                else if (data.equalsIgnoreCase("Receive Eggs")){
                    if (validationEggs()){
                        if (CommonApi.isNetworkAvailable(Activity_Receive_boiler.this)) {
                            CallReceivedEggsApi callReceivedEggsApi=new CallReceivedEggsApi(farmerCode,tempoCode,driverCode);
                            callReceivedEggsApi.execute();

                        }else {
                            CommonUI.showAlert(Activity_Receive_boiler.this,"Poultry",getString(R.string.network_error));

                        }

                    }

                }
                break;

            case R.id.imgBackArrow:
                onBackPressed();
            break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void initViews() {
        data=getIntent().getExtras().getString("Recevied","defaultKey");
        mTxtFarmerCode=findViewById(R.id.txtFarmerCode);
        txt_ToolboxHeader=findViewById(R.id.txt_ToolbHeader);
        txt_ToolboxHeader.setText(data);
        mLinFarmerCode=findViewById(R.id.rv_FarmerCode);
        mTxtTempoNo=findViewById(R.id.txtTempoNumber);
        mLinTempoNo=findViewById(R.id.lin_TempoNo);
        mTxtDriverNo=findViewById(R.id.txtDriverNumber);
        mEdtChallanNumber=findViewById(R.id.edtChallanNumber);
        mLinDriverNo=findViewById(R.id.lin_driver_no);
        mTxtPaperRate=findViewById(R.id.txtPaperRate);
        mEdtReceiveBirds=findViewById(R.id.txtReceiveBirds);
        mEdtBirdsWeight=findViewById(R.id.txtBirdsWeight);
        mTxtDailyRate=findViewById(R.id.txtDailyRate);
        mEdtReceiveAmount=findViewById(R.id.edtReceiveAmount);
        mEdtReceiveSerial=findViewById(R.id.txtReceiveSerial);
        mBtnSubmit=findViewById(R.id.relative_button);
        mEdtReceiveQt=findViewById(R.id.edtReceiveQt);
        mEdtReceiveTray=findViewById(R.id.edtReceiveTray);
        mBtnBack=findViewById(R.id.imgBackArrow);

        bFarmerList=false;
        linRec=findViewById(R.id.lin_rece_birds);
        txtHeadRece=findViewById(R.id.txt_head_rece_birds);
        linWt=findViewById(R.id.lin_wt);
        txtHeadWt=findViewById(R.id.txt_head_wt);
        txtHeadQt=findViewById(R.id.txt_head_Qntity);
        linQt=findViewById(R.id.lin_Qt);
        txtHeadTray=findViewById(R.id.txt_head_tray);
        linTray=findViewById(R.id.lin_tray);
        if (data.equalsIgnoreCase("Receive Gavran")||data.equalsIgnoreCase("Receive Boiler")){
           /* linRec.setVisibility(View.VISIBLE);
            txtHeadRece.setVisibility(View.VISIBLE);*/
            linQt.setVisibility(View.GONE);
            txtHeadQt.setVisibility(View.GONE);
            txtHeadTray.setVisibility(View.GONE);
            linTray.setVisibility(View.GONE);
            if (data.equalsIgnoreCase("Receive Gavran")){
                mTxtPaperRate.setText(CommonApi.rateGavran);
            }
            else {
                mTxtPaperRate.setText(CommonApi.rateBoiler);
            }
        }else if (data.equalsIgnoreCase("Receive Eggs")){
            linRec.setVisibility(View.GONE);
            txtHeadRece.setVisibility(View.GONE);
            linWt.setVisibility(View.GONE);
            txtHeadWt.setVisibility(View.GONE);
            mTxtPaperRate.setText(CommonApi.rateEggs);
        }



    }
    //Alert Dialog Tempo Number
    private void showTempoCodeAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Receive_boiler.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.farmer_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        EditText edtSearch=dialog.findViewById(R.id.edtSearch);
        final String search=edtSearch.getText().toString();
        tvtitle.setText("Select Tempo Number");

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bTempoList = false;
            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Receive_boiler.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < CommonApi.vehicleArrayList.size(); i++) {
            choices.add(CommonApi.vehicleArrayList.get(i).getVehicleNo()+"-"+CommonApi.vehicleArrayList.get(i).getMakeModel());
            currencyAdapter.add(CommonApi.vehicleArrayList.get(i).getVehicleNo()+"-"+CommonApi.vehicleArrayList.get(i).getMakeModel());
            currencyAdapter.notifyDataSetChanged();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Receive_boiler.this,
                R.layout.farmer_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                mTxtTempoNo.setText(CommonApi.vehicleArrayList.get(i).getVehicleNo()+"-"+CommonApi.vehicleArrayList.get(i).getMakeModel());
                                                tempoCode=CommonApi.vehicleArrayList.get(i).getId();
                                               /* iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);*/
                                                bTempoList = false;
                                                dialog.dismiss();
                                            }
                                        }
        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    //Alert Dialog Driver Number
    private void showDriverCodeAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Receive_boiler.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.farmer_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        EditText edtSearch=dialog.findViewById(R.id.edtSearch);
        final String search=edtSearch.getText().toString();
        tvtitle.setText("Select Driver Number");

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bDriverList = false;
            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Receive_boiler.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < CommonApi.driverArrayList.size(); i++) {
            choices.add(CommonApi.driverArrayList.get(i).getDriverNo()+"-"+CommonApi.driverArrayList.get(i).getDriverName());
            currencyAdapter.add(CommonApi.driverArrayList.get(i).getDriverNo()+"-"+CommonApi.driverArrayList.get(i).getDriverName());
            currencyAdapter.notifyDataSetChanged();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Receive_boiler.this,
                R.layout.farmer_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                mTxtDriverNo.setText(CommonApi.driverArrayList.get(i).getDriverNo()+"-"+CommonApi.driverArrayList.get(i).getDriverName());
                                               driverCode=CommonApi.driverArrayList.get(i).getId();
                                                /* iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);*/
                                                bDriverList = false;
                                                dialog.dismiss();
                                            }
                                        }
        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

//Alert Dialog Farmer Code
    private void showFarmerCodeAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Receive_boiler.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.farmer_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        EditText edtSearch=dialog.findViewById(R.id.edtSearch);
        final String search=edtSearch.getText().toString();
        tvtitle.setText("Select Farmer Code");

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bFarmerList = false;
            }
        });


        final ArrayList<String> choices = new ArrayList<>();

            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Receive_boiler.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < CommonApi.farmerList.size(); i++) {
                choices.add(CommonApi.farmerList.get(i).getmFarmerCode()+"-"+CommonApi.farmerList.get(i).getmFarmerName());
                currencyAdapter.add(CommonApi.farmerList.get(i).getmFarmerCode()+"-"+CommonApi.farmerList.get(i).getmFarmerName());
                currencyAdapter.notifyDataSetChanged();
            }
      /*  final List<String> listClone = new ArrayList<String>();

        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                for (String curVal : choices) {
                    if (curVal.contains(charSequence)) {
                        listClone.add(curVal);

                    }
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });*/


            ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Receive_boiler.this,
                    R.layout.farmer_list, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                            {
                                                @Override
                                                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                                    mTxtFarmerCode.setText(CommonApi.farmerList.get(i).getmFarmerCode()+"-"+CommonApi.farmerList.get(i).getmFarmerName());
                                               farmerCode=CommonApi.farmerList.get(i).getmFarmerCode();
                                                    /* iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);*/
                                                    if (CommonApi.isNetworkAvailable(Activity_Receive_boiler.this)) {
                                                        CallDailyRatesApi dailyRatesApi=new CallDailyRatesApi(CommonApi.farmerList.get(i).getmFarmerId());
                                                        dailyRatesApi.execute();

                                                    }else {
                                                        CommonUI.showAlert(Activity_Receive_boiler.this,"Poultry",getString(R.string.network_error));

                                                    }



                                                  bFarmerList = false;
                                               dialog.dismiss();
                                                }
                                            }
            );
            dialog.show();
            Window window = dialog.getWindow();
            window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        }









    //Call for Farmer List
    public class CallFARMERCODEAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
           // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showFarmerCodeAlertDialog();
            else
                CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForCurrency();
            return "DONE";

        }

        private void CallForCurrency() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_farmer_code_list" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    mFarmerLists = new ArrayList<FarmerList>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        FarmerList farmerList = new FarmerList();
                        farmerList.setmFarmerCode(jsonObj.getString("farmerCode"));
                        farmerList.setmFarmerId(jsonObj.getString("farmerId"));

                        mFarmerLists.add(farmerList);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    //Call for Tempo List
    public class CalltempoCODEAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showTempoCodeAlertDialog();
            else
                CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForCurrency();
            return "DONE";

        }

        private void CallForCurrency() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_vehicle_no_list" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    mVehicleArrayList = new ArrayList<Vehicle>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Vehicle vehicle = new Vehicle();
                        vehicle.setId(jsonObj.getString("id"));
                        vehicle.setVehicleNo(jsonObj.getString("vehicleNo"));

                        mVehicleArrayList.add(vehicle);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    //Call for Shop List
    public class CallShopCodeAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showFarmerCodeAlertDialog();
            else
                CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForShop();
            return "DONE";

        }

        private void CallForShop() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_shop_code_list" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    mShopArrayList = new ArrayList<Shop>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Shop shop = new Shop();
                        shop.setId(jsonObj.getString("id"));
                        shop.setShopCode(jsonObj.getString("shopCode"));

                        mShopArrayList.add(shop);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    //Call for Driver List
    public class CallDriverCodeAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showDriverCodeAlertDialog();
            else
                CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForDriver();
            return "DONE";

        }

        private void CallForDriver() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_driver_list" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    mDriverArrayList = new ArrayList<Driver>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Driver driver = new Driver();
                        driver.setId(jsonObj.getString("id"));
                        driver.setDriverNo(jsonObj.getString("driverNo"));

                        mDriverArrayList.add(driver);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    //Call for Post Received Boiler and Gavran
    public class CallReceivedBoilerApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";
        String farmerCode,tempoCode,driverCode;


        public CallReceivedBoilerApi(String farmerCode, String tempoCode, String driverCode) {
            this.farmerCode = farmerCode;
            this.tempoCode = tempoCode;
            this.driverCode = driverCode;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           // pd_login.setMessage("Loading...");
           // pd_login.setCancelable(false);
           // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    mTxtFarmerCode.setText("");
                    mEdtReceiveBirds.setText("");
                    mEdtBirdsWeight.setText("");
                    mTxtDailyRate.setText("");
                    mEdtReceiveAmount.setText("");
                    mTxtDriverNo.setText("");
                    mTxtTempoNo.setText("");
                    mEdtChallanNumber.setText("");


                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                String rate="";
                if (data.equalsIgnoreCase("Receive Boiler")){
                    URL url= new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_boiler_chicken");
                    urlConnection = (HttpURLConnection) url.openConnection();
                    rate=CommonApi.rateBoiler;
                }else if (data.equalsIgnoreCase("Receive Gavran")){
                    URL url= new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_gavran_chickens");
                    urlConnection = (HttpURLConnection) url.openConnection();
                    rate=CommonApi.rateGavran;
                }


                JSONObject postDataParams = new JSONObject();
                postDataParams.put("farmerCode",farmerCode);
                postDataParams.put("paperRate",rate);
                postDataParams.put("receiveBirds",mEdtReceiveBirds.getText().toString());
                postDataParams.put("birdsWeight",mEdtBirdsWeight.getText().toString());
                postDataParams.put("dailyRate",mTxtDailyRate.getText().toString());
                postDataParams.put("receiveAmount",mEdtReceiveAmount.getText().toString());
               // postDataParams.put("receiveSerial",mEdtReceiveSerial.getText().toString());
                postDataParams.put("tempoNo",tempoCode);
                postDataParams.put("driverNo",driverCode);
                postDataParams.put("challanNo",mEdtChallanNumber.getText().toString());
                postDataParams.put("entrySource","2");
                postDataParams.put("latitiude",CommonApi.lat);
                postDataParams.put("longitude",CommonApi.longs);
                postDataParams.put("createdById","1");
                postDataParams.put("lastModifiedById","1");


                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }

    //Call for Post Received Gavran
    public class CallReceivedGavranApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {



                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_code"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {

                URL url = new URL("http://18.220.107.138/poultry2.2/api/ /poultry/poultry_gavran_chickens");
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("farmerCode","");
                postDataParams.put("paperRate","");
                postDataParams.put("receiveBirds","");
                postDataParams.put("birdsWeight","");
                postDataParams.put("dailyRate","");
                postDataParams.put("receiveAmount","");
                postDataParams.put("receiveSerial","");
                postDataParams.put("tempoNo","");
                postDataParams.put("driverNo","");
                postDataParams.put("challanNo","");
                postDataParams.put("entrySource","");
                postDataParams.put("latitiude","");
                postDataParams.put("longitude","");
                postDataParams.put("createdById","");
                postDataParams.put("lastModifiedById","");


                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }

    //Call for Post Received Eggs
    public class CallReceivedEggsApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";
        String farmer_Code,tempo_Code,driver_Code;

        public CallReceivedEggsApi(String farmer_Code, String tempo_Code, String driver_Code) {
            this.farmer_Code = farmer_Code;
            this.tempo_Code = tempo_Code;
            this.driver_Code = driver_Code;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    mTxtFarmerCode.setText("");
                    mEdtReceiveBirds.setText("");
                    mEdtBirdsWeight.setText("");
                    mTxtDailyRate.setText("");
                    mEdtReceiveQt.setText("");
                    mEdtReceiveTray.setText("");
                    mEdtReceiveAmount.setText("");
                    mTxtDriverNo.setText("");
                    mTxtTempoNo.setText("");
                    mEdtChallanNumber.setText("");


                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {

                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_chicken_eggs");
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("farmerCode",farmer_Code);
                postDataParams.put("paperRate",CommonApi.rateEggs);
                postDataParams.put("receiveQty",mEdtReceiveQt.getText().toString());
                postDataParams.put("receiveTray",mEdtReceiveTray.getText().toString());
                postDataParams.put("dailyRate",mTxtDailyRate.getText().toString());
                postDataParams.put("receiveAmount",mEdtReceiveAmount.getText().toString());
              //  postDataParams.put("receiveSerial",mEdtReceiveSerial.getText().toString());
                postDataParams.put("tempoNo",tempo_Code);
                postDataParams.put("driverNo",driver_Code);
                postDataParams.put("challanNo",mEdtChallanNumber.getText().toString());
                postDataParams.put("entrySource","2");
                postDataParams.put("latitiude",CommonApi.lat);
                postDataParams.put("longitude",CommonApi.longs);
                postDataParams.put("createdById",CommonApi.createdById);
                postDataParams.put("lastModifiedById",CommonApi.lastModifiedById);
                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }


    //Call for Daily Rates
    public class CallDailyRatesApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";
        String farmer_Id;

        public CallDailyRatesApi(String farmerId) {
            this.farmer_Id = farmerId;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    if (data.equalsIgnoreCase("Receive Gavran")){
                         daily_rate=Float.parseFloat(CommonApi.rateGavran)-Float.parseFloat(objdata.getString("message_text"));
                        mTxtDailyRate.setText(daily_rate+"");

                    }
                    else if (data.equalsIgnoreCase("Receive Eggs")){
                        daily_rate=Float.parseFloat(CommonApi.rateEggs)-Float.parseFloat(objdata.getString("message_text"));
                        mTxtDailyRate.setText(daily_rate+"");
                    }
                    else if(data.equalsIgnoreCase("Receive Boiler")){
                        daily_rate=Float.parseFloat(CommonApi.rateBoiler)-Float.parseFloat(objdata.getString("message_text"));
                        mTxtDailyRate.setText(daily_rate+"");
                        /*JSONArray jsonArray = objdata.getJSONArray("message_text");
                        for (int i=0;i<jsonArray.length();i++){
                            if (data.equalsIgnoreCase("Receive Boiler")){
                                JSONObject jsonObj = jsonArray.getJSONObject(i);
                                 daily_rate=Float.parseFloat(CommonApi.rateBoiler)-Float.parseFloat(jsonObj.getString("boilerRate"));
                                mTxtDailyRate.setText(daily_rate+"");
                            }


                        }*/
                    }


                   // CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));



                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                String rate="";


                    if (data.equalsIgnoreCase("Receive Boiler")){
                        URL url= new URL("http://18.220.107.138/poultry2.2/api/poultry/get_dailyRate_boiler");
                        urlConnection = (HttpURLConnection) url.openConnection();
                    }
                    else if (data.equalsIgnoreCase("Receive Gavran")){
                        URL url= new URL("http://18.220.107.138/poultry2.2/api/poultry/get_dailyRate_gavran");
                        urlConnection = (HttpURLConnection) url.openConnection();
                    }
                    else if (data.equalsIgnoreCase("Receive Eggs")) {
                    URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/get_dailyRate_eggs");
                    urlConnection = (HttpURLConnection) url.openConnection();


                }




                JSONObject postDataParams = new JSONObject();
                postDataParams.put("farmerCode",farmer_Id);



                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Resultssss", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }

    //Validation for Boiler and Gavran
    private boolean validationEggs() {

        String rate=CommonApi.rateEggs;

        String farmercode=mTxtFarmerCode.getText().toString();
        String ratess=rate;
        String qty=mEdtReceiveQt.getText().toString();
        String tray=mEdtReceiveTray.getText().toString();
        String dailyrate=mTxtDailyRate.getText().toString();
        String amouts=mEdtReceiveAmount.getText().toString();
       // String serial=mEdtReceiveSerial.getText().toString();
        String Tempo=mTxtTempoNo.getText().toString();
        String driver=mTxtDriverNo.getText().toString();
        String chalan=mEdtChallanNumber.getText().toString();



        if (farmercode.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Farmer.");
        else if (ratess.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Paper Rate Not available.");
        else if (qty.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Eggs Quantity.");
        else if (tray.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Received Tray.");
        else if (dailyrate.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Daily Rate Not available.");
        else if (amouts.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Amount.");
       /* else if (serial.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Serial.");*/
        else if (Tempo.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Tempo Number.");
        else if (driver.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Driver Number.");
        else if (chalan.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Challan Number.");

        else
            return true;

        return false;
    }


    private boolean validation() {

        String rate="";
        if (data.equalsIgnoreCase("Receive Boiler")){
            rate=CommonApi.rateBoiler;
        }else if (data.equalsIgnoreCase("Receive Gavran")){
            rate=CommonApi.rateGavran;
        }
        String farmercode=mTxtFarmerCode.getText().toString();
        String ratess=rate;
        String Birds=mEdtReceiveBirds.getText().toString();
        String weight=mEdtBirdsWeight.getText().toString();
        String dailyrate=mTxtDailyRate.getText().toString();
        String amouts=mEdtReceiveAmount.getText().toString();
       // String serial=mEdtReceiveSerial.getText().toString();
        String Tempo=mTxtTempoNo.getText().toString();
        String driver=mTxtDriverNo.getText().toString();
        String chalan=mEdtChallanNumber.getText().toString();



        if (farmercode.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Farmer.");
        else if (ratess.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Paper Rate Not available.");
        else if (Birds.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Birds Quantity.");
        else if (weight.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Birds Weight.");
        else if (dailyrate.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Daily Rate Not available.");
        else if (amouts.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Amount.");
       /* else if (serial.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Serial.");*/
        else if (Tempo.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Tempo Number.");
        else if (driver.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Driver Number.");
        else if (chalan.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Challan Number.");

        else
            return true;

        return false;
    }

    /*
    Getting Current Location using GPSTracker
    */
    /*public void getLocation() {
        gps = new GPSTracker(this);
        // check if GPS enabled
        if (gps.canGetLocation()) {
            try {
                latitude = gps.getLatitude();
                longitude = gps.getLongitude();


             *//*   Geocoder geocoder;
                List<Address> addresses;
                geocoder = new Geocoder(this, Locale.getDefault());

                addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                Log.e("Adrrsssssssssss", "" + addresses);

                if (addresses != null) {
                    Address returnedAddress = addresses.get(0);
                    StringBuilder strReturnedAddress = new StringBuilder("");

                    for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                        strReturnedAddress.append(returnedAddress.getAddressLine(i)).append(",");
                    }
                    address = strReturnedAddress.toString().trim();

                    //  Log.w("My Current loction address", strReturnedAddress.toString());
                } else {
                    // Log.w("My Current loction address", "No Address returned!");
                }


                // String addres = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                String city = addresses.get(0).getLocality();
                String state = addresses.get(0).getAdminArea();
                String country = addresses.get(0).getCountryName();
                String postalCode = addresses.get(0).getPostalCode();
                String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL*//*

                Log.e("location", "Latitude:" + latitude + ", Longitude:" + longitude);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gps.showSettingsAlert();
        }
    }
    *//*
   check permission granted by user
   *//*
    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), ACCESS_FINE_LOCATION);
        return result == PackageManager.PERMISSION_GRANTED;
    }


    *//*
     Request Permission for android 6.0 >
     *//*
    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, PERMISSION_REQUEST_CODE);
    }*/
}
