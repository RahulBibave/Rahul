package com.rahul.poultry.Activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.rahul.poultry.Adapter.Adapter_Main_Menu;
import com.rahul.poultry.Data.CommonApi;
import com.rahul.poultry.Data.CommonUI;
import com.rahul.poultry.Data.Driver;
import com.rahul.poultry.Data.FarmerList;
import com.rahul.poultry.Data.GPSTracker;
import com.rahul.poultry.Data.Manu;
import com.rahul.poultry.Data.Shop;
import com.rahul.poultry.Data.Vehicle;
import com.rahul.poultry.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerViewManu;
    private Adapter_Main_Menu mAdapterMainMenu;
    private ArrayList<Manu>mManuArrayList;
    GPSTracker gps;
    private static final int REQUEST_CODE_PERMISSION = 1;
    String mPermission = Manifest.permission.ACCESS_FINE_LOCATION;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();

        if (CommonApi.isNetworkAvailable(MainActivity.this)) {
            CallFARMERCODEAPI callFARMERCODEAPI=new CallFARMERCODEAPI();
            callFARMERCODEAPI.execute();

        }else {
            CommonUI.showAlert(MainActivity.this,"Poultry",getString(R.string.network_error));

        }


        if(Build.VERSION.SDK_INT>= 23) {

            if (checkSelfPermission(mPermission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{mPermission,
                        },
                        REQUEST_CODE_PERMISSION);
                return;
            }


        }
        getLatLong();






       /* CalltempoCODEAPI calltempoCODEAPI=new CalltempoCODEAPI();
        calltempoCODEAPI.execute();*/

       /* CallDriverCodeAPI callDriverCodeAPI=new CallDriverCodeAPI();
        callDriverCodeAPI.execute();*/

       /* CallShopCodeAPI callShopCodeAPI=new CallShopCodeAPI();
        callShopCodeAPI.execute();*/

    }

    private void initViews() {
        mRecyclerViewManu=findViewById(R.id.recyclerViewManu);
        mRecyclerViewManu.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),3);
        mRecyclerViewManu.setLayoutManager(layoutManager);
        mManuArrayList=prepareData();
        mAdapterMainMenu=new Adapter_Main_Menu(mManuArrayList,MainActivity.this);
        mRecyclerViewManu.setAdapter(mAdapterMainMenu);
    }
    private void getLatLong() {
        gps = new GPSTracker(this,MainActivity.this);
        if (gps.canGetLocation()) {

            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();
            CommonApi.lat=latitude+"";
            CommonApi.longs=longitude+"";


        }
    }
    private ArrayList<Manu> prepareData(){
        mManuArrayList=new ArrayList<>();
        mManuArrayList.add(new Manu("Receive Boiler",R.drawable.ic_chicken));
        mManuArrayList.add(new Manu("Receive Gavran",R.drawable.ic_chekan_egg));
        mManuArrayList.add(new Manu("Receive Eggs",R.drawable.ic_eggs));
        mManuArrayList.add(new Manu("Issue Boiler",R.drawable.ic_chicken));
        mManuArrayList.add(new Manu("Issue Gavran",R.drawable.ic_chekan_egg));
        mManuArrayList.add(new Manu("Issue Eggs",R.drawable.ic_eggs));
        mManuArrayList.add(new Manu("Payment Collected",R.drawable.ic_receive_cash));
        mManuArrayList.add(new Manu(" Payment Issued",R.drawable.ic_hand_cash));

        return mManuArrayList;
    }



    //Call for Farmer List
    public class CallFARMERCODEAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            CallPaperRateAPI callPaperRateAPI=new CallPaperRateAPI();
            callPaperRateAPI.execute();
            // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase("")){

            }
                //showFarmerCodeAlertDialog();
            else
                CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForFarmer();
            return "DONE";

        }

        private void CallForFarmer() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_farmer_code_list" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    CommonApi.farmerList = new ArrayList<FarmerList>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        FarmerList farmerList = new FarmerList();
                        farmerList.setmFarmerCode(jsonObj.getString("farmerCode"));
                        farmerList.setmFarmerId(jsonObj.getString("farmerId"));
                        farmerList.setmFarmerName(jsonObj.getString("farmerName"));

                        CommonApi.farmerList.add(farmerList);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

   //Call for Paper_rate
    public class CallPaperRateAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            CalltempoCODEAPI calltempoCODEAPI=new CalltempoCODEAPI();
            calltempoCODEAPI.execute();
            // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase("")){

            }
            //showFarmerCodeAlertDialog();
            else
                CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForFarmer();
            return "DONE";

        }

        private void CallForFarmer() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_get_rates" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                   // CommonApi.farmerList = new ArrayList<FarmerList>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        CommonApi.rateBoiler=jsonObj.getString("rateBoiler");
                        CommonApi.rateEggs=jsonObj.getString("rateEggs");
                        CommonApi.rateGavran=jsonObj.getString("rateGavran");

                      /*  FarmerList farmerList = new FarmerList();
                        farmerList.setmFarmerCode(jsonObj.getString("farmerCode"));
                        farmerList.setmFarmerId(jsonObj.getString("farmerId"));*/


                       // CommonApi.farmerList.add(farmerList);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    //Call for Tempo List
    public class CalltempoCODEAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            CallDriverCodeAPI callDriverCodeAPI=new CallDriverCodeAPI();
            callDriverCodeAPI.execute();
            // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase("")){

            }
                //showTempoCodeAlertDialog();
            else
                CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForVehicle();
            return "DONE";

        }

        private void CallForVehicle() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_vehicle_no_list" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    CommonApi.vehicleArrayList = new ArrayList<Vehicle>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Vehicle vehicle = new Vehicle();
                        vehicle.setId(jsonObj.getString("id"));
                        vehicle.setVehicleNo(jsonObj.getString("vehicleNo"));
                        vehicle.setMakeModel(jsonObj.getString("makeModel"));

                        CommonApi.vehicleArrayList.add(vehicle);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    //Call for Driver List
    public class CallDriverCodeAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            CallShopCodeAPI callShopCodeAPI=new CallShopCodeAPI();
            callShopCodeAPI.execute();
            // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase("")){

            }
                //showDriverCodeAlertDialog();
            else
                CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForDriver();
            return "DONE";

        }

        private void CallForDriver() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_driver_list" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    CommonApi.driverArrayList = new ArrayList<Driver>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Driver driver = new Driver();
                        driver.setId(jsonObj.getString("id"));
                        driver.setDriverNo(jsonObj.getString("driverNo"));
                        driver.setDriverName(jsonObj.getString("driverName"));

                        CommonApi.driverArrayList.add(driver);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    //Call for Shop List
    public class CallShopCodeAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            // progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase("")){

            }
               // showFarmerCodeAlertDialog();
            else
                CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForShop();
            return "DONE";

        }

        private void CallForShop() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/poultry_shop_code_list" );

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    CommonApi.shopArrayList = new ArrayList<Shop>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Shop shop = new Shop();
                        shop.setId(jsonObj.getString("id"));
                        shop.setShopCode(jsonObj.getString("shopCode"));
                        shop.setShopName(jsonObj.getString("shopName"));

                        CommonApi.shopArrayList.add(shop);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(MainActivity.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }
}
