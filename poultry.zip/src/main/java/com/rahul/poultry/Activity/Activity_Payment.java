package com.rahul.poultry.Activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.rahul.poultry.Data.CommonApi;
import com.rahul.poultry.Data.CommonUI;
import com.rahul.poultry.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by rahul on 10/3/18.
 */

public class Activity_Payment extends AppCompatActivity implements View.OnClickListener{
    private TextView txtSignUpHeader;
    private TextView txtHeadShopcode;
    private LinearLayout linShopCode;
    private RelativeLayout rvShopCode;
    private TextView txtShopCode;
    private LinearLayout linFarmerCode;
    private RelativeLayout rvFarmerCode;
    private TextView txtFarmerCode;
    private TextView txtHeadIssueAmount,txtHeadFarmerCode;
    private LinearLayout linIssueAmount;
    private EditText txtissueAmount;
    private TextView txtHeadReceiveAmount;
    private LinearLayout linReceiveAmount;
    private EditText txtreceiveAmount;
    private EditText edtVescription;
    private RelativeLayout relativeButton;
    private String data,shopcode,farmer_Code;
    private boolean bFarmerList,bShopList;
    private ImageView mBtnBack;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        findViews();
        rvFarmerCode.setOnClickListener(this);
        rvShopCode.setOnClickListener(this);
        relativeButton.setOnClickListener(this);
        mBtnBack.setOnClickListener(this);


    }



    private void findViews() {
        data=getIntent().getExtras().getString("Payment","defaultKey");
        txtSignUpHeader = (TextView)findViewById( R.id.txt_SignUpHeader );
        txtHeadShopcode = (TextView)findViewById( R.id.txt_head_shopcode );
        linShopCode = (LinearLayout)findViewById( R.id.lin_ShopCode );
        rvShopCode = (RelativeLayout)findViewById( R.id.rv_ShopCode );
        mBtnBack=findViewById(R.id.imgBackArrow);
        txtShopCode = (TextView)findViewById( R.id.txtShopCode );
        linFarmerCode = (LinearLayout)findViewById( R.id.lin_FarmerCode );
        rvFarmerCode = (RelativeLayout)findViewById( R.id.rv_FarmerCode );
        txtFarmerCode = (TextView)findViewById( R.id.txtFarmerCode );
        txtHeadIssueAmount = (TextView)findViewById( R.id.txt_head_issueAmount );
        linIssueAmount = (LinearLayout)findViewById( R.id.lin_issueAmount );
        txtissueAmount = (EditText)findViewById( R.id.txtissueAmount );
        txtHeadReceiveAmount = (TextView)findViewById( R.id.txt_head_receiveAmount );
        linReceiveAmount = (LinearLayout)findViewById( R.id.lin_receiveAmount );
        txtreceiveAmount = (EditText)findViewById( R.id.txtreceiveAmount );
        edtVescription = (EditText)findViewById( R.id.edtVescription );
        relativeButton = (RelativeLayout)findViewById( R.id.relative_button );
        txtHeadFarmerCode=findViewById(R.id.txtHeadFarmerCode);
        txtSignUpHeader.setText(data);
        if (data.equalsIgnoreCase("Recive Payment")){
            txtHeadShopcode.setVisibility(View.GONE);
            linShopCode.setVisibility(View.GONE);
            txtHeadIssueAmount.setVisibility(View.GONE);
            linIssueAmount.setVisibility(View.GONE);

        }else if (data.equalsIgnoreCase("Issue Payment")){
            txtHeadFarmerCode.setVisibility(View.GONE);
            linFarmerCode.setVisibility(View.GONE);
            txtHeadReceiveAmount.setVisibility(View.GONE);
            linReceiveAmount.setVisibility(View.GONE);

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.rv_FarmerCode:

                if (bFarmerList==false){
                    if (CommonApi.farmerList == null || CommonApi.farmerList.size() <= 0){
                        bFarmerList=true;
                       // showFarmerCodeAlertDialog();
                        /*CallFARMERCODEAPI callFARMERCODEAPI=new CallFARMERCODEAPI();
                        callFARMERCODEAPI.execute();*/
                    }
                    else {
                        showFarmerCodeAlertDialog();
                    }

                }


                break;

            case R.id.rv_ShopCode:

                if (bShopList == false) {
                    if (CommonApi.farmerList == null || CommonApi.farmerList.size() <= 0) {
                        bShopList = true;

                        /*CallFARMERCODEAPI callFARMERCODEAPI=new CallFARMERCODEAPI();
                        callFARMERCODEAPI.execute();*/
                        //showShopCodeAlertDialog();
                    } else {
                        showShopCodeAlertDialog();
                    }

                }


                break;

            case R.id.relative_button:
               if (data.equalsIgnoreCase("Issue Payment")){
                   if (validationIssue()){
                       if (CommonApi.isNetworkAvailable(Activity_Payment.this)) {
                           CallPaymentIssueApi callPaymentIssueApi=new CallPaymentIssueApi(shopcode);
                           callPaymentIssueApi.execute();

                       }else {
                           CommonUI.showAlert(Activity_Payment.this,"Poultry",getString(R.string.network_error));

                       }

                   }

               }else if (data.equalsIgnoreCase("Recive Payment")){
                  if (validationReceive()){
                      if (CommonApi.isNetworkAvailable(Activity_Payment.this)) {
                          CallPaymentReceiveApi callPaymentApi=new CallPaymentReceiveApi(farmer_Code);
                          callPaymentApi.execute();;

                      }else {
                          CommonUI.showAlert(Activity_Payment.this,"Poultry",getString(R.string.network_error));

                      }

                  }
               }
                break;

            case R.id.imgBackArrow:
                onBackPressed();
                break;

        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    //Alert Dialog Shop Code
    private void showShopCodeAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Payment.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.farmer_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        EditText edtSearch=dialog.findViewById(R.id.edtSearch);
        final String search=edtSearch.getText().toString();
        tvtitle.setText("Select Farmer Code");

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bShopList = false;
            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Payment.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < CommonApi.shopArrayList.size(); i++) {
            choices.add(CommonApi.shopArrayList.get(i).getShopCode()+"-"+CommonApi.shopArrayList.get(i).getShopName());
            currencyAdapter.add(CommonApi.shopArrayList.get(i).getShopCode()+"-"+CommonApi.shopArrayList.get(i).getShopName());
            currencyAdapter.notifyDataSetChanged();
        }



        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Payment.this,
                R.layout.farmer_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                                txtShopCode.setText(CommonApi.shopArrayList.get(i).getShopCode()+"-"+CommonApi.shopArrayList.get(i).getShopName());
                                                shopcode=CommonApi.shopArrayList.get(i).getShopCode();
                                               /* iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);*/

                                                bShopList = false;
                                                dialog.dismiss();
                                            }
                                        }
        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    //Alert Dialog Farmer Code
    private void showFarmerCodeAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Payment.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.farmer_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        EditText edtSearch=dialog.findViewById(R.id.edtSearch);
        final String search=edtSearch.getText().toString();
        tvtitle.setText("Select Farmer Code");

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bFarmerList = false;
            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Payment.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < CommonApi.farmerList.size(); i++) {
            choices.add(CommonApi.farmerList.get(i).getmFarmerCode()+"-"+CommonApi.farmerList.get(i).getmFarmerName());
            currencyAdapter.add(CommonApi.farmerList.get(i).getmFarmerCode()+"-"+CommonApi.farmerList.get(i).getmFarmerName());
            currencyAdapter.notifyDataSetChanged();
        }


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Payment.this,
                R.layout.farmer_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                                txtFarmerCode.setText(CommonApi.farmerList.get(i).getmFarmerCode()+"-"+CommonApi.farmerList.get(i).getmFarmerName());
                                                farmer_Code=CommonApi.farmerList.get(i).getmFarmerCode();
                                                    /* iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);*/


                                                bFarmerList = false;
                                                dialog.dismiss();
                                            }
                                        }
        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    //Call for Post Payment
    public class CallPaymentReceiveApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";
        String codes;

        public CallPaymentReceiveApi(String code) {
            this.codes = code;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                    CommonUI.showAlert(Activity_Payment.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    txtFarmerCode.setText("");
                    txtreceiveAmount.setText("");
                    edtVescription.setText("");
                    txtShopCode.setText("");
                    txtissueAmount.setText("");


                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Payment.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {

                URL url = new URL("http://18.220.107.138/poultry2.2/api/payment/receive_payment");
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("farmerCode",codes);
                postDataParams.put("receiveAmount",txtreceiveAmount.getText().toString());
                postDataParams.put("description",edtVescription.getText().toString());
                postDataParams.put("createdById",CommonApi.createdById);
                postDataParams.put("lastModifiedById",CommonApi.lastModifiedById);


                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }

    //Call for Post Issued Payment
    public class CallPaymentIssueApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";
        String code;

        public CallPaymentIssueApi(String code) {
            this.code = code;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                    CommonUI.showAlert(Activity_Payment.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    txtFarmerCode.setText("");
                    txtreceiveAmount.setText("");
                    edtVescription.setText("");
                    txtShopCode.setText("");
                    txtissueAmount.setText("");


                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Payment.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {

                URL url = new URL("http://18.220.107.138/poultry2.2/api/payment/issue_payment");
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("shopCode",code);
                postDataParams.put("issueAmount",txtissueAmount.getText().toString());
                postDataParams.put("description",edtVescription.getText().toString());
                postDataParams.put("createdById",CommonApi.createdById);
                postDataParams.put("lastModifiedById",CommonApi.lastModifiedById);


                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }



    private boolean validationIssue() {

        String shopcode=txtShopCode.getText().toString();

        String desc=edtVescription.getText().toString();
        String amount=txtissueAmount.getText().toString().trim();




        if (shopcode.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Shop.");
        else if (amount.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter Issued Amount.");
        else if (desc.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Description.");

        else
            return true;

        return false;
    }

    private boolean validationReceive() {

        String farmercodess=txtFarmerCode.getText().toString();

        String desc=edtVescription.getText().toString().trim();
        String amount=txtreceiveAmount.getText().toString().trim();


        if (farmercodess.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Farmer.");
        else if (amount.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Enter Receive Amount.");
        else if (desc.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Description.");

        else
            return true;

        return false;
    }

}
