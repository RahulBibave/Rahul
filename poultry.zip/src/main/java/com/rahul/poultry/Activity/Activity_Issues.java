package com.rahul.poultry.Activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.rahul.poultry.Data.CommonApi;
import com.rahul.poultry.Data.CommonUI;
import com.rahul.poultry.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by rahul on 10/3/18.
 */

public class Activity_Issues extends AppCompatActivity implements View.OnClickListener {
    private TextView mToolbarName;
    private String data;
    private RelativeLayout rv_ShopCode, mLinTempoNo, mLinDriverNo;
    private boolean bShopList,bTempoList,bDriverList;
    float daily_rate = 0;
    float x;
    float amount;
    private TextView mTxtShopCode,mTxtPaperRate,mTxtTempoNo,mTxtDriverNo,mTxtDailyRate;
    private TextView txtHeadRece, txtHeadWt, txtHeadQt, txtHeadTray;
    private LinearLayout linRec, linWt, linQt, linTray;
    private EditText mEdtIssueBirds,mEdtBirdsWeight,mEdtIssueTray,mEdtIssueQt;
    private TextView mTxtIssueAmount;
    String shopCode,tempoCode,driverCode;
    private RelativeLayout mBtnSubmit;
    private TextView txt_head_Tray_ssued,txt_head_Tray_Receive;
    private LinearLayout lin_TrayReceive,lin_Tray_Issued;
    private EditText mEdtTrayIssued,mEdtTrayReceive;
    private ImageView mBtnBack;



    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_issues);
        initViews();
        ontouchListner();
        mEdtBirdsWeight.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                if (s.length() != 0)
                    x = Float.parseFloat(mEdtBirdsWeight.getText().toString());
                amount = daily_rate * x;
                mTxtIssueAmount.setText(amount + "");
                if (mEdtBirdsWeight.getText().toString() == null) {
                    mTxtIssueAmount.setText("");
                }
            }
        });

        mEdtIssueQt.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                if (s.length() != 0)
                    x = Integer.parseInt(mEdtIssueQt.getText().toString());
                amount = daily_rate * x;
                mTxtIssueAmount.setText(amount + "");
                if (mEdtIssueQt.getText().toString() == null) {
                    mTxtIssueAmount.setText("");
                }
            }
        });

    }

    private void initViews() {

        data=getIntent().getExtras().getString("Issue","defaultKey");
        mToolbarName=findViewById(R.id.txt_tool_Header);
        mToolbarName.setText(data);
        rv_ShopCode=findViewById(R.id.rv_ShopCode);
        mTxtShopCode=findViewById(R.id.txtShopCode);
        mTxtPaperRate=findViewById(R.id.txtPaperRate);
        mTxtTempoNo=findViewById(R.id.txtTempoNumber);
        mTxtDriverNo=findViewById(R.id.txtDriverNumber);
        mTxtDailyRate=findViewById(R.id.txtDailyRate);
        mLinTempoNo=findViewById(R.id.lin_TempoNo);
        mLinDriverNo=findViewById(R.id.lin_driver_no);
        mBtnSubmit=findViewById(R.id.relative_button);
        mEdtTrayIssued=findViewById(R.id.edtTrayIssued);
        mEdtTrayReceive=findViewById(R.id.edtTrayReceive);
        mBtnBack=findViewById(R.id.imgBackArrow);

        mEdtIssueBirds=findViewById(R.id.txtIssueBirds);
        mEdtBirdsWeight=findViewById(R.id.txtIssueBirdsWeight);
        mTxtIssueAmount=findViewById(R.id.txtIssueAmount);
        lin_Tray_Issued=findViewById(R.id.lin_Tray_Issued);
        lin_TrayReceive=findViewById(R.id.lin_TrayReceive);
        txt_head_Tray_ssued=findViewById(R.id.txt_head_Tray_ssued);
        txt_head_Tray_Receive=findViewById(R.id.txt_head_Tray_Receive);

        mEdtIssueTray=findViewById(R.id.edtIssueTray);
        mEdtIssueQt=findViewById(R.id.edtIssueQt);

        linRec=findViewById(R.id.lin_rece_birds);
        txtHeadRece=findViewById(R.id.txt_head_rece_birds);
        linWt=findViewById(R.id.lin_wt);
        txtHeadWt=findViewById(R.id.txt_head_wt);
        txtHeadQt=findViewById(R.id.txt_head_Qntity);
        linQt=findViewById(R.id.lin_Qt);
        txtHeadTray=findViewById(R.id.txt_head_tray);
        linTray=findViewById(R.id.lin_tray);
        if (data.equalsIgnoreCase("Issue Gavran")){
            mTxtPaperRate.setText(CommonApi.rateGavran);
        }
        else if (data.equalsIgnoreCase("Issue Boiler")){
            mTxtPaperRate.setText(CommonApi.rateBoiler);
        }
        else if (data.equalsIgnoreCase("Issue Eggs")){
            mTxtPaperRate.setText(CommonApi.rateEggs);
        }

        if (data.equalsIgnoreCase("Issue Gavran")||data.equalsIgnoreCase("Issue Boiler")){
           /* linRec.setVisibility(View.VISIBLE);
            txtHeadRece.setVisibility(View.VISIBLE);*/
            linQt.setVisibility(View.GONE);
            txtHeadQt.setVisibility(View.GONE);
            txtHeadTray.setVisibility(View.GONE);
            linTray.setVisibility(View.GONE);
            txt_head_Tray_ssued.setVisibility(View.GONE);
            txt_head_Tray_Receive.setVisibility(View.GONE);
            lin_Tray_Issued.setVisibility(View.GONE);
            lin_TrayReceive.setVisibility(View.GONE);

        }else if (data.equalsIgnoreCase("Issue Eggs")){
            linRec.setVisibility(View.GONE);
            txtHeadRece.setVisibility(View.GONE);
            linWt.setVisibility(View.GONE);
            txtHeadWt.setVisibility(View.GONE);

        }
    }

    private void ontouchListner() {
        rv_ShopCode.setOnClickListener(this);
        mLinTempoNo.setOnClickListener(this);
        mLinDriverNo.setOnClickListener(this);
        mBtnSubmit.setOnClickListener(this);
        mBtnBack.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.rv_ShopCode:
                mEdtBirdsWeight.setText("");
                mTxtIssueAmount.setText("");
                mEdtIssueQt.setText("");
                if (bShopList == false) {
                    if (CommonApi.farmerList == null || CommonApi.farmerList.size() <= 0) {
                        bShopList = true;

                        /*CallFARMERCODEAPI callFARMERCODEAPI=new CallFARMERCODEAPI();
                        callFARMERCODEAPI.execute();*/
                        //showShopCodeAlertDialog();
                    } else {
                        showShopCodeAlertDialog();
                    }

                }


                break;
            case R.id.lin_TempoNo:
                if (bTempoList==false){
                    if (CommonApi.vehicleArrayList==null||CommonApi.vehicleArrayList.size()<=0){
                        bTempoList=true;
                       // showTempoCodeAlertDialog();
                       /* CalltempoCODEAPI calltempoCODEAPI=new CalltempoCODEAPI();
                        calltempoCODEAPI.execute();*/
                    }
                    else {
                        showTempoCodeAlertDialog();
                    }
                }

                break;

            case R.id.lin_driver_no:
                if (bDriverList==false){
                    if (CommonApi.driverArrayList==null||CommonApi.driverArrayList.size()<=0){
                        bDriverList=true;
                       /* CallDriverCodeAPI callDriverCodeAPI=new CallDriverCodeAPI();
                        callDriverCodeAPI.execute();*/
                      //  showDriverCodeAlertDialog();

                    }
                    else {
                        showDriverCodeAlertDialog();
                    }
                }

                break;

            case R.id.relative_button:
                if (data.equalsIgnoreCase("Issue Boiler")||data.equalsIgnoreCase("Issue Gavran")){
                    if (validation()){
                        if (validationEggs()){
                            if (CommonApi.isNetworkAvailable(Activity_Issues.this)) {
                                CallIssueBoilerApi callIssueBoilerApi=new CallIssueBoilerApi(shopCode,tempoCode,driverCode);
                                callIssueBoilerApi.execute();

                            }else {
                                CommonUI.showAlert(Activity_Issues.this,"Poultry",getString(R.string.network_error));

                            }

                        }

                    }

                }
                else if (data.equalsIgnoreCase("Issue Eggs")){
                    if (validationEggs()){
                        if (CommonApi.isNetworkAvailable(Activity_Issues.this)) {
                            CallIssueEggsApi callIssueEggsApi=new CallIssueEggsApi(shopCode,tempoCode,driverCode);
                            callIssueEggsApi.execute();

                        }else {
                            CommonUI.showAlert(Activity_Issues.this,"Poultry",getString(R.string.network_error));

                        }

                    }

                }
                break;

            case R.id.imgBackArrow:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    //Alert Dialog Shop Code
    private void showShopCodeAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Issues.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.farmer_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        EditText edtSearch=dialog.findViewById(R.id.edtSearch);
        final String search=edtSearch.getText().toString();
        tvtitle.setText("Select Farmer Code");

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bShopList = false;
            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Issues.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < CommonApi.shopArrayList.size(); i++) {
            choices.add(CommonApi.shopArrayList.get(i).getShopCode()+"-"+CommonApi.shopArrayList.get(i).getShopName());
            currencyAdapter.add(CommonApi.shopArrayList.get(i).getShopCode()+"-"+CommonApi.shopArrayList.get(i).getShopName());
            currencyAdapter.notifyDataSetChanged();
        }



        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Issues.this,
                R.layout.farmer_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                                mTxtShopCode.setText(CommonApi.shopArrayList.get(i).getShopCode()+"-"+CommonApi.shopArrayList.get(i).getShopName());
                                               shopCode=CommonApi.shopArrayList.get(i).getShopCode();
                                               /* iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);*/
                                                if (CommonApi.isNetworkAvailable(Activity_Issues.this)) {
                                                    CallDailyRatesApi callDailyRatesApi=new CallDailyRatesApi(CommonApi.shopArrayList.get(i).getId());
                                                    callDailyRatesApi.execute();

                                                }else {
                                                    CommonUI.showAlert(Activity_Issues.this,"Poultry",getString(R.string.network_error));

                                                }

                                                bShopList = false;
                                                dialog.dismiss();
                                            }
                                        }
        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    //Alert Dialog Tempo Number
    private void showTempoCodeAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Issues.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.farmer_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        EditText edtSearch=dialog.findViewById(R.id.edtSearch);
        final String search=edtSearch.getText().toString();
        tvtitle.setText("Select Tempo Number");

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bTempoList = false;
            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Issues.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < CommonApi.vehicleArrayList.size(); i++) {
            choices.add(CommonApi.vehicleArrayList.get(i).getVehicleNo()+"-"+CommonApi.vehicleArrayList.get(i).getMakeModel());
            currencyAdapter.add(CommonApi.vehicleArrayList.get(i).getVehicleNo()+"-"+CommonApi.vehicleArrayList.get(i).getMakeModel());
            currencyAdapter.notifyDataSetChanged();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Issues.this,
                R.layout.farmer_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                mTxtTempoNo.setText(CommonApi.vehicleArrayList.get(i).getVehicleNo()+"-"+CommonApi.vehicleArrayList.get(i).getMakeModel());
                                               tempoCode=CommonApi.vehicleArrayList.get(i).getId();
                                                /* iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);*/
                                                bTempoList = false;
                                                dialog.dismiss();
                                            }
                                        }
        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    //Alert Dialog Driver Number
    private void showDriverCodeAlertDialog() {
        final Dialog dialog = new Dialog(Activity_Issues.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.farmer_alert_dialog);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        EditText edtSearch=dialog.findViewById(R.id.edtSearch);
        final String search=edtSearch.getText().toString();
        tvtitle.setText("Select Driver Number");

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bDriverList = false;
            }
        });


        final ArrayList<String> choices = new ArrayList<>();

        final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Issues.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < CommonApi.driverArrayList.size(); i++) {
            choices.add(CommonApi.driverArrayList.get(i).getDriverNo()+"-"+CommonApi.driverArrayList.get(i).getDriverName());
            currencyAdapter.add(CommonApi.driverArrayList.get(i).getDriverNo()+"-"+CommonApi.driverArrayList.get(i).getDriverName());
            currencyAdapter.notifyDataSetChanged();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Issues.this,
                R.layout.farmer_list, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                mTxtDriverNo.setText(CommonApi.driverArrayList.get(i).getDriverNo()+"-"+CommonApi.driverArrayList.get(i).getDriverName());
                                                driverCode=CommonApi.driverArrayList.get(i).getId();
                                               /* iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);*/
                                                bDriverList = false;
                                                dialog.dismiss();
                                            }
                                        }
        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }




    //Call for Daily Rates
    public class CallDailyRatesApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";
        String shop_id;

        public CallDailyRatesApi(String shopid) {
            this.shop_id = shopid;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Responeee ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    if (data.equalsIgnoreCase("Issue Gavran")){
                        daily_rate=Integer.parseInt(CommonApi.rateGavran)-Integer.parseInt(objdata.getString("message_text"));
                        mTxtDailyRate.setText(daily_rate+"");

                    }
                    else if (data.equalsIgnoreCase("Issue Eggs")){
                        daily_rate=Integer.parseInt(CommonApi.rateEggs)-Integer.parseInt(objdata.getString("message_text"));
                        mTxtDailyRate.setText(daily_rate+"");
                    }
                    else if(data.equalsIgnoreCase("Issue Boiler")){
                        daily_rate=Integer.parseInt(CommonApi.rateEggs)-Integer.parseInt(objdata.getString("message_text"));
                        mTxtDailyRate.setText(daily_rate+"");
                       /* JSONArray jsonArray = objdata.getJSONArray("message_text");
                        for (int i=0;i<jsonArray.length();i++){
                            if (data.equalsIgnoreCase("Receive Boiler")){
                                JSONObject jsonObj = jsonArray.getJSONObject(i);
                                daily_rate=Integer.parseInt(CommonApi.rateBoiler)-Integer.parseInt(jsonObj.getString("boilerRate"));
                                mTxtDailyRate.setText(daily_rate+"");
                            }


                        }*/
                    }


                    // CommonUI.showAlert(Activity_Receive_boiler.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));



                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Issues.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("eeError:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                String rate="";


                if (data.equalsIgnoreCase("Issue Boiler")){
                    URL url= new URL("http://18.220.107.138/poultry2.2/api/poultry/get_issueDailyRate_allChickhen");
                    urlConnection = (HttpURLConnection) url.openConnection();
                }
                else if (data.equalsIgnoreCase("Issue Gavran")){
                    URL url= new URL("http://18.220.107.138/poultry2.2/api/poultry/get_issueDailyRate_allChickhen");
                    urlConnection = (HttpURLConnection) url.openConnection();
                }
                else if (data.equalsIgnoreCase("Issue Eggs")) {
                    URL url = new URL("http://18.220.107.138/poultry2.2/api/poultry/get_issueDailyRate_eggs");
                    urlConnection = (HttpURLConnection) url.openConnection();

                }


                JSONObject postDataParams = new JSONObject();
                postDataParams.put("shopId",shop_id);

                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }


    //Call for Post Issue Boiler and Gavran
    public class CallIssueBoilerApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";
        String shop_code,tempo_code,driver_code;

        public CallIssueBoilerApi(String shop_code, String tempo_code, String driver_code) {
            this.shop_code = shop_code;
            this.tempo_code = tempo_code;
            this.driver_code = driver_code;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    mTxtIssueAmount.setText("");
                    mTxtShopCode.setText("");
                    mEdtBirdsWeight.setText("");
                    mEdtIssueQt.setText("");
                    mEdtIssueBirds.setText("");
                    mEdtTrayReceive.setText("");
                    mTxtTempoNo.setText("");
                    mTxtDriverNo.setText("");
                    mTxtDailyRate.setText("");
                    mTxtIssueAmount.setText("");


                    CommonUI.showAlert(Activity_Issues.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));



                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Issues.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                String rate="";
                if (data.equalsIgnoreCase("Issue Boiler")){
                    URL url= new URL("http://18.220.107.138/poultry2.2/api/issue/issue_boiler_chicken");
                    urlConnection = (HttpURLConnection) url.openConnection();
                    rate=CommonApi.rateBoiler;
                }else if (data.equalsIgnoreCase("Issue Gavran")){
                    URL url= new URL("http://18.220.107.138/poultry2.2/api/issue/issue_boiler_chicken");
                    urlConnection = (HttpURLConnection) url.openConnection();
                    rate=CommonApi.rateGavran;
                }


                JSONObject postDataParams = new JSONObject();
                postDataParams.put("shopCode",shop_code);
                postDataParams.put("paperRate",rate);
                postDataParams.put("issueBirds",mEdtIssueBirds.getText().toString());
                postDataParams.put("birdsWeight",mEdtBirdsWeight.getText().toString());
                postDataParams.put("dailyRate",mTxtDailyRate.getText().toString());
                postDataParams.put("issueAmount",mTxtIssueAmount.getText().toString());
                   // postDataParams.put("receiveSerial","2243");
                postDataParams.put("tempoNo",tempo_code);
                postDataParams.put("driverNo",driver_code);
                postDataParams.put("entrySource","2");
                postDataParams.put("latitiude",CommonApi.lat);
                postDataParams.put("longitude",CommonApi.longs);
                postDataParams.put("createdById",CommonApi.createdById);
                postDataParams.put("lastModifiedById",CommonApi.lastModifiedById);


                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }

    //Call for Post Issue Eggs
    public class CallIssueEggsApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";
        String shop_code,tempo_code,driver_code;

        public CallIssueEggsApi(String shop_code, String tempo_code, String driver_code) {
            this.shop_code = shop_code;
            this.tempo_code = tempo_code;
            this.driver_code = driver_code;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    CommonUI.showAlert(Activity_Issues.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    mTxtShopCode.setText("");
                    mEdtBirdsWeight.setText("");
                    mEdtIssueQt.setText("");
                    mEdtIssueBirds.setText("");
                    mEdtTrayReceive.setText("");
                    mTxtTempoNo.setText("");
                    mTxtDriverNo.setText("");
                    mTxtDailyRate.setText("");
                    mTxtIssueAmount.setText("");
                    mEdtTrayIssued.setText("");
                    mEdtIssueTray.setText("");



                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Issues.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {

                URL url = new URL("http://18.220.107.138/poultry2.2/api/issue/issue_eggs");
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("shopCode",shop_code);
                postDataParams.put("paperRate",CommonApi.rateEggs);
                postDataParams.put("issueQty",mEdtIssueQt.getText().toString());
                postDataParams.put("issueTray",mEdtIssueTray.getText().toString());
                postDataParams.put("dailyRate",mTxtDailyRate.getText().toString());
                postDataParams.put("issueAmount",mTxtIssueAmount.getText().toString());
                //  postDataParams.put("receiveSerial",mEdtReceiveSerial.getText().toString());
                postDataParams.put("tempoNo",tempo_code);
                postDataParams.put("driverNo",driver_code);
               // postDataParams.put("challanNo",mEdtChallanNumber.getText().toString());
                postDataParams.put("trayIssue",mEdtTrayIssued.getText().toString());
                postDataParams.put("trayReceive",mEdtTrayReceive.getText().toString());
                postDataParams.put("entrySource","2");
                postDataParams.put("latitiude",CommonApi.lat);
                postDataParams.put("longitude",CommonApi.longs);
                postDataParams.put("createdById",CommonApi.createdById);
                postDataParams.put("lastModifiedById",CommonApi.lastModifiedById);
                Log.e("lllllaaat",""+CommonApi.lat+"---"+CommonApi.longs);


                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }




    //Validation for Boiler and Gavran
    private boolean validationEggs() {

        String rate=CommonApi.rateEggs;

        String farmercode=mTxtShopCode.getText().toString();
        String ratess=rate;
        String qty=mEdtIssueQt.getText().toString();
        String tray=mEdtIssueTray.getText().toString();
        String dailyrate=mTxtDailyRate.getText().toString();
        String amouts=mTxtIssueAmount.getText().toString();
        // String serial=mEdtReceiveSerial.getText().toString();
        String Tempo=mTxtTempoNo.getText().toString();
        String driver=mTxtDriverNo.getText().toString();




        if (farmercode.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Shop.");
        else if (ratess.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Paper Rate Not available.");
        else if (qty.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Eggs Quantity.");
        else if (tray.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Issued Tray.");
        else if (dailyrate.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Daily Rate Not available.");
        else if (amouts.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Amount.");
       /* else if (serial.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Serial.");*/
        else if (Tempo.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Tempo Number.");
        else if (driver.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Driver Number.");

        else
            return true;

        return false;
    }


    private boolean validation() {

        String rate="";
        if (data.equalsIgnoreCase("Issue Boiler")){
            rate=CommonApi.rateBoiler;
        }else if (data.equalsIgnoreCase("Issue Gavran")){
            rate=CommonApi.rateGavran;
        }
        String farmercode=mTxtShopCode.getText().toString();
        String ratess=rate;
        String Birds=mEdtIssueBirds.getText().toString();
        String weight=mEdtBirdsWeight.getText().toString();
        String dailyrate=mTxtDailyRate.getText().toString();
        String amouts=mTxtIssueAmount.getText().toString();
        // String serial=mEdtReceiveSerial.getText().toString();
        String Tempo=mTxtTempoNo.getText().toString();
        String driver=mTxtDriverNo.getText().toString();

        if (farmercode.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Farmer.");
        else if (ratess.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Paper Rate Not available.");
        else if (Birds.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Birds Quantity.");
        else if (weight.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Birds Weight.");
        else if (dailyrate.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Daily Rate Not available.");
        else if (amouts.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Amount.");
       /* else if (serial.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Serial.");*/
        else if (Tempo.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Tempo Number.");
        else if (driver.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please Select Driver Number.");

        else
            return true;

        return false;
    }
}
