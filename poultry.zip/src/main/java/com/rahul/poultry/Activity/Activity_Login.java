package com.rahul.poultry.Activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.rahul.poultry.Data.CommonApi;
import com.rahul.poultry.Data.CommonUI;
import com.rahul.poultry.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by rahul on 9/3/18.
 */

public class Activity_Login extends AppCompatActivity {
    private EditText mEdtMobileNo,mEdtPassword;
    private Button mBtnLogin;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()){
                    if (CommonApi.isNetworkAvailable(Activity_Login.this)) {
                        CallLoginApi callLoginApi=new CallLoginApi();
                        callLoginApi.execute();
                    }else {
                        CommonUI.showAlert(Activity_Login.this,"Poultry",getString(R.string.network_error));

                    }

                }

            }
        });
    }

    private boolean validation() {
        String sUserName = mEdtMobileNo.getText().toString();
        String sUserPassword = mEdtPassword.getText().toString();
        if (sUserName.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter mobile number.");
        else if (sUserPassword.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter password.");

        else
            return true;

        return false;
    }

    private void init() {
        mEdtMobileNo=findViewById(R.id.edtMobile);
        mEdtPassword=findViewById(R.id.edtPassword);
        mBtnLogin=findViewById(R.id.btnLogin);
    }



    public class CallLoginApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // pd_login.setMessage("Loading...");
            // pd_login.setCancelable(false);
            // pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //  if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    JSONArray jsonArray = objdata.getJSONArray("message_text");
                    for (int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObj = jsonArray.getJSONObject(i);
                           CommonApi.createdById=jsonObj.getString("createdById");
                           CommonApi.lastModifiedById=jsonObj.getString("lastModifiedById");

                    }
                    Intent intent=new Intent(Activity_Login.this,MainActivity.class);
                    startActivity(intent);
                    finish();


                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_Login.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
            }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {

                URL url = new URL("http://18.220.107.138/poultry2.2/api/user/login_user");
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("userMobileNo",mEdtMobileNo.getText().toString().trim());
                postDataParams.put("userPin",mEdtPassword.getText().toString().trim());
                postDataParams.put("userRoleId","1");
                urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(CommonApi.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }
            return null;
        }
    }

}
