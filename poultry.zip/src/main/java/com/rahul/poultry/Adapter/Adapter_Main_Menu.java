package com.rahul.poultry.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.rahul.poultry.Activity.Activity_Issues;
import com.rahul.poultry.Activity.Activity_Payment;
import com.rahul.poultry.Activity.Activity_Receive_boiler;
import com.rahul.poultry.Data.Manu;
import com.rahul.poultry.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by rahul on 9/3/18.
 */

public class Adapter_Main_Menu extends RecyclerView.Adapter<Adapter_Main_Menu.ViewHolder> {
   private ArrayList<Manu>mArrayList;
   private Context mContext;

    public Adapter_Main_Menu(ArrayList<Manu> mArrayList, Context mContext) {
        this.mArrayList = mArrayList;
        this.mContext = mContext;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.lay_manu_view,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Manu manu=mArrayList.get(position);
        holder.mTextManuName.setText(manu.getmName());
        holder.mManuImg.setImageResource(manu.getmImage());
      //  Picasso.with(mContext).load(manu.getmImage()).into(holder.mManuImg);
        holder.mManuImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position==1||position==2||position==0){
                    Intent intent_re=new Intent(mContext, Activity_Receive_boiler.class);
                    if (position==0){
                        intent_re.putExtra("Recevied","Receive Boiler");
                    }
                    else if (position==1){
                        intent_re.putExtra("Recevied","Receive Gavran");
                    }
                    else if (position==2){
                        intent_re.putExtra("Recevied","Receive Eggs");
                    }
                    mContext.startActivity(intent_re);
                }else if (position==3||position==4||position==5){
                    Intent intent_issue=new Intent(mContext, Activity_Issues.class);
                    if (position==3){
                        intent_issue.putExtra("Issue","Issue Boiler");
                    }else if (position==4){
                        intent_issue.putExtra("Issue","Issue Gavran");
                    }else if (position==5){
                        intent_issue.putExtra("Issue","Issue Eggs");
                    }
                    mContext.startActivity(intent_issue);
                }else if (position==6||position==7){
                    Intent intent=new Intent(mContext, Activity_Payment.class);
                    if (position==6){
                        intent.putExtra("Payment","Recive Payment");
                    }
                    else if (position==7){
                        intent.putExtra("Payment","Issue Payment");
                    }
                    mContext.startActivity(intent);
                }

            }
        });


    }

    @Override
    public int getItemCount() {
        return mArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mManuImg;
        TextView mTextManuName;
        public ViewHolder(View itemView) {
            super(itemView);
            mManuImg=itemView.findViewById(R.id.imgManuImg);
            mTextManuName=itemView.findViewById(R.id.txtManuName);
        }
    }
}
