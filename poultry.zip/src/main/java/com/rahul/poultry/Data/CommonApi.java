package com.rahul.poultry.Data;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by rahul on 10/3/18.
 */

public class CommonApi {
    public final static String METHOD_GET = "GET";
    public final static String METHOD_POST = "POST";
    public static ArrayList<FarmerList>farmerList;
    public static ArrayList<Vehicle>vehicleArrayList;
    public static ArrayList<Driver>driverArrayList;
    public static ArrayList<Shop>shopArrayList;
    public static String rateEggs = "";
    public static String rateBoiler = "";
    public static String rateGavran = "";
    public static String createdById="";
    public static String lastModifiedById="";
    public static String lat="";
    public static String longs="";



    public static String getPostDataString(JSONObject params) throws Exception {

        StringBuilder result = new StringBuilder();
        boolean first = true;

        Iterator<String> itr = params.keys();

        while(itr.hasNext()){

            String key= itr.next();
            Object value = params.get(key);

            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(key, "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(value.toString(), "UTF-8"));

        }
        return result.toString();
    }



    public static boolean isNetworkAvailable(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected())
                return true;
        } catch (Exception | Error e) {
            e.printStackTrace();
        }
        return false;
    }

}
