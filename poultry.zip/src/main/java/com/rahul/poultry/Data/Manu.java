package com.rahul.poultry.Data;

import java.io.Serializable;

/**
 * Created by rahul on 9/3/18.
 */

public class Manu implements Serializable {
    private String mName;
    private int mImage;

    public Manu(String mName, int mImage) {
        this.mName = mName;
        this.mImage = mImage;
    }

    public String getmName() {
        return this.mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public int getmImage() {
        return this.mImage;
    }

    public void setmImage(int mImage) {
        this.mImage = mImage;
    }
}
