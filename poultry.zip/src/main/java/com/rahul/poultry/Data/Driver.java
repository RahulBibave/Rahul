package com.rahul.poultry.Data;

import java.io.Serializable;

/**
 * Created by rahul on 10/3/18.
 */

public class Driver implements Serializable {
    private String id;
    private String driverNo;
    private String driverName;

    public Driver() {
    }

    public Driver(String id, String driverNo, String driverName) {
        this.id = id;
        this.driverNo = driverNo;
        this.driverName = driverName;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDriverNo() {
        return this.driverNo;
    }

    public void setDriverNo(String driverNo) {
        this.driverNo = driverNo;
    }

    public String getDriverName() {
        return this.driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }
}
