package com.rahul.poultry.Data;

import java.io.Serializable;

/**
 * Created by rahul on 10/3/18.
 */

public class FarmerList implements Serializable {
    private String mFarmerId;
    private String mFarmerCode;
    private String mFarmerName;

    public FarmerList() {
    }

    public FarmerList(String mFarmerId, String mFarmerCode, String mFarmerName) {
        this.mFarmerId = mFarmerId;
        this.mFarmerCode = mFarmerCode;
        this.mFarmerName = mFarmerName;
    }

    public String getmFarmerId() {
        return this.mFarmerId;
    }

    public void setmFarmerId(String mFarmerId) {
        this.mFarmerId = mFarmerId;
    }

    public String getmFarmerCode() {
        return this.mFarmerCode;
    }

    public void setmFarmerCode(String mFarmerCode) {
        this.mFarmerCode = mFarmerCode;
    }

    public String getmFarmerName() {
        return this.mFarmerName;
    }

    public void setmFarmerName(String mFarmerName) {
        this.mFarmerName = mFarmerName;
    }
}
