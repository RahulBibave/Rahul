package com.rahul.poultry.Data;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;

import com.rahul.poultry.R;

/**
 * Created by rahul on 10/3/18.
 */

public class CommonUI {
    public static void showAlert(Context mycontext, String title, String message) {
        new AlertDialog.Builder(mycontext)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                    }
                })
//
                .show();
    }
}
