package com.rahul.poultry.Data;

import java.io.Serializable;

/**
 * Created by rahul on 10/3/18.
 */

public class Vehicle implements Serializable {
    private String vehicleNo;
    private String id;
    private String makeModel;

    public Vehicle() {
    }

    public Vehicle(String vehicleNo, String id, String makeModel) {
        this.vehicleNo = vehicleNo;
        this.id = id;
        this.makeModel = makeModel;
    }

    public String getMakeModel() {
        return this.makeModel;
    }

    public void setMakeModel(String makeModel) {
        this.makeModel = makeModel;
    }

    public String getVehicleNo() {
        return this.vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
