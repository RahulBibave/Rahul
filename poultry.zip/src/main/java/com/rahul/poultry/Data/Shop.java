package com.rahul.poultry.Data;

import java.io.Serializable;

/**
 * Created by rahul on 10/3/18.
 */

public class Shop implements Serializable {
    private String id;
    private String shopCode;
    private String shopName;

    public Shop() {
    }

    public Shop(String id, String shopCode, String shopName) {
        this.id = id;
        this.shopCode = shopCode;
        this.shopName = shopName;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getShopCode() {
        return this.shopCode;
    }

    public void setShopCode(String shopCode) {
        this.shopCode = shopCode;
    }

    public String getShopName() {
        return this.shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }
}
