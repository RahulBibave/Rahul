package com.rahul.applinktest;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.util.PatternsCompat;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by rahul on 3/8/17.
 */

public class FragmentPersonForm extends Fragment {
    private EditText mEdtName,mEdtPhone,mEdtEmail,mEdtAdd,mEdtCity;
    private Button mBtnSave,mBtnView;
    private DatabaseHelper db;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.lay_personinfo,container,false);

        mEdtName=view.findViewById(R.id.edtName);
        mEdtPhone=view.findViewById(R.id.edtPhoneNo);
        mEdtEmail=view.findViewById(R.id.edtEmail);
        mEdtAdd=view.findViewById(R.id.edtAdd);
        mEdtCity=view.findViewById(R.id.edtCity);

        mBtnSave=view.findViewById(R.id.btnSave);
        mBtnView=view.findViewById(R.id.btnView);

        db=new DatabaseHelper(getContext());


        mBtnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validate()){
                    Toast.makeText(getActivity(), "Data not inserted", Toast.LENGTH_SHORT).show();
                }
                else {
                    boolean result=db.insertData(mEdtName.getText().toString(),mEdtPhone.getText().toString(),mEdtEmail.getText().toString().toString(),
                            mEdtAdd.getText().toString(),mEdtCity.getText().toString());

                    if (result=true) {
                        Toast.makeText(getActivity(), "Data inserted", Toast.LENGTH_SHORT).show();

                    }
                    else {
                        Toast.makeText(getActivity(), "Data not Inserted", Toast.LENGTH_SHORT).show();
                    }


                }
            }
        });
        mBtnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res=db.getAllData();
                if (res.getCount()==0){
                    showMassage("Error","No Data Found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while (res.moveToNext()){
                  //  buffer.append("ID :"+res.getString(0)+"\n");
                    buffer.append("Name :"+res.getString(1)+"\n");
                    buffer.append("Phone :"+res.getString(2)+"\n");
                    buffer.append("Email :"+res.getString(3)+"\n");
                    buffer.append("Add :"+res.getString(4)+"\n");
                    buffer.append("City :"+res.getString(5)+"\n");
                    buffer.append("\n\n");

                }
                showMassage("Data",buffer.toString());
            }


        });



        return view;
    }
    public boolean validate(){
       boolean valid=true;
        if (mEdtName.getText().toString().trim().isEmpty()){
            mEdtName.setError("Plese enter Valid name");
            valid=false;
        }

        if (!(mEdtPhone.getText().toString().length()==10)){
            mEdtPhone.setError("Plese enter Valid Phone No");
            valid=false;
        }

        if (!(PatternsCompat.EMAIL_ADDRESS.matcher(mEdtEmail.getText().toString().trim()).matches())){
            mEdtEmail.setError("Plese enter Valid Email");
            valid=false;
        }

        if (mEdtAdd.getText().toString().trim().isEmpty()){
            mEdtAdd.setError("Plese enter Valid Address");
            valid=false;
        }
        if (mEdtCity.getText().toString().trim().isEmpty()){
            mEdtCity.setError("Plese enter Valid City");
            valid=false;
        }




        return valid;
    }

    public void showMassage(String tital,String Message){
        AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());
        builder.setCancelable(true);
        builder.setTitle(tital);
        builder.setMessage(Message);
        builder.show();
        }
}
