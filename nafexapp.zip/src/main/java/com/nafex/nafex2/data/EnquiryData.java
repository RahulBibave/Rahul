package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 10/10/2017.
 */

public class EnquiryData implements Serializable {
    public String requestId;
    public String requestType;
    public String requestSourceCurrencyId;
    public String requestTargetCurrencyId;
    public String requestDeliveryMode;
    public String requestAreaId;
    public String requestCityId;
    public String requestStateId;
    public String requestCountryId;
    public String requestLeadSourceId;
    public String  requestSourceRefId;
    public String  requestSourceRef;
    public String  requestNBC;
    public String  requestStatusId;
    public String  requestSMSStatusId;
    public String  requestEmailStatusId;
    public String  requestDisputeId;
    public String  requestWinnerFFMCId;
    public String  requestAcceptedBidId;
    public String  requestBidAcceptedDateTime;
    public String  requestBidAcceptedSource;
    public String  requestOpraterId;
    public String  requestBidAcceptedUserId;
    public String  createdById;
    public String  lastModifiedById;
    public String  requestLat;
    public String  requestLong;
    public String  requestUnixTime;
    public String  disputeId;
    public String  disputeStatusId;
    public String  remaining;
    public String  lastModifiedOn;
    public String  requestUserId;
    public String  userName;
    public String  userMobileNo;
    public String  requestTypeName;
    public String  requestDeliveryModeName;
    public String  requestLeadSourceName;
    public String  requestStatusName;
    public String  requestSourceCurrencyName;
    public String  requestTargetCurrencyName;
    public String  locationName;
    public String  countryName;
    public String  stateName;
    public String  cityName;
    public String  areaName;
    public String  requestProducts;
    public String  requestProductTypeId;
    public String  requestQuantity;
    public String  requestProductTypeName;
    public String  requestBids;
    public String  bidId;
    public String  bidFFMCId;
    public String  ffmcAreaId;
    public String  ffmcDistance;
    public String  averageRate;
    public String  averageAmount;
    public String  taxAmount;
    public String  deliveryCharges;
    public String  otherCharges;
    public String  remittanceCharges;

    public String getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(String commissionRate) {
        this.commissionRate = commissionRate;
    }

    public String  bidOperaterId;
    public String  createdByIdbidrate;
    public String  ffmcName;
    public String  commissionRate;

    public String getRequestProductTypeId1() {
        return requestProductTypeId1;
    }

    public void setRequestProductTypeId1(String requestProductTypeId1) {
        this.requestProductTypeId1 = requestProductTypeId1;
    }

    public String getRequestQuantity1() {
        return requestQuantity1;
    }

    public void setRequestQuantity1(String requestQuantity1) {
        this.requestQuantity1 = requestQuantity1;
    }

    public String getRequestProductTypeName1() {
        return requestProductTypeName1;
    }

    public void setRequestProductTypeName1(String requestProductTypeName1) {
        this.requestProductTypeName1 = requestProductTypeName1;
    }

    public String getRequestProductTypeId2() {
        return requestProductTypeId2;
    }

    public void setRequestProductTypeId2(String requestProductTypeId2) {
        this.requestProductTypeId2 = requestProductTypeId2;
    }

    public String getRequestQuantity2() {
        return requestQuantity2;
    }

    public void setRequestQuantity2(String requestQuantity2) {
        this.requestQuantity2 = requestQuantity2;
    }

    public String getRequestProductTypeName2() {
        return requestProductTypeName2;
    }

    public void setRequestProductTypeName2(String requestProductTypeName2) {
        this.requestProductTypeName2 = requestProductTypeName2;
    }

    public String  requestProductTypeId1;
    public String  requestQuantity1;
    public String  requestProductTypeName1;

    public String  requestProductTypeId2;
    public String  requestQuantity2;
    public String  requestProductTypeName2;


    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestSourceCurrencyId() {
        return requestSourceCurrencyId;
    }

    public void setRequestSourceCurrencyId(String requestSourceCurrencyId) {
        this.requestSourceCurrencyId = requestSourceCurrencyId;
    }

    public String getRequestTargetCurrencyId() {
        return requestTargetCurrencyId;
    }

    public void setRequestTargetCurrencyId(String requestTargetCurrencyId) {
        this.requestTargetCurrencyId = requestTargetCurrencyId;
    }

    public String getRequestDeliveryMode() {
        return requestDeliveryMode;
    }

    public void setRequestDeliveryMode(String requestDeliveryMode) {
        this.requestDeliveryMode = requestDeliveryMode;
    }

    public String getRequestAreaId() {
        return requestAreaId;
    }

    public void setRequestAreaId(String requestAreaId) {
        this.requestAreaId = requestAreaId;
    }

    public String getRequestCityId() {
        return requestCityId;
    }

    public void setRequestCityId(String requestCityId) {
        this.requestCityId = requestCityId;
    }

    public String getRequestStateId() {
        return requestStateId;
    }

    public void setRequestStateId(String requestStateId) {
        this.requestStateId = requestStateId;
    }

    public String getRequestCountryId() {
        return requestCountryId;
    }

    public void setRequestCountryId(String requestCountryId) {
        this.requestCountryId = requestCountryId;
    }

    public String getRequestLeadSourceId() {
        return requestLeadSourceId;
    }

    public void setRequestLeadSourceId(String requestLeadSourceId) {
        this.requestLeadSourceId = requestLeadSourceId;
    }

    public String getRequestSourceRefId() {
        return requestSourceRefId;
    }

    public void setRequestSourceRefId(String requestSourceRefId) {
        this.requestSourceRefId = requestSourceRefId;
    }

    public String getRequestSourceRef() {
        return requestSourceRef;
    }

    public void setRequestSourceRef(String requestSourceRef) {
        this.requestSourceRef = requestSourceRef;
    }

    public String getRequestNBC() {
        return requestNBC;
    }

    public void setRequestNBC(String requestNBC) {
        this.requestNBC = requestNBC;
    }

    public String getRequestStatusId() {
        return requestStatusId;
    }

    public void setRequestStatusId(String requestStatusId) {
        this.requestStatusId = requestStatusId;
    }

    public String getRequestSMSStatusId() {
        return requestSMSStatusId;
    }

    public void setRequestSMSStatusId(String requestSMSStatusId) {
        this.requestSMSStatusId = requestSMSStatusId;
    }

    public String getRequestEmailStatusId() {
        return requestEmailStatusId;
    }

    public void setRequestEmailStatusId(String requestEmailStatusId) {
        this.requestEmailStatusId = requestEmailStatusId;
    }

    public String getRequestDisputeId() {
        return requestDisputeId;
    }

    public void setRequestDisputeId(String requestDisputeId) {
        this.requestDisputeId = requestDisputeId;
    }

    public String getRequestWinnerFFMCId() {
        return requestWinnerFFMCId;
    }

    public void setRequestWinnerFFMCId(String requestWinnerFFMCId) {
        this.requestWinnerFFMCId = requestWinnerFFMCId;
    }

    public String getRequestAcceptedBidId() {
        return requestAcceptedBidId;
    }

    public void setRequestAcceptedBidId(String requestAcceptedBidId) {
        this.requestAcceptedBidId = requestAcceptedBidId;
    }

    public String getRequestBidAcceptedDateTime() {
        return requestBidAcceptedDateTime;
    }

    public void setRequestBidAcceptedDateTime(String requestBidAcceptedDateTime) {
        this.requestBidAcceptedDateTime = requestBidAcceptedDateTime;
    }

    public String getRequestBidAcceptedSource() {
        return requestBidAcceptedSource;
    }

    public void setRequestBidAcceptedSource(String requestBidAcceptedSource) {
        this.requestBidAcceptedSource = requestBidAcceptedSource;
    }

    public String getRequestOpraterId() {
        return requestOpraterId;
    }

    public void setRequestOpraterId(String requestOpraterId) {
        this.requestOpraterId = requestOpraterId;
    }

    public String getRequestBidAcceptedUserId() {
        return requestBidAcceptedUserId;
    }

    public void setRequestBidAcceptedUserId(String requestBidAcceptedUserId) {
        this.requestBidAcceptedUserId = requestBidAcceptedUserId;
    }

    public String getCreatedById() {
        return createdById;
    }

    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    public String getLastModifiedById() {
        return lastModifiedById;
    }

    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    public String getRequestLat() {
        return requestLat;
    }

    public void setRequestLat(String requestLat) {
        this.requestLat = requestLat;
    }

    public String getRequestLong() {
        return requestLong;
    }

    public void setRequestLong(String requestLong) {
        this.requestLong = requestLong;
    }

    public String getRequestUnixTime() {
        return requestUnixTime;
    }

    public void setRequestUnixTime(String requestUnixTime) {
        this.requestUnixTime = requestUnixTime;
    }

    public String getDisputeId() {
        return disputeId;
    }

    public void setDisputeId(String disputeId) {
        this.disputeId = disputeId;
    }

    public String getDisputeStatusId() {
        return disputeStatusId;
    }

    public void setDisputeStatusId(String disputeStatusId) {
        this.disputeStatusId = disputeStatusId;
    }

    public String getRemaining() {
        return remaining;
    }

    public void setRemaining(String remaining) {
        this.remaining = remaining;
    }

    public String getLastModifiedOn() {
        return lastModifiedOn;
    }

    public void setLastModifiedOn(String lastModifiedOn) {
        this.lastModifiedOn = lastModifiedOn;
    }

    public String getRequestUserId() {
        return requestUserId;
    }

    public void setRequestUserId(String requestUserId) {
        this.requestUserId = requestUserId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserMobileNo() {
        return userMobileNo;
    }

    public void setUserMobileNo(String userMobileNo) {
        this.userMobileNo = userMobileNo;
    }

    public String getRequestTypeName() {
        return requestTypeName;
    }

    public void setRequestTypeName(String requestTypeName) {
        this.requestTypeName = requestTypeName;
    }

    public String getRequestDeliveryModeName() {
        return requestDeliveryModeName;
    }

    public void setRequestDeliveryModeName(String requestDeliveryModeName) {
        this.requestDeliveryModeName = requestDeliveryModeName;
    }

    public String getRequestLeadSourceName() {
        return requestLeadSourceName;
    }

    public void setRequestLeadSourceName(String requestLeadSourceName) {
        this.requestLeadSourceName = requestLeadSourceName;
    }

    public String getRequestStatusName() {
        return requestStatusName;
    }

    public void setRequestStatusName(String requestStatusName) {
        this.requestStatusName = requestStatusName;
    }

    public String getRequestSourceCurrencyName() {
        return requestSourceCurrencyName;
    }

    public void setRequestSourceCurrencyName(String requestSourceCurrencyName) {
        this.requestSourceCurrencyName = requestSourceCurrencyName;
    }

    public String getRequestTargetCurrencyName() {
        return requestTargetCurrencyName;
    }

    public void setRequestTargetCurrencyName(String requestTargetCurrencyName) {
        this.requestTargetCurrencyName = requestTargetCurrencyName;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getRequestProducts() {
        return requestProducts;
    }

    public void setRequestProducts(String requestProducts) {
        this.requestProducts = requestProducts;
    }

    public String getRequestProductTypeId() {
        return requestProductTypeId;
    }

    public void setRequestProductTypeId(String requestProductTypeId) {
        this.requestProductTypeId = requestProductTypeId;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestProductTypeName() {
        return requestProductTypeName;
    }

    public void setRequestProductTypeName(String requestProductTypeName) {
        this.requestProductTypeName = requestProductTypeName;
    }

    public String getRequestBids() {
        return requestBids;
    }

    public void setRequestBids(String requestBids) {
        this.requestBids = requestBids;
    }

    public String getBidId() {
        return bidId;
    }

    public void setBidId(String bidId) {
        this.bidId = bidId;
    }

    public String getBidFFMCId() {
        return bidFFMCId;
    }

    public void setBidFFMCId(String bidFFMCId) {
        this.bidFFMCId = bidFFMCId;
    }

    public String getFfmcAreaId() {
        return ffmcAreaId;
    }

    public void setFfmcAreaId(String ffmcAreaId) {
        this.ffmcAreaId = ffmcAreaId;
    }

    public String getFfmcDistance() {
        return ffmcDistance;
    }

    public void setFfmcDistance(String ffmcDistance) {
        this.ffmcDistance = ffmcDistance;
    }

    public String getAverageRate() {
        return averageRate;
    }

    public void setAverageRate(String averageRate) {
        this.averageRate = averageRate;
    }

    public String getAverageAmount() {
        return averageAmount;
    }

    public void setAverageAmount(String averageAmount) {
        this.averageAmount = averageAmount;
    }

    public String getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(String taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getDeliveryCharges() {
        return deliveryCharges;
    }

    public void setDeliveryCharges(String deliveryCharges) {
        this.deliveryCharges = deliveryCharges;
    }

    public String getOtherCharges() {
        return otherCharges;
    }

    public void setOtherCharges(String otherCharges) {
        this.otherCharges = otherCharges;
    }

    public String getRemittanceCharges() {
        return remittanceCharges;
    }

    public void setRemittanceCharges(String remittanceCharges) {
        this.remittanceCharges = remittanceCharges;
    }

    public String getBidOperaterId() {
        return bidOperaterId;
    }

    public void setBidOperaterId(String bidOperaterId) {
        this.bidOperaterId = bidOperaterId;
    }

    public String getCreatedByIdbidrate() {
        return createdByIdbidrate;
    }

    public void setCreatedByIdbidrate(String createdByIdbidrate) {
        this.createdByIdbidrate = createdByIdbidrate;
    }

    public String getFfmcName() {
        return ffmcName;
    }

    public void setFfmcName(String ffmcName) {
        this.ffmcName = ffmcName;
    }

    public String getBidSourceId() {
        return bidSourceId;
    }

    public void setBidSourceId(String bidSourceId) {
        this.bidSourceId = bidSourceId;
    }

    public String  bidSourceId;



















}
