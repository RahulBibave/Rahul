package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 10/5/2017.
 */

public class OpenDispute implements Serializable {
    public String disputeId;
    public String requestId;

    public String disputeProductTypeId;
    public String requestNBCNumber;
    public String disputeRaiseSource;
    public String disputeType;
    public String disputeUserType;
    public String userReferenceId;
    public String disputeReasonId;
    public String disputeSubject;
    public String disputeDetails;
    public String disputeQuantity;
    public String disputeStatusId;
    public String commissionRate;
    public String createdById;
    public String createdOn;
    public String lastModifiedById;
    public String lastModifiedOn;
    public String requestType;
    public String requestSourceCurrencyId;
    public String requestTargetCurrencyId;
    public String FFMCAddress1;
    public String FFMCBranchLevel;

    public String getDisputeId() {
        return disputeId;
    }

    public void setDisputeId(String disputeId) {
        this.disputeId = disputeId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getDisputeProductTypeId() {
        return disputeProductTypeId;
    }

    public void setDisputeProductTypeId(String disputeProductTypeId) {
        this.disputeProductTypeId = disputeProductTypeId;
    }

    public String getRequestNBCNumber() {
        return requestNBCNumber;
    }

    public void setRequestNBCNumber(String requestNBCNumber) {
        this.requestNBCNumber = requestNBCNumber;
    }

    public String getDisputeRaiseSource() {
        return disputeRaiseSource;
    }

    public void setDisputeRaiseSource(String disputeRaiseSource) {
        this.disputeRaiseSource = disputeRaiseSource;
    }

    public String getDisputeType() {
        return disputeType;
    }

    public void setDisputeType(String disputeType) {
        this.disputeType = disputeType;
    }

    public String getDisputeUserType() {
        return disputeUserType;
    }

    public void setDisputeUserType(String disputeUserType) {
        this.disputeUserType = disputeUserType;
    }

    public String getUserReferenceId() {
        return userReferenceId;
    }

    public void setUserReferenceId(String userReferenceId) {
        this.userReferenceId = userReferenceId;
    }

    public String getDisputeReasonId() {
        return disputeReasonId;
    }

    public void setDisputeReasonId(String disputeReasonId) {
        this.disputeReasonId = disputeReasonId;
    }

    public String getDisputeSubject() {
        return disputeSubject;
    }

    public void setDisputeSubject(String disputeSubject) {
        this.disputeSubject = disputeSubject;
    }

    public String getDisputeDetails() {
        return disputeDetails;
    }

    public void setDisputeDetails(String disputeDetails) {
        this.disputeDetails = disputeDetails;
    }

    public String getDisputeQuantity() {
        return disputeQuantity;
    }

    public void setDisputeQuantity(String disputeQuantity) {
        this.disputeQuantity = disputeQuantity;
    }

    public String getDisputeStatusId() {
        return disputeStatusId;
    }

    public void setDisputeStatusId(String disputeStatusId) {
        this.disputeStatusId = disputeStatusId;
    }

    public String getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(String commissionRate) {
        this.commissionRate = commissionRate;
    }

    public String getCreatedById() {
        return createdById;
    }

    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getLastModifiedById() {
        return lastModifiedById;
    }

    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    public String getLastModifiedOn() {
        return lastModifiedOn;
    }

    public void setLastModifiedOn(String lastModifiedOn) {
        this.lastModifiedOn = lastModifiedOn;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestSourceCurrencyId() {
        return requestSourceCurrencyId;
    }

    public void setRequestSourceCurrencyId(String requestSourceCurrencyId) {
        this.requestSourceCurrencyId = requestSourceCurrencyId;
    }

    public String getRequestTargetCurrencyId() {
        return requestTargetCurrencyId;
    }

    public void setRequestTargetCurrencyId(String requestTargetCurrencyId) {
        this.requestTargetCurrencyId = requestTargetCurrencyId;
    }

    public String getFFMCAddress1() {
        return FFMCAddress1;
    }

    public void setFFMCAddress1(String FFMCAddress1) {
        this.FFMCAddress1 = FFMCAddress1;
    }

    public String getFFMCBranchLevel() {
        return FFMCBranchLevel;
    }

    public void setFFMCBranchLevel(String FFMCBranchLevel) {
        this.FFMCBranchLevel = FFMCBranchLevel;
    }

    public String getFFMCCompanyId() {
        return FFMCCompanyId;
    }

    public void setFFMCCompanyId(String FFMCCompanyId) {
        this.FFMCCompanyId = FFMCCompanyId;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestTypeName() {
        return requestTypeName;
    }

    public void setRequestTypeName(String requestTypeName) {
        this.requestTypeName = requestTypeName;
    }

    public String getRequestSourceCurrencyName() {
        return requestSourceCurrencyName;
    }

    public void setRequestSourceCurrencyName(String requestSourceCurrencyName) {
        this.requestSourceCurrencyName = requestSourceCurrencyName;
    }

    public String getRequestTargetCurrencyName() {
        return requestTargetCurrencyName;
    }

    public void setRequestTargetCurrencyName(String requestTargetCurrencyName) {
        this.requestTargetCurrencyName = requestTargetCurrencyName;
    }

    public String getFFMCCompany() {
        return FFMCCompany;
    }

    public void setFFMCCompany(String FFMCCompany) {
        this.FFMCCompany = FFMCCompany;
    }

    public String FFMCCompanyId;
    public String requestQuantity;
    public String requestTypeName;
    public String requestSourceCurrencyName;
    public String requestTargetCurrencyName;
    public String FFMCCompany;


}
