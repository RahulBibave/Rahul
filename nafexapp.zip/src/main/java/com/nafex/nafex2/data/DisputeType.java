package com.nafex.nafex2.data;

/**
 * Created by Swarup on 10/9/2017.
 */

public class DisputeType {
    private String codevalue;
    private String codeName;
    private String codeAtrribute;


    public String getCodevalue() {
        return codevalue;
    }

    public void setCodevalue(String codevalue) {
        this.codevalue = codevalue;
    }

    public String getCodeName() {
        return codeName;
    }

    public void setCodeName(String codeName) {
        this.codeName = codeName;
    }

    public String getCodeAtrribute() {
        return codeAtrribute;
    }

    public void setCodeAtrribute(String codeAtrribute) {
        this.codeAtrribute = codeAtrribute;
    }

    public DisputeType() {
    }

    public DisputeType(String codevalue, String codename, String codeAttibute) {
        this.codevalue = codevalue;
        this.codeName = codename;
        this.codeAtrribute = codeAttibute;

    }




}
