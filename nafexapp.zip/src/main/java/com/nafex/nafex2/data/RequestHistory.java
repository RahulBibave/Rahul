package com.nafex.nafex2.data;

import java.io.Serializable;
import java.lang.ref.SoftReference;

/**
 * Created by Swarup on 9/19/2017.
 */

public class RequestHistory implements Serializable {
    public String requestId;
    public String requestType;

    public String getNewProductQnt() {
        return newProductQnt;
    }

    public void setNewProductQnt(String newProductQnt) {
        this.newProductQnt = newProductQnt;
    }

    public String getNewProduct() {
        return newProduct;
    }

    public void setNewProduct(String newProduct) {
        this.newProduct = newProduct;
    }

    public String requestSourceCurrencyId;
    public String requestTargetCurrencyId;
    String requestCountryName,requestTransferTypeName,requestPurposeName,newProductQnt,newProduct;

    public String getRequestCountryName() {
        return requestCountryName;
    }

    public void setRequestCountryName(String requestCountryName) {
        this.requestCountryName = requestCountryName;
    }

    public String getRequestTransferTypeName() {
        return requestTransferTypeName;
    }

    public void setRequestTransferTypeName(String requestTransferTypeName) {
        this.requestTransferTypeName = requestTransferTypeName;
    }

    public String getRequestPurposeName() {
        return requestPurposeName;
    }

    public void setRequestPurposeName(String requestPurposeName) {
        this.requestPurposeName = requestPurposeName;
    }

    public String getRequestProductTypeId() {
        return requestProductTypeId;
    }

    public void setRequestProductTypeId(String requestProductTypeId) {
        this.requestProductTypeId = requestProductTypeId;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestProductTypeName() {
        return requestProductTypeName;
    }

    public void setRequestProductTypeName(String requestProductTypeName) {
        this.requestProductTypeName = requestProductTypeName;
    }

    public String requestProductTypeId;
    public String requestQuantity;
    public String requestProductTypeName;




    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestSourceCurrencyId() {
        return requestSourceCurrencyId;
    }

    public void setRequestSourceCurrencyId(String requestSourceCurrencyId) {
        this.requestSourceCurrencyId = requestSourceCurrencyId;
    }

    public String getRequestTargetCurrencyId() {
        return requestTargetCurrencyId;
    }

    public void setRequestTargetCurrencyId(String requestTargetCurrencyId) {
        this.requestTargetCurrencyId = requestTargetCurrencyId;
    }

    public String getRequestNBC() {
        return requestNBC;
    }

    public void setRequestNBC(String requestNBC) {
        this.requestNBC = requestNBC;
    }

    public String getRequestStatusId() {
        return requestStatusId;
    }

    public void setRequestStatusId(String requestStatusId) {
        this.requestStatusId = requestStatusId;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getRequestTypeName() {
        return requestTypeName;
    }

    public void setRequestTypeName(String requestTypeName) {
        this.requestTypeName = requestTypeName;
    }

    public String getRequestSourceCurrencyName() {
        return requestSourceCurrencyName;
    }

    public void setRequestSourceCurrencyName(String requestSourceCurrencyName) {
        this.requestSourceCurrencyName = requestSourceCurrencyName;
    }

    public String getRequestTargetCurrencyName() {
        return requestTargetCurrencyName;
    }

    public void setRequestTargetCurrencyName(String requestTargetCurrencyName) {
        this.requestTargetCurrencyName = requestTargetCurrencyName;
    }

    public String getRequestStatusName() {
        return requestStatusName;
    }

    public void setRequestStatusName(String requestStatusName) {
        this.requestStatusName = requestStatusName;
    }

    public String requestNBC;
    public String requestStatusId;
    public String createdOn;
    public String requestTypeName;
    public String requestSourceCurrencyName;
    public String requestTargetCurrencyName;
    public String requestStatusName;

    public String countryName;
    public String stateName;
    public String cityName;
    public String areaName;
    public String requestDeliveryModeName;

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getRequestDeliveryModeName() {
        return requestDeliveryModeName;
    }

    public void setRequestDeliveryModeName(String requestDeliveryModeName) {
        this.requestDeliveryModeName = requestDeliveryModeName;
    }
}
