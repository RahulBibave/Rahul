package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 10/11/2017.
 */

public class NbcHistory implements Serializable {
    public String requestId;
    public String requestType;
    public String requestSourceCurrencyId;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestSourceCurrencyId() {
        return requestSourceCurrencyId;
    }

    public void setRequestSourceCurrencyId(String requestSourceCurrencyId) {
        this.requestSourceCurrencyId = requestSourceCurrencyId;
    }

    public String getRequestTargetCurrencyId() {
        return requestTargetCurrencyId;
    }

    public void setRequestTargetCurrencyId(String requestTargetCurrencyId) {
        this.requestTargetCurrencyId = requestTargetCurrencyId;
    }

    public String getRequestNBC() {
        return requestNBC;
    }

    public void setRequestNBC(String requestNBC) {
        this.requestNBC = requestNBC;
    }

    public String getRequestStatusId() {
        return requestStatusId;
    }

    public void setRequestStatusId(String requestStatusId) {
        this.requestStatusId = requestStatusId;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getRequestTypeName() {
        return requestTypeName;
    }

    public void setRequestTypeName(String requestTypeName) {
        this.requestTypeName = requestTypeName;
    }

    public String getRequestSourceCurrencyName() {
        return requestSourceCurrencyName;
    }

    public void setRequestSourceCurrencyName(String requestSourceCurrencyName) {
        this.requestSourceCurrencyName = requestSourceCurrencyName;
    }

    public String getRequestTargetCurrencyName() {
        return requestTargetCurrencyName;
    }

    public void setRequestTargetCurrencyName(String requestTargetCurrencyName) {
        this.requestTargetCurrencyName = requestTargetCurrencyName;
    }

    public String getRequestStatusName() {
        return requestStatusName;
    }

    public void setRequestStatusName(String requestStatusName) {
        this.requestStatusName = requestStatusName;
    }

    public String getRequestProducts() {
        return requestProducts;
    }

    public void setRequestProducts(String requestProducts) {
        this.requestProducts = requestProducts;
    }

    public String getRequestProductTypeId() {
        return requestProductTypeId;
    }

    public void setRequestProductTypeId(String requestProductTypeId) {
        this.requestProductTypeId = requestProductTypeId;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestProductTypeName() {
        return requestProductTypeName;
    }

    public void setRequestProductTypeName(String requestProductTypeName) {
        this.requestProductTypeName = requestProductTypeName;
    }

    public String requestTargetCurrencyId;
    public String requestNBC;
    public String requestStatusId;
    public String createdOn;
    public String requestTypeName;
    public String requestSourceCurrencyName;
    public String requestTargetCurrencyName;
    public String requestStatusName;
    public String requestProducts;
    public String requestProductTypeId;
    public String requestQuantity;
    public String requestProductTypeName;


}
