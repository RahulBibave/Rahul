package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by rahul on 29/1/18.
 */

public class CurrencyForexCard implements Serializable {
    private String CurrencyName;
    private String CurrencyAbbrivation;
    private String CurrencySymbol;
    private int CurrencyId;
    private String CurrencyOrder;
    private String Rbirate;
    private String BuyRate;
    private String SellRate;
    private String Productcardoptions;

    public CurrencyForexCard() {
    }

    public CurrencyForexCard(String currencyName, String currencyAbbrivation, String currencySymbol, int currencyId, String currencyOrder, String rbirate, String buyRate, String sellRate, String productcardoptions) {
        CurrencyName = currencyName;
        CurrencyAbbrivation = currencyAbbrivation;
        CurrencySymbol = currencySymbol;
        CurrencyId = currencyId;
        CurrencyOrder = currencyOrder;
        Rbirate = rbirate;
        BuyRate = buyRate;
        SellRate = sellRate;
        Productcardoptions = productcardoptions;
    }

    public String getCurrencyName() {
        return CurrencyName;
    }

    public void setCurrencyName(String currencyName) {
        CurrencyName = currencyName;
    }

    public String getCurrencyAbbrivation() {
        return CurrencyAbbrivation;
    }

    public void setCurrencyAbbrivation(String currencyAbbrivation) {
        CurrencyAbbrivation = currencyAbbrivation;
    }

    public String getCurrencySymbol() {
        return CurrencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        CurrencySymbol = currencySymbol;
    }

    public int getCurrencyId() {
        return CurrencyId;
    }

    public void setCurrencyId(int currencyId) {
        CurrencyId = currencyId;
    }

    public String getCurrencyOrder() {
        return CurrencyOrder;
    }

    public void setCurrencyOrder(String currencyOrder) {
        CurrencyOrder = currencyOrder;
    }

    public String getRbirate() {
        return Rbirate;
    }

    public void setRbirate(String rbirate) {
        Rbirate = rbirate;
    }

    public String getBuyRate() {
        return BuyRate;
    }

    public void setBuyRate(String buyRate) {
        BuyRate = buyRate;
    }

    public String getSellRate() {
        return SellRate;
    }

    public void setSellRate(String sellRate) {
        SellRate = sellRate;
    }

    public String getProductcardoptions() {
        return Productcardoptions;
    }

    public void setProductcardoptions(String productcardoptions) {
        Productcardoptions = productcardoptions;
    }
}
