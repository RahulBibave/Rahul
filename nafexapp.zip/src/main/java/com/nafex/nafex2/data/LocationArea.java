package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by torinit01 on 5/9/16.
 */
public class LocationArea implements Serializable {

    private String AreaName;
    private int AreaId;

    public LocationArea() {
    }

    public LocationArea( int AreaId, String AreaName) {
        this.AreaId = AreaId;
        this.AreaName = AreaName;
    }

    public String getAreaName() {
        return AreaName;
    }

    public int getAreaId() {
        return AreaId;
    }


    public void setAreaName(String AreaName) {
        this.AreaName = AreaName;
    }

    public void setAreaId(int AreaId) {
        this.AreaId = AreaId;
    }


}
