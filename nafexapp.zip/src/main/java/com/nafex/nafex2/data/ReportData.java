package com.nafex.nafex2.data;

/**
 * Created by Sunil on 5/13/2017.
 */
public class ReportData {

    String date;
    String NbcNo;
    String Status;
    String Customer;
    String Name;
    String MobileNo;

    public ReportData(String date, String nbcNo, String status, String customer,String name, String mobileno) {
        this.date = date;
        NbcNo = nbcNo;
        Status = status;
        Customer = customer;
        Name = name;
        MobileNo = mobileno;

    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNbcNo() {
        return NbcNo;
    }

    public void setNbcNo(String nbcNo) {
        NbcNo = nbcNo;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getCustomer() {
        return Customer;
    }

    public void setCustomer(String customer) {
        Customer = customer;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileno) {
        MobileNo = mobileno;
    }
}
