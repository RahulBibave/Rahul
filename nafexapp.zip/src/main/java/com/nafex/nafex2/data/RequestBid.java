package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by torinit01 on 5/9/16.
 */
public class RequestBid implements Serializable {

    private int requestId, FFMCId, cityId, ffmcAreaId;
    private String areaName, ffmcName, NBC, ffmcLatitute, ffmcLongitute;
    private Double FFMCRate;
    private Boolean BestRate;
    private Boolean Accepted;

    public RequestBid() {
    }

//    public RequestBid(int AreaId, String CurrencyName, String CurrencyAbbrivation, String CurrencySymbol) {
//        this.CurrencyId = CurrencyId;
//        this.CurrencyName = CurrencyName;
//        this.CurrencyAbbrivation = CurrencyAbbrivation;
//        this.CurrencySymbol = CurrencySymbol;
//
//    }

    public String getFFMCName() {
        return ffmcName;
    }
    public String getAreaName() {
        return areaName;
    }
    public String getNBC() {
        return NBC;
    }
    public int getRequestId() {
        return requestId;
    }
    public int getFFMCId() {
        return FFMCId;
    }
    public Double getFFMCRate() {
        return FFMCRate;
    }

    public Boolean getBestRateYN() {
        return BestRate;
    }
    public Boolean getAcceptedYN() {
        return Accepted;
    }

    public void setFFMCName(String ffmcName) {
        this.ffmcName = ffmcName;
    }
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }
    public void setNBC(String NBC) {
        this.NBC = NBC;
    }
    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }
    public void setFFMCId(int ffmcId) {
        this.FFMCId = ffmcId;
    }
    public void setFFMCRate(Double FFMCRate) {
        this.FFMCRate = FFMCRate;
    }

    public void setBestRateYN(Boolean BestRate) {
        this.BestRate = BestRate;
    }
    public void setAcceptedYN(Boolean AcceptedYN) {
        this.Accepted = AcceptedYN;
    }

}
