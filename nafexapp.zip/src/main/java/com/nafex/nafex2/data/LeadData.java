package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 10/12/2017.
 */

public class LeadData implements Serializable {
    public String id;
    public String leadId;
    public String leadType;
    public String namePrefix;
    public String personName;
    public String personMobile;
    public String personPhone;
    public String personEmail;
    public String leadDate;
    public String leadCategory;
    public String leadCity;
    public String leadArea;
    public String leadBranchArea;
    public String leadDncMobile;
    public String leadDncPhone;
    public String leadCompany;
    public String leadPincode;
    public String leadTime;
    public String leadBranchPin;
    public String leadParentId;
    public String createdOn;
    public String leadSaveLater;
    public String isEnquiryGenerated;
    public String requestType;
    public String requestSourceCurrencyId;
    public String requestDeliveryMode;
    public String requestLocation;
    public String requestProductTypeId;
    public String requestQuantity;
    public String requestPurposeId;
    public String requestCountryId;
    public String requestTransferTypeId;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLeadId() {
        return leadId;
    }

    public void setLeadId(String leadId) {
        this.leadId = leadId;
    }

    public String getLeadType() {
        return leadType;
    }

    public void setLeadType(String leadType) {
        this.leadType = leadType;
    }

    public String getNamePrefix() {
        return namePrefix;
    }

    public void setNamePrefix(String namePrefix) {
        this.namePrefix = namePrefix;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getPersonMobile() {
        return personMobile;
    }

    public void setPersonMobile(String personMobile) {
        this.personMobile = personMobile;
    }

    public String getPersonPhone() {
        return personPhone;
    }

    public void setPersonPhone(String personPhone) {
        this.personPhone = personPhone;
    }

    public String getPersonEmail() {
        return personEmail;
    }

    public void setPersonEmail(String personEmail) {
        this.personEmail = personEmail;
    }

    public String getLeadDate() {
        return leadDate;
    }

    public void setLeadDate(String leadDate) {
        this.leadDate = leadDate;
    }

    public String getLeadCategory() {
        return leadCategory;
    }

    public void setLeadCategory(String leadCategory) {
        this.leadCategory = leadCategory;
    }

    public String getLeadCity() {
        return leadCity;
    }

    public void setLeadCity(String leadCity) {
        this.leadCity = leadCity;
    }

    public String getLeadArea() {
        return leadArea;
    }

    public void setLeadArea(String leadArea) {
        this.leadArea = leadArea;
    }

    public String getLeadBranchArea() {
        return leadBranchArea;
    }

    public void setLeadBranchArea(String leadBranchArea) {
        this.leadBranchArea = leadBranchArea;
    }

    public String getLeadDncMobile() {
        return leadDncMobile;
    }

    public void setLeadDncMobile(String leadDncMobile) {
        this.leadDncMobile = leadDncMobile;
    }

    public String getLeadDncPhone() {
        return leadDncPhone;
    }

    public void setLeadDncPhone(String leadDncPhone) {
        this.leadDncPhone = leadDncPhone;
    }

    public String getLeadCompany() {
        return leadCompany;
    }

    public void setLeadCompany(String leadCompany) {
        this.leadCompany = leadCompany;
    }

    public String getLeadPincode() {
        return leadPincode;
    }

    public void setLeadPincode(String leadPincode) {
        this.leadPincode = leadPincode;
    }

    public String getLeadTime() {
        return leadTime;
    }

    public void setLeadTime(String leadTime) {
        this.leadTime = leadTime;
    }

    public String getLeadBranchPin() {
        return leadBranchPin;
    }

    public void setLeadBranchPin(String leadBranchPin) {
        this.leadBranchPin = leadBranchPin;
    }

    public String getLeadParentId() {
        return leadParentId;
    }

    public void setLeadParentId(String leadParentId) {
        this.leadParentId = leadParentId;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getLeadSaveLater() {
        return leadSaveLater;
    }

    public void setLeadSaveLater(String leadSaveLater) {
        this.leadSaveLater = leadSaveLater;
    }

    public String getIsEnquiryGenerated() {
        return isEnquiryGenerated;
    }

    public void setIsEnquiryGenerated(String isEnquiryGenerated) {
        this.isEnquiryGenerated = isEnquiryGenerated;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestSourceCurrencyId() {
        return requestSourceCurrencyId;
    }

    public void setRequestSourceCurrencyId(String requestSourceCurrencyId) {
        this.requestSourceCurrencyId = requestSourceCurrencyId;
    }

    public String getRequestDeliveryMode() {
        return requestDeliveryMode;
    }

    public void setRequestDeliveryMode(String requestDeliveryMode) {
        this.requestDeliveryMode = requestDeliveryMode;
    }

    public String getRequestLocation() {
        return requestLocation;
    }

    public void setRequestLocation(String requestLocation) {
        this.requestLocation = requestLocation;
    }

    public String getRequestProductTypeId() {
        return requestProductTypeId;
    }

    public void setRequestProductTypeId(String requestProductTypeId) {
        this.requestProductTypeId = requestProductTypeId;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestPurposeId() {
        return requestPurposeId;
    }

    public void setRequestPurposeId(String requestPurposeId) {
        this.requestPurposeId = requestPurposeId;
    }

    public String getRequestCountryId() {
        return requestCountryId;
    }

    public void setRequestCountryId(String requestCountryId) {
        this.requestCountryId = requestCountryId;
    }

    public String getRequestTransferTypeId() {
        return requestTransferTypeId;
    }

    public void setRequestTransferTypeId(String requestTransferTypeId) {
        this.requestTransferTypeId = requestTransferTypeId;
    }

    public String getIsReminderSet() {
        return isReminderSet;
    }

    public void setIsReminderSet(String isReminderSet) {
        this.isReminderSet = isReminderSet;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getRequestSourceCurrencyName() {
        return requestSourceCurrencyName;
    }

    public void setRequestSourceCurrencyName(String requestSourceCurrencyName) {
        this.requestSourceCurrencyName = requestSourceCurrencyName;
    }

    public String isReminderSet;
    public String operatorId;
    public String operatorName;
    public String requestSourceCurrencyName;





}
