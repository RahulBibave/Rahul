package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by torinit01 on 5/9/16.
 */
public class Currency implements Serializable {

    private String CurrencyName;
    private String CurrencyAbbrivation;
    private String CurrencySymbol;
    private int CurrencyId;
    private String CurrencyOrder;
    private String Rbirate;
    private String BuyRate;
    private String SellRate;
    private String Productcardoptions;
    private String productMoneyTransferOrder;

    public String getProductMoneyTransferOrder() {
        return productMoneyTransferOrder;
    }

    public void setProductMoneyTransferOrder(String productMoneyTransferOrder) {
        this.productMoneyTransferOrder = productMoneyTransferOrder;
    }

    public Currency() {

    }

    public Currency(int AreaId, String CurrencyName, String CurrencyAbbrivation, String CurrencySymbol) {
        this.CurrencyId = CurrencyId;
        this.CurrencyName = CurrencyName;
        this.CurrencyAbbrivation = CurrencyAbbrivation;
        this.CurrencySymbol = CurrencySymbol;

    }

    public String getCurrencyName() {
        return CurrencyName;
    }

    public String getCurrencyOrder() {
        return CurrencyOrder;
    }

    public void setCurrencyOrder(String currencyOrder) {
        CurrencyOrder = currencyOrder;
    }

    public String getRbirate() {
        return Rbirate;
    }

    public void setRbirate(String rbirate) {
        Rbirate = rbirate;
    }

    public String getBuyRate() {
        return BuyRate;
    }

    public void setBuyRate(String buyRate) {
        BuyRate = buyRate;
    }

    public String getSellRate() {
        return SellRate;
    }

    public void setSellRate(String sellRate) {
        SellRate = sellRate;
    }

    public String getProductcardoptions() {
        return Productcardoptions;
    }

    public void setProductcardoptions(String productcardoptions) {
        Productcardoptions = productcardoptions;
    }

    public String getCurrencyAbbrivation() {
        return CurrencyAbbrivation;
    }
    public String getCurrencySymbol() {
        return CurrencySymbol;
    }
    public int getCurrencyId() {
        return CurrencyId;
    }


    public void setCurrencyName(String CurrencyName) {
        this.CurrencyName = CurrencyName;
    }
    public void setCurrencySymbol(String CurrencySymbol) {
        this.CurrencySymbol = CurrencySymbol;
    }
    public void setCurrencyAbbrivation(String CurrencyAbbrivation) {
        this.CurrencyAbbrivation = CurrencyAbbrivation;
    }
    public void setCurrencyId(int CurrencyId) {
        this.CurrencyId = CurrencyId;
    }


}
