package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 9/13/2017.
 */

public class Country implements Serializable {
    private String countryid;
    private String countryname;
    private String countryflagimgname;
    private String countrymobcode;
    private String countryorder;
    public Country() {
    }
    public Country(String countryid,String countryname,String countryflagimgname,String countrymobcode,String countryorder )
    {
        this.countryid = countryid;
        this.countryname = countryname;
        this.countryflagimgname = countryflagimgname;
        this.countrymobcode = countrymobcode;
        this.countryorder = countryorder;

    }



    public String getCountryid() {
        return countryid;
    }

    public void setCountryid(String countryid) {
        this.countryid = countryid;
    }

    public String getCountryname() {
        return countryname;
    }

    public void setCountryname(String countryname) {
        this.countryname = countryname;
    }

    public String getCountryflagimgname() {
        return countryflagimgname;
    }

    public void setCountryflagimgname(String countryflagimgname) {
        this.countryflagimgname = countryflagimgname;
    }

    public String getCountrymobcode() {
        return countrymobcode;
    }

    public void setCountrymobcode(String countrymobcode) {
        this.countrymobcode = countrymobcode;
    }

    public String getCountryorder() {
        return countryorder;
    }

    public void setCountryorder(String countryorder) {
        this.countryorder = countryorder;
    }
}
