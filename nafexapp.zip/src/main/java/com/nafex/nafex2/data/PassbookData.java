package com.nafex.nafex2.data;

/**
 * Created by Sunil on 5/13/2017.
 */
public class PassbookData {
    String date;
    String desc;
    String db;
    String cr;
    String NBCno;
    String bankname;
    String TDSAmount;
    String transactionReferenceId;
    String transactionMode;

    public PassbookData() {
    }


    public PassbookData(String date, String desc, String db, String cr, String NBCno) {
        this.date = date;
        this.desc = desc;
        this.db = db;
        this.cr = cr;
        this.NBCno = NBCno;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getDb() {
        return db;
    }

    public void setDb(String db) {
        this.db = db;
    }

    public String getCr() {
        return cr;
    }

    public void setCr(String cr) {
        this.cr = cr;
    }

    public String getNBCno() {
        return NBCno;
    }

    public void setNBCno(String NBCno) {
        this.NBCno = NBCno;
    }

    public String getBankname() {
        return bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname;
    }

    public String getTDSAmount() {
        return TDSAmount;
    }

    public void setTDSAmount(String TDSAmount) {
        this.TDSAmount = TDSAmount;
    }

    public String getTransactionReferenceId() {
        return transactionReferenceId;
    }

    public void setTransactionReferenceId(String transactionReferenceId) {
        this.transactionReferenceId = transactionReferenceId;
    }

    public String getTransactionMode() {
        return transactionMode;
    }

    public void setTransactionMode(String transactionMode) {
        this.transactionMode = transactionMode;
    }
}
