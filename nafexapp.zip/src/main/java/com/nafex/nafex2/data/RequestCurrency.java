package com.nafex.nafex2.data;

/**
 * Created by Sunil on 9/12/2017.
 */
public class RequestCurrency {
    String  requestProductTypeId;
    String requestQuantity;
    String requestProductTypeName ;

    public RequestCurrency(String requestProductTypeId, String requestQuantity, String requestProductTypeName) {
        this.requestProductTypeId = requestProductTypeId;
        this.requestQuantity = requestQuantity;
        this.requestProductTypeName = requestProductTypeName;
    }


    public String getRequestProductTypeId() {
        return requestProductTypeId;
    }

    public void setRequestProductTypeId(String requestProductTypeId) {
        this.requestProductTypeId = requestProductTypeId;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestProductTypeName() {
        return requestProductTypeName;
    }

    public void setRequestProductTypeName(String requestProductTypeName) {
        this.requestProductTypeName = requestProductTypeName;
    }
}
