package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by torinit01 on 5/9/16.
 */
public class BidRequest implements Serializable {

    private int requestId, reqQuantity, reqWinnerFFMCId,requestBidId,	requestBidAcceptedSource,	requestBidAcceptedUserId;
    private String currencyAbbrivation, Type, reqStatus, NBC, Mode, AreaName, RequestDate, Remaining;
    private Double reqWinnerRate;

    public int getRequestBidAcceptedSource() {
        return requestBidAcceptedSource;
    }

    public void setRequestBidAcceptedSource(int requestBidAcceptedSource) {
        this.requestBidAcceptedSource = requestBidAcceptedSource;
    }

    public int getRequestBidAcceptedUserId() {
        return requestBidAcceptedUserId;
    }

    public void setRequestBidAcceptedUserId(int requestBidAcceptedUserId) {
        this.requestBidAcceptedUserId = requestBidAcceptedUserId;
    }

    public int getRequestBidId() {
        return requestBidId;
    }

    public void setRequestBidId(int requestBidId) {
        this.requestBidId = requestBidId;
    }

    public BidRequest(int id, String NBC, int QTY, int FFMCId, Double FFMCRate, String Status, String Type, String Mode, String AreaName, String RequestDate, String Abbrivation, String Remaining) {
        this.requestId = id;
        this.NBC = NBC;
        this.reqQuantity = QTY;
        this.reqStatus = Status;
        this.reqWinnerFFMCId = FFMCId;

        this.reqWinnerRate = FFMCRate;
        this.reqStatus = Status;
        this.Type = Type;
        this.Mode = Mode;
        this.AreaName = AreaName;
        this.RequestDate = RequestDate;
        this.currencyAbbrivation = Abbrivation;
        this.Remaining = Remaining;
    }

    public BidRequest()
    {

    }

    public String getcurrencyAbbrivation() {
        return currencyAbbrivation;
    }
    public String getType() {
        return Type;
    }
    public String getreqStatus() {
        return reqStatus;
    }
    public String getDispMode() {

        if (Mode.equalsIgnoreCase("DELEVIRY"))
            return "Home Delivery";
        else if (Mode.equalsIgnoreCase("PICKUP"))
            return "Pick-up";
        return Mode;
    }
    public String getNBC() {
        return NBC;
    }
    public String getMode() {
        return Mode;
    }
    public String getRemaining() {
        return Remaining;
    }
    public String getAreaName() {
        return AreaName;
    }
    public String getRequestDate() {
        return RequestDate;
    }
    public int getRequestId() {
        return requestId;
    }
    public int getreqQuantity() {
        return reqQuantity;
    }
    public int getreqWinnerFFMCId() {
        return reqWinnerFFMCId;
    }
    public Double getreqWinnerRate() {
        return reqWinnerRate;
    }

    public void setcurrencyAbbrivation(String currencyAbbrivation) {
        this.currencyAbbrivation = currencyAbbrivation;
    }

    public void setMode(String Mode) {
        this.Mode = Mode;
    }
    public void setRemaining(String Remaining) {
        this.Remaining = Remaining;
    }
    public void setType(String Type) {
        this.Type = Type;
    }
    public void setRequestDate(String RequestDate) {
        this.RequestDate = RequestDate;
    }
    public void setAreaName(String AreaName) {
        this.AreaName = AreaName;
    }
    public void setreqStatus(String reqStatus) {
        this.reqStatus = reqStatus;
    }
    public void setNBC(String NBC) {
        this.NBC = NBC;
    }
    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }
    public void setreqQuantity(int reqQuantity) {
        this.reqQuantity = reqQuantity;
    }
    public void setreqWinnerFFMCId(int reqWinnerFFMCId) {
        this.reqWinnerFFMCId = reqWinnerFFMCId;
    }
    public void setreqWinnerRate(Double FFMCRate) {
        this.reqWinnerRate = reqWinnerRate;
    }


}
