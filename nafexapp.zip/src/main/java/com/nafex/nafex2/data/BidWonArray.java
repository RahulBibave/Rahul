package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by rahul on 9/2/18.
 */

public class BidWonArray implements Serializable {
    String requestBidRate,requestQuantity,productName,reuestProductTypeId;

    public BidWonArray(String requestBidRate, String requestQuantity, String productName, String reuestProductTypeId) {
        this.requestBidRate = requestBidRate;
        this.requestQuantity = requestQuantity;
        this.productName = productName;
        this.reuestProductTypeId = reuestProductTypeId;
    }

    public String getRequestBidRate() {
        return requestBidRate;
    }

    public void setRequestBidRate(String requestBidRate) {
        this.requestBidRate = requestBidRate;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getReuestProductTypeId() {
        return reuestProductTypeId;
    }

    public void setReuestProductTypeId(String reuestProductTypeId) {
        this.reuestProductTypeId = reuestProductTypeId;
    }
}
