package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 9/28/2017.
 */

public class DocumentType implements Serializable{
    private String codevalue;
    private String codeName;
    private String codeAtrribute;


    public String getCodevalue() {
        return codevalue;
    }

    public void setCodevalue(String codevalue) {
        this.codevalue = codevalue;
    }

    public String getCodeName() {
        return codeName;
    }

    public void setCodeName(String codeName) {
        this.codeName = codeName;
    }

    public String getCodeAtrribute() {
        return codeAtrribute;
    }

    public void setCodeAtrribute(String codeAtrribute) {
        this.codeAtrribute = codeAtrribute;
    }

    public DocumentType() {
    }

    public DocumentType(String codevalue, String codename, String codeAttibute) {
        this.codevalue = codevalue;
        this.codeName = codename;
        this.codeAtrribute = codeAttibute;

    }




}
