package com.nafex.nafex2.data;

/**
 * Created by Sunil on 9/12/2017.
 */
public class RequestProduct {

    String productTypeId;
    String productQuantity;
    String productRate;

    public RequestProduct(String productTypeId, String productQuantity, String productRate) {
        this.productTypeId = productTypeId;
        this.productQuantity = productQuantity;
        this.productRate = productRate;
    }

    public String getProductTypeId() {
        return productTypeId;
    }

    public void setProductTypeId(String productTypeId) {
        this.productTypeId = productTypeId;
    }

    public String getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity) {
        this.productQuantity = productQuantity;
    }

    public String getProductRate() {
        return productRate;
    }

    public void setProductRate(String productRate) {
        this.productRate = productRate;
    }
}
