package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 9/12/2017.
 */

public class Product implements Serializable {
    private String CodeValue;
    private String CodeName;
    private String CodeAtrribute;

    public Product() {
    }

    public Product( String CodeValue, String CodeName,String CodeAtrribute) {
        this.CodeValue = CodeValue;
        this.CodeName = CodeName;
        this.CodeAtrribute=CodeAtrribute;
    }

    public String getCodeValue() {
        return CodeValue;
    }

    public void setCodeValue(String codeValue) {
        CodeValue = codeValue;
    }

    public String getCodeName() {
        return CodeName;
    }

    public void setCodeName(String codeName) {
        CodeName = codeName;
    }

    public String getCodeAtrribute() {
        return CodeAtrribute;
    }

    public void setCodeAtrribute(String codeAtrribute) {
        CodeAtrribute = codeAtrribute;
    }
}
