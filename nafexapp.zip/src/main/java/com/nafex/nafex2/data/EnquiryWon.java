package com.nafex.nafex2.data;

import java.util.ArrayList;

/**
 * Created by Sunil on 9/13/2017.
 */
public class EnquiryWon {

    String requestId,requestType,requestSourceCurrencyId,requestTargetCurrencyId,requestDeliveryMode,requestAreaId,requestCityId,requestStateId,
            requestCountryId,requestLeadSourceId,requestSourceRefId,requestSourceRef,requestNBC,requestStatusId,requestSMSStatusId,
            requestEmailStatusId,requestDisputeId,requestWinnerFFMCId,requestAcceptedBidId,requestBidAcceptedDateTime,requestBidAcceptedSource,
            requestOpraterId,requestBidAcceptedUserId,createdById,lastModifiedById,requestLat,requestLong,remaining,lastModifiedOn,
            requestUserId,userName,userMobileNo,requestTypeName,requestDeliveryModeName,requestLeadSourceName,requestStatusName,requestSourceCurrencyName,
            requestTargetCurrencyName,countryName,stateName,cityName,areaName,requestDisputeNameN,requestCSSClass,requestProductTypeId,
            requestQuantity,requestProductTypeName,requestTypeIdClass,requestDeliveryModeClass,requestLeadSourceIdClass,requestSourceRefIdClass,
            ProductTypeClass,requestProductTypeId_2,
            requestQuantity_2,requestProductTypeName_2,avarageRate,commissionAmount,distance,
            requestBidRate,requestBidQuantity,productName,reuestProductTypeId ,requestBidRate1,requestBidQuantity1,productName1,reuestProductTypeId1,size;
    ArrayList<RequestCurrency>currencyArrayList;

    public String getRequestBidRate1() {
        return requestBidRate1;
    }

    public void setRequestBidRate1(String requestBidRate1) {
        this.requestBidRate1 = requestBidRate1;
    }

    public String getRequestBidQuantity1() {
        return requestBidQuantity1;
    }

    public void setRequestBidQuantity1(String requestBidQuantity1) {
        this.requestBidQuantity1 = requestBidQuantity1;
    }

    public String getProductName1() {
        return productName1;
    }

    public void setProductName1(String productName1) {
        this.productName1 = productName1;
    }

    public String getReuestProductTypeId1() {
        return reuestProductTypeId1;
    }

    public void setReuestProductTypeId1(String reuestProductTypeId1) {
        this.reuestProductTypeId1 = reuestProductTypeId1;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestSourceCurrencyId() {
        return requestSourceCurrencyId;
    }

    public void setRequestSourceCurrencyId(String requestSourceCurrencyId) {
        this.requestSourceCurrencyId = requestSourceCurrencyId;
    }

    public String getRequestTargetCurrencyId() {
        return requestTargetCurrencyId;
    }

    public void setRequestTargetCurrencyId(String requestTargetCurrencyId) {
        this.requestTargetCurrencyId = requestTargetCurrencyId;
    }

    public String getRequestDeliveryMode() {
        return requestDeliveryMode;
    }

    public void setRequestDeliveryMode(String requestDeliveryMode) {
        this.requestDeliveryMode = requestDeliveryMode;
    }

    public String getRequestAreaId() {
        return requestAreaId;
    }

    public void setRequestAreaId(String requestAreaId) {
        this.requestAreaId = requestAreaId;
    }

    public String getRequestCityId() {
        return requestCityId;
    }

    public void setRequestCityId(String requestCityId) {
        this.requestCityId = requestCityId;
    }

    public String getRequestStateId() {
        return requestStateId;
    }

    public void setRequestStateId(String requestStateId) {
        this.requestStateId = requestStateId;
    }

    public String getRequestCountryId() {
        return requestCountryId;
    }

    public void setRequestCountryId(String requestCountryId) {
        this.requestCountryId = requestCountryId;
    }

    public String getRequestLeadSourceId() {
        return requestLeadSourceId;
    }

    public void setRequestLeadSourceId(String requestLeadSourceId) {
        this.requestLeadSourceId = requestLeadSourceId;
    }

    public String getRequestSourceRefId() {
        return requestSourceRefId;
    }

    public void setRequestSourceRefId(String requestSourceRefId) {
        this.requestSourceRefId = requestSourceRefId;
    }

    public String getRequestSourceRef() {
        return requestSourceRef;
    }

    public void setRequestSourceRef(String requestSourceRef) {
        this.requestSourceRef = requestSourceRef;
    }

    public String getRequestNBC() {
        return requestNBC;
    }

    public void setRequestNBC(String requestNBC) {
        this.requestNBC = requestNBC;
    }

    public String getRequestStatusId() {
        return requestStatusId;
    }

    public void setRequestStatusId(String requestStatusId) {
        this.requestStatusId = requestStatusId;
    }

    public String getRequestSMSStatusId() {
        return requestSMSStatusId;
    }

    public void setRequestSMSStatusId(String requestSMSStatusId) {
        this.requestSMSStatusId = requestSMSStatusId;
    }

    public String getRequestEmailStatusId() {
        return requestEmailStatusId;
    }

    public void setRequestEmailStatusId(String requestEmailStatusId) {
        this.requestEmailStatusId = requestEmailStatusId;
    }

    public String getRequestDisputeId() {
        return requestDisputeId;
    }

    public void setRequestDisputeId(String requestDisputeId) {
        this.requestDisputeId = requestDisputeId;
    }

    public String getRequestWinnerFFMCId() {
        return requestWinnerFFMCId;
    }

    public void setRequestWinnerFFMCId(String requestWinnerFFMCId) {
        this.requestWinnerFFMCId = requestWinnerFFMCId;
    }

    public String getRequestAcceptedBidId() {
        return requestAcceptedBidId;
    }

    public void setRequestAcceptedBidId(String requestAcceptedBidId) {
        this.requestAcceptedBidId = requestAcceptedBidId;
    }

    public String getRequestBidAcceptedDateTime() {
        return requestBidAcceptedDateTime;
    }

    public void setRequestBidAcceptedDateTime(String requestBidAcceptedDateTime) {
        this.requestBidAcceptedDateTime = requestBidAcceptedDateTime;
    }

    public String getRequestBidAcceptedSource() {
        return requestBidAcceptedSource;
    }

    public void setRequestBidAcceptedSource(String requestBidAcceptedSource) {
        this.requestBidAcceptedSource = requestBidAcceptedSource;
    }

    public String getRequestOpraterId() {
        return requestOpraterId;
    }

    public void setRequestOpraterId(String requestOpraterId) {
        this.requestOpraterId = requestOpraterId;
    }

    public String getRequestBidAcceptedUserId() {
        return requestBidAcceptedUserId;
    }

    public void setRequestBidAcceptedUserId(String requestBidAcceptedUserId) {
        this.requestBidAcceptedUserId = requestBidAcceptedUserId;
    }

    public String getCreatedById() {
        return createdById;
    }

    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    public String getLastModifiedById() {
        return lastModifiedById;
    }

    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    public String getRequestLat() {
        return requestLat;
    }

    public void setRequestLat(String requestLat) {
        this.requestLat = requestLat;
    }

    public String getRequestLong() {
        return requestLong;
    }

    public void setRequestLong(String requestLong) {
        this.requestLong = requestLong;
    }

    public String getRemaining() {
        return remaining;
    }

    public void setRemaining(String remaining) {
        this.remaining = remaining;
    }

    public String getLastModifiedOn() {
        return lastModifiedOn;
    }

    public void setLastModifiedOn(String lastModifiedOn) {
        this.lastModifiedOn = lastModifiedOn;
    }

    public String getRequestUserId() {
        return requestUserId;
    }

    public void setRequestUserId(String requestUserId) {
        this.requestUserId = requestUserId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserMobileNo() {
        return userMobileNo;
    }

    public void setUserMobileNo(String userMobileNo) {
        this.userMobileNo = userMobileNo;
    }

    public String getRequestTypeName() {
        return requestTypeName;
    }

    public void setRequestTypeName(String requestTypeName) {
        this.requestTypeName = requestTypeName;
    }

    public String getRequestDeliveryModeName() {
        return requestDeliveryModeName;
    }

    public void setRequestDeliveryModeName(String requestDeliveryModeName) {
        this.requestDeliveryModeName = requestDeliveryModeName;
    }

    public String getRequestLeadSourceName() {
        return requestLeadSourceName;
    }

    public void setRequestLeadSourceName(String requestLeadSourceName) {
        this.requestLeadSourceName = requestLeadSourceName;
    }

    public String getRequestStatusName() {
        return requestStatusName;
    }

    public void setRequestStatusName(String requestStatusName) {
        this.requestStatusName = requestStatusName;
    }

    public String getRequestSourceCurrencyName() {
        return requestSourceCurrencyName;
    }

    public void setRequestSourceCurrencyName(String requestSourceCurrencyName) {
        this.requestSourceCurrencyName = requestSourceCurrencyName;
    }

    public String getRequestTargetCurrencyName() {
        return requestTargetCurrencyName;
    }

    public void setRequestTargetCurrencyName(String requestTargetCurrencyName) {
        this.requestTargetCurrencyName = requestTargetCurrencyName;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getRequestDisputeNameN() {
        return requestDisputeNameN;
    }

    public void setRequestDisputeNameN(String requestDisputeNameN) {
        this.requestDisputeNameN = requestDisputeNameN;
    }

    public String getRequestCSSClass() {
        return requestCSSClass;
    }

    public void setRequestCSSClass(String requestCSSClass) {
        this.requestCSSClass = requestCSSClass;
    }

    public String getRequestProductTypeId() {
        return requestProductTypeId;
    }

    public void setRequestProductTypeId(String requestProductTypeId) {
        this.requestProductTypeId = requestProductTypeId;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestProductTypeName() {
        return requestProductTypeName;
    }

    public void setRequestProductTypeName(String requestProductTypeName) {
        this.requestProductTypeName = requestProductTypeName;
    }

    public String getRequestTypeIdClass() {
        return requestTypeIdClass;
    }

    public void setRequestTypeIdClass(String requestTypeIdClass) {
        this.requestTypeIdClass = requestTypeIdClass;
    }

    public String getRequestDeliveryModeClass() {
        return requestDeliveryModeClass;
    }

    public void setRequestDeliveryModeClass(String requestDeliveryModeClass) {
        this.requestDeliveryModeClass = requestDeliveryModeClass;
    }

    public String getRequestLeadSourceIdClass() {
        return requestLeadSourceIdClass;
    }

    public void setRequestLeadSourceIdClass(String requestLeadSourceIdClass) {
        this.requestLeadSourceIdClass = requestLeadSourceIdClass;
    }

    public String getRequestSourceRefIdClass() {
        return requestSourceRefIdClass;
    }

    public void setRequestSourceRefIdClass(String requestSourceRefIdClass) {
        this.requestSourceRefIdClass = requestSourceRefIdClass;
    }

    public String getProductTypeClass() {
        return ProductTypeClass;
    }

    public void setProductTypeClass(String productTypeClass) {
        ProductTypeClass = productTypeClass;
    }

    public String getRequestProductTypeId_2() {
        return requestProductTypeId_2;
    }

    public void setRequestProductTypeId_2(String requestProductTypeId_2) {
        this.requestProductTypeId_2 = requestProductTypeId_2;
    }

    public String getRequestQuantity_2() {
        return requestQuantity_2;
    }

    public void setRequestQuantity_2(String requestQuantity_2) {
        this.requestQuantity_2 = requestQuantity_2;
    }

    public String getRequestProductTypeName_2() {
        return requestProductTypeName_2;
    }

    public void setRequestProductTypeName_2(String requestProductTypeName_2) {
        this.requestProductTypeName_2 = requestProductTypeName_2;
    }

    public String getAvarageRate() {
        return avarageRate;
    }

    public void setAvarageRate(String avarageRate) {
        this.avarageRate = avarageRate;
    }

    public String getCommissionAmount() {
        return commissionAmount;
    }

    public void setCommissionAmount(String commissionAmount) {
        this.commissionAmount = commissionAmount;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getRequestBidRate() {
        return requestBidRate;
    }

    public void setRequestBidRate(String requestBidRate) {
        this.requestBidRate = requestBidRate;
    }

    public String getRequestBidQuantity() {
        return requestBidQuantity;
    }

    public void setRequestBidQuantity(String requestBidQuantity) {
        this.requestBidQuantity = requestBidQuantity;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getReuestProductTypeId() {
        return reuestProductTypeId;
    }

    public void setReuestProductTypeId(String reuestProductTypeId) {
        this.reuestProductTypeId = reuestProductTypeId;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public ArrayList<RequestCurrency> getCurrencyArrayList() {
        return currencyArrayList;
    }

    public void setCurrencyArrayList(ArrayList<RequestCurrency> currencyArrayList) {
        this.currencyArrayList = currencyArrayList;
    }

    public EnquiryWon(String requestId, String requestType, String requestSourceCurrencyId, String requestTargetCurrencyId, String requestDeliveryMode, String requestAreaId, String requestCityId, String requestStateId, String requestCountryId, String requestLeadSourceId, String requestSourceRefId, String requestSourceRef, String requestNBC, String requestStatusId, String requestSMSStatusId, String requestEmailStatusId, String requestDisputeId, String requestWinnerFFMCId, String requestAcceptedBidId, String requestBidAcceptedDateTime, String requestBidAcceptedSource, String requestOpraterId, String requestBidAcceptedUserId, String createdById, String lastModifiedById, String requestLat, String requestLong, String remaining, String lastModifiedOn, String requestUserId, String userName, String userMobileNo, String requestTypeName, String requestDeliveryModeName, String requestLeadSourceName, String requestStatusName, String requestSourceCurrencyName, String requestTargetCurrencyName, String countryName, String stateName, String cityName, String areaName, String requestDisputeNameN, String requestCSSClass, String requestProductTypeId, String requestQuantity, String requestProductTypeName, String requestTypeIdClass, String requestDeliveryModeClass, String requestLeadSourceIdClass, String requestSourceRefIdClass, String productTypeClass, String requestProductTypeId_2, String requestQuantity_2, String requestProductTypeName_2, String avarageRate, String commissionAmount, String distance, String requestBidRate, String requestBidQuantity, String productName, String reuestProductTypeId, String requestBidRate1, String requestBidQuantity1, String productName1, String reuestProductTypeId1, String size) {
        this.requestId = requestId;
        this.requestType = requestType;
        this.requestSourceCurrencyId = requestSourceCurrencyId;
        this.requestTargetCurrencyId = requestTargetCurrencyId;
        this.requestDeliveryMode = requestDeliveryMode;
        this.requestAreaId = requestAreaId;
        this.requestCityId = requestCityId;
        this.requestStateId = requestStateId;
        this.requestCountryId = requestCountryId;
        this.requestLeadSourceId = requestLeadSourceId;
        this.requestSourceRefId = requestSourceRefId;
        this.requestSourceRef = requestSourceRef;
        this.requestNBC = requestNBC;
        this.requestStatusId = requestStatusId;
        this.requestSMSStatusId = requestSMSStatusId;
        this.requestEmailStatusId = requestEmailStatusId;
        this.requestDisputeId = requestDisputeId;
        this.requestWinnerFFMCId = requestWinnerFFMCId;
        this.requestAcceptedBidId = requestAcceptedBidId;
        this.requestBidAcceptedDateTime = requestBidAcceptedDateTime;
        this.requestBidAcceptedSource = requestBidAcceptedSource;
        this.requestOpraterId = requestOpraterId;
        this.requestBidAcceptedUserId = requestBidAcceptedUserId;
        this.createdById = createdById;
        this.lastModifiedById = lastModifiedById;
        this.requestLat = requestLat;
        this.requestLong = requestLong;
        this.remaining = remaining;
        this.lastModifiedOn = lastModifiedOn;
        this.requestUserId = requestUserId;
        this.userName = userName;
        this.userMobileNo = userMobileNo;
        this.requestTypeName = requestTypeName;
        this.requestDeliveryModeName = requestDeliveryModeName;
        this.requestLeadSourceName = requestLeadSourceName;
        this.requestStatusName = requestStatusName;
        this.requestSourceCurrencyName = requestSourceCurrencyName;
        this.requestTargetCurrencyName = requestTargetCurrencyName;
        this.countryName = countryName;
        this.stateName = stateName;
        this.cityName = cityName;
        this.areaName = areaName;
        this.requestDisputeNameN = requestDisputeNameN;
        this.requestCSSClass = requestCSSClass;
        this.requestProductTypeId = requestProductTypeId;
        this.requestQuantity = requestQuantity;
        this.requestProductTypeName = requestProductTypeName;
        this.requestTypeIdClass = requestTypeIdClass;
        this.requestDeliveryModeClass = requestDeliveryModeClass;
        this.requestLeadSourceIdClass = requestLeadSourceIdClass;
        this.requestSourceRefIdClass = requestSourceRefIdClass;
        ProductTypeClass = productTypeClass;
        this.requestProductTypeId_2 = requestProductTypeId_2;
        this.requestQuantity_2 = requestQuantity_2;
        this.requestProductTypeName_2 = requestProductTypeName_2;
        this.avarageRate = avarageRate;
        this.commissionAmount = commissionAmount;
        this.distance = distance;
        this.requestBidRate = requestBidRate;
        this.requestBidQuantity = requestBidQuantity;
        this.productName = productName;
        this.reuestProductTypeId = reuestProductTypeId;
        this.requestBidRate1 = requestBidRate1;
        this.requestBidQuantity1 = requestBidQuantity1;
        this.productName1 = productName1;
        this.reuestProductTypeId1 = reuestProductTypeId1;
        this.size = size;
    }
/* public EnquiryWon(String requestId, String requestType, String requestSourceCurrencyId, String requestTargetCurrencyId, String requestDeliveryMode, String requestAreaId, String requestCityId, String requestStateId, String requestCountryId, String requestLeadSourceId, String requestSourceRefId, String requestSourceRef, String requestNBC, String requestStatusId, String requestSMSStatusId, String requestEmailStatusId, String requestDisputeId, String requestWinnerFFMCId, String requestAcceptedBidId, String requestBidAcceptedDateTime, String requestBidAcceptedSource, String requestOpraterId, String requestBidAcceptedUserId, String createdById, String lastModifiedById, String requestLat, String requestLong, String remaining, String lastModifiedOn, String requestUserId, String userName, String userMobileNo, String requestTypeName, String requestDeliveryModeName, String requestLeadSourceName, String requestStatusName, String requestSourceCurrencyName, String requestTargetCurrencyName, String countryName, String stateName, String cityName, String areaName, String requestDisputeNameN, String requestCSSClass, String requestProductTypeId, String requestQuantity, String requestProductTypeName, String requestTypeIdClass, String requestDeliveryModeClass, String requestLeadSourceIdClass, String requestSourceRefIdClass, String productTypeClass, String requestProductTypeId_2, String requestQuantity_2, String requestProductTypeName_2,String avgRate,String commissionAmount,String distance) {
        this.requestId = requestId;
        this.requestType = requestType;
        this.requestSourceCurrencyId = requestSourceCurrencyId;
        this.requestTargetCurrencyId = requestTargetCurrencyId;
        this.requestDeliveryMode = requestDeliveryMode;
        this.requestAreaId = requestAreaId;
        this.requestCityId = requestCityId;
        this.requestStateId = requestStateId;
        this.requestCountryId = requestCountryId;
        this.requestLeadSourceId = requestLeadSourceId;
        this.requestSourceRefId = requestSourceRefId;
        this.requestSourceRef = requestSourceRef;
        this.requestNBC = requestNBC;
        this.requestStatusId = requestStatusId;
        this.requestSMSStatusId = requestSMSStatusId;
        this.requestEmailStatusId = requestEmailStatusId;
        this.requestDisputeId = requestDisputeId;
        this.requestWinnerFFMCId = requestWinnerFFMCId;
        this.requestAcceptedBidId = requestAcceptedBidId;
        this.requestBidAcceptedDateTime = requestBidAcceptedDateTime;
        this.requestBidAcceptedSource = requestBidAcceptedSource;
        this.requestOpraterId = requestOpraterId;
        this.requestBidAcceptedUserId = requestBidAcceptedUserId;
        this.createdById = createdById;
        this.lastModifiedById = lastModifiedById;
        this.requestLat = requestLat;
        this.requestLong = requestLong;
        this.remaining = remaining;
        this.lastModifiedOn = lastModifiedOn;
        this.requestUserId = requestUserId;
        this.userName = userName;
        this.userMobileNo = userMobileNo;
        this.requestTypeName = requestTypeName;
        this.requestDeliveryModeName = requestDeliveryModeName;
        this.requestLeadSourceName = requestLeadSourceName;
        this.requestStatusName = requestStatusName;
        this.requestSourceCurrencyName = requestSourceCurrencyName;
        this.requestTargetCurrencyName = requestTargetCurrencyName;
        this.countryName = countryName;
        this.stateName = stateName;
        this.cityName = cityName;
        this.areaName = areaName;
        this.requestDisputeNameN = requestDisputeNameN;
        this.requestCSSClass = requestCSSClass;
        this.requestProductTypeId = requestProductTypeId;
        this.requestQuantity = requestQuantity;
        this.requestProductTypeName = requestProductTypeName;
        this.requestTypeIdClass = requestTypeIdClass;
        this.requestDeliveryModeClass = requestDeliveryModeClass;
        this.requestLeadSourceIdClass = requestLeadSourceIdClass;
        this.requestSourceRefIdClass = requestSourceRefIdClass;
        ProductTypeClass = productTypeClass;
        this.requestProductTypeId_2 = requestProductTypeId_2;
        this.requestQuantity_2 = requestQuantity_2;
        this.requestProductTypeName_2 = requestProductTypeName_2;
        this.avarageRate=avgRate;
        this.commissionAmount=commissionAmount;
        this.distance=distance;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCreatedById() {
        return createdById;
    }

    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    public String getLastModifiedById() {
        return lastModifiedById;
    }

    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    public String getLastModifiedOn() {
        return lastModifiedOn;
    }

    public void setLastModifiedOn(String lastModifiedOn) {
        this.lastModifiedOn = lastModifiedOn;
    }

    public String getProductTypeClass() {
        return ProductTypeClass;
    }

    public void setProductTypeClass(String productTypeClass) {
        ProductTypeClass = productTypeClass;
    }

    public String getRemaining() {
        return remaining;
    }

    public void setRemaining(String remaining) {
        this.remaining = remaining;
    }

    public String getRequestAcceptedBidId() {
        return requestAcceptedBidId;
    }

    public void setRequestAcceptedBidId(String requestAcceptedBidId) {
        this.requestAcceptedBidId = requestAcceptedBidId;
    }

    public String getRequestAreaId() {
        return requestAreaId;
    }

    public void setRequestAreaId(String requestAreaId) {
        this.requestAreaId = requestAreaId;
    }

    public String getRequestBidAcceptedDateTime() {
        return requestBidAcceptedDateTime;
    }

    public void setRequestBidAcceptedDateTime(String requestBidAcceptedDateTime) {
        this.requestBidAcceptedDateTime = requestBidAcceptedDateTime;
    }

    public String getRequestBidAcceptedSource() {
        return requestBidAcceptedSource;
    }

    public void setRequestBidAcceptedSource(String requestBidAcceptedSource) {
        this.requestBidAcceptedSource = requestBidAcceptedSource;
    }

    public String getRequestBidAcceptedUserId() {
        return requestBidAcceptedUserId;
    }

    public void setRequestBidAcceptedUserId(String requestBidAcceptedUserId) {
        this.requestBidAcceptedUserId = requestBidAcceptedUserId;
    }

    public String getRequestCityId() {
        return requestCityId;
    }

    public void setRequestCityId(String requestCityId) {
        this.requestCityId = requestCityId;
    }

    public String getRequestCountryId() {
        return requestCountryId;
    }

    public void setRequestCountryId(String requestCountryId) {
        this.requestCountryId = requestCountryId;
    }

    public String getRequestCSSClass() {
        return requestCSSClass;
    }

    public void setRequestCSSClass(String requestCSSClass) {
        this.requestCSSClass = requestCSSClass;
    }

    public String getRequestDeliveryMode() {
        return requestDeliveryMode;
    }

    public void setRequestDeliveryMode(String requestDeliveryMode) {
        this.requestDeliveryMode = requestDeliveryMode;
    }

    public String getRequestDeliveryModeClass() {
        return requestDeliveryModeClass;
    }

    public void setRequestDeliveryModeClass(String requestDeliveryModeClass) {
        this.requestDeliveryModeClass = requestDeliveryModeClass;
    }

    public String getRequestDeliveryModeName() {
        return requestDeliveryModeName;
    }

    public void setRequestDeliveryModeName(String requestDeliveryModeName) {
        this.requestDeliveryModeName = requestDeliveryModeName;
    }

    public String getRequestDisputeId() {
        return requestDisputeId;
    }

    public void setRequestDisputeId(String requestDisputeId) {
        this.requestDisputeId = requestDisputeId;
    }

    public String getRequestDisputeNameN() {
        return requestDisputeNameN;
    }

    public void setRequestDisputeNameN(String requestDisputeNameN) {
        this.requestDisputeNameN = requestDisputeNameN;
    }

    public String getRequestEmailStatusId() {
        return requestEmailStatusId;
    }

    public void setRequestEmailStatusId(String requestEmailStatusId) {
        this.requestEmailStatusId = requestEmailStatusId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestLat() {
        return requestLat;
    }

    public void setRequestLat(String requestLat) {
        this.requestLat = requestLat;
    }

    public String getRequestLeadSourceId() {
        return requestLeadSourceId;
    }

    public void setRequestLeadSourceId(String requestLeadSourceId) {
        this.requestLeadSourceId = requestLeadSourceId;
    }

    public String getRequestLeadSourceIdClass() {
        return requestLeadSourceIdClass;
    }

    public void setRequestLeadSourceIdClass(String requestLeadSourceIdClass) {
        this.requestLeadSourceIdClass = requestLeadSourceIdClass;
    }

    public String getRequestLeadSourceName() {
        return requestLeadSourceName;
    }

    public void setRequestLeadSourceName(String requestLeadSourceName) {
        this.requestLeadSourceName = requestLeadSourceName;
    }

    public String getRequestLong() {
        return requestLong;
    }

    public void setRequestLong(String requestLong) {
        this.requestLong = requestLong;
    }

    public String getRequestNBC() {
        return requestNBC;
    }

    public void setRequestNBC(String requestNBC) {
        this.requestNBC = requestNBC;
    }

    public String getRequestOpraterId() {
        return requestOpraterId;
    }

    public void setRequestOpraterId(String requestOpraterId) {
        this.requestOpraterId = requestOpraterId;
    }

    public String getRequestProductTypeId() {
        return requestProductTypeId;
    }

    public void setRequestProductTypeId(String requestProductTypeId) {
        this.requestProductTypeId = requestProductTypeId;
    }

    public String getRequestProductTypeId_2() {
        return requestProductTypeId_2;
    }

    public void setRequestProductTypeId_2(String requestProductTypeId_2) {
        this.requestProductTypeId_2 = requestProductTypeId_2;
    }

    public String getRequestProductTypeName() {
        return requestProductTypeName;
    }

    public void setRequestProductTypeName(String requestProductTypeName) {
        this.requestProductTypeName = requestProductTypeName;
    }

    public String getRequestProductTypeName_2() {
        return requestProductTypeName_2;
    }

    public void setRequestProductTypeName_2(String requestProductTypeName_2) {
        this.requestProductTypeName_2 = requestProductTypeName_2;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestQuantity_2() {
        return requestQuantity_2;
    }

    public void setRequestQuantity_2(String requestQuantity_2) {
        this.requestQuantity_2 = requestQuantity_2;
    }

    public String getRequestSMSStatusId() {
        return requestSMSStatusId;
    }

    public void setRequestSMSStatusId(String requestSMSStatusId) {
        this.requestSMSStatusId = requestSMSStatusId;
    }

    public String getRequestSourceCurrencyId() {
        return requestSourceCurrencyId;
    }

    public void setRequestSourceCurrencyId(String requestSourceCurrencyId) {
        this.requestSourceCurrencyId = requestSourceCurrencyId;
    }

    public String getRequestSourceCurrencyName() {
        return requestSourceCurrencyName;
    }

    public void setRequestSourceCurrencyName(String requestSourceCurrencyName) {
        this.requestSourceCurrencyName = requestSourceCurrencyName;
    }

    public String getRequestSourceRef() {
        return requestSourceRef;
    }

    public void setRequestSourceRef(String requestSourceRef) {
        this.requestSourceRef = requestSourceRef;
    }

    public String getRequestSourceRefId() {
        return requestSourceRefId;
    }

    public void setRequestSourceRefId(String requestSourceRefId) {
        this.requestSourceRefId = requestSourceRefId;
    }

    public String getRequestSourceRefIdClass() {
        return requestSourceRefIdClass;
    }

    public void setRequestSourceRefIdClass(String requestSourceRefIdClass) {
        this.requestSourceRefIdClass = requestSourceRefIdClass;
    }

    public String getRequestStateId() {
        return requestStateId;
    }

    public void setRequestStateId(String requestStateId) {
        this.requestStateId = requestStateId;
    }

    public String getRequestStatusId() {
        return requestStatusId;
    }

    public void setRequestStatusId(String requestStatusId) {
        this.requestStatusId = requestStatusId;
    }

    public String getRequestStatusName() {
        return requestStatusName;
    }

    public void setRequestStatusName(String requestStatusName) {
        this.requestStatusName = requestStatusName;
    }

    public String getRequestTargetCurrencyId() {
        return requestTargetCurrencyId;
    }

    public void setRequestTargetCurrencyId(String requestTargetCurrencyId) {
        this.requestTargetCurrencyId = requestTargetCurrencyId;
    }

    public String getRequestTargetCurrencyName() {
        return requestTargetCurrencyName;
    }

    public void setRequestTargetCurrencyName(String requestTargetCurrencyName) {
        this.requestTargetCurrencyName = requestTargetCurrencyName;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestTypeIdClass() {
        return requestTypeIdClass;
    }

    public void setRequestTypeIdClass(String requestTypeIdClass) {
        this.requestTypeIdClass = requestTypeIdClass;
    }

    public String getRequestTypeName() {
        return requestTypeName;
    }

    public void setRequestTypeName(String requestTypeName) {
        this.requestTypeName = requestTypeName;
    }

    public String getRequestUserId() {
        return requestUserId;
    }

    public void setRequestUserId(String requestUserId) {
        this.requestUserId = requestUserId;
    }

    public String getRequestWinnerFFMCId() {
        return requestWinnerFFMCId;
    }

    public void setRequestWinnerFFMCId(String requestWinnerFFMCId) {
        this.requestWinnerFFMCId = requestWinnerFFMCId;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getUserMobileNo() {
        return userMobileNo;
    }

    public void setUserMobileNo(String userMobileNo) {
        this.userMobileNo = userMobileNo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getAvarageRate() {
        return avarageRate;
    }

    public void setAvarageRate(String avarageRate) {
        this.avarageRate = avarageRate;
    }

    public String getCommissionAmount() {
        return commissionAmount;
    }

    public void setCommissionAmount(String commissionAmount) {
        this.commissionAmount = commissionAmount;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }*/
}
