package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 9/28/2017.
 */

public class OtherFieldType implements Serializable {
    private String id;
    private String masterTypeId;
    private String subTypeName;
    private String subTypeType;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMasterTypeId() {
        return masterTypeId;
    }

    public void setMasterTypeId(String masterTypeId) {
        this.masterTypeId = masterTypeId;
    }

    public String getSubTypeName() {
        return subTypeName;
    }

    public void setSubTypeName(String subTypeName) {
        this.subTypeName = subTypeName;
    }

    public String getSubTypeType() {
        return subTypeType;
    }

    public void setSubTypeType(String subTypeType) {
        this.subTypeType = subTypeType;
    }

    public OtherFieldType() {
    }

    public OtherFieldType(String id, String masterTypeId, String subTypeName,String subTypeType) {
        this.id = id;
        this.masterTypeId = masterTypeId;
        this.subTypeName = subTypeName;
        this.subTypeType = subTypeType;

    }


}
