package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 10/6/2017.
 */

public class DisputeComment implements Serializable {
String disputeCommentId;
String requestId;
String requestNBCNumber;
String disputeId;
String createdById;
String createdOn;
String callComment;
String callNextAction;

    public String getDisputeCommentId() {
        return disputeCommentId;
    }

    public void setDisputeCommentId(String disputeCommentId) {
        this.disputeCommentId = disputeCommentId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestNBCNumber() {
        return requestNBCNumber;
    }

    public void setRequestNBCNumber(String requestNBCNumber) {
        this.requestNBCNumber = requestNBCNumber;
    }

    public String getDisputeId() {
        return disputeId;
    }

    public void setDisputeId(String disputeId) {
        this.disputeId = disputeId;
    }

    public String getCreatedById() {
        return createdById;
    }

    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getCallComment() {
        return callComment;
    }

    public void setCallComment(String callComment) {
        this.callComment = callComment;
    }

    public String getCallNextAction() {
        return callNextAction;
    }

    public void setCallNextAction(String callNextAction) {
        this.callNextAction = callNextAction;
    }
}
