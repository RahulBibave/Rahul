package com.nafex.nafex2.data;

/**
 * Created by Sunil on 5/13/2017.
 */
public class EnquiriesData {
    int reqId;
    String NBC;
    String reqDateTime;
    String reqLocation;
    String reqCurrencyName;
    String reqMode;
    String reqStatus;
    String reqBidRate;
    String reqBidStatus;
    String reqQuantity;
    String reqType;

    public EnquiriesData(int id,String nbc, String type, String reqdatetime, String reqlocation, String reqcurrencyname, String reqmode,String reqstatus, String reqbidstatus, String reqbidrate, String qty) {
        this.reqId = id;
        this.NBC = nbc;
        this.reqDateTime = reqdatetime;
        this.reqLocation = reqlocation;
        this.reqCurrencyName = reqcurrencyname;
        this.reqMode = reqmode;
        this.reqStatus = reqstatus;
        this.reqBidRate = reqbidrate;
        this.reqBidStatus = reqbidstatus;
        this.reqQuantity = qty;
        this.reqType = type;

    }

   /* "reqId": "167",
            "Type": "BUY",
            "currencyId": "4",
            "currencyName": "Australian Dollars",
            "currencyAbbrivation": "AUD",
            "reqQuantity": "250",
            "reqWinnerFFMCId": "0",
            "Mode": "PICKUP",
            "reqStatus": "O",
            "AreaName": "Swargate",
            "reqSourceId": "1",
            "NBC": "NBC104357",
            "createdOn": "2017-05-23 02:55:35",
            "remaining": "218:24:16",
            "reqWinnerRate": null,
            "reqBidStatus": "BID_NOTDONE",
            "reqBidRate": "0.00"*/


    public int getreqId() {
        return reqId;
    }

    public void setReqId(int id) {
        reqId = id;
    }

    public String getNBC() {
        return NBC;
    }

    public void setNBC(String nbc) {
        NBC = nbc;
    }

    public String getReqDateTime() {
        return reqDateTime;
    }

    public void setReqDateTime(String strdatetime) {
        this.reqDateTime = strdatetime;
    }

    public String getreqLocation() {
        return reqLocation;
    }

    public void setreqLocation(String loc) {
        this.reqLocation = loc;
    }

    public String getreqCurrencyName() {
        return reqCurrencyName;
    }

    public void setreqCurrencyName(String currency) {
        this.reqCurrencyName = currency;
    }

    public String getreqMode() {
        return reqMode;
    }

    public void setreqMode(String delivery_status) {
        this.reqMode = delivery_status;
    }

    public String getreqStatus() {
        return reqStatus;
    }

    public void setreqStatus(String status) {
        this.reqStatus = status;
    }

    public String getreqBidRate() {
        return reqBidRate;
    }

    public void setreqBidRate(String bidrate) {
        this.reqBidRate = bidrate;
    }

    public String getreqBidStatus() {
        return reqBidStatus;
    }

    public void setreqBidStatus(String bidstatus) {
        this.reqBidStatus = bidstatus;
    }

    public String getreqQuantity() {
        return reqQuantity;
    }

    public void setreqQuantity(String qty) {
        this.reqQuantity = qty;
    }

    public String getreqType() {
        return reqType;
    }

    public void setreqType(String type) {
        this.reqType = type;
    }


}
