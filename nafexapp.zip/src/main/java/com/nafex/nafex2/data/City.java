package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by torinit01 on 5/9/16.
 */
public class City implements Serializable {

    private String CityName;
    private int CityId;

    public City() {
    }

    public City(int CityId, String CityName) {
        this.CityId = CityId;
        this.CityName = CityName;
    }

    public String getCityName() {
        return CityName;
    }

    public int getCityId() {
        return CityId;
    }


    public void setCityName(String CityName) {
        this.CityName = CityName;
    }

    public void setCityId(int CityId) {
        this.CityId = CityId;
    }


}
