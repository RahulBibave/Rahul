package com.nafex.nafex2.data;

import java.io.Serializable;

/**
 * Created by Swarup on 10/2/2017.
 */

public class DocType implements Serializable{
    public String id;
    public String userId;
    public String docTypeId;
    public String docTypeName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDocTypeId() {
        return docTypeId;
    }

    public void setDocTypeId(String docTypeId) {
        this.docTypeId = docTypeId;
    }

    public String getDocTypeName() {
        return docTypeName;
    }

    public void setDocTypeName(String docTypeName) {
        this.docTypeName = docTypeName;
    }

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getOtherTypeId() {
        return otherTypeId;
    }

    public void setOtherTypeId(String otherTypeId) {
        this.otherTypeId = otherTypeId;
    }

    public String getOtherTypeName() {
        return otherTypeName;
    }

    public void setOtherTypeName(String otherTypeName) {
        this.otherTypeName = otherTypeName;
    }

    public String getOtherTypeInfo() {
        return otherTypeInfo;
    }

    public void setOtherTypeInfo(String otherTypeInfo) {
        this.otherTypeInfo = otherTypeInfo;
    }

    public String getDocFile() {
        return docFile;
    }

    public void setDocFile(String docFile) {
        this.docFile = docFile;
    }

    public String docNumber;
    public String docName;
    public String otherTypeId;
    public String otherTypeName;
    public String otherTypeInfo;
    public String docFile;







}
