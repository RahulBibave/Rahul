package com.nafex.nafex2.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Swarup on 9/16/2017.
 */

public class CustomerRequest implements Serializable{
    public String bidId;

    public List<CustomerRequest> getRequest() {
        return request;
    }

    public void setRequest(List<CustomerRequest> request) {
        this.request = request;
    }

    public String bidFFMCId;
    public String ffmcAreaId;
    public String ffmcDistance;
    public String averageRate;

    List<CustomerRequest> request;
    public String averageAmount;

    public String getReuestProductTypeId() {
        return reuestProductTypeId;
    }

    public void setReuestProductTypeId(String reuestProductTypeId) {
        this.reuestProductTypeId = reuestProductTypeId;
    }

    public String getRequestQuantity() {
        return requestQuantity;
    }

    public void setRequestQuantity(String requestQuantity) {
        this.requestQuantity = requestQuantity;
    }

    public String getRequestBidRate() {
        return requestBidRate;
    }

    public void setRequestBidRate(String requestBidRate) {
        this.requestBidRate = requestBidRate;
    }

    public String reuestProductTypeId;
    public String requestQuantity;
    public String requestBidRate;

    public String reuestProductTypeId1;

    public String getReuestProductTypeId1() {
        return reuestProductTypeId1;
    }

    public void setReuestProductTypeId1(String reuestProductTypeId1) {
        this.reuestProductTypeId1 = reuestProductTypeId1;
    }

    public String getRequestQuantity1() {
        return requestQuantity1;
    }

    public void setRequestQuantity1(String requestQuantity1) {
        this.requestQuantity1 = requestQuantity1;
    }

    public String getRequestBidRate1() {
        return requestBidRate1;
    }

    public void setRequestBidRate1(String requestBidRate1) {
        this.requestBidRate1 = requestBidRate1;
    }

    public String requestQuantity1;
    public String requestBidRate1;



    public  List<CustomerRequest> con;


    public CustomerRequest() {
    }



    public CustomerRequest(String bidId, String bidFFMCId, String ffmcAreaId, String ffmcDistance, String averageRate, String averageAmount, String taxAmount, String deliveryCharges, String otherCharges, String remittanceCharges, String bidOperaterId, String createdById, String ffmcAreaName, List<CustomerRequest> con) {
        this.bidId = bidId;
        this.bidFFMCId = bidFFMCId;
        this.ffmcAreaId = ffmcAreaId;
        this.ffmcDistance = ffmcDistance;
        this.averageRate = averageRate;
        this.averageAmount = averageAmount;
        this.taxAmount = taxAmount;
        this.deliveryCharges = deliveryCharges;
        this.otherCharges = otherCharges;
        this.remittanceCharges = remittanceCharges;
        this.bidOperaterId = bidOperaterId;
        this.createdById = createdById;
        this.ffmcAreaName = ffmcAreaName;
        this.con=con;
    }

    public String getBidId() {
        return bidId;
    }

    public void setBidId(String bidId) {
        this.bidId = bidId;
    }

    public String getBidFFMCId() {
        return bidFFMCId;
    }

    public void setBidFFMCId(String bidFFMCId) {
        this.bidFFMCId = bidFFMCId;
    }

    public String getFfmcAreaId() {
        return ffmcAreaId;
    }

    public void setFfmcAreaId(String ffmcAreaId) {
        this.ffmcAreaId = ffmcAreaId;
    }

    public String getFfmcDistance() {
        return ffmcDistance;
    }

    public void setFfmcDistance(String ffmcDistance) {
        this.ffmcDistance = ffmcDistance;
    }

    public String getAverageRate() {
        return averageRate;
    }

    public void setAverageRate(String averageRate) {
        this.averageRate = averageRate;
    }

    public String getAverageAmount() {
        return averageAmount;
    }

    public void setAverageAmount(String averageAmount) {
        this.averageAmount = averageAmount;
    }

    public String getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(String taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getDeliveryCharges() {
        return deliveryCharges;
    }

    public void setDeliveryCharges(String deliveryCharges) {
        this.deliveryCharges = deliveryCharges;
    }

    public String getOtherCharges() {
        return otherCharges;
    }

    public void setOtherCharges(String otherCharges) {
        this.otherCharges = otherCharges;
    }

    public String getRemittanceCharges() {
        return remittanceCharges;
    }

    public void setRemittanceCharges(String remittanceCharges) {
        this.remittanceCharges = remittanceCharges;
    }

    public String getBidOperaterId() {
        return bidOperaterId;
    }

    public void setBidOperaterId(String bidOperaterId) {
        this.bidOperaterId = bidOperaterId;
    }

    public String getCreatedById() {
        return createdById;
    }

    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    public String getFfmcAreaName() {
        return ffmcAreaName;
    }

    public void setFfmcAreaName(String ffmcAreaName) {
        this.ffmcAreaName = ffmcAreaName;
    }

    public String getBidRates() {
        return bidRates;
    }

    public void setBidRates(String bidRates) {
        this.bidRates = bidRates;
    }

    public String taxAmount;
    public String deliveryCharges;
    public String otherCharges;
    public String remittanceCharges;
    public String bidOperaterId;
    public String createdById;
    public String ffmcAreaName;
    public String bidRates;





}
