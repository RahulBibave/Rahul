package com.nafex.nafex2.fragments;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.activity.Activity_main;
import com.nafex.nafex2.adapters.EnquiryOneAdapter;
import com.nafex.nafex2.adapters.OnBidOpen;
import com.nafex.nafex2.data.EnquiriesOpen;
import com.nafex.nafex2.data.RequestCurrency;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Sunil on 5/13/2017.
 */
public class fragment_open extends Fragment {
    RecyclerView recycler_Open;
    EnquiryOneAdapter enquiryOneAdapter;
    ArrayList<EnquiriesOpen> enquiriesDataArrayList;

    AppGlobalData gbData;
    OnBidOpen objBidOpen;
    Double BidRate=0.00;
    int RequestId;
    ProgressDialog progressDialog;
    ArrayList<RequestCurrency> listOfRequestCurrency;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id,user_token,branchID;
    ArrayList<String> listOfRequestBidrate;
    TextView txtError;

    String requestId,requestType,requestSourceCurrencyId,requestTargetCurrencyId,requestDeliveryMode,requestAreaId,requestCityId,requestStateId,
            requestCountryId,requestLeadSourceId,requestSourceRefId,requestSourceRef,requestNBC,requestStatusId,requestSMSStatusId,
            requestEmailStatusId,requestDisputeId,requestWinnerFFMCId,requestAcceptedBidId,requestBidAcceptedDateTime,requestBidAcceptedSource,
            requestOpraterId,requestBidAcceptedUserId,createdById,lastModifiedById,requestLat,requestLong,remaining,lastModifiedOn,
            requestUserId,userName,userMobileNo,requestTypeName,requestDeliveryModeName,requestLeadSourceName,requestStatusName,requestSourceCurrencyName,
            requestTargetCurrencyName,countryName,stateName,cityName,areaName,requestDisputeNameN,requestCSSClass,requestProductTypeId,
            requestQuantity,requestProductTypeName,requestTypeIdClass,requestDeliveryModeClass,requestLeadSourceIdClass,requestSourceRefIdClass,
            ProductTypeClass,watermarkRate,thresholdMinRate,thresholdMaxRate,distance;
    String bidFFMCId="0",averageRate="0",averageRate2="0";
    private final Handler handler = new Handler();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        gbData = AppGlobalData.getInstance();
        progressDialog=new ProgressDialog(getActivity());
        getSharedPref();

    /*    objBidOpen = new OnBidOpen() {
            @Override
            public void onBidNowButtonClicked(final int index, final int reqId) {


// get prompts.xml view
                LayoutInflater li = LayoutInflater.from(getContext());
                View promptsView = li.inflate(R.layout.dialog_prompt, null);

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                        getContext());

                // set prompts.xml to alertdialog builder
                alertDialogBuilder.setView(promptsView);

                final EditText userInput = (EditText) promptsView
                        .findViewById(R.id.editTextDialogUserInput);

                userInput.setText("");
                userInput.setHint(("Rate per " + enquiriesDataArrayList.get(index).getreqCurrencyName()));

                // set dialog message
                alertDialogBuilder
                        .setTitle(getResources().getString(R.string.app_name))
                        .setCancelable(false)
                        .setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,int id) {
                                        // get user input and set it to result
                                        // edit text
                                        //.setText(userInput.getText());

                                        if (userInput.getText().toString() != "") {
                                            BidRate = Double.parseDouble(userInput.getText().toString());
                                            RequestId = reqId;
                                            if (BidRate == 0.00)
                                                showAlert(getResources().getString(R.string.app_name), "Rate cannot be 0.00. Please enter the rate again to bid the request.");
                                            else {
                                                CallBidRequestAPI objBidRequestAPI = new CallBidRequestAPI();
                                                objBidRequestAPI.execute(ConstantData.FFMCBID);
                                            }
                                        }
                                    }
                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,int id) {
                                        dialog.cancel();
                                    }
                                });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();

            }
        };*/

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.lay_open_fragment,container,false);
        recycler_Open=(RecyclerView)view.findViewById(R.id.recycler_open);
        recycler_Open.setLayoutManager(new LinearLayoutManager(getActivity()));
        txtError=(TextView)view.findViewById(R.id.txt_error_open);


       // setEnquiryData();
        try {
            if (gbData.isConnected(getActivity())) {
                CallRequestApiForOpen callRequestApiForOpen = new CallRequestApiForOpen();
                callRequestApiForOpen.execute();
            }else {
                showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");
            }
        }catch (NullPointerException e){
            e.printStackTrace();
        }


        doTheAutoRefresh();
        return view;
    }
    public void doTheAutoRefresh() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Write code for your refresh logic
                try {
                    if (gbData.isConnected(getActivity())) {
                        CallRequestApiForOpen callRequestApiForOpen = new CallRequestApiForOpen();
                        callRequestApiForOpen.execute();
                    }else {
                        try {
                            showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");

                        }catch (IllegalStateException e){
                            e.printStackTrace();
                        }
                    }

                }catch (NullPointerException e){
                    e.printStackTrace();
                }
              /* try {
                   FragmentTransaction ft = getFragmentManager().beginTransaction();
                   ft.detach(fragment_open.this).attach(fragment_open.this).commit();
               }catch (NullPointerException e){
                   e.printStackTrace();
               }*/


                doTheAutoRefresh();
            }
        }, 60000);
    }

    public void refresh(){
        try {
            FragmentTransaction ft = getFragmentManager().beginTransaction();
            ft.detach(fragment_open.this).attach(fragment_open.this).commit();
        }catch (NullPointerException e){
            e.printStackTrace();
        }
    }

  /*  @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        final Handler ha=new Handler();
        ha.postDelayed(new Runnable() {

            @Override
            public void run() {
                //call function


              //  if (gbData.isConnected(getActivity())) {
                    try {
                        CallRequestApiForOpen callRequestApiForOpen = new CallRequestApiForOpen();
                        callRequestApiForOpen.execute();
                    }catch (Exception e){

                    }

              *//*  }else {
                    try {
                        CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), "Please check your network connections.");
                    }catch (Exception e){
                        Log.e("EXCEPTIONNNNNNNNN",""+e);

                    }
                }
*//*
                ha.postDelayed(this, 10000);

            }
        }, 10000);
    }*/


   /* public void setEnquiryData()
    {

        if (gbData.isConnected(getActivity())) {
            CallRequestAPI objRequestAPI = new CallRequestAPI();
            objRequestAPI.execute(ConstantData.FFMCREQUEST);
        }
        else
            showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");


//        for (int i=0;i<=10;i++){
//            EnquiriesData enquiriesData;
//            if (i==3)
//                enquiriesData = new EnquiriesData("NBC10315" + String.valueOf(i),"BUY", "04:52", "Vimannagar, Pune","USD","DELIVERY","CONVERTED","BID_DONE","66.01", "200");
//            else
//                 enquiriesData=new EnquiriesData("NBC10315" + String.valueOf(i),"BUY", "04:52", "Vimannagar, Pune","USD","DELIVERY","OPEN","BID_PENDING","0.00", "100");
//            enquiriesDataArrayList.add(enquiriesData);
//        }
//        enquiryOneAdapter.notifyDataSetChanged();

    }*/




  /*  public class CallRequestAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            //Log.d("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                JSONArray jsonArray;
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {


                    jsonArray = objdata.getJSONArray("data_text");

                    enquiriesDataArrayList=new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObj = jsonArray.getJSONObject(i);
                        EnquiriesData enquiriesData;
//                        objRequest.setRequestId(jsonObj.getInt("reqId"));
//                        objRequest.setreqQuantity(jsonObj.getInt("reqQuantity"));
//                        objRequest.setreqStatus(jsonObj.getString("reqStatus").toString());
//
//                        if ((jsonObj.getString("reqWinnerFFMCId") != "null") && (jsonObj.getString("reqWinnerFFMCId") != null) && (jsonObj.getString("reqWinnerFFMCId") != ""))
//                            objRequest.setreqWinnerFFMCId(jsonObj.getInt("reqWinnerFFMCId"));
//
//                        objRequest.setcurrencyAbbrivation(jsonObj.getString("currencyAbbrivation"));
//                        objRequest.setType(jsonObj.getString("Type"));
//                        objRequest.setreqQuantity(jsonObj.getInt("reqQuantity"));
//
//                        txtRequestData.setText("You have requested to " + objRequest.getType() + " " + objRequest.getreqQuantity() + " " + jsonObj.getString("currencyAbbrivation"));
//                        txtStatus.setText(gbData.PrepareStatusString(jsonObj.getString("reqStatus")));
//
//                        objRequest.setRemaining(jsonObj.getString("remaining"));
//
//                        String[] arr = jsonObj.getString("remaining").split(":");

                        enquiriesData = new EnquiriesData(jsonObj.getInt("reqId") , jsonObj.getString("NBC"), jsonObj.getString("Type"),jsonObj.getString("remaining") , jsonObj.getString("AreaName"), jsonObj.getString("currencyAbbrivation"), jsonObj.getString("Mode"), jsonObj.getString("reqStatus"), jsonObj.getString("reqBidStatus"), jsonObj.getString("reqBidRate"), jsonObj.getString("reqQuantity"));
                        enquiriesDataArrayList.add(enquiriesData);

                    }

                    enquiryOneAdapter=new EnquiryOneAdapter(getActivity(),objBidOpen, enquiriesDataArrayList);
                    recycler_Open.setAdapter(enquiryOneAdapter);
                    enquiryOneAdapter.notifyDataSetChanged();
                    recycler_Open.refreshDrawableState();

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    showAlert(getResources().getString(R.string.app_name),objdata.getString("message_text") );
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }

            //progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                    URL url = new URL( ConstantData.SERVER_URL + ConstantData.BASE_URL + ConstantData.FFMCREQUEST);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    try {
                        JSONObject postDataParams = new JSONObject();
                        postDataParams.put("Status", "OPEN");
                        postDataParams.put("FFMC_Id", "1");

                        Log.e("params", postDataParams.toString());

                        urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                        urlConnection.setReadTimeout(15000 *//* milliseconds *//*);
                        urlConnection.setConnectTimeout(15000 *//* milliseconds *//*);
                        urlConnection.setDoInput(true);
                        urlConnection.setDoOutput(true);

                        OutputStream os = urlConnection.getOutputStream();
                        BufferedWriter writer = new BufferedWriter(
                                new OutputStreamWriter(os, "UTF-8"));
                        writer.write(gbData.getPostDataString(postDataParams));

                        writer.flush();
                        writer.close();
                        os.close();

                        int responseCode = urlConnection.getResponseCode();

                        if (responseCode == HttpsURLConnection.HTTP_OK) {
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                            StringBuilder stringBuilder = new StringBuilder();
                            String line;
                            while ((line = bufferedReader.readLine()) != null) {
                                stringBuilder.append(line).append("\n");
                            }
                            bufferedReader.close();
                            strResponse = stringBuilder.toString();
                            Log.e("Result", strResponse);
                        }
                    }
                    catch (Exception e) {
                        Log.e("ERROR", e.getMessage(), e);
                        Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
                    }
                    finally {
                        urlConnection.disconnect();
                    }
                } catch (Exception e) {
                    Log.e("ERROR", e.getMessage(), e);
                    Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
                }


            return null;
        }
    }*/



/*    public class CallBidRequestAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            //Log.d("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                JSONArray jsonArray;
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {


                    //jsonArray = objdata.getJSONArray("data_text");
                    JSONObject jsonObj = objdata.getJSONObject("data_text");

                    if (jsonObj.getInt("requestBidId") > 0)
                    {
                        showAlertwithOk(getResources().getString(R.string.app_name),"Bid is successfully updated." );
                    }
                    else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                        showAlert(getResources().getString(R.string.app_name),"Unable to put the bid" );
                    }

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    showAlert(getResources().getString(R.string.app_name),objdata.getString("message_text") );
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }

            //progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL( ConstantData.SERVER_URL + ConstantData.BASE_URL + ConstantData.FFMCBID);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();

                    postDataParams.put("FFMCId", "1");
                    postDataParams.put("FFMCRate", BidRate);
                    postDataParams.put("RequestId", RequestId);

                    Log.e("params", postDataParams.toString());

                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(15000 *//* milliseconds *//*);
                    urlConnection.setConnectTimeout(15000 *//* milliseconds *//*);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();

                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    }
                }
                catch (Exception e) {
                    Log.e("ERROR", e.getMessage(), e);
                    Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
                }
                finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
            }


            return null;
        }
    }*/

    private void showAlert(String title, String message) {
        new AlertDialog.Builder(getActivity())
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }


  /*  private void showAlertwithOk(String title, String message) {
        new AlertDialog.Builder(getActivity())
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (gbData.isConnected(getActivity())) {
                            CallRequestAPI objRequestAPI = new CallRequestAPI();
                            objRequestAPI.execute(ConstantData.FFMCREQUEST);
                        }
                        else
                            showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }*/


    public class CallRequestApiForOpen extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            enquiriesDataArrayList=new ArrayList<>();
            listOfRequestCurrency=new ArrayList<>();
            listOfRequestBidrate=new ArrayList<>();

           /* if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";*/
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("900")){

                    }
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                        if (objdata.isNull("message_text")){
                            txtError.setVisibility(View.VISIBLE);
                        }

                    JSONArray jsonArray=objdata.getJSONArray("message_text");
                    for (int i=0;i<jsonArray.length();i++){
                        bidFFMCId="0";
                        JSONObject jsonObjectInner=jsonArray.getJSONObject(i);
                        requestId=jsonObjectInner.getString("requestId");

                        requestType=jsonObjectInner.getString("requestType");
                        requestSourceCurrencyId=jsonObjectInner.getString("requestSourceCurrencyId");
                        requestTargetCurrencyId=jsonObjectInner.getString("requestTargetCurrencyId");
                        requestDeliveryMode=jsonObjectInner.getString("requestDeliveryMode");
                        requestAreaId=jsonObjectInner.getString("requestAreaId");
                        requestCityId=jsonObjectInner.getString("requestCityId");
                        requestStateId=jsonObjectInner.getString("requestStateId");
                        requestCountryId=jsonObjectInner.getString("requestCountryId");
                        requestSourceRefId=jsonObjectInner.getString("requestSourceRefId");
                        requestSourceRef=jsonObjectInner.getString("requestSourceRef");
                        requestNBC=jsonObjectInner.getString("requestNBC");
                        requestStatusId=jsonObjectInner.getString("requestStatusId");
                        requestSMSStatusId=jsonObjectInner.getString("requestSMSStatusId");
                        requestEmailStatusId=jsonObjectInner.getString("requestEmailStatusId");
                        requestDisputeId=jsonObjectInner.getString("requestDisputeId");
                        requestWinnerFFMCId=jsonObjectInner.getString("requestWinnerFFMCId");
                        requestAcceptedBidId=jsonObjectInner.getString("requestAcceptedBidId");
                        requestBidAcceptedDateTime=jsonObjectInner.getString("requestBidAcceptedDateTime");
                        requestBidAcceptedSource=jsonObjectInner.getString("requestBidAcceptedSource");
                        requestOpraterId=jsonObjectInner.getString("requestOpraterId");
                        requestBidAcceptedUserId=jsonObjectInner.getString("requestBidAcceptedUserId");
                        createdById=jsonObjectInner.getString("createdById");
                        lastModifiedById=jsonObjectInner.getString("lastModifiedById");
                        remaining=jsonObjectInner.getString("remaining");
                        lastModifiedOn=jsonObjectInner.getString("lastModifiedOn");
                        requestUserId=jsonObjectInner.getString("requestUserId");
                        userName=jsonObjectInner.getString("userName");
                        userMobileNo=jsonObjectInner.getString("userMobileNo");
                        requestTypeName=jsonObjectInner.getString("requestTypeName");
                        requestDeliveryModeName=jsonObjectInner.getString("requestDeliveryModeName");
                        requestLeadSourceName=jsonObjectInner.getString("requestLeadSourceName");
                        requestStatusName=jsonObjectInner.getString("requestStatusName");
                        requestSourceCurrencyName=jsonObjectInner.getString("requestSourceCurrencyName");
                        requestTargetCurrencyName=jsonObjectInner.getString("requestTargetCurrencyName");
                        watermarkRate = jsonObjectInner.getString("watermarkRate");
                        thresholdMinRate=jsonObjectInner.getString("thresholdMinRate");
                        thresholdMaxRate=jsonObjectInner.getString("thresholdMaxRate");
                        distance=jsonObjectInner.getString("distance");
                        JSONObject jsonObjectLocation=jsonObjectInner.getJSONObject("locationName");

                        countryName=jsonObjectLocation.getString("countryName");
                        stateName=jsonObjectLocation.getString("stateName");
                        cityName=jsonObjectLocation.getString("cityName");
                        areaName=jsonObjectLocation.getString("areaName");

                        requestCSSClass=jsonObjectInner.getString("requestCSSClass");
                        JSONObject jsonObjectStringParser = new JSONObject(requestCSSClass);
                        requestTypeIdClass=jsonObjectStringParser.getString("requestTypeIdClass");
                        requestDeliveryModeClass=jsonObjectStringParser.getString("requestDeliveryModeClass");
                        requestLeadSourceIdClass=jsonObjectStringParser.getString("requestLeadSourceIdClass");
                        requestSourceRefIdClass=jsonObjectStringParser.getString("requestSourceRefIdClass");
                        ProductTypeClass=jsonObjectStringParser.getString("ProductTypeClass");

                        /*requestDisputeNameN=jsonObjectInner.getString("requestDisputeNameN");
                        JSONObject jsonObjectRquestCssClass=jsonObjectInner.getJSONObject("requestCSSClass");*/

                        JSONArray jsonArrayRequestProducts=jsonObjectInner.getJSONArray("requestProducts");
                        listOfRequestCurrency.clear();
                        for (int j=0;j<jsonArrayRequestProducts.length();j++){
                            JSONObject jsonObjectRequstProducts=jsonArrayRequestProducts.getJSONObject(j);
                            requestProductTypeId=jsonObjectRequstProducts.getString("requestProductTypeId");
                            requestQuantity=jsonObjectRequstProducts.getString("requestQuantity");
                            requestProductTypeName=jsonObjectRequstProducts.getString("requestProductTypeName");
                            RequestCurrency requestCurrency=new RequestCurrency(requestProductTypeId,requestQuantity,requestProductTypeName);
                            listOfRequestCurrency.add(requestCurrency);
                        }

                        JSONArray jsonArrayRequestBid=jsonObjectInner.getJSONArray("requestBids");
                        for (int k=0;k<jsonArrayRequestBid.length();k++){
                            JSONObject jsonObjectRequestBid=jsonArrayRequestBid.getJSONObject(k);

                            if (branchID.equalsIgnoreCase(jsonObjectRequestBid.getString("bidFFMCId"))){
                                bidFFMCId=jsonObjectRequestBid.getString("bidFFMCId");
                            //    averageRate=jsonObjectRequestBid.getString("averageRate");
                                listOfRequestBidrate.clear();
                                JSONArray jsonArrayrequestBidRate=jsonObjectRequestBid.getJSONArray("bidRates");
                                for (int m=0;m<jsonArrayrequestBidRate.length();m++){
                                    JSONObject jsonObjectRequestBidRate=jsonArrayrequestBidRate.getJSONObject(m);
                                    String requestBidRate=jsonObjectRequestBidRate.getString("requestBidRate");
                                    listOfRequestBidrate.add(requestBidRate);

                                }
                            }else {
                                bidFFMCId="0";
                            }

                        }

                        if (listOfRequestBidrate.size()>0){

                            if (listOfRequestBidrate.size() == 1) {
                                averageRate=listOfRequestBidrate.get(0);
                            }else if (listOfRequestBidrate.size()>1) {
                                averageRate=listOfRequestBidrate.get(0);
                                averageRate2 = listOfRequestBidrate.get(1);
                            }

                           /* for (int n=0;n<listOfRequestBidrate.size();n++){
                                averageRate=lastModifiedById.g
                            }*/

                        }


                        Log.e("REQUEST TYPEEEEEEEEEEEE",""+requestType);
                        Log.e("CONTRY NAMEEEEEEEE",""+countryName);
                        Log.e("REQ TYPE IDDDDD",""+requestTypeIdClass);
                        Log.e("BidffmcIDDDDDDDDD",""+bidFFMCId);

                        Log.e("ArraylistSize_Currency",""+listOfRequestCurrency.size());
                        Log.e("ThreSholdMin",""+thresholdMinRate);
                        Log.e("ThreSholdMax",""+thresholdMaxRate);


                        if (listOfRequestCurrency.size()==1) {


                            EnquiriesOpen enquiriesOpen = new EnquiriesOpen(requestId, requestType, requestSourceCurrencyId, requestTargetCurrencyId, requestDeliveryMode, requestAreaId, requestCityId, requestStateId,
                                    requestCountryId, requestLeadSourceId, requestSourceRefId, requestSourceRef, requestNBC, requestStatusId, requestSMSStatusId,
                                    requestEmailStatusId, requestDisputeId, requestWinnerFFMCId, requestAcceptedBidId, requestBidAcceptedDateTime, requestBidAcceptedSource,
                                    requestOpraterId, requestBidAcceptedUserId, createdById, lastModifiedById, requestLat, requestLong, remaining, lastModifiedOn,
                                    requestUserId, userName, userMobileNo, requestTypeName, requestDeliveryModeName, requestLeadSourceName, requestStatusName, requestSourceCurrencyName,
                                    requestTargetCurrencyName, countryName, stateName, cityName, areaName, requestDisputeNameN, requestCSSClass, listOfRequestCurrency.get(0).getRequestProductTypeId(),
                                    listOfRequestCurrency.get(0).getRequestQuantity(), listOfRequestCurrency.get(0).getRequestProductTypeName(), requestTypeIdClass, requestDeliveryModeClass, requestLeadSourceIdClass, requestSourceRefIdClass,
                                    ProductTypeClass,"0","0","0",bidFFMCId,averageRate,averageRate2,watermarkRate,thresholdMinRate,thresholdMaxRate,distance);
                            enquiriesDataArrayList.add(enquiriesOpen);

                        } else if (listOfRequestCurrency.size()==2){

                            EnquiriesOpen enquiriesOpen = new EnquiriesOpen(requestId, requestType, requestSourceCurrencyId, requestTargetCurrencyId, requestDeliveryMode, requestAreaId, requestCityId, requestStateId,
                                    requestCountryId, requestLeadSourceId, requestSourceRefId, requestSourceRef, requestNBC, requestStatusId, requestSMSStatusId,
                                    requestEmailStatusId, requestDisputeId, requestWinnerFFMCId, requestAcceptedBidId, requestBidAcceptedDateTime, requestBidAcceptedSource,
                                    requestOpraterId, requestBidAcceptedUserId, createdById, lastModifiedById, requestLat, requestLong, remaining, lastModifiedOn,
                                    requestUserId, userName, userMobileNo, requestTypeName, requestDeliveryModeName, requestLeadSourceName, requestStatusName, requestSourceCurrencyName,
                                    requestTargetCurrencyName, countryName, stateName, cityName, areaName, requestDisputeNameN, requestCSSClass, listOfRequestCurrency.get(0).getRequestProductTypeId(),
                                    listOfRequestCurrency.get(0).getRequestQuantity(), listOfRequestCurrency.get(0).getRequestProductTypeName(), requestTypeIdClass, requestDeliveryModeClass, requestLeadSourceIdClass, requestSourceRefIdClass,
                                    ProductTypeClass,listOfRequestCurrency.get(1).getRequestProductTypeId(),
                                    listOfRequestCurrency.get(1).getRequestQuantity(), listOfRequestCurrency.get(1).getRequestProductTypeName(),bidFFMCId,averageRate,averageRate2,watermarkRate,thresholdMinRate,thresholdMaxRate,distance);
                            enquiriesDataArrayList.add(enquiriesOpen);

                        }

                    }


                    Log.e("ArraylistSize********",""+enquiriesDataArrayList.size());

                    enquiryOneAdapter=new EnquiryOneAdapter(getActivity(),objBidOpen,enquiriesDataArrayList,fragment_open.this);
                    recycler_Open.setAdapter(enquiryOneAdapter);
                    enquiryOneAdapter.notifyDataSetChanged();




                    } else if (objdata.getString("message_code").equalsIgnoreCase("999")){
                        txtError.setVisibility(View.VISIBLE);
                    }
                       // CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else{}*/
                      //  Error_Message = "JSONError: Please contact Nafex support team.";

                  //  CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), Error_Message);
                }
            /*} else
                CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), Error_Message);
*/
            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.ffmcRequestList);
              //  Log.e("APIIIIIIIIIIIII",""+url);

                urlConnection = (HttpURLConnection) url.openConnection();
                Log.e("Id,Token",""+user_id+""+"Token"+" "+user_token);

                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);
                //Log.e("BranchIDDDDDDDDD",""+ConstantData.branchId);

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("requestStatus", "O");
                postDataParams.put("FFMCBranchId",ConstantData.branchId);
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result_ENQUIRYYYYYY123", strResponse);

                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
               // Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }
    public void timerStop(String ID){
        try {
            Log.e("INside time Stop",""+ID);
            Iterator<EnquiriesOpen> iter = enquiriesDataArrayList.iterator();
            while (iter.hasNext()) {
                Log.e("IIIIII",""+ID);
                try {
                    EnquiriesOpen p = iter.next();
                    if (p.getRequestId().toString().equalsIgnoreCase(ID))
                        enquiriesDataArrayList.remove(p);
                }catch (ConcurrentModificationException e){
                    e.printStackTrace();
                }


            }

            enquiryOneAdapter.notifyDataSetChanged();
        }catch (IllegalStateException e){
            e.printStackTrace();
        }





        Log.e("timerStop","Timer stop");
    }

    private void getSharedPref() {
        sharedpreferences = getActivity().getSharedPreferences(ConstantData.MyPREFERENCES, getActivity().MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN,"");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN,"");
        branchID=sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID,"");

    }



}
