package com.nafex.nafex2.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;

/**
 * Created by rahul on 7/9/17.
 */

public class FragmentMoneyTransfer extends Fragment {

    private RelativeLayout layQuantity,layCurrency,layMobile,layTransferType,layCountry,layPurpose;
    private ImageView imgQuantity,imgCurrency,imgTransferType,imgPurpose,imgCountry,imgMobile;
    private EditText txtQuantity,txtMobile;
    private TextView txtCurrency,txtPurpose,txtTransferType;
    private Button btnProceed;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.lay_money_transfer,container,false);

       // init(view);

        return view;
    }

    public void init(View view){

        layQuantity = (RelativeLayout)view.findViewById( R.id.layQuantity );
        imgQuantity =(ImageView)view.findViewById( R.id.imgQuantity );
        txtQuantity = (EditText)view.findViewById( R.id.txtQuantity );
        layCurrency = (RelativeLayout)view.findViewById( R.id.layCurrency );
        imgCurrency = (ImageView)view.findViewById( R.id.imgCurrency );
        txtCurrency = (TextView)view.findViewById( R.id.txtCurrency );
        layMobile = (RelativeLayout)view.findViewById( R.id.layMobile );
        imgMobile = (ImageView)view.findViewById( R.id.imgMobile );
        txtMobile = (EditText)view.findViewById( R.id.txtMobile );
        layTransferType = (RelativeLayout)view.findViewById( R.id.layTransferType );
        imgTransferType = (ImageView)view.findViewById( R.id.imgTransferType );
        txtTransferType = (TextView)view.findViewById( R.id.txtTransferType );
        layPurpose = (RelativeLayout)view.findViewById( R.id.layPurpose );
        imgPurpose = (ImageView)view.findViewById( R.id.imgPurpose );
        txtPurpose = (TextView)view.findViewById( R.id.txtPurpose );
        layCountry = (RelativeLayout)view.findViewById( R.id.layCountry );
        imgCountry = (ImageView)view.findViewById( R.id.imgCountry );
        btnProceed = (Button)view.findViewById( R.id.btnProceed );
    }
}
