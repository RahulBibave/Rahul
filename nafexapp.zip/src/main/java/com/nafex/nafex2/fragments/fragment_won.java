package com.nafex.nafex2.fragments;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.EnquiryWonAdapter;
import com.nafex.nafex2.data.BidWonArray;
import com.nafex.nafex2.data.EnquiryWon;
import com.nafex.nafex2.data.RequestCurrency;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Sunil on 5/13/2017.
 */
public class fragment_won extends Fragment {

    RecyclerView recycler_Open;
    EnquiryWonAdapter enquiryWonAdapter;
    ArrayList<EnquiryWon> enquiryWonArrayList;

    AppGlobalData gbData;
    ArrayList<RequestCurrency> listOfRequestCurrency;
    ArrayList<BidWonArray>bidWonArrayArrayList;
    TextView txtError;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id,user_token,branchID;
    String datatime="";

    String requestId,requestType,requestSourceCurrencyId,requestTargetCurrencyId,requestDeliveryMode,requestAreaId,requestCityId,requestStateId,
            requestCountryId,requestLeadSourceId,requestSourceRefId,requestSourceRef,requestNBC,requestStatusId,requestSMSStatusId,
            requestEmailStatusId,requestDisputeId,requestWinnerFFMCId,requestAcceptedBidId,requestBidAcceptedDateTime,requestBidAcceptedSource,
            requestOpraterId,requestBidAcceptedUserId,createdById,lastModifiedById,requestLat,requestLong,remaining,lastModifiedOn,
            requestUserId,userName,userMobileNo,requestTypeName,requestDeliveryModeName,requestLeadSourceName,requestStatusName,requestSourceCurrencyName,
            requestTargetCurrencyName,countryName,stateName,cityName,areaName,requestDisputeNameN,requestCSSClass,requestProductTypeId,
            requestQuantity,requestProductTypeName,requestTypeIdClass,requestDeliveryModeClass,requestLeadSourceIdClass,requestSourceRefIdClass,
            ProductTypeClass,averageRate,CommissionAmount,distance;
    ProgressDialog progressDialog;
    private final Handler handler = new Handler();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gbData = AppGlobalData.getInstance();
        progressDialog=new ProgressDialog(getActivity());
        getSharedPref();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.lay_inprogress,container,false);

        recycler_Open=(RecyclerView)view.findViewById(R.id.recycler_inProgress);
        recycler_Open.setLayoutManager(new LinearLayoutManager(getActivity()));
        txtError=(TextView)view.findViewById(R.id.txt_error_inprogress);


      //  setData();

        if (gbData.isConnected(getActivity())) {

            CallRequestApiForWon callRequestApiForWon = new CallRequestApiForWon();
            callRequestApiForWon.execute();
        }else {
            CommonUI.showAlert(getActivity(),getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");

        }
        doTheAutoRefresh();

        return view;


    }
    public void doTheAutoRefresh() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Write code for your refresh logic
                try {
                    if (gbData.isConnected(getActivity())) {
                        CallRequestApiForWon callRequestApiForOpen = new CallRequestApiForWon();
                        callRequestApiForOpen.execute();
                    }else {
                        try {
                            showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");

                        }catch (IllegalStateException e){
                            e.printStackTrace();
                        }
                    }

                }catch (NullPointerException e){
                    e.printStackTrace();
                }
               /* try {
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    ft.detach(fragment_won.this).attach(fragment_won.this).commit();
                }catch (NullPointerException e){
                    e.printStackTrace();
                }*/


                doTheAutoRefresh();
            }
        }, 60000);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }



/*    public void setData() {

        if (gbData.isConnected(getActivity())) {
            CallRequestAPI objRequestAPI = new CallRequestAPI();
            objRequestAPI.execute(ConstantData.FFMCREQUEST);
        } else
            showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");

    }*/

  /*      public class CallRequestAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            //Log.d("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                JSONArray jsonArray;
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {


                    jsonArray = objdata.getJSONArray("data_text");

                    enquiriesDataArrayList=new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObj = jsonArray.getJSONObject(i);
                        EnquiriesData enquiriesData;
//                        objRequest.setRequestId(jsonObj.getInt("reqId"));
//                        objRequest.setreqQuantity(jsonObj.getInt("reqQuantity"));
//                        objRequest.setreqStatus(jsonObj.getString("reqStatus").toString());
//
//                        if ((jsonObj.getString("reqWinnerFFMCId") != "null") && (jsonObj.getString("reqWinnerFFMCId") != null) && (jsonObj.getString("reqWinnerFFMCId") != ""))
//                            objRequest.setreqWinnerFFMCId(jsonObj.getInt("reqWinnerFFMCId"));
//
//                        objRequest.setcurrencyAbbrivation(jsonObj.getString("currencyAbbrivation"));
//                        objRequest.setType(jsonObj.getString("Type"));
//                        objRequest.setreqQuantity(jsonObj.getInt("reqQuantity"));
//
//                        txtRequestData.setText("You have requested to " + objRequest.getType() + " " + objRequest.getreqQuantity() + " " + jsonObj.getString("currencyAbbrivation"));
//                        txtStatus.setText(gbData.PrepareStatusString(jsonObj.getString("reqStatus")));
//
//                        objRequest.setRemaining(jsonObj.getString("remaining"));
//
//                        String[] arr = jsonObj.getString("remaining").split(":");

                        enquiriesData = new EnquiriesData(jsonObj.getInt("reqId") , jsonObj.getString("NBC"), jsonObj.getString("Type"),jsonObj.getString("remaining") , jsonObj.getString("AreaName"), jsonObj.getString("currencyAbbrivation"), jsonObj.getString("Mode"), jsonObj.getString("reqStatus"), jsonObj.getString("reqBidStatus"), jsonObj.getString("reqBidRate"), jsonObj.getString("reqQuantity"));
                        enquiriesDataArrayList.add(enquiriesData);

                    }


                    enquiryOneAdapter=new EnquiryOneAdapter(getActivity(), null, enquiriesDataArrayList);
                    recycler_Open.setAdapter(enquiryOneAdapter);
                    enquiryOneAdapter.notifyDataSetChanged();
                    recycler_Open.refreshDrawableState();

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    showAlert(getResources().getString(R.string.app_name),objdata.getString("message_text") );
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }

            //progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL( ConstantData.SERVER_URL + ConstantData.BASE_URL + ConstantData.FFMCREQUEST);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("Status", "WON");
                    postDataParams.put("FFMC_Id", "1");

                    Log.e("params", postDataParams.toString());

                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(15000 *//* milliseconds *//*);
                    urlConnection.setConnectTimeout(15000 *//* milliseconds *//*);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();

                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    }
                }
                catch (Exception e) {
                    Log.e("ERROR", e.getMessage(), e);
                    Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
                }
                finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
            }


            return null;
        }
    }
*/


    private void showAlert(String title, String message) {
        new AlertDialog.Builder(getActivity())
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }





    public class CallRequestApiForWon extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }

        @SuppressLint("LongLogTag")
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            enquiryWonArrayList=new ArrayList<>();
            listOfRequestCurrency=new ArrayList<>();
            bidWonArrayArrayList=new ArrayList<>();

         //   if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";
                Log.e("Response:****************Won", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    JSONArray jsonArray=objdata.getJSONArray("message_text");
                    for (int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObjectInner=jsonArray.getJSONObject(i);
                        requestId=jsonObjectInner.getString("requestId");

                        requestType=jsonObjectInner.getString("requestType");
                        requestSourceCurrencyId=jsonObjectInner.getString("requestSourceCurrencyId");
                        requestTargetCurrencyId=jsonObjectInner.getString("requestTargetCurrencyId");
                        requestDeliveryMode=jsonObjectInner.getString("requestDeliveryMode");
                        requestAreaId=jsonObjectInner.getString("requestAreaId");
                        requestCityId=jsonObjectInner.getString("requestCityId");
                        requestStateId=jsonObjectInner.getString("requestStateId");
                        requestCountryId=jsonObjectInner.getString("requestCountryId");
                        requestSourceRefId=jsonObjectInner.getString("requestSourceRefId");
                        requestSourceRef=jsonObjectInner.getString("requestSourceRef");
                        requestNBC=jsonObjectInner.getString("requestNBC");
                        requestStatusId=jsonObjectInner.getString("requestStatusId");
                        requestSMSStatusId=jsonObjectInner.getString("requestSMSStatusId");
                        requestEmailStatusId=jsonObjectInner.getString("requestEmailStatusId");
                        requestDisputeId=jsonObjectInner.getString("requestDisputeId");
                        requestWinnerFFMCId=jsonObjectInner.getString("requestWinnerFFMCId");
                        requestAcceptedBidId=jsonObjectInner.getString("requestAcceptedBidId");
                      //  requestBidAcceptedDateTime=jsonObjectInner.getString("requestBidAcceptedDateTime");
                       // requestBidAcceptedDateTime=jsonObjectInner.getString("requestBidAcceptedDateTime");
                        long time= Long.parseLong(jsonObjectInner.getString("requestUnixTime"));
                        String OUTPUT_DATE_FORMATE="MMM dd - h:mm a";
                        getDateFromUTCTimestamp(time,OUTPUT_DATE_FORMATE);
                        requestBidAcceptedSource=jsonObjectInner.getString("requestBidAcceptedSource");
                        requestOpraterId=jsonObjectInner.getString("requestOpraterId");
                        requestBidAcceptedUserId=jsonObjectInner.getString("requestBidAcceptedUserId");
                        createdById=jsonObjectInner.getString("createdById");
                        lastModifiedById=jsonObjectInner.getString("lastModifiedById");
                        remaining=jsonObjectInner.getString("remaining");
                        lastModifiedOn=jsonObjectInner.getString("lastModifiedOn");
                        requestUserId=jsonObjectInner.getString("requestUserId");
                        userName=jsonObjectInner.getString("userName");
                        userMobileNo=jsonObjectInner.getString("userMobileNo");
                        requestTypeName=jsonObjectInner.getString("requestTypeName");
                        requestDeliveryModeName=jsonObjectInner.getString("requestDeliveryModeName");
                        requestLeadSourceName=jsonObjectInner.getString("requestLeadSourceName");
                        requestStatusName=jsonObjectInner.getString("requestStatusName");
                        requestSourceCurrencyName=jsonObjectInner.getString("requestSourceCurrencyName");
                        requestTargetCurrencyName=jsonObjectInner.getString("requestTargetCurrencyName");
                        distance=jsonObjectInner.getString("distance");
                        CommissionAmount=jsonObjectInner.getString("commissionAmount");

                        JSONObject jsonObjectLocation=jsonObjectInner.getJSONObject("locationName");

                        countryName=jsonObjectLocation.getString("countryName");
                        stateName=jsonObjectLocation.getString("stateName");
                        cityName=jsonObjectLocation.getString("cityName");
                        areaName=jsonObjectLocation.getString("areaName");

                        requestCSSClass=jsonObjectInner.getString("requestCSSClass");
                        JSONObject jsonObjectStringParser = new JSONObject(requestCSSClass);
                        requestTypeIdClass=jsonObjectStringParser.getString("requestTypeIdClass");
                        requestDeliveryModeClass=jsonObjectStringParser.getString("requestDeliveryModeClass");
                        requestLeadSourceIdClass=jsonObjectStringParser.getString("requestLeadSourceIdClass");
                        requestSourceRefIdClass=jsonObjectStringParser.getString("requestSourceRefIdClass");
                        ProductTypeClass=jsonObjectStringParser.getString("ProductTypeClass");

                        /*requestDisputeNameN=jsonObjectInner.getString("requestDisputeNameN");
                        JSONObject jsonObjectRquestCssClass=jsonObjectInner.getJSONObject("requestCSSClass");*/

                        JSONArray jsonArrayRequestProducts=jsonObjectInner.getJSONArray("requestProducts");
                        listOfRequestCurrency.clear();
                        for (int j=0;j<jsonArrayRequestProducts.length();j++){
                            JSONObject jsonObjectRequstProducts=jsonArrayRequestProducts.getJSONObject(j);
                            requestProductTypeId=jsonObjectRequstProducts.getString("requestProductTypeId");
                            requestQuantity=jsonObjectRequstProducts.getString("requestQuantity");
                            requestProductTypeName=jsonObjectRequstProducts.getString("requestProductTypeName");
                            RequestCurrency requestCurrency=new RequestCurrency(requestProductTypeId,requestQuantity,requestProductTypeName);
                            listOfRequestCurrency.add(requestCurrency);
                        }
                        Log.e("listOfRequestCurrencySize",""+listOfRequestCurrency.size());
                        JSONArray jsonArrayBidWonArray=jsonObjectInner.getJSONArray("bidWonRateArray");
                        bidWonArrayArrayList.clear();
                        for (int a=0;a<jsonArrayBidWonArray.length();a++){
                            JSONObject jsonObjectBidWon=jsonArrayBidWonArray.getJSONObject(a);
                            Log.e("qqqqq",""+jsonObjectBidWon.getString("requestBidRate"));
                            String requestBidRate=jsonObjectBidWon.getString("requestBidRate");
                            String requestQuantity=jsonObjectBidWon.getString("requestQuantity");
                            String productName =jsonObjectBidWon.getString("productName");
                            String reuestProductTypeId=jsonObjectBidWon.getString("reuestProductTypeId");
                            BidWonArray bidWonArray=new BidWonArray(requestBidRate,requestQuantity,productName,reuestProductTypeId);
                            bidWonArrayArrayList.add(bidWonArray);

                        }
                        Log.e("SizeOfArray",""+bidWonArrayArrayList.size());



                        JSONArray jsonArrayRequestBids=jsonObjectInner.getJSONArray("requestBids");
                        for (int k=0;k<jsonArrayRequestBids.length();k++){
                            JSONObject jsonObjectRequestBid=jsonArrayRequestBids.getJSONObject(k);
                            averageRate=jsonObjectRequestBid.getString("averageRate");
                            Log.e("AverageRate***********",""+averageRate);

                            JSONArray jsonArrayBidRates=jsonObjectRequestBid.getJSONArray("bidRates");
                            for (int l=0;l<jsonArrayBidRates.length();l++){
                                JSONObject jsonObjectBidRates=jsonArrayBidRates.getJSONObject(l);
                              //  CommissionAmount=jsonObjectBidRates.getString("commisionAmount");
                                Log.e("CommissionAmounttttttttt",""+CommissionAmount);
                            }

                        }


                        Log.e("REQUEST TYPEEEEEEEEEEEE",""+requestType);
                        Log.e("CONTRY NAMEEEEEEEE",""+countryName);
                        Log.e("REQ TYPE IDDDDDDDD",""+requestTypeIdClass);

                        Log.e("ArraylistSize_Currency",""+listOfRequestCurrency.size());


                        if (listOfRequestCurrency.size()==1) {


                            EnquiryWon enquiryWon = new EnquiryWon(requestId, requestType, requestSourceCurrencyId, requestTargetCurrencyId, requestDeliveryMode, requestAreaId, requestCityId, requestStateId,
                                    requestCountryId, requestLeadSourceId, requestSourceRefId, requestSourceRef, requestNBC, requestStatusId, requestSMSStatusId,
                                    requestEmailStatusId, requestDisputeId, requestWinnerFFMCId, requestAcceptedBidId, requestBidAcceptedDateTime, requestBidAcceptedSource,
                                    requestOpraterId, requestBidAcceptedUserId, createdById, lastModifiedById, requestLat, requestLong, remaining, lastModifiedOn,
                                    requestUserId, userName, userMobileNo, requestTypeName, requestDeliveryModeName, requestLeadSourceName, requestStatusName, requestSourceCurrencyName,
                                    requestTargetCurrencyName, countryName, stateName, cityName, areaName, requestDisputeNameN, requestCSSClass, listOfRequestCurrency.get(0).getRequestProductTypeId(),
                                    listOfRequestCurrency.get(0).getRequestQuantity(), listOfRequestCurrency.get(0).getRequestProductTypeName(), requestTypeIdClass, requestDeliveryModeClass, requestLeadSourceIdClass, requestSourceRefIdClass,
                                    ProductTypeClass,"0","0","0",averageRate,CommissionAmount,distance,
                                    bidWonArrayArrayList.get(0).getRequestBidRate(),bidWonArrayArrayList.get(0).getRequestQuantity(),bidWonArrayArrayList.get(0).getProductName(),bidWonArrayArrayList.get(0).getProductName(),"0","0","0","0","1");
                            enquiryWonArrayList.add(enquiryWon);

                        } else if (listOfRequestCurrency.size()==2){
                            Log.e("bidAARR",""+bidWonArrayArrayList.size());

                            EnquiryWon enquiryWon  = new EnquiryWon(requestId, requestType, requestSourceCurrencyId, requestTargetCurrencyId, requestDeliveryMode, requestAreaId, requestCityId, requestStateId,
                                    requestCountryId, requestLeadSourceId, requestSourceRefId, requestSourceRef, requestNBC, requestStatusId, requestSMSStatusId,
                                    requestEmailStatusId, requestDisputeId, requestWinnerFFMCId, requestAcceptedBidId, requestBidAcceptedDateTime, requestBidAcceptedSource,
                                    requestOpraterId, requestBidAcceptedUserId, createdById, lastModifiedById, requestLat, requestLong, remaining, lastModifiedOn,
                                    requestUserId, userName, userMobileNo, requestTypeName, requestDeliveryModeName, requestLeadSourceName, requestStatusName, requestSourceCurrencyName,
                                    requestTargetCurrencyName, countryName, stateName, cityName, areaName, requestDisputeNameN, requestCSSClass, listOfRequestCurrency.get(0).getRequestProductTypeId(),
                                    listOfRequestCurrency.get(0).getRequestQuantity(), listOfRequestCurrency.get(0).getRequestProductTypeName(), requestTypeIdClass, requestDeliveryModeClass, requestLeadSourceIdClass, requestSourceRefIdClass,
                                    ProductTypeClass,listOfRequestCurrency.get(1).getRequestProductTypeId(),
                                    listOfRequestCurrency.get(1).getRequestQuantity(), listOfRequestCurrency.get(1).getRequestProductTypeName(),averageRate,CommissionAmount,distance,
                                    bidWonArrayArrayList.get(0).getRequestBidRate(),bidWonArrayArrayList.get(0).getRequestQuantity(),bidWonArrayArrayList.get(0).getProductName(),bidWonArrayArrayList.get(0).getProductName(),
                                    bidWonArrayArrayList.get(1).getRequestBidRate(),bidWonArrayArrayList.get(1).getRequestQuantity(),bidWonArrayArrayList.get(1).getProductName(),bidWonArrayArrayList.get(1).getProductName(),"2");
                            enquiryWonArrayList.add(enquiryWon);

                        }

                    }


                    Log.e("ArraylistSize********",""+enquiryWonArrayList.size());

                    enquiryWonAdapter=new EnquiryWonAdapter(getActivity(),enquiryWonArrayList);
                    recycler_Open.setAdapter(enquiryWonAdapter);




                    } else if (objdata.getString("message_code").equalsIgnoreCase("999")){
                        txtError.setVisibility(View.VISIBLE);
                    }
                       // CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   // if (strResponse.equalsIgnoreCase(""))
                      //  Error_Message = "Please check your network connections.";
                   // else{}
                       // Error_Message = "JSONError: Please contact Nafex support team.";

                    //CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), Error_Message);
                }
           /* } else
                CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), Error_Message);*/

            progressDialog.dismiss();
        }


        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.ffmcRequestList);
                //  Log.e("APIIIIIIIIIIIII",""+url);

                urlConnection = (HttpURLConnection) url.openConnection();
                Log.e("Id,Token",""+user_id+""+"Token"+" "+user_token);

                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);
                //Log.e("BranchIDDDDDDDDD",""+ConstantData.branchId);

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("requestStatus", "A");
                // postDataParams.put("FFMCBranchId",ConstantData.branchId);
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result_ENQUIRYYYYYY123", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
              /*  if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }

/*        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
            //    URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.GET_ENQUIRY_REQUEST);
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.ffmcRequestList);
                Log.e("APIIIIIIIIIIIII",""+url);

                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("requestStatus", "A");
               // postDataParams.put("FFMCBranchId",ConstantData.branchId);
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 *//* milliseconds *//*);
                urlConnection.setConnectTimeout(15000 *//* milliseconds *//*);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result_ENQUIRYYYYYY123", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }*/
    }

    private void getSharedPref() {
        sharedpreferences = getActivity().getSharedPreferences(ConstantData.MyPREFERENCES, getActivity().MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN,"");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN,"");
        branchID=sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID,"");

    }
    public String getDateFromUTCTimestamp(long mTimestamp, String mDateFormate) {
        String date = null;
        try {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+05:30"));
            cal.setTimeInMillis(mTimestamp * 1000L);
            date = DateFormat.format(mDateFormate, cal.getTimeInMillis()).toString();

            SimpleDateFormat formatter = new SimpleDateFormat(mDateFormate);
            formatter.setTimeZone(TimeZone.getTimeZone("GMT+05:30"));
            Date value = formatter.parse(date);

            SimpleDateFormat dateFormatter = new SimpleDateFormat(mDateFormate);
            dateFormatter.setTimeZone(TimeZone.getDefault());
            date = dateFormatter.format(value);
            //txtDate.setText(date);
            requestBidAcceptedDateTime=date;
            return date;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

}
