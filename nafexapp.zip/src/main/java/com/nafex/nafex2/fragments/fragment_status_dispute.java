package com.nafex.nafex2.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.activity.Activity_Dispute_Comment_List;
import com.nafex.nafex2.adapters.AdapterDisputeStatus;
import com.nafex.nafex2.data.HistoryDispute;
import com.nafex.nafex2.interfaces.DisputeOperation;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.RecyclerItemClickListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sunil on 5/15/2017.
 */
public class fragment_status_dispute extends Fragment {
    TextView txtErrorMsg;
    private AdapterDisputeStatus adapterDisputeStatus;
    private RecyclerView mRecyclerView;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id, user_token, branchID;
    ProgressDialog progressDialog;
    List<HistoryDispute> historydisList;
    AppGlobalData gbData;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gbData = AppGlobalData.getInstance();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.lay_rise_dispute, container, false);
        init(view);
        getSharedPref();


        if (gbData.isConnected(getActivity())) {


            CallHistoryDisputeAPI callDisputeApiForHistory = new CallHistoryDisputeAPI();
            callDisputeApiForHistory.execute();
        }else {
            CommonUI.showAlert(getActivity(),getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");

        }

        setFont();
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }


    public void init(View view) {
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_riseDispute);
        /*mRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intdispcmtlist=new Intent(getActivity(), Activity_Dispute_Comment_List.class);
                intdispcmtlist.putExtra("disputeid",historydisList.get(position).disputeId);
                startActivity(intdispcmtlist);


            }
        }));*/
        //txtErrorMsg=(TextView)view.findViewById(R.id.txt_errorMsg);
    }

    private void getSharedPref() {
        progressDialog = new ProgressDialog(getActivity());
        sharedpreferences = getActivity().getSharedPreferences(ConstantData.MyPREFERENCES, getActivity().MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }

    public class CallHistoryDisputeAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

           // if (Error_Message.equalsIgnoreCase("")) {
                adapterDisputeStatus = new AdapterDisputeStatus(getActivity(), historydisList, new DisputeOperation() {
                    @Override
                    public void OnRespondclick(String kycId) {

                    }
                });
                mRecyclerView.setAdapter(adapterDisputeStatus);
           /* } else
                CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), Error_Message)*/;
            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CallForHistoryDispute();
            return "DONE";

        }

        private void CallForHistoryDispute() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.HistoryDISPUTELIST);
                //    URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + "/getRequestHistory");

                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    historydisList = new ArrayList<HistoryDispute>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        HistoryDispute objCity = new HistoryDispute();
                        objCity.setDisputeId(jsonObj.getString("disputeId"));
                        objCity.setRequestId(jsonObj.getString("requestId"));
                        objCity.setDisputeProductTypeId(jsonObj.getString("disputeProductTypeId"));
                        objCity.setRequestNBCNumber(jsonObj.getString("requestNBCNumber"));
                        objCity.setDisputeRaiseSource(jsonObj.getString("disputeRaiseSource"));
                        objCity.setDisputeType(jsonObj.getString("disputeType"));
                        objCity.setDisputeUserType(jsonObj.getString("disputeUserType"));
                        objCity.setUserReferenceId(jsonObj.getString("userReferenceId"));
                        objCity.setDisputeReasonId(jsonObj.getString("disputeReasonId"));
                        objCity.setDisputeSubject(jsonObj.getString("disputeSubject"));
                        objCity.setDisputeDetails(jsonObj.getString("disputeDetails"));
                        objCity.setDisputeQuantity(jsonObj.getString("disputeQuantity"));
                        objCity.setDisputeStatusId(jsonObj.getString("disputeStatusId"));
                        objCity.setCommissionRate(jsonObj.getString("commissionRate"));
                        objCity.setCreatedById(jsonObj.getString("createdById"));
                        objCity.setCreatedOn(jsonObj.getString("createdOn"));
                        objCity.setLastModifiedById(jsonObj.getString("lastModifiedById"));
                        objCity.setLastModifiedOn(jsonObj.getString("disputeReasonUnixTime"));
                        objCity.setRequestType(jsonObj.getString("requestType"));
                        objCity.setRequestSourceCurrencyId(jsonObj.getString("requestSourceCurrencyId"));
                        objCity.setRequestTargetCurrencyId(jsonObj.getString("requestTargetCurrencyId"));
                        objCity.setFFMCAddress1(jsonObj.getString("FFMCAddress1"));
                        objCity.setFFMCBranchLevel(jsonObj.getString("FFMCBranchLevel"));
                        objCity.setFFMCCompanyId(jsonObj.getString("FFMCCompanyId"));
                        objCity.setRequestQuantity(jsonObj.getString("requestQuantity"));
                        objCity.setRequestTypeName(jsonObj.getString("requestTypeName"));
                        objCity.setRequestSourceCurrencyName(jsonObj.getString("requestSourceCurrencyName"));
                        objCity.setRequestTargetCurrencyName(jsonObj.getString("requestTargetCurrencyName"));
                        objCity.setFFMCCompany(jsonObj.getString("FFMCCompany"));

                        historydisList.add(objCity);
                    }

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                 //   Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(getActivity(),getResources().getString(R.string.app_name),objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                /*if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in city data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }

    }


    public void setFont() {

        //txtErrorMsg.setTypeface(FontData.setFonts(getActivity(),txtErrorMsg,FontData.font_robotoregular));
    }
}