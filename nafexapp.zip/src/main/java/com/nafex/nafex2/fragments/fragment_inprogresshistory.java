package com.nafex.nafex2.fragments;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.activity.Activity_requesttrace;
import com.nafex.nafex2.activity.Activityrequesttracemenu;
import com.nafex.nafex2.adapters.RequestAdapterInProgressNew;
import com.nafex.nafex2.adapters.RequestAdapterProgress;
import com.nafex.nafex2.adapters.RequestHistoryAdapter;
import com.nafex.nafex2.data.RequestHistory;
import com.nafex.nafex2.interfaces.OnRequestSelected;
import com.nafex.nafex2.data.BidRequest;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Sunil on 5/15/2017.
 */
public class fragment_inprogresshistory extends Fragment implements OnRequestSelected {
    RecyclerView recycleHistory;
    RequestHistoryAdapter requestAdapter;
    ArrayList<BidRequest> arrRequests;
    private ProgressBar progressBar;
    AppGlobalData gbData;
    int iUserId;
    SharedPreferences sharedpreferences;
    RelativeLayout layHistoryMessage, layHistoryList;
    TextView txtHistoryMessage;
    String strtoken;
    private String sUserName, sUserEmail, sUserMobileNo, sOldpassword, sNewpassword, sConfirmpassword;
    ArrayList<RequestHistory> listreqhistory;
    RecyclerView lv_history;
    //RequestAdapterProgress adapter;
    RequestAdapterInProgressNew adapter;
    SharedPreferences.Editor editor;
    private boolean isViewShown = false;
    String UnixTime="";
    private final Handler handler = new Handler();


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        gbData = AppGlobalData.getInstance();

        arrRequests = new ArrayList<>();
        sharedpreferences = getActivity().getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.lay_history, container, false);
        recycleHistory = (RecyclerView) view.findViewById(R.id.recyclerHistory);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
        layHistoryList = (RelativeLayout) view.findViewById(R.id.layHistoryList);
        layHistoryMessage = (RelativeLayout) view.findViewById(R.id.layHistoryMessage);
        txtHistoryMessage = (TextView) view.findViewById(R.id.txtHistoryMessage);
        lv_history = (RecyclerView) view.findViewById(R.id.recycler_riseDispute);
        lv_history.setLayoutManager(new LinearLayoutManager(getContext()));
        txtHistoryMessage.setText("There are no inquiries history at the moment.");

        recycleHistory.setLayoutManager(new LinearLayoutManager(getActivity()));
        requestAdapter = new RequestHistoryAdapter(getActivity(), arrRequests, gbData, this);
        recycleHistory.setAdapter(requestAdapter);
        if (!isViewShown) {
            if (gbData.isConnected(getActivity())) {
                getSharedPref();
                lv_history.setVisibility(View.GONE);
                CallRequestHistory objRequestAPI = new CallRequestHistory();
                objRequestAPI.execute(CommonApi.REQUESTHISTORY);
            } else{
                showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");
                progressBar.setVisibility(View.GONE);
            }
            doTheAutoRefresh();

        }
        return view;
    }
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (getView() != null) {
            isViewShown = true;
            // fetchdata() contains logic to show data when page is selected mostly asynctask to fill the data
            if (gbData.isConnected(getActivity())) {
                getSharedPref();
                lv_history.setVisibility(View.GONE);
                CallRequestHistory objRequestAPI = new CallRequestHistory();
                objRequestAPI.execute(CommonApi.REQUESTHISTORY);
            } else{
                showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");
                progressBar.setVisibility(View.GONE);
            }
               //doTheAutoRefresh();

        } else {
            isViewShown = false;
        }
    }



    private void getSharedPref() {
        sharedpreferences = getActivity().getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");
    }

    public void doTheAutoRefresh() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Write code for your refresh logic
                try {
                    if (gbData.isConnected(getActivity())) {
                        getSharedPref();
                        lv_history.setVisibility(View.GONE);
                        CallRequestHistory objRequestAPI = new CallRequestHistory();
                        objRequestAPI.execute(CommonApi.REQUESTHISTORY);
                    } else{
                        try
                        {
                            showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");
                            progressBar.setVisibility(View.GONE);
                        }catch (IllegalStateException e){
                            e.printStackTrace();
                        }
                    }

                }catch (NullPointerException e){
                    e.printStackTrace();
                }
               /* try {
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    ft.detach(fragment_inprogress.this).attach(fragment_inprogress.this).commit();
                }catch (NullPointerException e){
                    e.printStackTrace();
                }*/


                doTheAutoRefresh();
            }
        }, 30000);
    }


    /*
     Call for getting history in track order
     */
    public class CallRequestHistory extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

        //    if (Error_Message.equalsIgnoreCase("")) {
            try {
                if (listreqhistory.size() > 0) {
                    lv_history.setVisibility(View.VISIBLE);
                    adapter = new RequestAdapterInProgressNew(getActivity(), listreqhistory);
                    lv_history.setAdapter(adapter);

                   /* lv_history.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                            setRequestpref(Integer.parseInt(listreqhistory.get(i).getRequestId()),listreqhistory.get(i).getRequestNBC());
                            Intent int_historydetails=new Intent(getActivity(), Activityrequesttracemenu.class);
                            startActivity(int_historydetails);
                           // getActivity().finish();
                        }
                    });*/
                }
            }catch (NullPointerException e){
                e.printStackTrace();
            }
           /* } else {
                CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), Error_Message);
            }*/

            progressBar.setVisibility(View.GONE);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForRequestHistory();
            return "DONE";

        }

        private void CallForRequestHistory() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.REQUESTHISTORY);
                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (iUserId + ":" + strtoken).getBytes();
                Log.e("iUserId",Integer.toString(iUserId));
                Log.e("strtoken",strtoken);

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result-history", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    listreqhistory = new ArrayList<RequestHistory>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        RequestHistory objCurrency = new RequestHistory();
                        String requestId = jsonObj.getString("requestId");
                        String requestType = jsonObj.getString("requestType");
                        String requestSourceCurrencyId = jsonObj.getString("requestSourceCurrencyId");
                        String requestTargetCurrencyId = jsonObj.getString("requestTargetCurrencyId");
                        String requestNBC = jsonObj.getString("requestNBC");
                        String requestStatusId = jsonObj.getString("requestStatusId");
                       // String createdOn = jsonObj.getString("createdOn");

                        long time= Long.parseLong(jsonObj.getString("requestUnixTime"));
                        String OUTPUT_DATE_FORMATE="MMM dd - h:mm a";
                        getDateFromUTCTimestamp(time,OUTPUT_DATE_FORMATE);

                        String requestTypeName = jsonObj.getString("requestTypeName");
                        String requestSourceCurrencyName = jsonObj.getString("requestSourceCurrencyName");
                        String requestTargetCurrencyName = jsonObj.getString("requestTargetCurrencyName");
                        String requestStatusName = jsonObj.getString("requestStatusName");
                        String createdon = jsonObj.getString("createdOn");
                     // String requestUnixTime=jsonObj.getString("requestUnixTime");


                        String requestDeliveryModeName=jsonObj.getString("requestDeliveryModeName");
                        if (requestStatusId.equalsIgnoreCase("1") || requestStatusId.equalsIgnoreCase("4")) {

                            objCurrency.setRequestId(requestId);
                            objCurrency.setRequestType(requestType);
                            objCurrency.setRequestSourceCurrencyId(requestSourceCurrencyId);
                            objCurrency.setRequestTargetCurrencyId(requestTargetCurrencyId);
                            objCurrency.setRequestNBC("NBC" + requestNBC);
                            objCurrency.setRequestStatusId(requestStatusId);
                            objCurrency.setCreatedOn(UnixTime);
                            objCurrency.setRequestTypeName(requestTypeName);
                            objCurrency.setRequestSourceCurrencyName(requestSourceCurrencyName);
                            objCurrency.setRequestTargetCurrencyName(requestTargetCurrencyName);
                            objCurrency.setRequestStatusName(requestStatusName);
                          //  objCurrency.setCreatedOn(createdon);
                            objCurrency.setRequestDeliveryModeName(requestDeliveryModeName);


                            JSONArray jsonDataset1 = jsonObj.getJSONArray("requestProducts");
                            if (jsonDataset1.length() == 2) {


                                JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                                String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                                String requestQuantity = jsonObjectInner.getString("requestQuantity");
                                String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");

                                JSONObject jsonObjectInner2 = jsonDataset1.getJSONObject(1);
                                String requestProductTypeId1 = jsonObjectInner2.getString("requestProductTypeId");
                                String requestQuantity1 = jsonObjectInner2.getString("requestQuantity");
                                String requestProductTypeName1 = jsonObjectInner2.getString("requestProductTypeName");

                                int totalquantity = Integer.parseInt(requestQuantity1) + Integer.parseInt(requestQuantity) ;
                                /*int totalquantity = Integer.parseInt(requestQuantity1) + Integer.parseInt(requestQuantity);
                                Log.e("TotalQTYYYYYYYYYYYYYYYYYYYYYY",""+totalquantity);*/

                                objCurrency.setRequestProductTypeId(requestProductTypeId);
                                objCurrency.setRequestQuantity(Integer.toString(totalquantity));
                                objCurrency.setNewProduct("2");
                                objCurrency.setNewProductQnt(requestProductTypeName+" - "+requestQuantity+" | "+requestProductTypeName1+" - "+requestQuantity1);

                                objCurrency.setRequestProductTypeName(requestProductTypeName +" | "+requestProductTypeName1);


                            }else if (jsonDataset1.length()==1){
                                JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                                String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                                String requestQuantity = jsonObjectInner.getString("requestQuantity");
                                String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");
                                objCurrency.setRequestProductTypeId(requestProductTypeId);
                                objCurrency.setRequestQuantity(requestQuantity);
                                objCurrency.setRequestProductTypeName(requestProductTypeName);
                                if (requestType.equalsIgnoreCase("3")){
                                    String requestPurposeName=jsonObjectInner.getString("requestPurposeName");
                                    String requestCountryName=jsonObjectInner.getString("requestCountryName");
                                    String requestTransferTypeName=jsonObjectInner.getString("requestTransferTypeName");
                                    objCurrency.setRequestCountryName(requestCountryName);
                                    objCurrency.setRequestPurposeName(requestPurposeName);
                                    objCurrency.setRequestTransferTypeName(requestTransferTypeName);
                                }


                            }
                            JSONObject jsonDatasetArea = jsonObj.getJSONObject("locationName");

                                String AreaName= jsonDatasetArea.getString("areaName");
                                String cityName= jsonDatasetArea.getString("cityName");
                                String stateName= jsonDatasetArea.getString("stateName");
                                String countryName = jsonDatasetArea.getString("countryName");
                            objCurrency.setAreaName(AreaName);
                            objCurrency.setCityName(cityName);
                            objCurrency.setStateName(stateName);
                            objCurrency.setCountryName(countryName);

                           /* if (jsonDataset1.length() == 1) {
                                JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                                String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                                String requestQuantity = jsonObjectInner.getString("requestQuantity");
                                String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");

                                if (requestType.equalsIgnoreCase("3")){
                                    String requestPurposeName=jsonObjectInner.getString("requestPurposeName");
                                    String requestCountryName=jsonObjectInner.getString("requestCountryName");
                                    String requestTransferTypeName=jsonObjectInner.getString("requestTransferTypeName");
                                    objCurrency.setRequestCountryName(requestCountryName);
                                    objCurrency.setRequestPurposeName(requestPurposeName);
                                    objCurrency.setRequestTransferTypeName(requestTransferTypeName);
                                }
                                objCurrency.setRequestProductTypeId(requestProductTypeId);
                                objCurrency.setRequestQuantity(requestQuantity);
                                objCurrency.setRequestProductTypeName(requestProductTypeName);
                            }*/
                            listreqhistory.add(objCurrency);
                        }
                    }

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(getActivity(), getResources().getString(R.string.app_name), Error_Message);
                }
            } catch (JSONException e) {
               /* Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
               /* Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";*/
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    private void setRequestpref(int requestid, String nbc) {
        sharedpreferences = getActivity().getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_requestid, requestid);
        editor.putString(ConstantData.KEY_nbc, nbc);
        editor.commit();
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }


    public class CallRequestAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

        /*    if (Error_Message.equalsIgnoreCase("")) {*/
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    JSONArray jsonArray;
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                        //JSONObject obj = objdata.getJSONObject("data_text");
                        jsonArray = objdata.getJSONArray("data_text");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObj = jsonArray.getJSONObject(i);
                            if (!jsonObj.getString("reqStatus").equalsIgnoreCase("O") && !jsonObj.getString("reqStatus").equalsIgnoreCase("F")) {
                                Double rate = 0.00;
                                if (jsonObj.getString("reqWinnerRate") != null && !jsonObj.getString("reqWinnerRate").toString().equalsIgnoreCase("") && !jsonObj.getString("reqWinnerRate").toString().equalsIgnoreCase("null"))
                                    rate = Double.parseDouble(jsonObj.getString("reqWinnerRate"));

                                BidRequest obj = new BidRequest(jsonObj.getInt("reqId"), jsonObj.getString("NBC"), jsonObj.getInt("reqQuantity"),
                                        jsonObj.getInt("reqWinnerFFMCId"), rate, jsonObj.getString("reqStatus"), jsonObj.getString("Type"), jsonObj.getString("Mode"), jsonObj.getString("AreaName"), jsonObj.getString("createdOn"), jsonObj.getString("currencyAbbrivation"), jsonObj.getString("remaining"));

                                arrRequests.add(obj);
                            }
                        }

                        requestAdapter.notifyDataSetChanged();

                        if (arrRequests.size() > 0) {
                            layHistoryList.setVisibility(View.VISIBLE);
                            layHistoryMessage.setVisibility(View.GONE);
                        } else {
                            layHistoryMessage.setVisibility(View.VISIBLE);
                            layHistoryList.setVisibility(View.GONE);
                        }
                    } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                        //showAlert(getResources().getString(R.string.app_name),objdata.getString("message_text") );
                        if (arrRequests.size() > 0) {
                            layHistoryList.setVisibility(View.VISIBLE);
                            layHistoryMessage.setVisibility(View.GONE);
                        } else {
                            layHistoryMessage.setVisibility(View.VISIBLE);
                            layHistoryList.setVisibility(View.GONE);
                        }

                    }
                } catch (Exception e) {
                    Log.e("Exceptionnnn",""+e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "No data received from server. Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";*/
                }
            /*} else
                showAlert(getResources().getString(R.string.app_name), Error_Message);*/

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(ConstantData.SERVER_URL + ConstantData.BASE_URL + ConstantData.GETREQUESTS);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();

                    postDataParams.put("UserId", iUserId);

                    Log.e("params", postDataParams.toString());

                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(60000 /* milliseconds */);
                    urlConnection.setConnectTimeout(60000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();

                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result**INprogress", strResponse);
                    }
                } catch (Exception e) {
                    Log.e("ERROR", e.getMessage(), e);
                 //   Error_Message = "Error: " + e.getClass().getName() + " in get request. Please contact Nafex support team.";
                } /*finally {
                    urlConnection.disconnect();
                }*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
               // Error_Message = "Error: " + e.getClass().getName() + " in get request. Please contact Nafex support team.";
            }

            return null;
        }
    }


    private void showAlert(String title, String message) {
        new AlertDialog.Builder(getActivity())
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }

    @Override
    public void onInfoButtonClicked(String sNBC) {
        Intent i = new Intent(getActivity(), Activity_requesttrace.class);
        i.putExtra("NBC", sNBC);
        i.putExtra("Source", "OLDREQUEST");
        startActivity(i);
        getActivity().finish();
    }

    public String getDateFromUTCTimestamp(long mTimestamp, String mDateFormate) {
        String date = null;
        try {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+05:30"));
            cal.setTimeInMillis(mTimestamp * 1000L);
            date = DateFormat.format(mDateFormate, cal.getTimeInMillis()).toString();

            SimpleDateFormat formatter = new SimpleDateFormat(mDateFormate);
            formatter.setTimeZone(TimeZone.getTimeZone("GMT+05:30"));
            Date value = formatter.parse(date);

            SimpleDateFormat dateFormatter = new SimpleDateFormat(mDateFormate);
            dateFormatter.setTimeZone(TimeZone.getDefault());
            date = dateFormatter.format(value);
            //txtDate.setText(date);
            UnixTime=date;
            return date;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }




}
