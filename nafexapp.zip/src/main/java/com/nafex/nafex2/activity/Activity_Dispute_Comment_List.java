package com.nafex.nafex2.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.AdapterDisputeComment;
import com.nafex.nafex2.data.DisputeComment;
import com.nafex.nafex2.interfaces.RefreshDisputeOperations;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rahul on 27/10/17.
 */

public class Activity_Dispute_Comment_List extends AppCompatActivity implements RefreshDisputeOperations {




    private RecyclerView mRecyclerView;
    private AdapterDisputeComment mAdapterDisputeComment;
    List<DisputeComment> discomment;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id, user_token, branchID;
    AppGlobalData gbData;
    String strdisputeid = "";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dispute_comment);
        init();
    }

    private void init() {
        gbData = AppGlobalData.getInstance();
        gbData.setStatusBarColor(Activity_Dispute_Comment_List.this,R.color.colorPrimaryDark);
        getSharedPref();
        Intent intgetdispute = getIntent();
        strdisputeid = intgetdispute.getStringExtra("disputeid");
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_dispute_comment);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        if (gbData.isConnected(Activity_Dispute_Comment_List.this)) {
            CallDisputeCommentAPI obdisputecmt = new CallDisputeCommentAPI();
            obdisputecmt.execute();

        } else {
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
        }
    }

    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES,MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }

    @Override
    public void onRefreshdisputelist(String value) {
        if (gbData.isConnected(Activity_Dispute_Comment_List.this)) {
            CallDisputeCommentAPI obdisputecmt = new CallDisputeCommentAPI();
            obdisputecmt.execute();

        } else {
            CommonUI.showAlert(this,getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");

        }

    }


    public  class CallDisputeCommentAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //  progressDialog.setMessage("Loading...");
            //  progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //if (Error_Message.equalsIgnoreCase("")) {
                mAdapterDisputeComment = new AdapterDisputeComment(Activity_Dispute_Comment_List.this, discomment,Activity_Dispute_Comment_List.this);
                mRecyclerView.setAdapter(mAdapterDisputeComment);
           //} else
            {

            }
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CallForDisputeCommentList();
            return "DONE";

        }

        private void CallForDisputeCommentList() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.DISPUTECOMMENTLIST + strdisputeid);
                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();

                byte[] auth = (user_id + ":" + user_token).getBytes();


                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);

                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                //   Log.e("userid",user_id);
                // Log.e("user_token",user_token);


                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    discomment = new ArrayList<DisputeComment>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        DisputeComment objdiscmt = new DisputeComment();
                        objdiscmt.setDisputeCommentId(jsonObj.getString("disputeCommentId"));
                        objdiscmt.setRequestId(jsonObj.getString("requestId"));
                        objdiscmt.setRequestNBCNumber(jsonObj.getString("requestNBCNumber"));
                        objdiscmt.setDisputeId(jsonObj.getString("disputeId"));
                        objdiscmt.setCreatedById(jsonObj.getString("createdById"));
                        objdiscmt.setCreatedOn(jsonObj.getString("createdOn"));
                        objdiscmt.setCallComment(jsonObj.getString("callComment"));
                        objdiscmt.setCallNextAction(jsonObj.getString("callNextAction"));
                        discomment.add(objdiscmt);
                    }


                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                  //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_Dispute_Comment_List.this,getResources().getString(R.string.app_name), objdata.getString("message_text"));

                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
               /* if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
             //   Error_Message = "Error: " + e.getClass().getName() + " in city data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }

    }


}
