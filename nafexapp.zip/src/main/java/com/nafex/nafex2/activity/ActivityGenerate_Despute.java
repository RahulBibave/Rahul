package com.nafex.nafex2.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nafex.nafex2.R;
import com.nafex.nafex2.data.EnquiryData;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by rahul on 4/10/17.
 */

public class ActivityGenerate_Despute extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbarTop;
    private TextView txtHeder;
    private TextView txtGenrateDispute;
    private TextView txtDisputeDetail;
    private TextView txtCustName, TotalCommission, txtCommission, txtArea, txtCity, txtCountry, txtProduct, txtExchangeBy,
            txtCurrency, txtQuantity, txtEnquiryType, txtNBCNo, txtMobileNo;
    private EditText edtCustName, edtMobileNo, edtNBCNumber, edtEnquiryType, edtQuantity, edtCurrency,
            edtExchangeBy, edtProduct, edtCountry, edtCity, edtArea, edtCommission, edtTotalCommission;

    private TextView txtDisputeDesc;
    private TextView txtHowMuch;
    private TextView txtHowMuch2;
    private EditText edtEg10;
    private TextView txtActualCommission;
    private EditText edtActualCommission;
    private TextView txtRefundAmount;
    private EditText edtRefundAmount;
    private TextView txtRefundType;
    private EditText edtRefundType;
    private TextView txtDesc;
    private EditText edtDesc;
    private Button btnCancle, btnSubmit;
    AppGlobalData gbData;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id, user_token, branchID;
    String enquiryjson;
    int position;
    String strRequestId,strdisputeproducttypeid,strnbcnumber,strdisputeRaiseSource,strdisputeType,strdisputeUserType,struserReferenceId,strdisputeReasonId,strdisputestatusid,strdisputequantity,strproducttypeid;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay_generate_dispute);
        findViews();
        getSharedPref();
        setData();
//        CallProductAPI callDisputeApiForHistory=new CallProductAPI();
//        callDisputeApiForHistory.execute();


    }

    private void setData() {
        Type type = new TypeToken<List<EnquiryData>>() {
        }.getType();
        List<EnquiryData> inpList = new Gson().fromJson(enquiryjson, type);
        for (int i = 0; i < inpList.size(); i++) {
            EnquiryData x = inpList.get(position);
            Log.e("name", x.getUserName());
            System.out.println(x);
            edtCustName.setText(x.getUserName());
            edtMobileNo.setText(x.getUserMobileNo());
            edtNBCNumber.setText("NBC " + x.getRequestNBC());
            edtEnquiryType.setText(x.getRequestTypeName());
            edtQuantity.setText(x.getRequestQuantity());
            edtCurrency.setText(x.getRequestSourceCurrencyName());
            edtExchangeBy.setText(x.getRequestTargetCurrencyName());
            edtProduct.setText(x.getRequestProductTypeName());
            edtCountry.setText(x.getCountryName());
            edtCity.setText(x.getCityName());
            edtArea.setText(x.getAreaName());


            strRequestId=x.getRequestId();
            strdisputeproducttypeid=x.getRequestDisputeId();
            strnbcnumber=x.getRequestNBC();
            strdisputestatusid=x.getDisputeStatusId();
            strproducttypeid=x.getRequestProductTypeId();



            edtCommission.setText(x.getCommissionRate());
            Float value = Float.parseFloat(x.getRequestQuantity()) * Float.parseFloat(edtCommission.getText().toString().trim());
            edtTotalCommission.setText(Float.toString(value));

            edtEg10.addTextChangedListener(new TextWatcher() {
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (!edtEg10.getText().toString().equalsIgnoreCase("")) {
                        Float act = Float.parseFloat(edtEg10.getText().toString().trim()) * Float.parseFloat(edtCommission.getText().toString().trim());
                        edtActualCommission.setText(Float.toString(act));
                        Float refamt = Float.parseFloat(edtTotalCommission.getText().toString().trim()) - act;
                        edtRefundAmount.setText(Float.toString(refamt));
                        if (refamt < 0) {
                            edtRefundType.setText("EXCESS COMMISION");
                        } else {
                            if (refamt == 0) {
                                edtRefundType.setText("NO REFUND");

                            } else {
                                edtRefundType.setText("PARTIAL REFUND");

                            }

                        }
                    }
                    // TODO Auto-generated method stub
                }

                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    // TODO Auto-generated method stub
                }

                @Override
                public void afterTextChanged(Editable s) {

                    // TODO Auto-generated method stub
                }
            });


        }

    }

    private void findViews() {
        Intent ints = getIntent();
        enquiryjson = ints.getStringExtra("enquiryListGson");
        position = ints.getIntExtra("position", 0);

        gbData = AppGlobalData.getInstance();
        gbData.setStatusBarColor(ActivityGenerate_Despute.this, R.color.colorPrimaryDark);

        toolbarTop = (Toolbar) findViewById(R.id.toolbar_top);
        txtHeder = (TextView) findViewById(R.id.txt_heder);
        txtGenrateDispute = (TextView) findViewById(R.id.txtGenrateDispute);
        txtDisputeDetail = (TextView) findViewById(R.id.txtDisputeDetail);
        txtCustName = (TextView) findViewById(R.id.txt_custName);
        edtCustName = (EditText) findViewById(R.id.edtCustName);
        txtMobileNo = (TextView) findViewById(R.id.txt_MobileNo);
        edtMobileNo = (EditText) findViewById(R.id.edtMobileNo);
        txtNBCNo = (TextView) findViewById(R.id.txt_NBC_No);
        edtNBCNumber = (EditText) findViewById(R.id.edtNBCNumber);
        txtEnquiryType = (TextView) findViewById(R.id.txt_Enquiry_type);
        edtEnquiryType = (EditText) findViewById(R.id.edtEnquiryType);
        txtQuantity = (TextView) findViewById(R.id.txt_Quantity);
        edtQuantity = (EditText) findViewById(R.id.edtQuantity);
        txtCurrency = (TextView) findViewById(R.id.txt_Currency);
        edtCurrency = (EditText) findViewById(R.id.edtCurrency);
        txtExchangeBy = (TextView) findViewById(R.id.txt_Exchange_By);
        edtExchangeBy = (EditText) findViewById(R.id.edtExchangeBy);
        txtProduct = (TextView) findViewById(R.id.txt_Product);
        edtProduct = (EditText) findViewById(R.id.edtProduct);
        txtCountry = (TextView) findViewById(R.id.txt_Country);
        edtCountry = (EditText) findViewById(R.id.edtCountry);
        txtCity = (TextView) findViewById(R.id.txt_City);
        edtCity = (EditText) findViewById(R.id.edtCity);
        txtArea = (TextView) findViewById(R.id.txt_Area);
        edtArea = (EditText) findViewById(R.id.edtArea);
        txtCommission = (TextView) findViewById(R.id.txt_Commission);
        edtCommission = (EditText) findViewById(R.id.edtCommission);
        TotalCommission = (TextView) findViewById(R.id.Total_Commission);
        edtTotalCommission = (EditText) findViewById(R.id.edtTotalCommission);
        txtDisputeDesc = (TextView) findViewById(R.id.txt_Dispute_Desc);
        txtHowMuch = (TextView) findViewById(R.id.txt_HowMuch);
        txtHowMuch2 = (TextView) findViewById(R.id.txt_HowMuch2);
        edtEg10 = (EditText) findViewById(R.id.edtEg10);
        txtActualCommission = (TextView) findViewById(R.id.txt_ActualCommission);
        edtActualCommission = (EditText) findViewById(R.id.edtActualCommission);
        txtRefundAmount = (TextView) findViewById(R.id.txt_Refund_Amount);
        edtRefundAmount = (EditText) findViewById(R.id.edtRefundAmount);
        txtRefundType = (TextView) findViewById(R.id.txt_Refund_Type);
        edtRefundType = (EditText) findViewById(R.id.edtRefundType);
        txtDesc = (TextView) findViewById(R.id.txt_Desc);
        edtDesc = (EditText) findViewById(R.id.edtDesc);
        btnCancle = (Button) findViewById(R.id.btnCancle);
        btnSubmit = (Button) findViewById(R.id.btn_Submit);
        btnSubmit.setOnClickListener(this);
        btnCancle.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btnCancle:
                finish();

                break;
            case R.id.btn_Submit:
                validateGenerateDispute();

                break;


        }
    }

    public void validateGenerateDispute() {

        String strvalidconv = edtEg10.getText().toString().trim();
        String strdisputedesc = edtDesc.getText().toString().trim();
        if (strvalidconv.equalsIgnoreCase("")) {
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter valid actual converted quantity.");

        } else {
            if (strdisputedesc.equalsIgnoreCase("")) {
                gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter dispute description.");

            } else {
                if (gbData.isConnected(ActivityGenerate_Despute.this)) {
                    //api call for Dispute
                    CallGenerateDisputeAPI callDisputeApi = new CallGenerateDisputeAPI();
                    callDisputeApi.execute();
                }
            }
        }


    }

    public  void showsuccessAlert(Context mycontext, String title, String message) {
        new AlertDialog.Builder(mycontext)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }



    public class CallGenerateDisputeAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objmsgtext=null;
                    JSONObject objmsgtextin=null;

                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                         objmsgtext = objdata.getJSONObject("message_text");
                        String msg = objmsgtext.getString("msg");
                        showsuccessAlert(ActivityGenerate_Despute.this, getResources().getString(R.string.app_name), msg);

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(ActivityGenerate_Despute.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(ActivityGenerate_Despute.this, getResources().getString(R.string.app_name), Error_Message);
                }
                //  showProductAlertCustomDialog();

            } else
                CommonUI.showAlert(ActivityGenerate_Despute.this, getResources().getString(R.string.app_name), Error_Message);

            // progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.NEWDISPUTE);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("requestId", strRequestId);
                postDataParams.put("disputeProductTypeId", strproducttypeid);
                postDataParams.put("requestNBCNumber", strnbcnumber);
                postDataParams.put("disputeRaiseSource", "5");
                postDataParams.put("disputeType", "1");
                postDataParams.put("disputeUserType", "1");
                postDataParams.put("userReferenceId", "1");   //?
                postDataParams.put("disputeReasonId", "1");
                postDataParams.put("disputeSubject", "New+Dispute");
                postDataParams.put("disputeDetails", edtDesc.getText().toString().trim());
                postDataParams.put("disputeStatusId", strdisputestatusid);
                postDataParams.put("disputeQuantity", edtEg10.getText().toString().trim());
                postDataParams.put("commissionRate", edtCommission.getText().toString().trim());
                postDataParams.put("requestQuantity", edtQuantity.getText().toString().trim());

                byte[] auth = (user_id + ":" + user_token).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }

    }


    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }


}
