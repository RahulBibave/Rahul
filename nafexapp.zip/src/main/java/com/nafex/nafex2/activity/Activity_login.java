package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.PatternMatcher;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nafex.nafex2.NafexApplication;
import com.nafex.nafex2.R;
import com.nafex.nafex2.api.VolleyResponseListener;
import com.nafex.nafex2.api.VolleyUtils;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;
import com.nafex.nafex2.utilities.Validation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import cc.cloudist.acplibrary.ACProgressConstant;
import cc.cloudist.acplibrary.ACProgressFlower;

public class Activity_login extends AppCompatActivity implements View.OnClickListener {


    private LinearLayout layExistingUser, layNewUser;
    private RadioGroup rdOptions;
    EditText edt_Username, edt_Password;
    private String OptionSelected = "";
    private AppGlobalData gbData;
    private RelativeLayout btnRegister, btnLogin;
    TextView txt_ForgotPassword, txt_SignUp, txt_SignIn, txt_NotMember;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    ProgressDialog pd_login;
    private String mUrl;
    private String userType;
    String userID,token,username,usermobile,usertype,userrole,useremail,branchID;
    LinearLayout linear_travel_agent;
    TextView txtTravelAgent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_n);
        initView();
        setTypeface();
        // setOpacityView();
        clickListeners();

        edt_Username.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if (isNumeric(charSequence.toString())){
                    int maxLength = 10;
                    InputFilter[] fArray = new InputFilter[1];
                    fArray[0] = new InputFilter.LengthFilter(maxLength);
                    edt_Username.setFilters(fArray);
                }else {
                    int maxLength = 100;
                    InputFilter[] fArray = new InputFilter[1];
                    fArray[0] = new InputFilter.LengthFilter(maxLength);
                    edt_Username.setFilters(fArray);
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        linear_travel_agent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Activity_login.this,Activity_travel_Agent.class);
                startActivity(intent);
            }
        });
    }

    private void setTypeface() {
        edt_Username.setTypeface(FontData.setFonts(Activity_login.this, edt_Username, FontData.font_robotoregular));
        edt_Password.setTypeface(FontData.setFonts(Activity_login.this, edt_Password, FontData.font_robotoregular));
        txt_ForgotPassword.setTypeface(FontData.setFonts(Activity_login.this, txt_ForgotPassword, FontData.font_robotolight));
        txt_SignIn.setTypeface(FontData.setFonts(Activity_login.this, txt_SignIn, FontData.font_robotoregular));
        txt_NotMember.setTypeface(FontData.setFonts(Activity_login.this, txt_NotMember, FontData.font_robotoregular));
        txt_SignUp.setTypeface(FontData.setFonts(Activity_login.this, txt_SignUp, FontData.font_robotoregular));
        txtTravelAgent.setTypeface(FontData.setFonts(Activity_login.this, txtTravelAgent, FontData.font_robotoregular));
    }

    private void HideKeybaord() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }


    /*
       Clicklistners for Views
     */
    private void clickListeners() {
        btnLogin.setOnClickListener(this);
        txt_SignUp.setOnClickListener(this);
        txt_ForgotPassword.setOnClickListener(this);
    }

    /*
    Going to Forgot Password screens
     */
    private void GotoFFMCMain() {
        Intent intent = new Intent(Activity_login.this, activity_ffmcmain.class);
        startActivity(intent);
        finish();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(Activity_login.this,Activity_main.class);
        startActivity(intent);
        finish();
    }

    /*
     Initialization of views
    */
    public void initView() {
        pd_login = new ProgressDialog(Activity_login.this);
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();

        gbData = AppGlobalData.getInstance();
        OptionSelected = "N";
        gbData.setStatusBarColor(Activity_login.this, R.color.colorPrimaryDark);
        btnLogin = (RelativeLayout) findViewById(R.id.btnLogin);
        txt_ForgotPassword = (TextView) findViewById(R.id.txtForgotPassword);
        txt_SignUp = (TextView) findViewById(R.id.txt_SignUp);
        edt_Username = (EditText) findViewById(R.id.txtUserLoginMobileNo);
        edt_Password = (EditText) findViewById(R.id.txtUserPassword);
        txt_SignIn = (TextView) findViewById(R.id.txt_signin);
        txt_NotMember = (TextView) findViewById(R.id.txt_notmember);
        linear_travel_agent=(LinearLayout)findViewById(R.id.linear_travel_agent);
        txtTravelAgent=(TextView)findViewById(R.id.txt_not_agent);

        validateuserType();
    }


    /*
    Click listener for Views
     */
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnLogin:
                HideKeybaord();

                if (gbData.isConnected(Activity_login.this)) {
                    submitLoginForm();
                } else {
                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                }

                // GotoFFMCMain();
                break;
            case R.id.txt_SignUp:
                Intent intentsignup = new Intent(Activity_login.this, Activity_signup.class);
                startActivity(intentsignup);
                break;
            case R.id.txtForgotPassword:
                Intent int_fgpwd=new Intent(Activity_login.this,Activity_ForgotPassword.class);
                startActivity(int_fgpwd);
                break;

        }

    }

    private void submitLoginForm() {
        if (gbData.isConnected(Activity_login.this)) {
            if (validateData()) {
                String loginCust=edt_Username.getText().toString();
                if (userType.equalsIgnoreCase("Customer")){
                    if (loginCust.length()!=10){
                        gbData.showAlert(this, getResources().getString(R.string.app_name), "Enter 10 digit mobile number.");


                    }
                    else if (loginCust.substring(0,1).equalsIgnoreCase("6")||loginCust.substring(0,1).equalsIgnoreCase("5")||loginCust.substring(0,1).equalsIgnoreCase("4")||
                            loginCust.substring(0,1).equalsIgnoreCase("1")||loginCust.substring(0,1).equalsIgnoreCase("2")||loginCust.substring(0,1).equalsIgnoreCase("3")||loginCust.substring(0,1).equalsIgnoreCase("0") ){
                            gbData.showAlert(this, getResources().getString(R.string.app_name), "Mobile number should start with  7,8 or 9");

                        }else {
                        CallLoginApi objRequestAPI = new CallLoginApi();
                        objRequestAPI.execute(CommonApi.CUSTOMER_LOGIN);

                    }

                }
                if (userType.equalsIgnoreCase("FFMC")){
                    CallLoginApi objRequestAPI = new CallLoginApi();
                    objRequestAPI.execute(CommonApi.CUSTOMER_LOGIN);
                }



            }
        } else {
            CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

        }


    }

    private void validateuserType() {
        edt_Username.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (Validation.isEmailAddress(edt_Username,true)){
                    Log.e("EmailID",""+edt_Username.getText().toString());
                    mUrl=CommonApi.FFMC_LOGIN;
                    userType="FFMC";
                }else
                {
                    Log.e("Phone",""+edt_Username.getText().toString());

                    mUrl=CommonApi.CUSTOMER_LOGIN;
                    userType="Customer";
                }
            }
        });



    }

    private boolean validateData() {
        String sUserEmail = edt_Username.getText().toString();
        String sUserPassword = edt_Password.getText().toString();
        if (sUserEmail.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter email address/mobile number.");
       /* else if (Validation.isEmailAddress(edt_Username, true)){
            Log.e("email ","email");
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter email.");
            mUrl=CommonApi.FFMC_LOGIN
        }*/
      /* if (userType.equalsIgnoreCase("Customer")){
           if (sUserEmail.length()!=10){
               gbData.showAlert(this, getResources().getString(R.string.app_name), "Enter 10 digit mobile number.");


           }
           else {
               if (sUserEmail.substring(0,1).equalsIgnoreCase("6")||sUserEmail.substring(0,1).equalsIgnoreCase("5")||sUserEmail.substring(0,1).equalsIgnoreCase("4")||
                       sUserEmail.substring(0,1).equalsIgnoreCase("1")||sUserEmail.substring(0,1).equalsIgnoreCase("2")||sUserEmail.substring(0,1).equalsIgnoreCase("3")||sUserEmail.substring(0,1).equalsIgnoreCase("0") ){
                   gbData.showAlert(this, getResources().getString(R.string.app_name), "Mobile number should start with  7,8 or 9");

               }

           }


       }*/


        else if (sUserPassword.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter password.");

        else
            return true;


        return false;
    }

    public static boolean isNumeric(String str) {
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) return false;
        }
        return true;
    }


    /*
     Track Order  Api
     */
    public class CallTrackOrderApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {


                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    {
                        CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                      /* if(userType.equalsIgnoreCase("FFMC")){
                            CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                        }else if (userType.equalsIgnoreCase("Customer")){
                            CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                        }
                        else {
                            CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                        }*/

                    }


                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);
                }
            } else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);

            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_TRACKORDER);
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("userId", "swarup.gosavi@gmail.com");
                postDataParams.put("userMobileNo", "swarup.gosavi@gmail.com");
                postDataParams.put("userNBCNo", "swarup.gosavi@gmail.com");

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }
    }



    /*
     Login Api
     */
    public class CallLoginApi extends AsyncTask<String, Void, String> {



        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

          //  if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";
                Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        /*if(userType.equalsIgnoreCase("Customer")) {
                        JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        String userId = (String) objmsgtext.get("userId");
                        String userName = (String) objmsgtext.get("userName");
                        String userMobileNo = (String) objmsgtext.get("userMobileNo");
                        String userEmail = (String) objmsgtext.get("userEmail");
                        String userToken = (String) objmsgtext.get("userToken");
                        setSharedPref(Integer.parseInt(userId),userName,userEmail,userMobileNo,userToken);
                        Intent int_mainscreen=new Intent(Activity_login.this,Activity_main.class);
                        startActivity(int_mainscreen);
                        finish();
                        }else
                        {
                            JSONArray jsonArray=objdata.getJSONArray("message_text");
                            for (int i=0;i<jsonArray.length();i++){
                                JSONObject jsonObjectInner=jsonArray.getJSONObject(i);
                                userID=jsonObjectInner.getString("userId");
                                username=jsonObjectInner.getString("userName");
                                token=jsonObjectInner.getString("userToken");
                                useremail=jsonObjectInner.getString("userEmail");
                                usermobile=jsonObjectInner.getString("userMobile");
                                usertype=jsonObjectInner.getString("userType");
                                userrole=jsonObjectInner.getString("userRoleId");
                                branchID=jsonObjectInner.getString("FFMCBranchId");
                                setSharedPrefFFMC(userID,username,useremail,usermobile,token,usertype,userrole,"YES");
                                ConstantData.USERID=userID;
                                ConstantData.token=token;

                                Intent intent = new Intent(Activity_login.this, activity_ffmcmain.class);
                                startActivity(intent);
                                finish();
                            }


                        }*/
                            JSONObject objmsgtext = objdata.getJSONObject("message_text");
                           /* if(objmsgtext.get("userType").toString().equalsIgnoreCase("Customer")) {
                                String userId = (String) objmsgtext.get("userId");
                                String userName = (String) objmsgtext.get("userName");
                                String userMobileNo = (String) objmsgtext.get("userMobileNo");
                                String userEmail = (String) objmsgtext.get("userEmail");
                                String userToken = (String) objmsgtext.get("userToken");
                                String userType=(String)objmsgtext.get("userType");
                                String userReferenceId=(String) objmsgtext.get("userReferenceId");
                                String userRoleId=(String) objmsgtext.get("userRoleId");
                                setSharedPref(Integer.parseInt(userId), userName, userEmail, userMobileNo, userToken,userType,userReferenceId,userRoleId);
                                Intent int_mainscreen = new Intent(Activity_login.this, Activity_main.class);
                                startActivity(int_mainscreen);
                                finish();
                            }*/


                        if(objmsgtext.get("userRoleId").toString().equalsIgnoreCase("1")||objmsgtext.get("userRoleId").toString().equalsIgnoreCase("8")) {
                            String userId = (String) objmsgtext.get("userId");
                            String userName = (String) objmsgtext.get("userName");
                            String userMobileNo = (String) objmsgtext.get("userMobileNo");
                            String userEmail = (String) objmsgtext.get("userEmail");
                            String userToken = (String) objmsgtext.get("userToken");
                            String userType=(String)objmsgtext.get("userType");
                            String userReferenceId=(String) objmsgtext.get("userReferenceId");
                            String userRoleId=(String) objmsgtext.get("userRoleId");


                            setSharedPref(Integer.parseInt(userId), userName, userEmail, userMobileNo, userToken,userType,userReferenceId,userRoleId);
                            Intent int_mainscreen = new Intent(Activity_login.this, Activity_main.class);
                            startActivity(int_mainscreen);
                            finish();
                        }
                           else if (objmsgtext.get("userRoleId").toString().equalsIgnoreCase("7")){
                                userID=objmsgtext.getString("userId");
                                username=objmsgtext.getString("userName");
                                token=objmsgtext.getString("userToken");
                                useremail=objmsgtext.getString("userEmail");
                                usermobile=objmsgtext.getString("userMobile");
                                usertype=objmsgtext.getString("userType");
                                userrole=objmsgtext.getString("userRoleId");
                                branchID=objmsgtext.getString("FFMCBranchId");


                            String userLatitude=(String)objmsgtext.getString("userLatitude");
                            String userLongitude=(String)objmsgtext.getString("userLongitude");
                            String area=(String)objmsgtext.getString("areaName");
                            String cityName=(String)objmsgtext.getString("cityName");
                            String areaName=area+","+cityName;
                                setSharedPrefFFMC(userID,username,useremail,usermobile,token,usertype,userrole,"YES",userLatitude,userLongitude,areaName);
                                ConstantData.USERID=userID;
                                ConstantData.token=token;
                                ConstantData.branchId=branchID;
                                Intent intent = new Intent(Activity_login.this, activity_enquiries.class);
                                startActivity(intent);
                                finish();
                            }else {
                            CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), "Invalid user");
                            edt_Username.setText("");
                            edt_Password.setText("");
                        }




                       /* else if(objmsgtext.get("userType").toString().equalsIgnoreCase("FFMC")) {
                            userID=objmsgtext.getString("userId");
                            username=objmsgtext.getString("userName");
                            token=objmsgtext.getString("userToken");
                            useremail=objmsgtext.getString("userEmail");
                            usermobile=objmsgtext.getString("userMobile");
                            usertype=objmsgtext.getString("userType");
                            userrole=objmsgtext.getString("userRoleId");
                            branchID=objmsgtext.getString("FFMCBranchId");
                            setSharedPrefFFMC(userID,username,useremail,usermobile,token,usertype,userrole,"YES");
                            ConstantData.USERID=userID;
                            ConstantData.token=token;
                            ConstantData.branchId=branchID;
                            Intent intent = new Intent(Activity_login.this, activity_ffmcmain.class);
                            startActivity(intent);
                            finish();
                        }*/

                                //you have an object

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        if (userType.equals("FFMC")){
                            CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), "The Email or Password are inccorect. Please contact Nafex support team.");
                        }
                        else {
                            CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), "The Mobile or Password are inccorect. Please contact Nafex support team.");
                        }
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
            /*} else
                CommonUI.showAlert(Activity_login.this, getResources().getString(R.string.app_name), Error_Message);*/

            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                Log.e("mURL",""+mUrl);
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + mUrl);
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                if(userType.equals("FFMC"))
                {
                    postDataParams.put("userEmail", edt_Username.getText().toString().trim());
                }else {
                    postDataParams.put("userMobileNo", edt_Username.getText().toString().trim());
                }
                postDataParams.put("userPassword", edt_Password.getText().toString().trim());
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
           //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }

    private void setSharedPref(int id,String username,String useremail,String usermobno,String strtoken,String userType, String userReferenceId,String userRoleId) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_USERID, id);
        editor.putString(ConstantData.KEY_USERNAME, username);
        editor.putString(ConstantData.KEY_USEREMAIL, useremail);
        editor.putString(ConstantData.KEY_USERMOBILENO, usermobno);
        editor.putString(ConstantData.KEY_REGToken, strtoken);
        editor.putString(ConstantData.KEY_userReferenceId, userReferenceId);
        editor.putString(ConstantData.KEY_userRoleId, userRoleId);

        editor.commit();
    }


    private void setSharedPrefFFMC(String id,String user_name,String user_mail,String user_mobile,String user_token,String user_type,String user_role,String islogin,String userLatitude,String userLongitude,String areaName) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putString(ConstantData.KEY_USERID_LFFCMLOGIN, id);
        editor.putString(ConstantData.KEY_USERNAME_LFFCMLOGIN, user_name);
        editor.putString(ConstantData.KEY_USEREMAIL_LFFCMLOGIN, user_mail);
        editor.putString(ConstantData.KEY_USERMOBILENO_LFFCMLOGIN,user_mobile);
        editor.putString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, user_token);
        editor.putString(ConstantData.KEY_USERTYPE_LFFCMLOGIN, user_type);
        editor.putString(ConstantData.KEY_USERROLE_LFFCMLOGIN,user_role);
        editor.putString(ConstantData.KEY_ISLOGIN,islogin);
        editor.putString(ConstantData.KEY_FFCM_BRANCHID,branchID);
        editor.putString(ConstantData.KEY_FFMC_LAT,userLatitude);
        editor.putString(ConstantData.KEY_FFMC_LONG,userLongitude);
        editor.putString(ConstantData.KEY_FFMC_AREA,areaName);


        editor.commit();
    }
}
