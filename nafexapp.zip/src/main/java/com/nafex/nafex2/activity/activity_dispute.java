package com.nafex.nafex2.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.AdapterDisputeOpen;
import com.nafex.nafex2.adapters.TabAdapter;
import com.nafex.nafex2.fragments.fragment_status_dispute;
import com.nafex.nafex2.fragments.fragment_open_dispute;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Sunil on 5/15/2017.
 */
public class activity_dispute extends AppCompatActivity {
    ViewPager viewPager;
    TabLayout tabLayout;

    Toolbar toolbar;

    AppGlobalData gbData;
    String user_id, user_token, branchID;
    private SharedPreferences sharedpreferences;

    private NavigationView navigationView;
    private View navHeader;
    private DrawerLayout drawerLayout;
    private ProgressBar progressBar;
    private LinearLayout llMainView;
    FragmentManager fragmentManager;
    FragmentTransaction transaction;
    RadioGroup radioGroup_Dispute;
    private ImageView plus_icon_dispute;
    RadioButton radioButton_RaiseDispute,radioButton_DisputeHistory;
    TextView txt_header;
    private RecyclerView mRecyclerView;
    private AdapterDisputeOpen adapterDisputeopenOpen;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dispute_new);
        init();
        setFont();
        replaceFragment(new fragment_open_dispute());
        navigationView.inflateMenu(R.menu.menu_ffmc);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

        radioGroup_Dispute.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkId) {

                switch (checkId){
                    case R.id.radio_raiseDispute:
                        replaceFragment(new fragment_open_dispute());
                        break;
                    case R.id.radio_diputeHistory:
                        replaceFragment(new fragment_status_dispute());
                        break;
                }

            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(activity_dispute.this, activity_ffmcmain.class);
        startActivity(i);
        finish();
    }

    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }
    public void init(){

        gbData = AppGlobalData.getInstance();
        getSharedPref();
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);

        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
      //  toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
   //     drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
      //  navigationView = (NavigationView) findViewById(R.id.nav_view);
      //  progressBar = (ProgressBar) findViewById(R.id.progressBar);
        radioGroup_Dispute=(RadioGroup)findViewById(R.id.radioGroup_dispute);
        radioButton_RaiseDispute=(RadioButton)findViewById(R.id.radio_raiseDispute);
        radioButton_DisputeHistory=(RadioButton)findViewById(R.id.radio_diputeHistory);
        plus_icon_dispute=(ImageView)findViewById(R.id.plus_icon_dispute);
        /*viewPager = (ViewPager) findViewById(R.id.viewPager_dispute);
        tabLayout = (TabLayout) findViewById(R.id.tabe_lay_dispute);*/

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setUpNavigationView();
        txt_header=(TextView)findViewById(R.id.txt_heder);

        plus_icon_dispute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ints=new Intent(activity_dispute.this, Activity_dispute_select.class);
                startActivity(ints);
            }
        });
    }

    public void setFont(){
        txt_header.setTypeface(FontData.setFonts(activity_dispute.this,txt_header, FontData.font_robotomedium));
        radioButton_RaiseDispute.setTypeface(FontData.setFonts(activity_dispute.this,radioButton_RaiseDispute, FontData.font_robotoregular));
        radioButton_DisputeHistory.setTypeface(FontData.setFonts(activity_dispute.this,radioButton_DisputeHistory, FontData.font_robotoregular));
    }


    public void setUpViewPager(ViewPager viewPager) {
        TabAdapter tabAdapter = new TabAdapter(getSupportFragmentManager());
        tabAdapter.addFragment(new fragment_open_dispute(), "RAISE DISPUTE");
        tabAdapter.addFragment(new fragment_status_dispute(),"DISPUTE HISTORY");

        viewPager.setAdapter(tabAdapter);
    }


    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_dashboard:
//                        Intent intentmain =new Intent(activity_main.this, activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_enquiries:
                        Intent intentEnquiries=new Intent(activity_dispute.this,activity_enquiries.class);
                        startActivity(intentEnquiries);
                        finish();
                        break;
                    case R.id.nav_dispute:
                        Intent intentDispute=new Intent(activity_dispute.this,activity_dispute.class);
                        startActivity(intentDispute);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_reports:
                        Intent intentReport=new Intent(activity_dispute.this,activity_reports.class);
                        startActivity(intentReport);
                        finish();

                        break;
                    case R.id.nav_b2b:
                        Intent intent_b2b=new Intent(activity_dispute.this,Activity_Generate_Enquiry_B2B.class);
                        startActivity(intent_b2b);
                        finish();
                        break;
                    case R.id.nav_passbook:
                        Intent intentpassbook=new Intent(activity_dispute.this,activity_passbook.class);
                        startActivity(intentpassbook);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_settings:
                        Intent intentSetting=new Intent(activity_dispute.this,activity_settings_ffcm.class);
                        startActivity(intentSetting);
                        finish();
//                       /* Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();*/
                        break;

                    case R.id.nav_logout:
                       /* if (gbData.isConnected(activity_dispute.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(activity_dispute.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }*/

                       logoutApplication();
                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }




    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
         //   if (Error_Message.equalsIgnoreCase("")) {
                ConstantData constantData = new ConstantData();
                constantData.clearSharedPref(activity_dispute.this);
                Intent intent = new Intent(activity_dispute.this, Activity_main.class);
                startActivity(intent);
                finish();
            /*} else
                CommonUI.showAlert(activity_dispute.this, getResources().getString(R.string.app_name), Error_Message);*/

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.FFMC_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                   // Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(activity_dispute.this,getResources().getString(R.string.app_name),objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
             /*   if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
             //   Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }








    private void replaceFragment(Fragment fragment) {

        fragmentManager = getSupportFragmentManager();
        transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.dispute_Container, fragment);
        transaction.commit();
    }
    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity_dispute.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(activity_dispute.this,Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

}
