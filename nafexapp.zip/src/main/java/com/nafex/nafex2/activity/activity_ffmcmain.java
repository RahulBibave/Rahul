package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

//implements PlaceSelectionListener
public class activity_ffmcmain extends AppCompatActivity {

    private static final String LOG_TAG = "activity_ffmcmain";

    private NavigationView navigationView;
    private View navHeader;
    private DrawerLayout drawerLayout;
    private boolean bCurrency, bArea;
    private int iCity, iCountry, iArea, iCurrency, iQuantity;
    private String sType, sMode, sAreaString;
    private ProgressBar progressBar;
    private SharedPreferences sharedpreferences;

    AppGlobalData gbData;
    Context mContext = activity_ffmcmain.this;
    LinearLayout llMainView;
    Toolbar toolbar;
    PieChart pieChart_first, pieChart_Second;
    LineChart lineChart;
    SharedPreferences.Editor editor;
    String user_id, user_token, branchID;


    private TextView txtDashboardHeader;
    private TextView txtTodaysStats;
    private TextView txtSuccessful;
    private TextView txtSuccessful2;
    private TextView txtmissedtrans;
    private TextView txtmissedtrans2;
    private TextView txtcommission;
    private TextView txtcommission2;
    private TextView txtDispute_n;
    private TextView txtDispute2;
    private TextView txtEnquiryGenerated1;
    private TextView txtEnquiryGenerated2;
    private TextView txtZeroOpen;
    private TextView txtOpen;
    private TextView txtZeroInprogress;
    private TextView txtInprogress;
    private TextView txtZeroWon;
    private TextView txtWon;
    private TextView txtZeroLost;
    private TextView txtLost;
    private TextView txtZeroBidsMade;
    private TextView txtBidsMade;
    private TextView txtZeroDispute;
    private TextView txtDispute;
    private TextView txtBranchFilter;
    private EditText edtDateFrom;
    private EditText edtDateTo;
    private Button btnGo;
    private TextView txtEnquiryHistory;
    private TextView txtTotalEnquiry;
    private TextView txtEnquiryWon;
    private TextView txtEnquiryLost;
    private TextView txtEnquiriesParticipated1;
    private TextView txtEnquiriesParticipated2;

    Typeface robotoLight, robotMedium, robotoRegular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ffmcmain);

        gbData = AppGlobalData.getInstance();

        init();
        setFonts();

        getSharedPref();
        navigationView.inflateMenu(R.menu.menu_ffmc);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);
        pieChart_first = configureChart(pieChart_first, activity_ffmcmain.this);
        pieChart_first = setData(pieChart_first, activity_ffmcmain.this);
        pieChart_first.animateXY(1500, 1500);

        pieChart_Second = configureChart(pieChart_Second, activity_ffmcmain.this);
        pieChart_Second = setData(pieChart_Second, activity_ffmcmain.this);
        pieChart_Second.animateXY(1500, 1500);

        setData();


    }


    public void init() {

        gbData.setStatusBarColor(activity_ffmcmain.this, R.color.colorPrimaryDark);
        //fontHelvetica = Typeface.createFromAsset(getAssets(), "Interstate-Light.ttf");

        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);

        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        pieChart_first = (PieChart) findViewById(R.id.pi_Chart1);
        lineChart = (LineChart) findViewById(R.id.line_chart);
        pieChart_Second = (PieChart) findViewById(R.id.pi_Chart2);


        txtDashboardHeader = (TextView) findViewById(R.id.txt_DashboardHeader);
        txtTodaysStats = (TextView) findViewById(R.id.txtTodaysStats);
        txtSuccessful = (TextView) findViewById(R.id.txtSuccessful);
        txtSuccessful2 = (TextView) findViewById(R.id.txtSuccessful_2);
        txtmissedtrans = (TextView) findViewById(R.id.txtmissedtrans);
        txtmissedtrans2 = (TextView) findViewById(R.id.txtmissedtrans_2);
        txtcommission = (TextView) findViewById(R.id.txtcommission);
        txtcommission2 = (TextView) findViewById(R.id.txtcommission_2);
        txtDispute = (TextView) findViewById(R.id.txtDispute);
        txtDispute2 = (TextView) findViewById(R.id.txtDispute_2);
        txtEnquiryGenerated1 = (TextView) findViewById(R.id.txt_enquiryGenerated1);
        txtEnquiryGenerated2 = (TextView) findViewById(R.id.txt_enquiryGenerated2);
        txtZeroOpen = (TextView) findViewById(R.id.txt_zero_open);
        txtOpen = (TextView) findViewById(R.id.txt_open);
        txtZeroInprogress = (TextView) findViewById(R.id.txt_zero_inprogress);
        txtInprogress = (TextView) findViewById(R.id.txt_inprogress);
        txtZeroWon = (TextView) findViewById(R.id.txt_zero_won);
        txtWon = (TextView) findViewById(R.id.txt_won);
        txtZeroLost = (TextView) findViewById(R.id.txt_zero_lost);
        txtLost = (TextView) findViewById(R.id.txt_lost);
        txtZeroBidsMade = (TextView) findViewById(R.id.txt_zero_bidsMade);
        txtBidsMade = (TextView) findViewById(R.id.txt_bidsMade);
        txtZeroDispute = (TextView) findViewById(R.id.txt_zero_Dispute);
        txtDispute = (TextView) findViewById(R.id.txt_Dispute);
        txtBranchFilter = (TextView) findViewById(R.id.txt_branchFilter);
        edtDateFrom = (EditText) findViewById(R.id.edt_date_From);
        edtDateTo = (EditText) findViewById(R.id.edt_date_To);
        btnGo = (Button) findViewById(R.id.btn_Go);
        txtEnquiryHistory = (TextView) findViewById(R.id.txt_enquiryHistory);
        txtTotalEnquiry = (TextView) findViewById(R.id.txt_totalEnquiry);
        txtEnquiryWon = (TextView) findViewById(R.id.txt_Enquiry_won);
        txtEnquiryLost = (TextView) findViewById(R.id.txt_Enquiry_lost);
        txtEnquiriesParticipated1 = (TextView) findViewById(R.id.txt_EnquiriesParticipated_1);
        txtEnquiriesParticipated2 = (TextView) findViewById(R.id.txt_EnquiriesParticipated_2);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setUpNavigationView();
    }


    private ArrayList<String> setXAxisValues() {
        ArrayList<String> xVals = new ArrayList<String>();
        xVals.add("10");
        xVals.add("20");
        xVals.add("30");
        xVals.add("30.5");
        xVals.add("40");

        return xVals;
    }


    private ArrayList<Entry> setYAxisValues() {
        ArrayList<Entry> yVals = new ArrayList<Entry>();
        yVals.add(new Entry(60, 0));
        yVals.add(new Entry(48, 1));
        yVals.add(new Entry(70.5f, 2));
        yVals.add(new Entry(100, 3));
        yVals.add(new Entry(180.9f, 4));

        return yVals;
    }


    private void setData() {
        ArrayList<String> xVals = setXAxisValues();

        ArrayList<Entry> yVals = setYAxisValues();

        LineDataSet set1;

        // create a dataset and give it a type
        set1 = new LineDataSet(yVals, "DataSet 1");
        set1.setFillAlpha(110);
        // set1.setFillColor(Color.RED);

        // set the line to be drawn like this "- - - - - -"
        // set1.enableDashedLine(10f, 5f, 0f);
        // set1.enableDashedHighlightLine(10f, 5f, 0f);
        set1.setColor(Color.BLACK);
        set1.setCircleColor(Color.BLACK);
        set1.setLineWidth(1f);
        set1.setCircleRadius(3f);
        set1.setDrawCircleHole(false);
        set1.setValueTextSize(9f);
        set1.setDrawFilled(true);

        ArrayList<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
        dataSets.add(set1); // add the datasets

        // create a data object with the datasets
        LineData data = new LineData(dataSets);

        // set data
        lineChart.setData(data);

    }


    private void showAlert(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }

    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_dashboard:
//                        Intent intentmain =new Intent(activity_main.this, activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_enquiries:
                        Intent intentEnquiries = new Intent(activity_ffmcmain.this, activity_enquiries.class);
                        startActivity(intentEnquiries);
                        finish();
                        break;

                    case R.id.nav_b2b:
                        Intent intent_b2b=new Intent(activity_ffmcmain.this,Activity_Generate_Enquiry_B2B.class);
                        startActivity(intent_b2b);
                        finish();
                        break;
                    case R.id.nav_dispute:
                        Intent intentDispute = new Intent(activity_ffmcmain.this, activity_dispute.class);
                        startActivity(intentDispute);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_reports:
                        Intent intentReport = new Intent(activity_ffmcmain.this, activity_reports.class);
                        startActivity(intentReport);
                        finish();

                        break;
                    case R.id.nav_passbook:
                        Intent intentpassbook = new Intent(activity_ffmcmain.this, activity_passbook.class);
                        startActivity(intentpassbook);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_settings:
                        Intent intentSetting = new Intent(activity_ffmcmain.this, activity_settings_ffcm.class);
                        startActivity(intentSetting);
                        finish();
//                       /* Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();*/
                        break;

                    case R.id.nav_logout:
                        /*if (gbData.isConnected(activity_ffmcmain.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(activity_ffmcmain.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }*/
                        logoutApplication();

                       /* ConstantData constantData = new ConstantData();
                        constantData.clearSharedPref(activity_ffmcmain.this);
                        Intent intent = new Intent(activity_ffmcmain.this, Activity_main.class);
                        startActivity(intent);
                        finish();*/
                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }


    public static PieChart configureChart(PieChart chart, Context context) {


        chart.setHoleRadius(5f);
        // chart.setDescription("");
        chart.setTransparentCircleRadius(10f);
        //  chart.setDrawYValues(true);
        chart.setDrawCenterText(true);
        chart.setDrawHoleEnabled(true);
        chart.setRotationAngle(0);

        // chart.setDrawXValues(false);
        chart.setRotationEnabled(true);
        chart.setUsePercentValues(true);
        chart.setCenterText("100");
        chart.setCenterTextColor(context.getResources().getColor(R.color.white));
        chart.setEntryLabelColor(context.getResources().getColor(R.color.white));
        return chart;
    }

    public static PieChart setData(PieChart chart, Context context) {
        //  Typeface fontInLight = Typeface.createFromAsset(context.getAssets(), "Font Bureau - Interstate-Light.otf");
        ArrayList<PieEntry> yVals1 = new ArrayList<PieEntry>();

        yVals1.add(new PieEntry(75, ""));
        ArrayList<String> xVals = new ArrayList<String>();
        xVals.add("Good");
        xVals.add("Bad");
        String lables = "";
        PieDataSet set1 = new PieDataSet(yVals1, lables);
        // set1.setValueTypeface(fontInLight);
      /*  set1.setValueLinePart1OffsetPercentage(80.f);
        set1.setValueLinePart1Length(0.2f);
        set1.setValueLinePart2Length(0.2f);*/
        set1.setXValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        set1.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        set1.setValueLineColor(Color.parseColor("#ffffff"));
        set1.setValueTextColor(context.getResources().getColor(R.color.white));


        set1.setSliceSpace(2f);
        ArrayList<Integer> colors = new ArrayList<Integer>();
        colors.add(context.getResources().getColor(R.color.gray));
       /* colors.add(context.getResources().getColor(R.color.colorAccent));*/
        set1.setColors(colors);
        PieData data = new PieData(set1);
        data.setValueTextColor(context.getResources().getColor(R.color.white));
        chart.setData(data);

        chart.highlightValues(null);
        chart.invalidate();
        return chart;
    }

    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }


    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (Error_Message.equalsIgnoreCase("")) {
                ConstantData constantData = new ConstantData();
                constantData.clearSharedPref(activity_ffmcmain.this);
                Intent intent = new Intent(activity_ffmcmain.this, Activity_main.class);
                startActivity(intent);
                finish();
            } else
                CommonUI.showAlert(activity_ffmcmain.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.FFMC_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }


    public void setFonts() {

        txtDashboardHeader.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtDashboardHeader, FontData.font_robotomedium));
        txtTodaysStats.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtTodaysStats, FontData.font_robotoregular));
        txtSuccessful.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtSuccessful, FontData.font_robotolight));
        txtSuccessful2.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtSuccessful2, FontData.font_robotoregular));
        txtmissedtrans.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtmissedtrans, FontData.font_robotolight));
        txtmissedtrans2.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtmissedtrans2, FontData.font_robotoregular));
        txtcommission.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtcommission, FontData.font_robotolight));
        txtcommission2.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtcommission2, FontData.font_robotoregular));
        txtDispute.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtDispute, FontData.font_robotolight));
        txtDispute2.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtDispute2, FontData.font_robotoregular));
        txtEnquiryGenerated1.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtEnquiryGenerated1, FontData.font_robotolight));
        txtEnquiryGenerated2.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtEnquiryGenerated2, FontData.font_robotomedium));
        txtZeroOpen.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtZeroOpen, FontData.font_robotomedium));
        txtOpen.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtOpen, FontData.font_robotomedium));
        txtZeroInprogress.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtZeroInprogress, FontData.font_robotomedium));
        txtInprogress.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtInprogress, FontData.font_robotomedium));
        txtZeroWon.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtZeroWon, FontData.font_robotomedium));
        txtWon.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtWon, FontData.font_robotomedium));
        txtZeroLost.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtZeroLost, FontData.font_robotomedium));
        txtLost.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtLost, FontData.font_robotomedium));
        txtZeroBidsMade.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtZeroBidsMade, FontData.font_robotomedium));
        txtBidsMade.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtBidsMade, FontData.font_robotomedium));
        txtZeroDispute.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtZeroDispute, FontData.font_robotomedium));
        txtDispute.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtDispute, FontData.font_robotomedium));
        txtBranchFilter.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtBranchFilter, FontData.font_robotoregular));
        edtDateFrom.setTypeface(FontData.setFonts(activity_ffmcmain.this, edtDateFrom, FontData.font_robotoregular));
        edtDateTo.setTypeface(FontData.setFonts(activity_ffmcmain.this, edtDateTo, FontData.font_robotoregular));
        // btnGo = (Button)findViewById( R.id.btn_Go );
        txtEnquiryHistory.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtDashboardHeader, FontData.font_robotoregular));
        txtTotalEnquiry.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtDashboardHeader, FontData.font_robotoregular));
        txtEnquiryWon.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtDashboardHeader, FontData.font_robotoregular));
        txtEnquiryLost.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtDashboardHeader, FontData.font_robotoregular));
        txtEnquiriesParticipated1.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtEnquiriesParticipated1, FontData.font_robotolight));
        txtEnquiriesParticipated2.setTypeface(FontData.setFonts(activity_ffmcmain.this, txtEnquiriesParticipated2, FontData.font_robotomedium));


    }
    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity_ffmcmain.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(activity_ffmcmain.this, Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

}
