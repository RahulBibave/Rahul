package com.nafex.nafex2.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.TabAdapter;
import com.nafex.nafex2.fragments.fragment_inprogresshistory;
import com.nafex.nafex2.fragments.fragment_pasthistory;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Activity_history extends AppCompatActivity {

    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    //private ImageView imgNafexMenu;
    private View navHeader;
    LinearLayout llMainView;
    Toolbar toolbar;

    ViewPager viewPager;
    TabLayout tabLayout;
    String Source = "";
    RadioGroup radioGroup1;
    RadioButton radioButtonInProcess,radioButtonHistory;
    FragmentManager fragmentManager;
    FragmentTransaction transaction;
    TextView txtTrackOrder;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    private int iUserId;


    private AppGlobalData gbData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_n);

        Source = getIntent().getStringExtra("Source");
        gbData = AppGlobalData.getInstance();

        init();
        replaceFragment(new fragment_inprogresshistory());

        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                switch (checkedId){
                    case R.id.radioinProcess:
                        replaceFragment(new fragment_inprogresshistory());

                        break;
                    case R.id.radioHistory:
                        replaceFragment(new fragment_pasthistory());
                        break;

                }
            }
        });
    }



    public void init(){

        gbData.setStatusBarColor(Activity_history.this,R.color.colorPrimaryDark);
        llMainView=(LinearLayout )findViewById(R.id.linear_main);
        toolbar=(Toolbar)findViewById(R.id.toolbar_top);

        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        viewPager = (ViewPager) findViewById(R.id.vpHistory);
        tabLayout = (TabLayout) findViewById(R.id.tablayHistory);

        txtTrackOrder= (TextView) findViewById(R.id.txtTrackYourOrder);
        txtTrackOrder.setTypeface(FontData.setFonts(Activity_history.this,txtTrackOrder,FontData.font_robotomedium));

        setSupportActionBar(toolbar);

        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        if (iUserId == -1) {
            navigationView.inflateMenu(R.menu.menu_customer_new);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

            setUpNavigationViewNewUser();
        } else {
            navigationView.inflateMenu(R.menu.menu_customer);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);
            setUpNavigationView();
        }


        if (viewPager !=null){
            setUpViewPager(viewPager);
        }

        if (Source.equalsIgnoreCase("") || Source.equalsIgnoreCase("NEWREQUEST"))
            viewPager.setCurrentItem(0);
        else
            viewPager.setCurrentItem(1);

        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#91bf35"));
        tabLayout.setSelectedTabIndicatorHeight((int)(5*getResources().getDisplayMetrics().density));
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        tabLayout.setTabTextColors(Color.parseColor("#003740"),Color.parseColor("#ffffff"));
        radioGroup1=(RadioGroup)findViewById(R.id.radioGroup1);
        radioButtonInProcess=(RadioButton)findViewById(R.id.radioinProcess);
        radioButtonHistory=(RadioButton)findViewById(R.id.radioHistory);

    }
    private void setUpNavigationViewNewUser() {
        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
//                        Intent intentmain =new Intent(Activity_main.this, Activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_signIn:
                    /*    Intent intenthistory = new Intent(Activity_main.this, Activity_login.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        CommonUI.setStrregtype("self");
                        startActivity(intenthistory);*/


                        Intent intenthistory = new Intent(Activity_history.this, Activity_otpdashboard.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        editor = sharedpreferences.edit();
                        editor.putString(ConstantData.ISLEFTLOGIN, "true");
                        editor.commit();
                        startActivity(intenthistory);
                        finish();

                        break;

                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


    }

    public void logoutApplication()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(Activity_history.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh=new Intent(Activity_history.this,Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (Error_Message.equalsIgnoreCase("")) {

                logoutApplication();
            } else
                CommonUI.showAlert(Activity_history.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }


   /*
    Setup of Inprogress and Completed history task
    */
    public void setUpViewPager(ViewPager viewPager) {
        TabAdapter tabAdapter = new TabAdapter(getSupportFragmentManager());
        tabAdapter.addFragment(new fragment_inprogresshistory(), "IN-PROCESS");
        tabAdapter.addFragment(new fragment_pasthistory(),"HISTORY");
        viewPager.setAdapter(tabAdapter);
    }


    /*
      Set up of Navigation drawer
     */
    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
                       Intent intentmain =new Intent(Activity_history.this, Activity_main.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_trackorder:
                     /*   Intent intenthistory = new Intent(Activity_main.this, Activity_history.class);
                        intenthistory.putExtra("Source", "");
                        startActivity(intenthistory);
                        finish();*/
                        break;
                    case R.id.nav_profile:
                        Intent intentprofile = new Intent(Activity_history.this, Activity_profile.class);
                        startActivity(intentprofile);
                        finish();
                        break;

                    case R.id.nav_kyc:
                        Intent intentkyc = new Intent(Activity_history.this, Activity_Kyc_Listing_Menu.class);
                        startActivity(intentkyc);
                        finish();
                        break;
                    case R.id.NBC_Details:
                        Intent intentNBC = new Intent(Activity_history.this, Activity_KycList_NBC.class);
                        startActivity(intentNBC);
                        finish();
                        break;
                    case R.id.nav_signout:
                        if (gbData.isConnected(Activity_history.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(Activity_history.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }
                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }


    private void replaceFragment(Fragment fragment) {
        fragmentManager = getSupportFragmentManager();
        transaction = fragmentManager.beginTransaction();
       // fragmentArrayList.add(fragment);
        transaction.replace(R.id.frameLayoutForNav, fragment, fragment.getTag());
        transaction.commit();

    }
}
