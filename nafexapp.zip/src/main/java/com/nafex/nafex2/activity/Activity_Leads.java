package com.nafex.nafex2.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.Window;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.AdapterLeads;
import com.nafex.nafex2.data.LeadData;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rahul on 12/10/17.
 */

public class Activity_Leads extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AdapterLeads adapterLeads;
    AppGlobalData gbData;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id, user_token, branchID;
    List<LeadData> justdiallist;


    @Override
    public void onCreate( Bundle savedInstanceState  ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leads);
        init();
        getSharedPref();
        if(gbData.isConnected(Activity_Leads.this))
        {
            CalljustdialLeadAPI objustleadapi =new CalljustdialLeadAPI();
            objustleadapi.execute();
        }


    }



    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }


    public class CalljustdialLeadAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressDialog.setMessage("Loading...");
            // progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

          //  if (Error_Message.equalsIgnoreCase("")) {
            /*    adapterDisputeStatus=new AdapterDisputeStatus(getActivity(), historydisList, new DisputeOperation() {
                    @Override
                    public void OnRespondclick(String kycId) {

                    }
                });
                mRecyclerView.setAdapter(adapterDisputeStatus);*/

                adapterLeads =new AdapterLeads(Activity_Leads.this,justdiallist);
                recyclerView.setAdapter(adapterLeads);
           /* } else
                CommonUI.showAlert(Activity_Leads.this, getResources().getString(R.string.app_name), Error_Message);*/
            // progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CalljustdialLead();
            return "DONE";

        }

        private void CalljustdialLead() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.JUSTDIALLEADLIST);
                //  URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + "/jdleadlist");

                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    justdiallist = new ArrayList<LeadData>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        LeadData objleaddata = new LeadData();
                        objleaddata.setId(jsonObj.getString("id"));
                        objleaddata.setLeadId(jsonObj.getString("leadId"));
                        objleaddata.setLeadType(jsonObj.getString("leadType"));
                        objleaddata.setNamePrefix(jsonObj.getString("namePrefix"));
                        objleaddata.setPersonName(jsonObj.getString("personName"));
                        objleaddata.setPersonPhone(jsonObj.getString("personPhone"));
                        objleaddata.setPersonEmail(jsonObj.getString("personEmail"));
                        objleaddata.setLeadDate(jsonObj.getString("leadDate"));
                        objleaddata.setLeadCategory(jsonObj.getString("leadCategory"));
                        objleaddata.setLeadCity(jsonObj.getString("leadCity"));
                        objleaddata.setLeadArea(jsonObj.getString("leadArea"));
                        objleaddata.setLeadBranchArea(jsonObj.getString("leadBranchArea"));
                        objleaddata.setLeadDncMobile(jsonObj.getString("leadDncMobile"));
                        objleaddata.setLeadDncPhone(jsonObj.getString("leadDncPhone"));
                        objleaddata.setLeadCompany(jsonObj.getString("leadCompany"));
                        objleaddata.setLeadPincode(jsonObj.getString("leadPincode"));
                        objleaddata.setLeadTime(jsonObj.getString("leadTime"));
                        objleaddata.setLeadBranchPin(jsonObj.getString("leadBranchPin"));
                        objleaddata.setLeadParentId(jsonObj.getString("leadParentId"));
                        objleaddata.setCreatedOn(jsonObj.getString("createdOn"));
                        objleaddata.setLeadSaveLater(jsonObj.getString("leadSaveLater"));
                        objleaddata.setRequestType(jsonObj.getString("requestType"));
                        objleaddata.setRequestSourceCurrencyId(jsonObj.getString("requestSourceCurrencyId"));
                        objleaddata.setRequestDeliveryMode(jsonObj.getString("requestDeliveryMode"));
                        objleaddata.setRequestLocation(jsonObj.getString("requestLocation"));
                        objleaddata.setRequestProductTypeId(jsonObj.getString("requestProductTypeId"));
                        objleaddata.setRequestQuantity(jsonObj.getString("requestQuantity"));
                        objleaddata.setRequestPurposeId(jsonObj.getString("requestPurposeId"));
                        objleaddata.setRequestCountryId(jsonObj.getString("requestCountryId"));
                        objleaddata.setRequestTransferTypeId(jsonObj.getString("requestTransferTypeId"));
                        objleaddata.setIsReminderSet(jsonObj.getString("isReminderSet"));
                        objleaddata.setOperatorId(jsonObj.getString("operatorId"));
                        objleaddata.setOperatorName(jsonObj.getString("operatorName"));
                        objleaddata.setRequestSourceCurrencyName(jsonObj.getString("requestSourceCurrencyName"));

                        justdiallist.add(objleaddata);
                    }

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                  //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_Leads.this,getResources().getString(R.string.app_name),objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
               /* if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in city data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }

    }

    private void init() {
        gbData = AppGlobalData.getInstance();
        gbData.setStatusBarColor(Activity_Leads.this, R.color.colorPrimaryDark);
        recyclerView= (RecyclerView) findViewById(R.id.recycler_Lids);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }


}
