package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Swarup on 9/10/2017.
 */

public class Activity_otpdashboard extends AppCompatActivity implements View.OnClickListener {
    ProgressDialog pd_login;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    private AppGlobalData gbData;
    private String OptionSelected = "";
    private RelativeLayout btnRegister, btnLogin, btnSubmit;
    EditText edtMobileNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpdashboard);
        initView();
        // setTypeface();
        clickListeners();
    }

    private void clickListeners() {
        btnSubmit.setOnClickListener(this);
        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
    }

    /*
     Initialization of views
    */
    public void initView() {
        pd_login = new ProgressDialog(Activity_otpdashboard.this);

        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();

        gbData = AppGlobalData.getInstance();
        OptionSelected = "N";
        gbData.setStatusBarColor(Activity_otpdashboard.this, R.color.colorPrimaryDark);
        btnSubmit = (RelativeLayout) findViewById(R.id.btnSubmit);
        btnLogin = (RelativeLayout) findViewById(R.id.btnLogin);
        btnRegister = (RelativeLayout) findViewById(R.id.btnRegisteration);
        edtMobileNo = (EditText) findViewById(R.id.edtMobileNo);
    }


    public class CallMobileNoVerification extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

       //    if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        JSONObject objmsgtext = objdata.getJSONObject("message_text");

                        String regType = (String) objmsgtext.get("regType");

                        if (regType.equalsIgnoreCase("autoReg")) {
                            String userId = (String) objmsgtext.get("userId");
                            Log.e("userid", userId);
                            setSharedPrefforSignup(userId, "", "", edtMobileNo.getText().toString().trim(), regType);
                            Intent int_signup=new Intent(Activity_otpdashboard.this,Activity_signup.class);
                            startActivity(int_signup);
                            finish();

                        }else
                        {
                            String userName = (String) objmsgtext.get("userName");
                            String userMobileNo = (String) objmsgtext.get("userMobileNo");
                            String userEmail = (String) objmsgtext.get("userEmail");
                            String userId = (String) objmsgtext.get("userId");
                            Log.e("userid", userId);
                            setSharedPrefforSignup(userId, userName, userEmail, userMobileNo, regType);
                            Intent int_signup=new Intent(Activity_otpdashboard.this,Activity_otpverification_manu.class);
                            startActivity(int_signup);
                            finish();
                        }
                      //  btnRegister.setVisibility(View.VISIBLE);


                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_otpdashboard.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_otpdashboard.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
           /* } else
                CommonUI.showAlert(Activity_otpdashboard.this, getResources().getString(R.string.app_name), Error_Message);*/

            pd_login.dismiss();        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_CHECKEXIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("userMobileNo", edtMobileNo.getText().toString().trim());
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
             //   Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }
    private void setSharedPrefforSignup(String id,String name,String email,String mobileno,String regtype) {
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_USERID, Integer.parseInt(id));
        editor.putString(ConstantData.KEY_USERNAME, name);
        editor.putString(ConstantData.KEY_USEREMAIL, email);
        editor.putString(ConstantData.KEY_USERMOBILENO,mobileno);
        editor.putString(ConstantData.KEY_REGTYPE,"autoReg");
        editor.commit();
    }

    private void HideKeybaord() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    private boolean validateData() {
        String sUserMobileNo = edtMobileNo.getText().toString();

        if (sUserMobileNo.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter mobile number for Sign Up.");

        else
            return true;


        return false;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSubmit:
                HideKeybaord();
                if (validateData()) {
                    if (gbData.isConnected(getApplicationContext())) {
                        CallMobileNoVerification objRequestAPI = new CallMobileNoVerification();
                        objRequestAPI.execute(CommonApi.CUSTOMER_CHECKEXIST);
                    } else
                    {
                        CommonUI.showAlert(Activity_otpdashboard.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                    }
                }

                break;
            case R.id.btnRegisteration:
                Intent intent_signup = new Intent(Activity_otpdashboard.this, Activity_signup.class);
                startActivity(intent_signup);
                break;
            case R.id.btnLogin:
                Intent intent_login = new Intent(Activity_otpdashboard.this, Activity_login.class);
                startActivity(intent_login);
               finish();

                break;

        }


    }
}
