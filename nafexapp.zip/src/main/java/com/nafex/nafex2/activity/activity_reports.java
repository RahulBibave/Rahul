package com.nafex.nafex2.activity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.ReportAdapter;
import com.nafex.nafex2.data.ReportData;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Sunil on 5/13/2017.
 */
public class activity_reports extends AppCompatActivity {
    EditText edt_Date_From,edt_Date_To;
    RecyclerView recycler_reports;
    Button btnGO;
    ReportAdapter reportAdapter;
    ArrayList<ReportData> listOfReports;
    Calendar calendar;
    DatePickerDialog datePickerDialog;
    SimpleDateFormat dateFormat;
    Toolbar toolbar;

    private NavigationView navigationView;
    private View navHeader;
    private DrawerLayout drawerLayout;
    private ProgressBar progressBar;
    private LinearLayout llMainView;


    private TextView txtorderNo;
    private EditText edtDateFrom;
    private EditText edtDateTo;
    private Button btnGo;
    private ImageView imgCalender;
    private TextView txtReportDate;
    private TextView txtNbcNo;
    private TextView txtStaus;
    private TextView txtCust;
    private RecyclerView recyclerReport;
    AppGlobalData gbData;
    String user_id, user_token, branchID;
    private SharedPreferences sharedpreferences;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        init();

        navigationView.inflateMenu(R.menu.menu_ffmc);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        listOfReports=new ArrayList<>();

        recycler_reports.setLayoutManager(new LinearLayoutManager(activity_reports.this));


        reportAdapter=new ReportAdapter(activity_reports.this,listOfReports);
        recycler_reports.setAdapter(reportAdapter);
        addData();

        calendar = Calendar.getInstance();
       edt_Date_From.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog = new DatePickerDialog(activity_reports.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(year, monthOfYear, dayOfMonth);
                       edt_Date_From.setText(dateFormat.format(calendar.getTime()));

                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });



        edt_Date_To.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog = new DatePickerDialog(activity_reports.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(year, monthOfYear, dayOfMonth);
                        edt_Date_To.setText(dateFormat.format(calendar.getTime()));

                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });



        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        edt_Date_From.setText(dateFormat.format(new Date())); // it will show 16/07/2013
        dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        edt_Date_To.setText(dateFormat.format(new Date())); // it will show 16 Jul 2013

       // reportAdapter.notifyDataSetChanged();
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(activity_reports.this, activity_ffmcmain.class);
        startActivity(i);
        finish();
    }


    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }

    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (Error_Message.equalsIgnoreCase("")) {
                ConstantData constantData = new ConstantData();
                constantData.clearSharedPref(activity_reports.this);
                Intent intent = new Intent(activity_reports.this, Activity_main.class);
                startActivity(intent);
                finish();
            } else
                CommonUI.showAlert(activity_reports.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.FFMC_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }




    public void init(){
        gbData = AppGlobalData.getInstance();
        getSharedPref();
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        edt_Date_From=(EditText)findViewById(R.id.edt_date_From);
        edt_Date_To=(EditText)findViewById(R.id.edt_date_To);
        recycler_reports=(RecyclerView)findViewById(R.id.recycler_Report);
        btnGO=(Button)findViewById(R.id.btn_Go);

        txtorderNo = (TextView)findViewById( R.id.txtorderNo );
        edtDateFrom = (EditText)findViewById( R.id.edt_date_From );
        edtDateTo = (EditText)findViewById( R.id.edt_date_To );

        imgCalender = (ImageView)findViewById( R.id.imgCalender );
        txtReportDate = (TextView)findViewById( R.id.txtReportDate );
        txtNbcNo = (TextView)findViewById( R.id.txtNbcNo );
        txtStaus = (TextView)findViewById( R.id.txtStaus );
        txtCust = (TextView)findViewById( R.id.txtCust );
        recyclerReport = (RecyclerView)findViewById( R.id.recycler_Report );

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setUpNavigationView();

    }
    private void setTypeface() {
        txtorderNo.setTypeface(FontData.setFonts(activity_reports.this, txtorderNo, FontData.font_robotomedium));
        edtDateFrom.setTypeface(FontData.setFonts(activity_reports.this, edtDateFrom, FontData.font_robotoregular));
        edtDateTo.setTypeface(FontData.setFonts(activity_reports.this, edtDateTo, FontData.font_robotoregular));
        txtReportDate.setTypeface(FontData.setFonts(activity_reports.this, txtReportDate, FontData.font_robotomedium));
        txtNbcNo.setTypeface(FontData.setFonts(activity_reports.this, txtNbcNo, FontData.font_robotomedium));
        txtStaus.setTypeface(FontData.setFonts(activity_reports.this, txtStaus, FontData.font_robotomedium));
        txtCust.setTypeface(FontData.setFonts(activity_reports.this, txtCust, FontData.font_robotomedium));
        btnGo.setTypeface(FontData.setFonts(activity_reports.this, btnGo, FontData.font_robotomedium));

    }
    public void addData(){
        for(int i=0;i<=5;i++){
            ReportData reportData;
            if (i==1)
                reportData = new ReportData("APR 19","NBC10194" + String.valueOf(i),"WON","N*******","Sunil","9860180648");
            else
                reportData=new ReportData("APR 19","NBC10194" + String.valueOf(i) ,"BIDLOST","N*******","","");


            listOfReports.add(reportData);
        }
        reportAdapter.notifyDataSetChanged();

    }


    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_dashboard:
                        Intent intentmain =new Intent(activity_reports.this, activity_ffmcmain.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_enquiries:
                        Intent intentEnquiries=new Intent(activity_reports.this,activity_enquiries.class);
                        startActivity(intentEnquiries);
                        finish();
                        break;
                    case R.id.nav_dispute:
                        Intent intentDispute=new Intent(activity_reports.this,activity_dispute.class);
                        startActivity(intentDispute);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_b2b:
                        Intent intent_b2b=new Intent(activity_reports.this,Activity_Generate_Enquiry_B2B.class);
                        startActivity(intent_b2b);
                        finish();
                        break;
                    case R.id.nav_reports:
//                        Intent intentReport=new Intent(activity_reports.this,activity_reports.class);
//                        startActivity(intentReport);

                        break;
                    case R.id.nav_passbook:
                        Intent intentpassbook=new Intent(activity_reports.this,activity_passbook.class);
                        startActivity(intentpassbook);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_settings:
                        Intent intentSetting=new Intent(activity_reports.this,activity_settings_ffcm.class);
                        startActivity(intentSetting);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;



                    case R.id.nav_logout:
                       /* if (gbData.isConnected(activity_reports.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(activity_reports.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }*/
                       logoutApplication();
                        break;

                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }

    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity_reports.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(activity_reports.this, Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }




}
