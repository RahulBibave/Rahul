package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.PassbookAdapter;
import com.nafex.nafex2.data.LeadData;
import com.nafex.nafex2.data.PassbookData;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sunil on 5/13/2017.
 */
public class activity_passbook extends AppCompatActivity {
    RecyclerView recycler_Passbook;
    ArrayList<PassbookData> passbookDataArrayList;
    PassbookAdapter passbookAdapter;

    ProgressDialog progressDialog;


    Toolbar toolbar;

    private NavigationView navigationView;
    private View navHeader;
    private DrawerLayout drawerLayout;
    private ProgressBar progressBar;
    private LinearLayout llMainView;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id, user_token, ffmcbranchid;
    private AppGlobalData gbData;
    List<PassbookData> passbooklist;


    String TransactionDate, Description, DEBIT, CREDIT, bankname, TDSAmount, transactionReferenceId, transactionMode;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passbook);
        init();
        getSharedPref();

        progressDialog = new ProgressDialog(activity_passbook.this);

        navigationView.inflateMenu(R.menu.menu_ffmc);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);
        gbData = AppGlobalData.getInstance();


        passbookDataArrayList = new ArrayList<>();
        recycler_Passbook.setLayoutManager(new LinearLayoutManager(activity_passbook.this));

        //setPassbookData();
        /*CallFFMCPassbookApi callFFMCPassbookApi=new CallFFMCPassbookApi();
        callFFMCPassbookApi.execute();*/
        CallRequestPassbookAPI callRequestPassbookAPI = new CallRequestPassbookAPI();
        callRequestPassbookAPI.execute();

    }

    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (Error_Message.equalsIgnoreCase("")) {
                ConstantData constantData = new ConstantData();
                constantData.clearSharedPref(activity_passbook.this);
                Intent intent = new Intent(activity_passbook.this, Activity_main.class);
                startActivity(intent);
                finish();
            } else
                CommonUI.showAlert(activity_passbook.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.FFMC_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }


    @Override
    public void onBackPressed() {
        Intent i = new Intent(activity_passbook.this, activity_ffmcmain.class);
        startActivity(i);
        finish();
    }

    public void init() {
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        recycler_Passbook = (RecyclerView) findViewById(R.id.recycler_passbook);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setUpNavigationView();
    }

    public void setPassbookData() {
        for (int i = 0; i <= 10; i++) {
            PassbookData passbookData = new PassbookData("13-Apr-2017", "Being partial Commiss", "120.000", "120.000", "NBC101223");
            passbookDataArrayList.add(passbookData);
        }
        passbookAdapter.notifyDataSetChanged();
    }


    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_dashboard:
                        Intent intentmain = new Intent(activity_passbook.this, activity_ffmcmain.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_enquiries:
                        Intent intentEnquiries = new Intent(activity_passbook.this, activity_enquiries.class);
                        startActivity(intentEnquiries);
                        finish();
                        break;
                    case R.id.nav_dispute:
                        Intent intentDispute = new Intent(activity_passbook.this, activity_dispute.class);
                        startActivity(intentDispute);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_reports:
                        Intent intentReport = new Intent(activity_passbook.this, activity_reports.class);
                        startActivity(intentReport);
                        finish();
                        break;
                    case R.id.nav_passbook:
                        //Intent intentpassbook=new Intent(activity_passbook.this,activity_passbook.class);
                        //startActivity(intentpassbook);
                        //finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_b2b:
                        Intent intent_b2b=new Intent(activity_passbook.this,Activity_Generate_Enquiry_B2B.class);
                        startActivity(intent_b2b);
                        finish();
                        break;
                    case R.id.nav_settings:
                        Intent intentSetting = new Intent(activity_passbook.this, activity_settings_ffcm.class);
                        startActivity(intentSetting);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_logout:
                       /* if (gbData.isConnected(activity_passbook.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(activity_passbook.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }*/
                       logoutApplication();

                        break;

                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }



   /* public class CallFFMCPassbookApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.e("Response*********: ", strResponse);

          *//*  if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";
                Log.e("Response*********: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    Log.e("MESSAGECODE*******",""+objdata.getString("message_code"));
                    JSONArray jsonArray=objdata.getJSONArray("message_text");
                    for (int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObjectInner=jsonArray.getJSONObject(i);
                        TransactionDate=jsonObjectInner.getString("TransactionDate");
                        Description=jsonObjectInner.getString("Description");
                        DEBIT=jsonObjectInner.getString("DEBIT");
                        CREDIT=jsonObjectInner.getString("CREDIT");
                        bankname=jsonObjectInner.getString("bankname");
                        TDSAmount=jsonObjectInner.getString("TDSAmount");
                        transactionReferenceId=jsonObjectInner.getString("transactionReferenceId");
                        transactionMode=jsonObjectInner.getString("transactionMode");
                        Log.e("transactionMode***********",""+transactionMode);

                    }


                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {



                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(activity_passbook.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(activity_passbook.this, getResources().getString(R.string.app_name), Error_Message);
                }
            } else
                CommonUI.showAlert(activity_passbook.this, getResources().getString(R.string.app_name), Error_Message);

            progressDialog.dismiss();*//*
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL +"/"+user_id+"/passbook");
                Log.e("APIIIIIIIIIIIII",""+url);

                urlConnection = (HttpURLConnection) url.openConnection();


                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                urlConnection.setReadTimeout(15000 *//* milliseconds *//*);
                urlConnection.setConnectTimeout(15000 *//* milliseconds *//*);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
             //   writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                strResponse = stringBuilder.toString();
                Log.e("Result", strResponse);

               *//* if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }*//*
            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }
    }*/


    private class CallRequestPassbookAPI extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading...");
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + "/" + ffmcbranchid + "/passbook");
                Log.e("URLLLLLLL", "" + url);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    return stringBuilder.toString();
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            Log.e("RESPONCEEEEEEEEEEEEEEE", "" + s);
            passbookDataArrayList.clear();

            //  JSONObject objdata = null;
            try {
                JSONObject objdata = new JSONObject(s);
                Log.e("MESSAGECODE*******", "" + objdata.getString("message_code"));
                if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    CommonUI.showAlert(activity_passbook.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
                JSONArray jsonArray = objdata.getJSONArray("message_text");
                passbooklist = new ArrayList<PassbookData>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObjectInner = jsonArray.getJSONObject(i);
                    PassbookData objdatas = new PassbookData();

                    TransactionDate = jsonObjectInner.getString("TransactionDate");
                    Description = jsonObjectInner.getString("Description");
                    DEBIT = jsonObjectInner.getString("DEBIT");
                    CREDIT = jsonObjectInner.getString("CREDIT");
                    bankname = jsonObjectInner.getString("bankname");
                    TDSAmount = jsonObjectInner.getString("TDSAmount");
                    transactionReferenceId = jsonObjectInner.getString("transactionReferenceId");
                    transactionMode = jsonObjectInner.getString("transactionMode");
                    Log.e("transactionMode*****", "" + transactionMode);
                    Log.e("DESE*******", "" + Description);
                    objdatas.setDate(TransactionDate);
                    objdatas.setDesc(Description);
                    objdatas.setDb(DEBIT);
                    objdatas.setCr(CREDIT);
                    objdatas.setBankname(bankname);
                    objdatas.setTDSAmount(TDSAmount);
                    objdatas.setTransactionReferenceId(transactionReferenceId);
                    objdatas.setTransactionMode(transactionMode);


                    passbooklist.add(objdatas);

                  /*  PassbookData passbookData=new PassbookData(TransactionDate,Description,DEBIT,CREDIT,"NBC101223");
                    passbookDataArrayList.add(passbookData);*/

                }
                passbookAdapter = new PassbookAdapter(activity_passbook.this, passbooklist);
                recycler_Passbook.setAdapter(passbookAdapter);
                passbookAdapter.notifyDataSetChanged();
                //  passbookAdapter.notifyDataSetChanged();
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }


        @Override
        protected void onCancelled() {
            super.onCancelled();
        }

    }


    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        ffmcbranchid = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");
    }
    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity_passbook.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(activity_passbook.this, Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }


}
