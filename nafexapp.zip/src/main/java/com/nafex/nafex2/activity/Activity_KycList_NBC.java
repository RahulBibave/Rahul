package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.AdapterKycListNBC;
import com.nafex.nafex2.data.NbcHistory;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rahul on 12/9/17.
 */

public class Activity_KycList_NBC extends AppCompatActivity {

    ViewPager viewPager;
    TabLayout tabLayout;
    LinearLayout llMainView;

    android.support.v7.widget.Toolbar toolbar;


    private NavigationView navigationView;
    private View navHeader;
    private DrawerLayout drawerLayout;

    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    private TextView txtToolbarKycDoc, txtKycDocAval, txtChekBank, txtcheckPassport, txtcheckPanCard,
            txtcheckAadharCard, txtcheckDrivingLicense, txtNBCDetails;
    private CheckBox chekBank, checkPassport, checkPanCard, checkAadharCard, checkDrivingLicense;
    private RecyclerView recyclerNBCDetails;
    private AdapterKycListNBC mAdapterKycListNBC;
    List<NbcHistory> listnbchistory;
    AppGlobalData gbData;
    ProgressDialog progressDialog;
    String user_id,user_token,branchID,strtoken;

    private int iUserId;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay_kyc_list_under_profile);
        findViews();
        setTypeFace();
      /*  navigationView.inflateMenu(R.menu.menu_ffmc);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);*/
        recyclerNBCDetails.setLayoutManager(new LinearLayoutManager(this));


        getSharedPref();
        parseNBCList();

       /* if (gbData.isConnected(getApplicationContext())) {
            CallHistoryDisputeAPI objcurrrencyAPI = new CallHistoryDisputeAPI();
            objcurrrencyAPI.execute(CommonApi.GETREQUESTHISTORYCUSTOMER);
        }*/

    }
    private void getSharedPref() {
        progressDialog=new ProgressDialog(Activity_KycList_NBC.this);
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");

    }
    public class CallHistoryDisputeAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {
                mAdapterKycListNBC = new AdapterKycListNBC(Activity_KycList_NBC.this,listnbchistory);
                recyclerNBCDetails.setAdapter(mAdapterKycListNBC);
            } else
                CommonUI.showAlert(Activity_KycList_NBC.this, getResources().getString(R.string.app_name), Error_Message);
            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CallForHistoryDispute();
            return "DONE";

        }

        private void CallForHistoryDispute() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.GETREQUESTHISTORYCUSTOMER);
                //   URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + "/getRequestHistory");

                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (Integer.toString(iUserId) + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    listnbchistory = new ArrayList<NbcHistory>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        NbcHistory objCurrency = new NbcHistory();
                        String requestId = jsonObj.getString("requestId");
                        String requestType = jsonObj.getString("requestType");
                        String requestSourceCurrencyId = jsonObj.getString("requestSourceCurrencyId");
                        String requestTargetCurrencyId = jsonObj.getString("requestTargetCurrencyId");
                        String requestNBC = jsonObj.getString("requestNBC");
                        String requestStatusId = jsonObj.getString("requestStatusId");
                        String createdOn = jsonObj.getString("createdOn");
                        String requestTypeName = jsonObj.getString("requestTypeName");
                        String requestSourceCurrencyName = jsonObj.getString("requestSourceCurrencyName");
                        String requestTargetCurrencyName = jsonObj.getString("requestTargetCurrencyName");
                        String requestStatusName = jsonObj.getString("requestStatusName");
                        String createdon = jsonObj.getString("createdOn");

                        objCurrency.setRequestId(requestId);
                        objCurrency.setRequestType(requestType);
                        objCurrency.setRequestSourceCurrencyId(requestSourceCurrencyId);
                        objCurrency.setRequestTargetCurrencyId(requestTargetCurrencyId);
                        objCurrency.setRequestNBC("NBC" + requestNBC);
                        objCurrency.setRequestStatusId(requestStatusId);
                        objCurrency.setCreatedOn(createdOn);
                        objCurrency.setRequestTypeName(requestTypeName);
                        objCurrency.setRequestSourceCurrencyName(requestSourceCurrencyName);
                        objCurrency.setRequestTargetCurrencyName(requestTargetCurrencyName);
                        objCurrency.setRequestStatusName(requestStatusName);
                        objCurrency.setCreatedOn(createdon);


                        JSONArray jsonDataset1 = jsonObj.getJSONArray("requestProducts");
                        if (jsonDataset1.length() == 2) {
                            JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                            String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                            String requestQuantity = jsonObjectInner.getString("requestQuantity");
                            String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");

                            JSONObject jsonObjectInner2 = jsonDataset1.getJSONObject(1);
                            String requestProductTypeId1 = jsonObjectInner.getString("requestProductTypeId");
                            String requestQuantity1 = jsonObjectInner.getString("requestQuantity");
                            String requestProductTypeName1 = jsonObjectInner.getString("requestProductTypeName");

                            int totalquantity = Integer.parseInt(requestQuantity1) + Integer.parseInt(requestQuantity) / 2;

                            objCurrency.setRequestProductTypeId(requestProductTypeId);
                            objCurrency.setRequestQuantity(Integer.toString(totalquantity));
                            objCurrency.setRequestProductTypeName(requestProductTypeName);


                        }
                        if (jsonDataset1.length() == 1) {
                            JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                            String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                            String requestQuantity = jsonObjectInner.getString("requestQuantity");
                            String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");

                            objCurrency.setRequestProductTypeId(requestProductTypeId);
                            objCurrency.setRequestQuantity(requestQuantity);
                            objCurrency.setRequestProductTypeName(requestProductTypeName);
                        }
                        listnbchistory.add(objCurrency);
                    }




                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in city data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }

    }






    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (Error_Message.equalsIgnoreCase("")) {

                logoutApplication();
            } else
                CommonUI.showAlert(Activity_KycList_NBC.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }



    private void parseNBCList() {
        try {
            JSONArray jsonArray;
            JSONObject jsonObj;
            JSONObject objdata = new JSONObject(CommonApi.GETREQUESTHISTORY);
            if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                jsonArray = objdata.getJSONArray("message_text");
                listnbchistory = new ArrayList<NbcHistory>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    jsonObj = jsonArray.getJSONObject(i);
                    NbcHistory objCurrency = new NbcHistory();
                    String requestId = jsonObj.getString("requestId");
                    String requestType = jsonObj.getString("requestType");
                    String requestSourceCurrencyId = jsonObj.getString("requestSourceCurrencyId");
                    String requestTargetCurrencyId = jsonObj.getString("requestTargetCurrencyId");
                    String requestNBC = jsonObj.getString("requestNBC");
                    String requestStatusId = jsonObj.getString("requestStatusId");
                    String createdOn = jsonObj.getString("createdOn");
                    String requestTypeName = jsonObj.getString("requestTypeName");
                    String requestSourceCurrencyName = jsonObj.getString("requestSourceCurrencyName");
                    String requestTargetCurrencyName = jsonObj.getString("requestTargetCurrencyName");
                    String requestStatusName = jsonObj.getString("requestStatusName");
                    String createdon = jsonObj.getString("createdOn");

                        objCurrency.setRequestId(requestId);
                        objCurrency.setRequestType(requestType);
                        objCurrency.setRequestSourceCurrencyId(requestSourceCurrencyId);
                        objCurrency.setRequestTargetCurrencyId(requestTargetCurrencyId);
                        objCurrency.setRequestNBC("NBC" + requestNBC);
                        objCurrency.setRequestStatusId(requestStatusId);
                        objCurrency.setCreatedOn(createdOn);
                        objCurrency.setRequestTypeName(requestTypeName);
                        objCurrency.setRequestSourceCurrencyName(requestSourceCurrencyName);
                        objCurrency.setRequestTargetCurrencyName(requestTargetCurrencyName);
                        objCurrency.setRequestStatusName(requestStatusName);
                        objCurrency.setCreatedOn(createdon);


                        JSONArray jsonDataset1 = jsonObj.getJSONArray("requestProducts");
                        if (jsonDataset1.length() == 2) {
                            JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                            String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                            String requestQuantity = jsonObjectInner.getString("requestQuantity");
                            String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");

                            JSONObject jsonObjectInner2 = jsonDataset1.getJSONObject(1);
                            String requestProductTypeId1 = jsonObjectInner.getString("requestProductTypeId");
                            String requestQuantity1 = jsonObjectInner.getString("requestQuantity");
                            String requestProductTypeName1 = jsonObjectInner.getString("requestProductTypeName");

                            int totalquantity = Integer.parseInt(requestQuantity1) + Integer.parseInt(requestQuantity) / 2;

                            objCurrency.setRequestProductTypeId(requestProductTypeId);
                            objCurrency.setRequestQuantity(Integer.toString(totalquantity));
                            objCurrency.setRequestProductTypeName(requestProductTypeName);


                        }
                        if (jsonDataset1.length() == 1) {
                            JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                            String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                            String requestQuantity = jsonObjectInner.getString("requestQuantity");
                            String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");

                            objCurrency.setRequestProductTypeId(requestProductTypeId);
                            objCurrency.setRequestQuantity(requestQuantity);
                            objCurrency.setRequestProductTypeName(requestProductTypeName);
                        }
                    listnbchistory.add(objCurrency);
                    }

                mAdapterKycListNBC = new AdapterKycListNBC(Activity_KycList_NBC.this,listnbchistory);
                recyclerNBCDetails.setAdapter(mAdapterKycListNBC);


            } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                //Error_Message = objdata.getString("message_text");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void findViews() {
        gbData = AppGlobalData.getInstance();
        toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar_top);

        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        gbData.setStatusBarColor(Activity_KycList_NBC.this, R.color.colorPrimaryDark);
        txtToolbarKycDoc = (TextView) findViewById(R.id.txtToolbarKycDoc);
        txtKycDocAval = (TextView) findViewById(R.id.txtKycDocAvl);
        chekBank = (CheckBox) findViewById(R.id.chekBank);
        txtChekBank = (TextView) findViewById(R.id.txtChekBank);
        checkPassport = (CheckBox) findViewById(R.id.checkPassport);
        txtcheckPassport = (TextView) findViewById(R.id.txtcheckPassport);
        checkPanCard = (CheckBox) findViewById(R.id.checkPanCard);
        txtcheckPanCard = (TextView) findViewById(R.id.txtcheckPanCard);
        llMainView=(LinearLayout )findViewById(R.id.linear_main);
        checkAadharCard = (CheckBox) findViewById(R.id.checkAadharCard);
        txtcheckAadharCard = (TextView) findViewById(R.id.txtcheckAadharCard);
        checkDrivingLicense = (CheckBox) findViewById(R.id.checkDrivingLicense);
        txtcheckDrivingLicense = (TextView) findViewById(R.id.txtcheckDrivingLicense);
        txtNBCDetails = (TextView) findViewById(R.id.txtNBCDetails);
        recyclerNBCDetails = (RecyclerView) findViewById(R.id.recyclerNBCDetails);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setSupportActionBar(toolbar);

        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        if (iUserId == -1) {
            navigationView.inflateMenu(R.menu.menu_customer_new);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

            setUpNavigationViewNewUser();
        } else {
            navigationView.inflateMenu(R.menu.menu_customer);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);
            setUpNavigationView();
        }


        setUpNavigationView();
    }

    private void setTypeFace() {
        txtToolbarKycDoc.setTypeface(FontData.setFonts(Activity_KycList_NBC.this, txtToolbarKycDoc, FontData.font_robotomedium));
        txtKycDocAval.setTypeface(FontData.setFonts(Activity_KycList_NBC.this, txtKycDocAval, FontData.font_robotomedium));
        txtChekBank.setTypeface(FontData.setFonts(Activity_KycList_NBC.this, txtChekBank, FontData.font_robotoregular));
        txtcheckPassport.setTypeface(FontData.setFonts(Activity_KycList_NBC.this, txtcheckPassport, FontData.font_robotoregular));
        txtcheckPanCard.setTypeface(FontData.setFonts(Activity_KycList_NBC.this, txtcheckPanCard, FontData.font_robotoregular));
        txtcheckAadharCard.setTypeface(FontData.setFonts(Activity_KycList_NBC.this, txtcheckAadharCard, FontData.font_robotoregular));
        txtcheckDrivingLicense.setTypeface(FontData.setFonts(Activity_KycList_NBC.this, txtcheckDrivingLicense, FontData.font_robotoregular));
        txtNBCDetails.setTypeface(FontData.setFonts(Activity_KycList_NBC.this, txtNBCDetails, FontData.font_robotomedium));

    }



    /*private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
//                        Intent intentmain =new Intent(Activity_main.this, Activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_trackorder:
                        Intent intenthistory = new Intent(Activity_KycList_NBC.this, Activity_history.class);
                        intenthistory.putExtra("Source", "");
                        startActivity(intenthistory);
                        finish();
                        break;
                    case R.id.nav_profile:
                        Intent intentprofile = new Intent(Activity_KycList_NBC.this, Activity_profile.class);
                        startActivity(intentprofile);
                        finish();
                        break;

                    case R.id.NBC_Details:
                        Intent intentNBC = new Intent(Activity_KycList_NBC.this, Activity_KycList_NBC.class);
                        startActivity(intentNBC);
                        finish();
                        break;
                    case R.id.nav_kyc:
                        Intent intentkyc = new Intent(Activity_KycList_NBC.this, Activity_Kyc_Listing_Menu.class);
                        startActivity(intentkyc);
                        finish();
                        break;
                    case R.id.nav_signout:
                        logoutApplication();

                       *//* SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                       // ActivityCompat.finishAffinity(Activity_main.this);
                        System.exit(0);*//*
                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }*/


    public void logoutApplication()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(Activity_KycList_NBC.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh=new Intent(Activity_KycList_NBC.this,Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
                        Intent intentmain =new Intent(Activity_KycList_NBC.this, Activity_main.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_trackorder:
                        Intent intenthistory = new Intent(Activity_KycList_NBC.this, Activity_history.class);
                        intenthistory.putExtra("Source", "");
                        startActivity(intenthistory);
                        finish();
                        break;
                    case R.id.nav_profile:
                        Intent intentprofile = new Intent(Activity_KycList_NBC.this, Activity_profile.class);
                        startActivity(intentprofile);
                        finish();
                        break;

                    case R.id.nav_kyc:
                        Intent intentkyc = new Intent(Activity_KycList_NBC.this, Activity_Kyc_Listing_Menu.class);
                        startActivity(intentkyc);
                        finish();
                        break;
                    case R.id.NBC_Details:
                       /* Intent intentNBC = new Intent(Activity_KycList_NBC.this, Activity_KycList_NBC.class);
                        startActivity(intentNBC);
                        finish();*/
                        break;
                    case R.id.nav_signout:
                       /* if (gbData.isConnected(Activity_KycList_NBC.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(Activity_KycList_NBC.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }*/
                       logoutApplication();
                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }


    private void setUpNavigationViewNewUser() {
        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
//                        Intent intentmain =new Intent(Activity_main.this, Activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_signIn:
                    /*    Intent intenthistory = new Intent(Activity_main.this, Activity_login.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        CommonUI.setStrregtype("self");
                        startActivity(intenthistory);*/


                        Intent intenthistory = new Intent(Activity_KycList_NBC.this, Activity_otpdashboard.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        editor = sharedpreferences.edit();
                        editor.putString(ConstantData.ISLEFTLOGIN, "true");
                        editor.commit();
                        startActivity(intenthistory);
                        finish();

                        break;

                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


    }
}





