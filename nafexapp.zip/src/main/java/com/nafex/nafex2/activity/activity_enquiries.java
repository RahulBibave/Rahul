package com.nafex.nafex2.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.OnBidOpen;
import com.nafex.nafex2.adapters.TabAdapter;
import com.nafex.nafex2.fragments.fragment_inprogress;
import com.nafex.nafex2.fragments.fragment_open;
import com.nafex.nafex2.fragments.fragment_won;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

/**
 * Created by Sunil on 5/13/2017.
 */
public class activity_enquiries extends AppCompatActivity implements OnBidOpen {
    ViewPager viewPager;
    TabLayout tabLayout;

    Toolbar toolbar;

    private NavigationView navigationView;
    private View navHeader;
    private DrawerLayout drawerLayout;
    private ProgressBar progressBar;
    private LinearLayout llMainView;
    FragmentManager fragmentManager;
    FragmentTransaction transaction;
    RadioGroup radioGroup_Enquiries;
    RadioButton radioButton_Open,radioButton_Inprogress,radioButton_Won;
    TextView  txtEnquiryHeader;
    private ImageView plus_icon_b2b;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enquiries);
        init();
        setFonts();

        navigationView.inflateMenu(R.menu.menu_ffmc);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

        if (viewPager !=null){
            setUpViewPager(viewPager);
        }
        viewPager.setCurrentItem(0);

        tabLayout.setupWithViewPager(viewPager);

        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#91bf35"));
        tabLayout.setSelectedTabIndicatorHeight((int)(5*getResources().getDisplayMetrics().density));
        tabLayout.setTabGravity(TabLayout.GRAVITY_CENTER);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        tabLayout.setTabTextColors(Color.parseColor("#003740"),Color.parseColor("#ffffff"));

        replaceFragment(new fragment_open());


        radioGroup_Enquiries.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checked) {
                switch (checked){
                    case R.id.radioOpen:
                        replaceFragment(new fragment_open());
                        break;
                    case R.id.radioInprogress:
                        replaceFragment(new fragment_inprogress());
                        break;
                    case R.id.radioWon:
                        replaceFragment(new fragment_won());
                        break;

                }

            }
        });
        plus_icon_b2b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentReport=new Intent(activity_enquiries.this,Activity_Generate_Enquiry_B2B.class);
                startActivity(intentReport);
                finish();

            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(activity_enquiries.this, activity_ffmcmain.class);
        startActivity(i);
        finish();
    }

    @Override
    public void onBidNowButtonClicked(int index, int reqId) {

    }



    public void init(){

        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        viewPager = (ViewPager) findViewById(R.id.viewPage);
        tabLayout = (TabLayout) findViewById(R.id.tabe_lay);
        radioGroup_Enquiries=(RadioGroup)findViewById(R.id.radioGroup_Enquiries);
        radioButton_Open=(RadioButton)findViewById(R.id.radioOpen);
        radioButton_Inprogress=(RadioButton)findViewById(R.id.radioInprogress);
        radioButton_Won=(RadioButton)findViewById(R.id.radioWon);
        txtEnquiryHeader=(TextView)findViewById(R.id.txt_enquiry_header);
        plus_icon_b2b= (ImageView) findViewById(R.id.plus_icon_b2b);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setUpNavigationView();
    }

    public void setFonts(){

        radioButton_Open.setTypeface(FontData.setFonts(activity_enquiries.this,radioButton_Open, FontData.font_robotomedium));
        radioButton_Inprogress.setTypeface(FontData.setFonts(activity_enquiries.this,radioButton_Inprogress, FontData.font_robotomedium));
        radioButton_Won.setTypeface(FontData.setFonts(activity_enquiries.this,radioButton_Won, FontData.font_robotomedium));
        txtEnquiryHeader.setTypeface(FontData.setFonts(activity_enquiries.this,txtEnquiryHeader, FontData.font_robotomedium));

    }


    public void setUpViewPager(ViewPager viewPager) {
        TabAdapter tabAdapter = new TabAdapter(getSupportFragmentManager());
        tabAdapter.addFragment(new fragment_open(), "OPEN");
        tabAdapter.addFragment(new fragment_inprogress(),"IN PROGRESS");
        tabAdapter.addFragment(new fragment_won(),"WON");
        viewPager.setAdapter(tabAdapter);
    }


    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_dashboard:
                        Intent intentmain =new Intent(activity_enquiries.this, activity_ffmcmain.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_enquiries:
//                        Intent intentEnquiries=new Intent(activity_enquiries.this,activity_enquiries.class);
//                        startActivity(intentEnquiries);
//                        finish();
                        break;

                    case R.id.nav_b2b:
                        Intent intent_b2b=new Intent(activity_enquiries.this,Activity_Generate_Enquiry_B2B.class);
                        startActivity(intent_b2b);
                        finish();
                        break;

                    case R.id.nav_dispute:
                        Intent intentDispute=new Intent(activity_enquiries.this,activity_dispute.class);
                        startActivity(intentDispute);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_reports:
                        Intent intentReport=new Intent(activity_enquiries.this,activity_reports.class);
                        startActivity(intentReport);
                        finish();
                        break;
                    case R.id.nav_passbook:
                        Intent intentpassbook=new Intent(activity_enquiries.this,activity_passbook.class);
                        startActivity(intentpassbook);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_settings:
                        Intent intentSetting=new Intent(activity_enquiries.this,activity_settings_ffcm.class);
                        startActivity(intentSetting);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_logout:
                       /* ConstantData constantData=new ConstantData();
                        constantData.clearSharedPref(activity_enquiries.this);
                        Intent intent = new Intent(activity_enquiries.this, Activity_main.class);
                        startActivity(intent);
                        finish();*/
                       logoutApplication();

                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }



    private void replaceFragment(Fragment fragment) {
        fragmentManager = getSupportFragmentManager();
        transaction = fragmentManager.beginTransaction();
        // fragmentArrayList.add(fragment);
        transaction.replace(R.id.frameLayoutForNav, fragment, fragment.getTag());
        transaction.commit();
    }
    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity_enquiries.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(activity_enquiries.this, Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}
