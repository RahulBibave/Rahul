package com.nafex.nafex2.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.ConstantData;

public class Activity_splash extends AppCompatActivity {
    private int iUserId;

    SharedPreferences sharedpreferences;
    //global data for single time variables
    private AppGlobalData gbData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();
        handlerSingleTimeLogic();
    }

    /*
       single time logic
     */
    private void handlerSingleTimeLogic() {

        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        if (sharedpreferences.getString(ConstantData.KEY_USERROLE_LFFCMLOGIN,"").equalsIgnoreCase("7")){
            try {
                //timer for setting timer
                Thread.sleep(3000);


              //  iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);


                Intent int_home = new Intent(Activity_splash.this, activity_enquiries.class);
                startActivity(int_home);
                finish();


            } catch (Exception ex) {
                Log.e("Nafex2.0", "Thread expcetion");
            }
        }

        else {
            try {
                //timer for setting timer
                Thread.sleep(3000);


                iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);


                Intent int_home = new Intent(Activity_splash.this, Activity_main.class);
                startActivity(int_home);
                finish();


            } catch (Exception ex) {
                Log.e("Nafex2.0", "Thread expcetion");
            }

        }

    }


    /*
      Initialization of views
     */
    private void initView() {
        gbData = AppGlobalData.getInstance();
        gbData.setStatusBarColor(Activity_splash.this, R.color.white);
    }

}
