package com.nafex.nafex2.activity;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.os.AsyncTask;
import android.os.Build;

import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.nafex.nafex2.R;
import com.nafex.nafex2.data.Currency;
import com.nafex.nafex2.data.DocType;
import com.nafex.nafex2.data.DocumentType;
import com.nafex.nafex2.data.OtherFieldType;
import com.nafex.nafex2.data.Product;
import com.nafex.nafex2.data.PurposeType;
import com.nafex.nafex2.utilities.AndroidMultiPartEntity;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;
import com.nafex.nafex2.utilities.HttpClient;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import android.app.DatePickerDialog;

import javax.net.ssl.HttpsURLConnection;

import droidninja.filepicker.FilePickerBuilder;
import droidninja.filepicker.FilePickerConst;
import droidninja.filepicker.utils.Orientation;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;


/**
 * Created by rahul on 12/9/17.
 */

public class Activity_KycUpload extends AppCompatActivity implements View.OnClickListener, View.OnTouchListener {
    private TextView txtDocType, txtSelect, txtDocNo, txtOtherFiles, txtOtherField, txtOtherInfo, txtSelectFileToUpload;
    private RelativeLayout layDocumentType, rv_otherfield, rv_otherinfo;
    private EditText edtDocNo, txtNameAsPer, edtxtotherinfo, edtxtexpiredate;
    private Button btnBrowse;
    ProgressDialog pd_login;
    private Button btn_upload;
    AppGlobalData gbData;
    List<DocumentType> doctypeList;
    Calendar calendar;
    DatePickerDialog datePickerDialog, datePickerDialog2;
    int isupload = 0;
    int Year, Month, Day;
    List<OtherFieldType> otherfieldList;
    private int iotherfield = 0, icusttypelist = 0;
    private boolean bkycupload, bycotherupload;
    private int MAX_ATTACHMENT_COUNT = 1;
    private ArrayList<String> photoPaths = new ArrayList<>();
    private ArrayList<String> docPaths = new ArrayList<>();
    private static final int PERMISSION_REQUEST_CODE = 1;
    Toolbar toolbar;
    ImageView img_click;
    SharedPreferences sharedpreferences;
    private int iUserId;
    String strtoken;
    SimpleDateFormat dateFormat;
    ImageView imgback;
    RelativeLayout rv_expiredate;
    List<DocType> object = null;
    String datetype = "valid";
    private static final int PERMISSIONS_REQUEST_CAPTURE_IMAGE = 1;

    ArrayList<String> filePaths = new ArrayList<>();
    String fileTypes[] = new String[]{".pdf", ".doc"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay_upload_kyc);

        globalData();
        findViews();

        getSharedPref();
        ontouchListner();
        setTypeFace();

    }



    private void showFileTypeAlertCustomDialog() {
        final Dialog dialog = new Dialog(Activity_KycUpload.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        // tvtitle.setVisibility(View.GONE);
        tvtitle.setText("Select File Type");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {

            }
        });

        ArrayList<String> choices = new ArrayList<>();
        choices.add("Select Image");
        choices.add("Select Document");


        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_KycUpload.this,
                R.layout.currency_list_item_n, R.id.list_item_id, choices);


        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                final String strName = adapter.getItem(i);
                                                if (strName.equalsIgnoreCase("Select Image")) {
                                                    onPickPhoto();
                                                } else {
                                                    onPickDocument();

                                                }
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    private void showDocumentTypeAlertCustomDialog() {
        final Dialog dialog = new Dialog(Activity_KycUpload.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
      //  tvtitle.setVisibility(View.GONE);
        tvtitle.setText("Select Document Type");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bkycupload = false;
            }
        });


        if (doctypeList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_KycUpload.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < doctypeList.size(); i++) {
                choices.add(doctypeList.get(i).getCodeName());
                currencyAdapter.add(doctypeList.get(i).getCodeName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_KycUpload.this,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtSelect.setText(doctypeList.get(i).getCodeName());
                                                icusttypelist = Integer.parseInt(doctypeList.get(i).getCodevalue());
                                                Log.e("icusttypelist", Integer.toString(icusttypelist));
                                                bkycupload = false;
                                               /* if(icusttypelist==10 || icusttypelist==8)
                                                {
                                                    txtOtherFiles.setVisibility(View.GONE);
                                                    rv_otherfield.setVisibility(View.GONE);
                                                }else
                                                {
                                                    txtOtherFiles.setVisibility(View.VISIBLE);
                                                    rv_otherfield.setVisibility(View.VISIBLE);
                                                }*/
                                                CallOtherFieldAPI objcurrrencyAPI = new CallOtherFieldAPI();
                                                objcurrrencyAPI.execute(CommonApi.GETDOCFIELDS);


                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);

        strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");

    }


    public class CallDocumentTypeApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        doctypeList = new ArrayList<DocumentType>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            DocumentType objProduct = new DocumentType();


                            objProduct.setCodevalue(jsonObj.getString("codeValue"));
                            objProduct.setCodeName(jsonObj.getString("codeName"));
                            objProduct.setCodeAtrribute(jsonObj.getString("codeAttribute"));

                            doctypeList.add(objProduct);

                        }
                        if (object == null) {

                        } else

                        {

                            Iterator<DocumentType> it = doctypeList.iterator();
                            while (it.hasNext()) {
                                DocumentType user = it.next();
                                for (int inh = 0; inh < object.size(); inh++) {
                                    if (user.getCodevalue().equals(object.get(inh).docTypeId)) {
                                        try{
                                            it.remove();
                                        }catch (IllegalStateException e){
                                            e.printStackTrace();
                                        }

                                    }
                                }
                            }
                        }


                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), Error_Message);
                }
                showDocumentTypeAlertCustomDialog();

            } else
                CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), Error_Message);

            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CODELIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("codeType", "DOCUMENTTYPE");
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }
    }

    public void onPickPhoto() {
        int maxCount = MAX_ATTACHMENT_COUNT;
        if ((docPaths.size() + photoPaths.size()) == MAX_ATTACHMENT_COUNT)
            Toast.makeText(this, "Cannot select more than " + MAX_ATTACHMENT_COUNT + " items", Toast.LENGTH_SHORT).show();
        else
            FilePickerBuilder.getInstance().setMaxCount(maxCount)
                    .setSelectedFiles(photoPaths)
                    .setActivityTheme(R.style.FilePickerTheme)
                    .enableVideoPicker(false)
                    .enableCameraSupport(true)
                    .showGifs(false)
                    .showFolderView(true)
                    .enableImagePicker(true)
                    .setCameraPlaceholder(R.drawable.ic_launcher)
                    .withOrientation(Orientation.PORTRAIT_ONLY)
                    .pickPhoto(this);
    }


    public void validateKycList() {
        if (icusttypelist == 0) {
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Document Type.");

        } else {
            if (edtDocNo.getText().toString().equalsIgnoreCase("")) {
                gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter document number.");

            } else {
                if (txtNameAsPer.getText().toString().equalsIgnoreCase("")) {
                    gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter document name.");

                } else {

                    if (rv_otherinfo.getVisibility() == View.VISIBLE && edtxtotherinfo.getText().toString().equalsIgnoreCase("")) {
                        gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter " + edtxtotherinfo.getHint().toString());

                    } else {
                        if (rv_expiredate.getVisibility() == View.VISIBLE && edtxtexpiredate.getText().toString().equalsIgnoreCase("")) {
                            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter " + edtxtexpiredate.getHint().toString());

                        } else {

                   /* if (iotherfield == 0) {
                        gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Other Field.");

                    } else {*/


                            if (filePaths.size() == 0) {
                                gbData.showAlert(this, getResources().getString(R.string.app_name), "Please upload file.");
                            } else {
                                //api call upload
                                Log.e("api call", "api call");
                                if (gbData.isConnected(getApplicationContext())) {
                                    new UploadFileToServer().execute();
                                } else {

                                }
                                // }

                            }
                        }
                    }
                }
            }
        }


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case FilePickerConst.REQUEST_CODE_PHOTO:
                if (resultCode == Activity.RESULT_OK && data != null) {
                    photoPaths = new ArrayList<>();
                    photoPaths.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_MEDIA));

                }
                txtSelectFileToUpload.setText(photoPaths.toString());

                break;

            case FilePickerConst.REQUEST_CODE_DOC:
                if (resultCode == Activity.RESULT_OK && data != null) {
                    docPaths = new ArrayList<>();
                    docPaths.addAll(data.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_DOCS));
                }
                if(docPaths.toString().contains(".ppt")||docPaths.toString().contains(".xls"))
                {
                    CommonUI.showAlert(Activity_KycUpload.this,"Error","The filetype you are attempting to upload is not allowed");
                    txtSelectFileToUpload.setText(null);
                    txtSelectFileToUpload.setHint("Select File to upload");
                    photoPaths.clear();
                    docPaths.clear();
                    filePaths.clear();
                }else {
                    txtSelectFileToUpload.setText(docPaths.toString());
                }
                break;
        }


        addThemToView(photoPaths, docPaths);
    }

    private void addThemToView(ArrayList<String> imagePaths, ArrayList<String> docPaths) {
        filePaths.clear();
        if (imagePaths != null)
            filePaths.addAll(imagePaths);

        if (docPaths != null)
            filePaths.addAll(docPaths);


        Toast.makeText(this, "Num of files selected: " + filePaths.size(), Toast.LENGTH_SHORT).show();
    }


    private void ontouchListner() {
        img_click.setOnClickListener(this);
        btn_upload.setOnClickListener(this);
        txtSelect.setOnTouchListener(this);
        layDocumentType.setOnTouchListener(this);
        rv_otherfield.setOnTouchListener(this);
        txtOtherField.setOnTouchListener(this);

    }

    private void findViews() {
        rv_expiredate = (RelativeLayout) findViewById(R.id.rv_expiredate);
        imgback = (ImageView) findViewById(R.id.imgNafexback);
        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        calendar = Calendar.getInstance();
        pd_login = new ProgressDialog(Activity_KycUpload.this);
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        img_click = (ImageView) toolbar.findViewById(R.id.img_click);
        setSupportActionBar(toolbar);
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        gbData.setStatusBarColor(Activity_KycUpload.this, R.color.colorPrimaryDark);
        rv_otherinfo = (RelativeLayout) findViewById(R.id.rv_otherinfo);
        txtDocType = (TextView) findViewById(R.id.txtDocType);
        layDocumentType = (RelativeLayout) findViewById(R.id.layDocumentType);
        txtSelect = (TextView) findViewById(R.id.txtSelect);
        txtDocNo = (TextView) findViewById(R.id.txtDocNo);
        edtDocNo = (EditText) findViewById(R.id.edtDocNo);
        btn_upload = (Button) findViewById(R.id.btn_upload);
        txtNameAsPer = (EditText) findViewById(R.id.txtNameAsPer);
        edtxtotherinfo = (EditText) findViewById(R.id.edtxtotherinfo);
        edtxtexpiredate = (EditText) findViewById(R.id.edtxtexpiredate);
        edtxtexpiredate.setOnTouchListener(this);
        edtxtotherinfo.setOnTouchListener(this);

       /* edtxtotherinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                switch (iotherfield) {
                    case 1:

                        //edtxtotherinfo.setFocusable(true);
                        edtxtotherinfo.requestFocus();

                        edtxtotherinfo.setText(null);

                        break;
                    case 2:
                    case 3:
                        //edtxtotherinfo.setFocusable(false);

                        edtxtotherinfo.setText(null);
                        datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                calendar.set(year, monthOfYear, dayOfMonth);

                                edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));


                            }
                        }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();


//date
                        break;

                    case 4:
                        //edtxtotherinfo.setFocusable(false);

                        edtxtotherinfo.setText(null);
                        datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                calendar.set(year, monthOfYear, dayOfMonth);

                                edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));


                            }
                        }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();

//date
                        break;
                    case 5:
                    case 6:
                        //  edtxtotherinfo.setFocusable(false);

                        edtxtotherinfo.setText(null);
                        datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                calendar.set(year, monthOfYear, dayOfMonth);

                                edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));


                            }
                        }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();


                        break;
                    case 7:
                        //edtxtotherinfo.setFocusable(false);

                        edtxtotherinfo.setText(null);
                        datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                calendar.set(year, monthOfYear, dayOfMonth);

                                edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));


                            }
                        }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();
                        //date
                        break;
                    case 8:

                        //edtxtotherinfo.setFocusable(true);
                        edtxtotherinfo.requestFocus();

                        edtxtotherinfo.setText(null);

                        //number
                        break;

                    case 9:
                    case 10:

                        //edtxtotherinfo.setFocusable(true);
                        edtxtotherinfo.requestFocus();


                        edtxtotherinfo.setText(null);

                        //number
                        break;

                    case 11:


                        //edtxtotherinfo.setFocusable(true);
                        edtxtotherinfo.requestFocus();
                        edtxtotherinfo.setText(null);

                        //number
                        break;
                    default:


                        break;


                }


            }
        });*/

        txtOtherFiles = (TextView) findViewById(R.id.txtOtherFiles);
        txtOtherField = (TextView) findViewById(R.id.txtOtherField);
        txtOtherInfo = (TextView) findViewById(R.id.txtOtherInfo);
        txtSelectFileToUpload = (TextView) findViewById(R.id.txtSelectFileToUpload);
        btnBrowse = (Button) findViewById(R.id.btnBrowse);
        btnBrowse.setOnClickListener(this);
        rv_otherfield = (RelativeLayout) findViewById(R.id.rv_otherfield);

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.btnBrowse:
                if (Build.VERSION.SDK_INT >= 23) {
                    if (checkPermission()) {
                        photoPaths.clear();
                        docPaths.clear();
                        // txtOtherInfo.setText(null);
                        showFileTypeAlertCustomDialog();


                    } else {
                        requestPermission(); // Code for permission
                    }
                } else {
                    photoPaths.clear();
                    docPaths.clear();
                    showFileTypeAlertCustomDialog();


                    // Code for Below 23 API Oriented Device
                    // Do next code
                }
                break;

            case R.id.btn_upload:
                validateKycList();

                break;

            case R.id.img_click:

                validateKycList();

                break;

        }
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(Activity_KycUpload.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestPermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(Activity_KycUpload.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Toast.makeText(Activity_KycUpload.this, "Write External Storage permission allows us to do store images. Please allow this permission in App Settings.", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(Activity_KycUpload.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e("value", "Permission Granted, Now you can use local drive .");
                    photoPaths.clear();
                    docPaths.clear();
                    showFileTypeAlertCustomDialog();

                } else {
                    Log.e("value", "Permission Denied, You cannot use local drive .");
                }
                break;
        }
    }

    private void onPickDocument() {
        int maxCount = MAX_ATTACHMENT_COUNT;
        if ((docPaths.size() + photoPaths.size()) == MAX_ATTACHMENT_COUNT)
            Toast.makeText(this, "Cannot select more than " + MAX_ATTACHMENT_COUNT + " items", Toast.LENGTH_SHORT).show();
        else

            FilePickerBuilder.getInstance().setMaxCount(maxCount)
                    .setSelectedFiles(docPaths)
                    .setActivityTheme(R.style.FilePickerTheme)
                    .enableDocSupport(true)
                    .showFolderView(true)
                    .setCameraPlaceholder(R.drawable.ic_launcher)
                    .withOrientation(Orientation.PORTRAIT_ONLY)
                    .pickFile(this);


    }


    /**
     * Uploading the file to server
     */
    private class UploadFileToServer extends AsyncTask<Void, Integer, String> {
        @Override
        protected void onPreExecute() {
            // setting progress bar to zero
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... progress) {
            // Making progress bar visible

        }

        @Override
        protected String doInBackground(Void... params) {
            return uploadFile();
        }

        @SuppressWarnings("deprecation")
        private String uploadFile() {
            String responseString = null;

            DefaultHttpClient httpclient = new DefaultHttpClient();
            byte[] auth = (iUserId + ":" + strtoken).getBytes();
            String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
           HttpPost httppost = new HttpPost(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTTYPEUPLOAD);
          //  HttpPost httppost = new HttpPost("http://13.59.118.35/nafex2dev/customer/uploadkyc");
            httppost.setHeader("Authorization", "Basic " + basic);
            try {
                AndroidMultiPartEntity entity = new AndroidMultiPartEntity(
                        new AndroidMultiPartEntity.ProgressListener() {

                            @Override
                            public void transferred(long num) {

                            }
                        });
                File sourceFile = null;

                if (photoPaths.size() > 0) {
                    for (int i = 0; i < photoPaths.size(); i++) {
                        Log.e("Photopath", "" + photoPaths.get(i).toString());
                        String str = photoPaths.get(i).toString();
                        sourceFile = new File(str);
                    }
                } else {
                    if (docPaths.size() > 0) {
                        for (int i = 0; i < docPaths.size(); i++) {
                            Log.e("Docpath", "" + docPaths.get(i).toString());
                            String str = docPaths.get(i).toString();
                            sourceFile = new File(str);
                        }
                    }
                }


                // Adding file data to http body

                entity.addPart("docFile", new FileBody(sourceFile));

                // Extra parameters if you want to pass to server
                entity.addPart("docTypeId",
                        new StringBody(Integer.toString(icusttypelist)));
                entity.addPart("otherTypeId", new StringBody(Integer.toString(iotherfield)));
                Log.e("otherTypeId",Integer.toString(iotherfield));
               /* if(edtxtotherinfo.getVisibility()==View.VISIBLE && edtxtexpiredate.getVisibility()==View.VISIBLE)
                {
                    entity.addPart("otherTypeInfo", new StringBody(edtxtotherinfo.getText().toString().trim()+":"+edtxtexpiredate.getText().toString().trim()));

                }else {
                    entity.addPart("otherTypeInfo", new StringBody(edtxtotherinfo.getText().toString().trim()));
                }*/

                if(iotherfield==7)
                {
                    entity.addPart("otherTypeInfo", new StringBody(edtxtotherinfo.getText().toString().trim()+":"+edtxtexpiredate.getText().toString().trim()));

                }else
                {
                    if(iotherfield==6)
                    {
                        Log.e("Issuedate",edtxtotherinfo.getText().toString().trim());
                        Log.e("Expiredate",edtxtexpiredate.getText().toString().trim());

                        entity.addPart("otherTypeInfo", new StringBody(edtxtotherinfo.getText().toString().trim()+":"+edtxtexpiredate.getText().toString().trim()));

                    }else
                    {
                        entity.addPart("otherTypeInfo", new StringBody(edtxtotherinfo.getText().toString().trim()));

                    }
                }

                entity.addPart("docNumber", new StringBody(edtDocNo.getText().toString().trim()));
                entity.addPart("docName", new StringBody(txtNameAsPer.getText().toString().trim()));
                entity.addPart("travellerNo",new StringBody("1"));
                Log.e("docFile", "" + sourceFile);
                Log.e("docNumber", "" + edtDocNo.getText().toString().trim());
                Log.e("docName", "" + txtNameAsPer.getText().toString().trim());


                httppost.setEntity(entity);

                // Making server call
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity r_entity = response.getEntity();

                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == 200) {
                    // Server response
                    responseString = EntityUtils.toString(r_entity);
                } else {
                    responseString = "Error occurred! Http Status Code: "
                            + statusCode;
                }

            } catch (ClientProtocolException e) {
                responseString = e.toString();
            } catch (IOException e) {
                responseString = e.toString();
            }

            return responseString;

        }

        @Override
        protected void onPostExecute(String result) {
            Log.e("Response", "Response from server: " + result);
            //  Toast.makeText(Activity_KycUpload.this, result, Toast.LENGTH_LONG).show();
            // showing the server response in an alert dialog
            pd_login.dismiss();
            try {
                JSONObject objdata = new JSONObject(result);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    photoPaths.clear();
                    docPaths.clear();
                    filePaths.clear();
                    showAlertSuccess(Activity_KycUpload.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

                } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                    CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
            }

            super.onPostExecute(result);
        }

    }

    public void showAlert(Context mycontext, String title, String message) {
        new AlertDialog.Builder(mycontext)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // txtUserEmail.setText(null);
                        //   finish();
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })

                .show();
    }

    public void showAlertSuccess(Context mycontext, String title, String message) {
        new AlertDialog.Builder(mycontext)
                .setTitle(title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //  Intent int_view = new Intent(Activity_KycUpload.this, Activity_Kyc_Listing.class);
                        // startActivity(int_view);

                        finish();
                    }
                })

                .show();
    }


    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
            switch (view.getId()) {

                case R.id.layDocumentType:
                case R.id.txtSelect:
                    txtOtherInfo.setVisibility(View.GONE);
                    rv_otherinfo.setVisibility(View.GONE);
                    rv_expiredate.setVisibility(View.GONE);

                    if (bkycupload == false) {
                        if (doctypeList == null || doctypeList.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                bkycupload = true;
                                CallDocumentTypeApi objcurrrencyAPI = new CallDocumentTypeApi();
                                objcurrrencyAPI.execute(CommonApi.CODELIST);
                            } else
                                CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        } else
                            showDocumentTypeAlertCustomDialog();

                    }


                    break;
                case R.id.rv_otherfield:
                case R.id.txtOtherField:


                    if (otherfieldList == null) {
                        CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Please select Document Type.");

                    } else {
                        if (otherfieldList.size() >= 0) {
                            showOtherFieldAlertCustomDialog();
                        } else {
                            CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Please select Document Type.");

                        }
                    }

                 /*   if (bycotherupload == false) {
                        if (otherfieldList == null || otherfieldList.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                bycotherupload = true;
                                CallOtherFieldAPI objcurrrencyAPI = new CallOtherFieldAPI();
                                objcurrrencyAPI.execute(CommonApi.GETDOCFIELDS);
                            } else
                                CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        }else
                            showDocumentTypeAlertCustomDialog();
                    }
*/

                    break;

                case R.id.edtxtotherinfo:

                    switch (iotherfield) {
                        case 1:
                            edtxtotherinfo.setText(null);
                            edtxtotherinfo.requestFocus();

                            edtxtotherinfo.isInEditMode();
                            edtxtotherinfo.setFocusable(true);
                            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm.showSoftInput(edtxtotherinfo, InputMethodManager.SHOW_IMPLICIT);
                            //edtxtotherinfo.setFocusable(true);
                            edtxtotherinfo.requestFocus();


                            break;
                        case 2:
                        case 3:
                            //edtxtotherinfo.setFocusable(false);

                            edtxtotherinfo.setText(null);
                            datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                                @Override
                                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                    calendar.set(year, monthOfYear, dayOfMonth);

                                    edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));


                                }
                            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                            datePickerDialog.show();


//date
                            break;

                        case 4:
                            //edtxtotherinfo.setFocusable(false);

                            edtxtotherinfo.setText(null);
                            datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                                @Override
                                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                    calendar.set(year, monthOfYear, dayOfMonth);

                                    edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));


                                }
                            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                            datePickerDialog.show();

//date
                            break;
                        case 5:


                            edtxtotherinfo.setText(null);
                            datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                                @Override
                                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                    calendar.set(year, monthOfYear, dayOfMonth);

                                    edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));


                                }
                            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                            datePickerDialog.show();

//date
                            break;


                        case 6:
                            //  edtxtotherinfo.setFocusable(false);
                            Log.e("5,6", "5,6");


                            edtxtotherinfo.setText(null);
                            datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                                @Override
                                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                    calendar.set(year, monthOfYear, dayOfMonth);
                                    Log.e("5,6-datepicker", "5,6");

                                   /* if(edtxtexpiredate.getText().toString()!="") {
                                        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
                                        Date convertedDate = new Date();
                                        Date convertedDate2 = new Date();
                                        try {
                                            convertedDate = dateFormatter.parse(edtxtexpiredate.getText().toString().trim());
                                            convertedDate2 = dateFormatter.parse(dateFormatter.format(calendar.getTime()));

                                            if (convertedDate.after(convertedDate2)) {
                                                Log.e("5,6-valid", "5,6");

                                                edtxtotherinfo.setText(dateFormatter.format(calendar.getTime()));
                                            } else {
                                                CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Invalid Expiry date");

                                                Log.e("invalide", "invlaid");
                                            }


                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                    }else
                                    {
                                        edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));

                                    }*/

                                    //  if (edtxtexpiredate.getText().toString() != null) {
                                    try {
                                        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
                                        Date convertedDate = dateFormatter.parse(edtxtexpiredate.getText().toString().trim());
                                        Date convertedDate2 = dateFormatter.parse(dateFormatter.format(calendar.getTime()));

                                        if (convertedDate.after(convertedDate2)) {
                                            Log.e("Issue date", "valid");
                                            //          edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));
                                            datetype = "valid";

                                        } else {
                                            CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Invalid date Range");
                                            datetype = "Invalid";
                                            Log.e("Issue date", "Invalid");
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    if (datetype.equalsIgnoreCase("valid")) {
                                        edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));
                                    } else {
                                        edtxtotherinfo.setText(null);

                                    }
                                  /*  } else {
                                        Toast.makeText(Activity_KycUpload.this, "Please add Issue date", Toast.LENGTH_LONG).show();
                                    }*/


                                }
                            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                            datePickerDialog.show();


                            break;
                        case 7:
                            //edtxtotherinfo.setFocusable(false);

                            edtxtotherinfo.setText(null);
                            datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                                @Override
                                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                    calendar.set(year, monthOfYear, dayOfMonth);
                                    Log.e("5,6-datepicker", "5,6");

                                   /* if(edtxtexpiredate.getText().toString()!="") {
                                        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
                                        Date convertedDate = new Date();
                                        Date convertedDate2 = new Date();
                                        try {
                                            convertedDate = dateFormatter.parse(edtxtexpiredate.getText().toString().trim());
                                            convertedDate2 = dateFormatter.parse(dateFormatter.format(calendar.getTime()));

                                            if (convertedDate.after(convertedDate2)) {
                                                Log.e("5,6-valid", "5,6");

                                                edtxtotherinfo.setText(dateFormatter.format(calendar.getTime()));
                                            } else {
                                                CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Invalid Expiry date");

                                                Log.e("invalide", "invlaid");
                                            }


                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                    }else
                                    {
                                        edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));

                                    }*/

                                    //  if (edtxtexpiredate.getText().toString() != null) {
                                    try {
                                        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
                                        Date convertedDate = dateFormatter.parse(edtxtexpiredate.getText().toString().trim());
                                        Date convertedDate2 = dateFormatter.parse(dateFormatter.format(calendar.getTime()));

                                        if (convertedDate.after(convertedDate2)) {
                                            Log.e("Departure date", "valid");
                                            //          edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));
                                            datetype = "valid";

                                        } else {
                                            CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Invalid date Range");
                                            datetype = "Invalid";
                                            Log.e("Departure date", "Invalid");
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    if (datetype.equalsIgnoreCase("valid")) {
                                        edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));
                                    } else {
                                        edtxtotherinfo.setText(null);

                                    }
                                  /*  } else {
                                        Toast.makeText(Activity_KycUpload.this, "Please add Issue date", Toast.LENGTH_LONG).show();
                                    }*/


                                }
                            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                            datePickerDialog.show();





                          /*
                            edtxtotherinfo.setText(null);
                            datePickerDialog = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                                @Override
                                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                    calendar.set(year, monthOfYear, dayOfMonth);

                                    edtxtotherinfo.setText(dateFormat.format(calendar.getTime()));


                                }
                            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                            datePickerDialog.show();*/
                            //date
                            break;
                        case 8:
                            edtxtotherinfo.requestFocus();
                            edtxtotherinfo.isInEditMode();
                            edtxtotherinfo.setFocusable(true);
                            InputMethodManager imm6 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm6.showSoftInput(edtxtotherinfo, InputMethodManager.SHOW_IMPLICIT);
                            //edtxtotherinfo.setFocusable(true);
                            edtxtotherinfo.requestFocus();

                            break;

                        case 9:
                        case 10:
                            edtxtotherinfo.requestFocus();
                            edtxtotherinfo.isInEditMode();
                            edtxtotherinfo.setFocusable(true);
                            InputMethodManager imm2 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm2.showSoftInput(edtxtotherinfo, InputMethodManager.SHOW_IMPLICIT);
                            //edtxtotherinfo.setFocusable(true);
                            edtxtotherinfo.requestFocus();


                            //number
                            break;

                        case 11:
                            edtxtotherinfo.requestFocus();
                            edtxtotherinfo.isInEditMode();
                            edtxtotherinfo.setFocusable(true);
                            InputMethodManager imm3 = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm3.showSoftInput(edtxtotherinfo, InputMethodManager.SHOW_IMPLICIT);
                            //edtxtotherinfo.setFocusable(true);
                            edtxtotherinfo.requestFocus();


                            //number
                            break;
                        default:


                            break;


                    }

                    break;

                case R.id.edtxtexpiredate:

                    edtxtexpiredate.setText(null);
                    datePickerDialog2 = new DatePickerDialog(Activity_KycUpload.this, new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                            calendar.set(year, monthOfYear, dayOfMonth);
                            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
                            Date convertedDate = new Date();
                            Date convertedDate2 = new Date();
                            try {
                                convertedDate = dateFormat.parse(edtxtotherinfo.getText().toString().trim());
                                convertedDate2 = dateFormat.parse(dateFormat.format(calendar.getTime()));

                                if (convertedDate2.after(convertedDate)) {
                                    edtxtexpiredate.setText(dateFormat.format(calendar.getTime()));
                                } else {
                                    CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), "Invalid Expiry date");

                                    Log.e("invalide", "invlaid");
                                }


                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            //edtxtexpiredate.setText(dateFormat.format(calendar.getTime()));


                        }
                    }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                    datePickerDialog2.show();
                    break;

                default:
                    break;


            }
        }

        return true;


    }

    /*
    set global data for main screen
    */
    private void globalData() {
        gbData = AppGlobalData.getInstance();
        bkycupload = false;
        bycotherupload = false;
        Intent intent = getIntent();
        Bundle args = intent.getBundleExtra("BUNDLE");
        isupload = intent.getIntExtra("isSize", 0);
        if (isupload == 0) {
            object = null;
            //doctypeList.clear();
        } else {
            object = (ArrayList<DocType>) args.getSerializable("KYCList");
        }

    }


    public class CallOtherFieldAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd_login.dismiss();
            txtOtherFiles.setVisibility(View.VISIBLE);
            txtOtherField.setText(null);
            // edtxtotherinfo.setText(null);
            if (Error_Message.equalsIgnoreCase(""))
                if (otherfieldList.size() > 0) {
                    // txtOtherFiles.setText(null);
                    if (icusttypelist == 10 || icusttypelist == 8) {
                        txtOtherFiles.setVisibility(View.GONE);
                        rv_otherfield.setVisibility(View.GONE);
                        //txtOtherInfo.setVisibility(View.VISIBLE);
                        //rv_otherinfo.setVisibility(View.VISIBLE);
                    } else {

                        // txtOtherInfo.setVisibility(View.VISIBLE);
                        // rv_otherinfo.setVisibility(View.VISIBLE);
                        txtOtherFiles.setVisibility(View.VISIBLE);
                        rv_otherfield.setVisibility(View.VISIBLE);
                    }
                } else {
                    // txtOtherInfo.setVisibility(View.GONE);
                    //rv_otherinfo.setVisibility(View.GONE);
                    txtOtherFiles.setVisibility(View.GONE);
                    rv_otherfield.setVisibility(View.GONE);

                }

               /* if(icusttypelist==10 || icusttypelist==9)
                {
                    txtOtherFiles.setVisibility(View.GONE);
                    rv_otherfield.setVisibility(View.GONE);
                }*/


            else
                CommonUI.showAlert(Activity_KycUpload.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForOtherField();
            return "DONE";

        }

        private void CallForOtherField() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.GETDOCFIELDS);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    otherfieldList = new ArrayList<OtherFieldType>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        OtherFieldType objOtherfield = new OtherFieldType();
                        if (Integer.toString(icusttypelist).equalsIgnoreCase(jsonObj.getString("masterTypeId"))) {
                            Log.e("id", jsonObj.getString("id"));
                            Log.e("masterTypeId", jsonObj.getString("masterTypeId"));
                            Log.e("subTypeName", jsonObj.getString("subTypeName"));
                            Log.e("subTypeType", jsonObj.getString("subTypeType"));
                            if (jsonObj.getString("masterTypeId").equalsIgnoreCase("2")) {
                                if (jsonObj.getString("id").equalsIgnoreCase("2")) {

                                    objOtherfield.setId(jsonObj.getString("id"));
                                    objOtherfield.setMasterTypeId(jsonObj.getString("masterTypeId"));
                                    objOtherfield.setSubTypeName(jsonObj.getString("subTypeName"));
                                    objOtherfield.setSubTypeType(jsonObj.getString("subTypeType"));
                                    otherfieldList.add(objOtherfield);
                                }

                            } else {
                                objOtherfield.setId(jsonObj.getString("id"));
                                objOtherfield.setMasterTypeId(jsonObj.getString("masterTypeId"));
                                objOtherfield.setSubTypeName(jsonObj.getString("subTypeName"));
                                objOtherfield.setSubTypeType(jsonObj.getString("subTypeType"));
                                otherfieldList.add(objOtherfield);
                            }
                        }
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }

    private void showOtherFieldAlertCustomDialog() {

        final Dialog dialog = new Dialog(Activity_KycUpload.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
       // tvtitle.setVisibility(View.GONE);
        tvtitle.setText("Select Other Field");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bycotherupload = false;
            }
        });


        if (otherfieldList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_KycUpload.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < otherfieldList.size(); i++) {
                choices.add(otherfieldList.get(i).getSubTypeName());
                currencyAdapter.add(otherfieldList.get(i).getSubTypeName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_KycUpload.this,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtOtherInfo.setVisibility(View.VISIBLE);
                                                rv_otherinfo.setVisibility(View.VISIBLE);
                                                edtxtotherinfo.setText(null);
                                                txtOtherField.setText(otherfieldList.get(i).getSubTypeName());
                                                iotherfield = Integer.parseInt(otherfieldList.get(i).getMasterTypeId());
                                                Log.e("iotherfield", Integer.toString(iotherfield));

                                                if (iotherfield == 6) {
                                                    edtxtexpiredate.setText(null);

                                                    rv_expiredate.setVisibility(View.VISIBLE);
                                                    edtxtotherinfo.setHint("Issue Date");
                                                } else {
                                                    if (iotherfield == 7) {
                                                        rv_expiredate.setVisibility(View.VISIBLE);
                                                        edtxtexpiredate.setText(null);
                                                        edtxtexpiredate.setHint("Return Date");
                                                        edtxtotherinfo.setHint("Departure Date");
                                                    } else {
                                                        rv_expiredate.setVisibility(View.GONE);
                                                        edtxtotherinfo.setHint("Other info");

                                                    }


                                                }

                                              /*  if (iotherfield == 7) {
                                                    rv_expiredate.setVisibility(View.VISIBLE);
                                                    edtxtexpiredate.setHint("Return Date");
                                                    edtxtotherinfo.setHint("Departure Date");
                                                } else {
                                                    rv_expiredate.setVisibility(View.GONE);
                                                    edtxtotherinfo.setHint("Other info");

                                                }*/


                                                bycotherupload = false;
                                                // edtxtotherinfo.setText(null);
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);


    }


    private void showKycAlertCustomDialog() {
        final Dialog dialog = new Dialog(Activity_KycUpload.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bkycupload = false;
            }
        });


      /*  if (currencyList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < currencyList.size(); i++) {
                choices.add(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
                currencyAdapter.add(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtCurrency.setText(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
                                                iCurrency = currencyList.get(i).getCurrencyId();
                                                bCurrency = false;
                                                dialog.dismiss();
                                            }
                                        }

        );*/
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    private void setTypeFace() {
        txtDocType.setTypeface(FontData.setFonts(Activity_KycUpload.this, txtDocType, FontData.font_robotomedium));
        txtSelect.setTypeface(FontData.setFonts(Activity_KycUpload.this, txtSelect, FontData.font_robotoregular));
        txtDocNo.setTypeface(FontData.setFonts(Activity_KycUpload.this, txtDocNo, FontData.font_robotoregular));
        txtNameAsPer.setTypeface(FontData.setFonts(Activity_KycUpload.this, txtNameAsPer, FontData.font_robotoregular));
        txtOtherField.setTypeface(FontData.setFonts(Activity_KycUpload.this, txtOtherField, FontData.font_robotoregular));
        txtOtherInfo.setTypeface(FontData.setFonts(Activity_KycUpload.this, txtOtherInfo, FontData.font_robotoregular));

        txtSelectFileToUpload.setTypeface(FontData.setFonts(Activity_KycUpload.this, txtSelectFileToUpload, FontData.font_robotoregular));
        txtOtherFiles.setTypeface(FontData.setFonts(Activity_KycUpload.this, txtOtherFiles, FontData.font_robotoregular));
    }
}



