package com.nafex.nafex2.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.AdapterKycListing;
import com.nafex.nafex2.data.DocType;
import com.nafex.nafex2.interfaces.KYCOperation;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Swarup on 10/4/2017.
 */


public class Activity_Kyc_Listing_Menu extends AppCompatActivity {

    SharedPreferences.Editor editor;

    private TextView mTxtKycDoc;
    private RecyclerView mRecyclerView;
    private AdapterKycListing mAdapterKycListing;
    private ProgressBar progressBar;
    AppGlobalData gbData;
    SharedPreferences sharedpreferences;
    private int iUserId;
    String strtoken;
    String kycdoctypeid;
    List<DocType> docList;
    Toolbar toolbar;
    ProgressDialog pd_login;
    FloatingActionButton fb;
    ImageView imgback;
    ImageView imgadd;
    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private View navHeader;
    LinearLayout llMainView;
    LinearLayout lv_nodoc;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kyc_listing_menu);
        globalData();
        getSharedPref();

    }

    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);

        strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");

    }


    private void globalData() {
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        lv_nodoc = (LinearLayout) findViewById(R.id.lv_nodoc);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        gbData = AppGlobalData.getInstance();
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        pd_login = new ProgressDialog(Activity_Kyc_Listing_Menu.this);
        //  fb = (FloatingActionButton) findViewById(R.id.floating_action_button_fab_with_listview);
       /* fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int_upload = new Intent(Activity_Kyc_Listing.this, Activity_KycUpload.class);
                startActivity(int_upload);
            }
        });*/


        setSupportActionBar(toolbar);
        gbData.setStatusBarColor(Activity_Kyc_Listing_Menu.this, R.color.colorPrimaryDark);
        imgadd = (ImageView) findViewById(R.id.img_addupload);
        imgadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int_upload = new Intent(Activity_Kyc_Listing_Menu.this, Activity_KycUpload.class);
                Bundle args = new Bundle();
                if (docList==null) {
                    int_upload.putExtra("isSize", 0);

                }else
                {
                    args.putSerializable("KYCList", (Serializable) docList);
                    int_upload.putExtra("isSize", docList.size());
                }
                int_upload.putExtra("BUNDLE", args);
                startActivity(int_upload);
            }
        });
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        mTxtKycDoc = (TextView) findViewById(R.id.txtKycDoc);
        mTxtKycDoc.setTypeface(FontData.setFonts(Activity_Kyc_Listing_Menu.this, mTxtKycDoc, FontData.font_robotomedium));

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_kyc_listing);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        if (iUserId == -1) {
            navigationView.inflateMenu(R.menu.menu_customer_new);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

            setUpNavigationViewNewUser();
        } else {
            navigationView.inflateMenu(R.menu.menu_customer);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);
            setUpNavigationView();
        }

    }

    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
                        Intent intentmain = new Intent(Activity_Kyc_Listing_Menu.this, Activity_main.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_trackorder:
                        Intent intenthistory = new Intent(Activity_Kyc_Listing_Menu.this, Activity_history.class);
                        intenthistory.putExtra("Source", "");
                        startActivity(intenthistory);
                        finish();
                        break;
                    case R.id.nav_profile:
                        Intent intentprofile = new Intent(Activity_Kyc_Listing_Menu.this, Activity_profile.class);
                        startActivity(intentprofile);
                        finish();
                        break;
                    case R.id.nav_kyc:
                       /* Intent intentprofile = new Intent(Activity_Kyc_Listing_Menu.this, Activity_profile.class);
                        startActivity(intentprofile);
                        finish();*/
                        break;
                    case R.id.NBC_Details:
                        Intent intentNBC = new Intent(Activity_Kyc_Listing_Menu.this, Activity_KycList_NBC.class);
                        startActivity(intentNBC);
                        finish();
                        break;
                    case R.id.nav_signout:
                        /*if (gbData.isConnected(Activity_Kyc_Listing_Menu.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(Activity_Kyc_Listing_Menu.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }*/
                        logoutApplication();
                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }

    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Activity_Kyc_Listing_Menu.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(Activity_Kyc_Listing_Menu.this, Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }


    @Override
    protected void onResume() {
        if (gbData.isConnected(getApplicationContext())) {
            CallKYClistAPI objcurrrencyAPI = new CallKYClistAPI();
            objcurrrencyAPI.execute(CommonApi.GETKYCLIST);
        }
        super.onResume();
    }


    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (Error_Message.equalsIgnoreCase("")) {

                logoutApplication();
            } else
                CommonUI.showAlert(Activity_Kyc_Listing_Menu.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }




    private void setUpNavigationViewNewUser() {
        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
//                        Intent intentmain =new Intent(Activity_main.this, Activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_signIn:
                    /*    Intent intenthistory = new Intent(Activity_main.this, Activity_login.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        CommonUI.setStrregtype("self");
                        startActivity(intenthistory);*/


                        Intent intenthistory = new Intent(Activity_Kyc_Listing_Menu.this, Activity_otpdashboard.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        editor = sharedpreferences.edit();
                        editor.putString(ConstantData.ISLEFTLOGIN, "true");
                        editor.commit();
                        startActivity(intenthistory);
                        finish();

                        break;

                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


    }

    public class CallKYClistAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mRecyclerView.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }
        public class AppWebViewClients extends WebViewClient {



            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // TODO Auto-generated method stub
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // TODO Auto-generated method stub
                super.onPageFinished(view, url);

            }
        }
        private class Callback extends WebViewClient {
            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view, String url) {
                return(false);
            }
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);

            if (Error_Message.equalsIgnoreCase("")) {
                if (gbData.isConnected(getApplicationContext())) {
                    //CallAreaAPI objAreaAPI = new CallAreaAPI();
                    //objAreaAPI.execute(ConstantData.AREA);
                    if (docList.size() > 0) {
                        mRecyclerView.setVisibility(View.VISIBLE);

                        mAdapterKycListing = new AdapterKycListing(Activity_Kyc_Listing_Menu.this, docList, new KYCOperation() {
                            @Override
                            public void onDeleteKyc(final String kycId) {
                                final Dialog dialog = new Dialog(Activity_Kyc_Listing_Menu.this);
                                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialog.setCancelable(false);
                                dialog.setContentView(R.layout.lay_kyc_delete_confermation);


                                Button dialogButtonno = (Button) dialog.findViewById(R.id.btn_no);
                                dialogButtonno.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialog.dismiss();
                                    }
                                });

                                Button dialogButtonyes = (Button) dialog.findViewById(R.id.btn_yes);
                                dialogButtonyes.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        if (gbData.isConnected(getApplicationContext())) {

                                            kycdoctypeid = kycId;
                                            dialog.dismiss();
                                            CallDeleteKYCAPI objRequestAPI = new CallDeleteKYCAPI();
                                            objRequestAPI.execute(CommonApi.DELETEKYC);


                                        }
                                    }
                                });

                                dialog.show();

                            }

                            @Override
                            public void onViewClick(String kycId) {
                                // Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(kycId));
                                // startActivity(browserIntent);

                                Log.e("docurl",kycId);
                                if (kycId.toString().contains(".doc") || kycId.toString().contains(".docx")) {
                                    // Word document
                                    AlertDialog.Builder alert = new AlertDialog.Builder(Activity_Kyc_Listing_Menu.this);

                                    WebView wv = new WebView(Activity_Kyc_Listing_Menu.this);
                                   // wv.setWebViewClient(new AppWebViewClients());
                                    wv.getSettings().setPluginState(WebSettings.PluginState.ON);
                                    wv.setWebViewClient(new Callback());

                                   // String pdfURL = "http://dl.dropboxusercontent.com/u/37098169/Course%20Brochures/AND101.pdf";
                                    wv.loadUrl(
                                            "http://docs.google.com/gview?embedded=true&url=" + kycId);

                                    wv.getSettings().setJavaScriptEnabled(true);
                                    wv.getSettings().setUseWideViewPort(true);
                                   // wv.loadUrl(kycId);
                                    WebSettings webSettings = wv.getSettings();
                                    webSettings.setBuiltInZoomControls(true);
                                    webSettings.setSupportZoom(true);
                                    alert.setView(wv);
                                    alert.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.dismiss();
                                        }
                                    });
                                    alert.show();



                                    /*Intent intentdoc = new Intent(Intent.ACTION_VIEW);
                                    intentdoc.setDataAndType(Uri.parse(kycId), "application/msword");
                                    intentdoc.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intentdoc);
*/
                                }  else if(kycId.toString().contains(".pdf")) {
                                    // PDF file

                                    AlertDialog.Builder alert = new AlertDialog.Builder(Activity_Kyc_Listing_Menu.this);

                                    WebView wv = new WebView(Activity_Kyc_Listing_Menu.this);
                                    // wv.setWebViewClient(new AppWebViewClients());
                                    wv.getSettings().setPluginState(WebSettings.PluginState.ON);
                                    wv.setWebViewClient(new Callback());

                                    // String pdfURL = "http://dl.dropboxusercontent.com/u/37098169/Course%20Brochures/AND101.pdf";
                                    wv.loadUrl(
                                            "http://docs.google.com/gview?embedded=true&url=" + kycId);

                                    wv.getSettings().setJavaScriptEnabled(true);
                                    wv.getSettings().setUseWideViewPort(true);
                                    // wv.loadUrl(kycId);
                                    WebSettings webSettings = wv.getSettings();
                                    webSettings.setBuiltInZoomControls(true);
                                    webSettings.setSupportZoom(true);
                                    alert.setView(wv);
                                    alert.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.dismiss();
                                        }
                                    });
                                    alert.show();






                                   /* Intent intentpdf = new Intent(Intent.ACTION_VIEW);
                                    intentpdf.setDataAndType(Uri.parse(kycId), "application/pdf");
                                    intentpdf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intentpdf);*/

                                }else {


                                    AlertDialog.Builder alert = new AlertDialog.Builder(Activity_Kyc_Listing_Menu.this);

                                    WebView wv = new WebView(Activity_Kyc_Listing_Menu.this);
                                    wv.loadUrl(kycId);
                                    wv.getSettings().setLoadWithOverviewMode(true);
                                    wv.getSettings().setUseWideViewPort(true);
                                    wv.setWebViewClient(new WebViewClient() {
                                        @Override
                                        public boolean shouldOverrideUrlLoading(WebView view, String url) {
                                            view.loadUrl(url);

                                            return true;
                                        }
                                    });

                                    alert.setView(wv);
                                    alert.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.dismiss();
                                        }
                                    });
                                    alert.show();

                                }

                              /*  final Dialog dialog = new Dialog(Activity_Kyc_Listing_Menu.this);
                                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialog.setContentView(R.layout.customdialog);
                                try {
                                    ImageView imageView = (ImageView) dialog.findViewById(R.id.dialogimageview);
                                    URL url = new URL(kycId);
                                    Bitmap bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                                    imageView.setImageBitmap(bmp);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                dialog.show();*/

                            }
                        });
                        mRecyclerView.setAdapter(mAdapterKycListing);

                    } else {
                        mRecyclerView.setVisibility(View.GONE);
                        lv_nodoc.setVisibility(View.VISIBLE);

                    }
                } else
                    CommonUI.showAlert(Activity_Kyc_Listing_Menu.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
            } else
                CommonUI.showAlert(Activity_Kyc_Listing_Menu.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CallForKYCList();
            return "DONE";

        }

        private void CallForKYCList() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.GETKYCLIST);
                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (iUserId + ":" + strtoken).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                docList = new ArrayList<DocType>();

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        DocType objCity = new DocType();
                        objCity.setId(jsonObj.getString("id"));
                        objCity.setUserId(jsonObj.getString("userId"));
                        objCity.setDocTypeId(jsonObj.getString("docTypeId"));
                        objCity.setDocTypeName(jsonObj.getString("docTypeName"));
                        objCity.setDocNumber(jsonObj.getString("docNumber"));
                        objCity.setDocName(jsonObj.getString("docName"));
                        objCity.setOtherTypeId(jsonObj.getString("otherTypeId"));
                        if (jsonObj.getString("otherTypeId").equalsIgnoreCase("0")){
                            objCity.setOtherTypeName("");
                            objCity.setOtherTypeInfo("");
                        }else {
                            objCity.setOtherTypeName(jsonObj.getString("otherTypeName"));
                            objCity.setOtherTypeInfo(jsonObj.getString("otherTypeInfo"));
                        }



                        objCity.setDocFile(jsonObj.getString("docFile"));


                        docList.add(objCity);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    docList.clear();
                    Error_Message = objdata.getString("message_text");
                   /* runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mRecyclerView.setVisibility(View.GONE);
                            lv_nodoc.setVisibility(View.VISIBLE);
                        }
                    });*/

                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in city data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }

    }


    private void showAlert(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                       /* Intent i = new Intent(Activity_requesttrace.this, Activity_bidsuccess.class);
                        i.putExtra("NBC", NBC);
                        startActivity(i);
                        finish();
*/
                        // continue with delete
                    }
                })

                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void showAlertSuccess(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setCancelable(false)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (gbData.isConnected(getApplicationContext())) {
                            CallKYClistAPI objcurrrencyAPI = new CallKYClistAPI();
                            objcurrrencyAPI.execute(CommonApi.GETKYCLIST);
                        }
                    }
                })

                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }


    public class CallDeleteKYCAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    Log.e("response", strResponse);
                    JSONArray jsonArray;
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        CallKYClistAPI objcurrrencyAPI = new CallKYClistAPI();
                        objcurrrencyAPI.execute(CommonApi.GETKYCLIST);
                        //showAlertSuccess(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                        showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    }
                } catch (JSONException e) {
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "No data received from server. Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";
                }
            } else
                showAlert(getResources().getString(R.string.app_name), Error_Message);

            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.DELETEKYC);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("KYCId", kycdoctypeid);

                    // Log.e("params",postDataParams.toString());
                    byte[] auth = (iUserId + ":" + strtoken).getBytes();

                    String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                    urlConnection.setRequestProperty("Authorization", "Basic " + basic);
                    urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                    urlConnection.setReadTimeout(15000 /* milliseconds */);
                    urlConnection.setConnectTimeout(15000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));
                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();

                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        //Log.e("Result", strResponse);
                    }
                } catch (Exception e) {
                    Log.e("ERROR", e.getMessage(), e);
                    Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
            }

            return null;
        }
    }



}
