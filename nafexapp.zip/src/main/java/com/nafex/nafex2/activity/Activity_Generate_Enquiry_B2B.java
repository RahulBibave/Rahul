package com.nafex.nafex2.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.nafex.nafex2.R;
import com.nafex.nafex2.data.Currency;
import com.nafex.nafex2.data.CurrencyForexCard;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

import static com.github.mikephil.charting.charts.Chart.LOG_TAG;

/**
 * Created by rahul on 13/2/18.
 */

public class Activity_Generate_Enquiry_B2B extends AppCompatActivity implements PlaceSelectionListener, View.OnClickListener, View.OnTouchListener{
    Toolbar toolbar;

    private NavigationView navigationView;
    private static final int REQUEST_SELECT_PLACE = 1000;
    private static final LatLngBounds BOUNDS_MOUNTAIN_VIEW = new LatLngBounds(
            new LatLng(37.398160, -122.180831), new LatLng(37.430610, -121.972090));
    boolean bArea;
    private View navHeader;
    private DrawerLayout drawerLayout;
    private ProgressBar progressBar;
    private LinearLayout llMainView;
    private RelativeLayout rv_currency;
    List<Currency> currencyList;
    private boolean bCurrency;
    private int iCurrency = 0;
    private TextView txtCurrency;
    AppGlobalData gbData;
    CheckBox checkBoxHome_Delivery, checkBoxPick_Up;
    CheckBox checkBuy,checkSell;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id,user_token,branchID;
    private EditText txtQuantity;
    private TextView  b2b_location;
    private RelativeLayout rv_button;
    SharedPreferences sharedpreferencescallrequest;
    public String strlat;
    public String strlong;
    String address;
    double latitude, longitude;

    String requestLat,requestType="1",requestSourceCurrencyId="2",requestTargetCurrencyId,deliveryoption="1",requestTransferCountryId,
    requestLeadSourceId,requestSourceRefId,requestProducts,requestLocation,requestLong,requestPurposeId,requestTransferTypeId;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b2b);
        getSharedPref();
        init();
        checkboxlistner();

        navigationView.inflateMenu(R.menu.menu_ffmc);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

        rv_currency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Log.e("insss",""+currencyList.size());
                if (bCurrency == false) {

                    if (currencyList == null || currencyList.size() <= 0) {
                        if (gbData.isConnected(getApplicationContext())) {
                            bCurrency = true;
                            CallCurrencyAPI objcurrrencyAPI = new CallCurrencyAPI();
                            objcurrrencyAPI.execute(CommonApi.CURRENCY);
                        } else
                            CommonUI.showAlert(Activity_Generate_Enquiry_B2B.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                    } else
                        showCurrencyAlertCustomDialog();
                }
            }
        });


        if (txtQuantity.getText().toString().length() > 0) {
            try {
                JSONArray jArry = new JSONArray();
                JSONObject jObjd = new JSONObject();
                jObjd.put("productTypeId", "2");
                jObjd.put("productQuantity", txtQuantity.getText().toString().trim());
                jArry.put(jObjd);

                Log.e("requestProducts", jArry.toString());
                requestProducts = jArry.toString();

            } catch (JSONException ex) {
                ex.printStackTrace();
            }

        }

        rv_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validation()){
                    if (gbData.isConnected(getApplicationContext())) {
                        CallAddRequestApi objRequestAPI = new CallAddRequestApi();
                        objRequestAPI.execute(CommonApi.REQUEST);
                    }else{
                        CommonUI.showAlert(Activity_Generate_Enquiry_B2B.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                    }
                }


            }
        });
        b2b_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bArea == false) {
                    bArea = true;
                    try {
                        AutocompleteFilter autocompleteFilter = new AutocompleteFilter.Builder()
                                .setTypeFilter(Place.TYPE_COUNTRY)
                                .setCountry("IN")
                                .build();
                        Intent intent = new PlaceAutocomplete.IntentBuilder
                                (PlaceAutocomplete.MODE_OVERLAY)
                                .setFilter(autocompleteFilter)
                                .setBoundsBias(BOUNDS_MOUNTAIN_VIEW)
                                .build(Activity_Generate_Enquiry_B2B.this);
                        startActivityForResult(intent, REQUEST_SELECT_PLACE);

                    } catch (GooglePlayServicesRepairableException |
                            GooglePlayServicesNotAvailableException e) {
                        e.printStackTrace();
                    }

                }
            }
        });
    }


    private void init() {


        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        rv_currency= (RelativeLayout) findViewById(R.id.rv_currency);
        txtCurrency= (TextView) findViewById(R.id.txtCurrency_b2b);
        checkBoxHome_Delivery = (CheckBox) findViewById(R.id.checkHomeDelivery);
        checkBoxPick_Up = (CheckBox) findViewById(R.id.checkPickUp);
        checkBuy= (CheckBox) findViewById(R.id.checkBuy);
        checkSell= (CheckBox) findViewById(R.id.checksell);
        txtQuantity= (EditText) findViewById(R.id.b2b_quantity);
        b2b_location= (TextView) findViewById(R.id.b2b_location);
        b2b_location.setText(requestLocation);
        rv_button= (RelativeLayout) findViewById(R.id.relative_button);
        sharedpreferencescallrequest = getSharedPreferences(ConstantData.REQUESTPREFERENCES, MODE_PRIVATE);


        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        gbData = AppGlobalData.getInstance();

        setUpNavigationView();
    }

    private void checkboxlistner() {
        checkBoxHome_Delivery.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) {
                    //checked
                   // checkBoxHome_Delivery.setChecked(true);
                    deliveryoption="1";
                    if (checkBoxHome_Delivery.isChecked()){
                        checkBoxHome_Delivery.setEnabled(false);
                    }
                    else {
                        checkBoxHome_Delivery.setChecked(true);
                    }

                    if (checkBoxPick_Up.isChecked()) {
                        checkBoxPick_Up.setChecked(false);
                        checkBoxPick_Up.setEnabled(true);

                    }
                } else {
                    //   checkBoxPick_Up.setChecked(false);

                    //not checked
                }
            }
        });

        checkBoxPick_Up.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) {
                    //checked

                   // checkBoxPick_Up.setChecked(true);
                    deliveryoption="2";
                    if (checkBoxPick_Up.isChecked()){
                        checkBoxPick_Up.setEnabled(false);
                    }
                    else {
                        checkBoxPick_Up.setChecked(true);
                    }
                    if (checkBoxHome_Delivery.isChecked()) {
                        checkBoxHome_Delivery.setChecked(false);
                        checkBoxHome_Delivery.setEnabled(true);
                    }
                } else {
                    // checkBoxHome_Delivery.setChecked(false);

                    //not checked
                }
            }
        });

        checkBuy.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) {
                    //checked
                    txtQuantity.setText("");
                    txtCurrency.setText("");
                    txtCurrency.setHint("e.g USD-US Doller");
                    txtQuantity.setHint("e.g 100");

                    requestType="1";
                    requestSourceCurrencyId = "2";
                    requestTargetCurrencyId = Integer.toString(iCurrency);

                    if (checkBuy.isChecked()){
                        checkBuy.setEnabled(false);
                    }
                    else {
                        checkBuy.setChecked(true);
                    }

                    if (checkSell.isChecked()) {
                        checkSell.setChecked(false);
                        checkSell.setEnabled(true);
                    }
                } else {
                    //   checkBoxPick_Up.setChecked(false);

                    //not checked
                }

            }
        });


        checkSell.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) {
                    //checked
                    txtQuantity.setText("");
                    txtCurrency.setText("");
                    txtCurrency.setHint("e.g USD-US Doller");
                    txtQuantity.setHint("e.g 100");

                    requestType="2";
                    requestSourceCurrencyId = Integer.toString(iCurrency);
                    Log.e("requestSourceCurrencyId",""+requestSourceCurrencyId);
                    requestTargetCurrencyId = "2";

                    if (checkSell.isChecked()){
                        compoundButton.setEnabled(false);
                    }
                    else {
                        checkSell.setChecked(true);
                    }
                    if (checkBuy.isChecked()) {
                        checkBuy.setChecked(false);
                        checkBuy.setEnabled(true);
                    }
                } else {
                    // checkBoxHome_Delivery.setChecked(false);

                    //not checked
                }

            }
        });


    }

    public boolean validation(){
          if (iCurrency == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Currency.");
        else if (txtQuantity.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Quantity.");
        else if (Integer.parseInt(txtQuantity.getText().toString()) < 100)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Quantity must be greater than 99. For less quantity please contact Nafex support team.");
          else
              return true;

        return false;
    }


    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_dashboard:
                        Intent intentmain =new Intent(Activity_Generate_Enquiry_B2B.this, activity_ffmcmain.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_enquiries:
                        Intent intentEnquiries=new Intent(Activity_Generate_Enquiry_B2B.this,activity_enquiries.class);
                        startActivity(intentEnquiries);
                        finish();
                        break;
                    case R.id.nav_dispute:
                        Intent intentDispute=new Intent(Activity_Generate_Enquiry_B2B.this,activity_dispute.class);
                        startActivity(intentDispute);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;

                    case R.id.nav_reports:
                        Intent intentReport=new Intent(Activity_Generate_Enquiry_B2B.this,activity_reports.class);
                        startActivity(intentReport);
                        finish();
                        break;
                    case R.id.nav_passbook:
                        Intent intentpassbook=new Intent(Activity_Generate_Enquiry_B2B.this,activity_passbook.class);
                        startActivity(intentpassbook);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_settings:
                        Intent intentSetting=new Intent(Activity_Generate_Enquiry_B2B.this,activity_settings_ffcm.class);
                        startActivity(intentSetting);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_logout:
                       /* ConstantData constantData=new ConstantData();
                        constantData.clearSharedPref(activity_enquiries.this);
                        Intent intent = new Intent(activity_enquiries.this, Activity_main.class);
                        startActivity(intent);
                        finish();*/
                       logoutApplication();

                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


    }



    private void showCurrencyAlertCustomDialog() {
        final Dialog dialog = new Dialog(Activity_Generate_Enquiry_B2B.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bCurrency = false;
            }
        });


       /* if (currencyList != null) {
            currencyListForexCard=new ArrayList<>();

            for (int i=0;i<currencyList.size();i++){
                if (currencyList.get(i).getProductcardoptions().equalsIgnoreCase("Y")){
                    CurrencyForexCard currencyForexCard=new CurrencyForexCard();
                    currencyForexCard.setCurrencyId(currencyList.get(i).getCurrencyId());
                    currencyForexCard.setCurrencyName(currencyList.get(i).getCurrencyName());
                    currencyForexCard.setCurrencyAbbrivation(currencyList.get(i).getCurrencyAbbrivation());
                    currencyForexCard.setCurrencySymbol(currencyList.get(i).getCurrencySymbol());
                    currencyForexCard.setCurrencyOrder(currencyList.get(i).getCurrencyOrder());
                    currencyForexCard.setRbirate(currencyList.get(i).getRbirate());
                    currencyForexCard.setBuyRate(currencyList.get(i).getBuyRate());
                    currencyForexCard.setSellRate(currencyList.get(i).getSellRate());
                    currencyForexCard.setProductcardoptions(currencyList.get(i).getProductcardoptions());
                    currencyListForexCard.add(currencyForexCard);

                }
            }



            if (iProduct==2 ){*/

        ArrayList<String> choices = new ArrayList<>();
        final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_Generate_Enquiry_B2B.this, android.R.layout.select_dialog_singlechoice);
        for (int i = 0; i < currencyList.size(); i++) {
            choices.add(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
            currencyAdapter.add(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_Generate_Enquiry_B2B.this,
                R.layout.currency_list_item_n, R.id.list_item_id, choices);


        listView.setAdapter(adapter);
                /*  ArrayList<String> choices = new ArrayList<>();
                  final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
                  for (int i = 0; i < currenyMonyTransfers.size(); i++) {
                      Log.e("cccc",""+currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                      choices.add(currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                      currencyAdapter.add(currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                  }

                  ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                          R.layout.currency_list_item_n, R.id.list_item_id, choices);


                  listView.setAdapter(adapter);*/

            /*}else {
                ArrayList<String> choices = new ArrayList<>();
                final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
                for (int i = 0; i < currencyListForexCard.size(); i++) {
                    choices.add(currencyListForexCard.get(i).getCurrencyName() + " - " + currencyListForexCard.get(i).getCurrencyAbbrivation());
                    currencyAdapter.add(currencyListForexCard.get(i).getCurrencyName() + " - " + currencyListForexCard.get(i).getCurrencyAbbrivation());
//                    Log.e("11111",""+currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());

                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                        R.layout.currency_list_item_n, R.id.list_item_id, choices);


                listView.setAdapter(adapter);


            }*/



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtCurrency.setText(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
                                                iCurrency = currencyList.get(i).getCurrencyId();
                                                requestTargetCurrencyId = Integer.toString(iCurrency);
                                                bCurrency = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        return false;
    }


    public class CallCurrencyAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showCurrencyAlertCustomDialog();
            else
                CommonUI.showAlert(Activity_Generate_Enquiry_B2B.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForCurrency();
            return "DONE";

        }

        private void CallForCurrency() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CURRENCY);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    currencyList = new ArrayList<Currency>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Currency objCurrency = new Currency();
                        objCurrency.setCurrencyId(jsonObj.getInt("id"));
                        objCurrency.setCurrencyName(jsonObj.getString("currencyName"));
                        objCurrency.setCurrencyAbbrivation(jsonObj.getString("currencyAbbrevation"));
                        objCurrency.setCurrencySymbol(jsonObj.getString("currencySymbol"));
                        objCurrency.setCurrencyOrder(jsonObj.getString("currencyOrder"));
                        objCurrency.setRbirate(jsonObj.getString("rbiRate"));
                        objCurrency.setBuyRate(jsonObj.getString("buyRate"));
                        objCurrency.setSellRate(jsonObj.getString("sellRate"));
                        objCurrency.setProductcardoptions(jsonObj.getString("productCardYesNo"));
                        objCurrency.setProductMoneyTransferOrder(jsonObj.getString("productMoneyTransferOrder"));
                        currencyList.add(objCurrency);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_Generate_Enquiry_B2B.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }




/*
   Call Request Api for application*/


    public class CallAddRequestApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            // if (Error_Message.equalsIgnoreCase("")) {
            String strNBC = "";
            //Log.e("Response: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                Log.e("callrequestres", strResponse);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    JSONObject objmsgtext = objdata.getJSONObject("message_text");
                    int requestid = (int) objmsgtext.get("RequestId");
                    String nbc = (String) objmsgtext.get("NBC");
                   setRequestpref(requestid, nbc);
                   sharedpreferencescallrequest.edit().clear().commit();
                    //call get callrequest
               //     clearallvaluefortype();

                    Intent int_requesttrace = new Intent(Activity_Generate_Enquiry_B2B.this, Activity_requesttrace.class);
                    startActivity(int_requesttrace);
                    finish();


                } else {
                    if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                        CommonUI.showAlert(Activity_Generate_Enquiry_B2B.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    } else {
                        if (objdata.getString("message_code").equalsIgnoreCase("400")) {
                            CommonUI.showAlert(Activity_Generate_Enquiry_B2B.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

                        }
                    }
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_Generate_Enquiry_B2B.this, getResources().getString(R.string.app_name), Error_Message);
            }
           /* } else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.REQUEST);
                urlConnection = (HttpURLConnection) url.openConnection();

                if (txtQuantity.getText().toString().length() > 0) {
                    try {
                        JSONArray jArry = new JSONArray();
                        JSONObject jObjd = new JSONObject();
                        jObjd.put("productTypeId", "2");
                        jObjd.put("productQuantity", txtQuantity.getText().toString().trim());
                        jArry.put(jObjd);

                        Log.e("requestProducts", jArry.toString());
                        requestProducts = jArry.toString();

                    } catch (JSONException ex) {
                        ex.printStackTrace();
                    }

                }

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("requestUserid", user_id);
                postDataParams.put("requestType", requestType);
                if (requestType.equalsIgnoreCase("2")){
                    requestSourceCurrencyId = Integer.toString(iCurrency);
                    requestTargetCurrencyId = "2";
                }
                postDataParams.put("requestSourceCurrencyId", requestSourceCurrencyId);
                postDataParams.put("requestTargetCurrencyId", requestTargetCurrencyId);
                postDataParams.put("deliveryMode", deliveryoption);
                postDataParams.put("requestLeadSourceId", "3");
                postDataParams.put("requestSourceRefId", "5");
                postDataParams.put("requestProducts", requestProducts);
                postDataParams.put("requestLocation", requestLocation);
                postDataParams.put("requestLat", requestLat);
                postDataParams.put("requestLong", requestLong);
                postDataParams.put("requestPurposeId", "0");
                postDataParams.put("requestTransferCountryId", "0");
                postDataParams.put("requestTransferTypeId", "0");


                Log.e("requestUserid", user_id);
                Log.e("requestType", requestType);
                Log.e("requestSourceCurrencyId", requestSourceCurrencyId);
                Log.e("requestTargetCurrencyId", requestTargetCurrencyId);
                Log.e("deliveryMode", deliveryoption);
                Log.e("requestLeadSourceId", "5");
                Log.e("requestSourceRefId", "3");
                Log.e("requestProducts", requestProducts);
                Log.e("requestLocation", requestLocation);
                Log.e("requestLat", requestLat);
                Log.e("requestLong", requestLong);
               // Log.e("requestPurposeId", requestPurposeId);
               // Log.e("requestTransferCountry", requestTransferCountryId);
                //Log.e("requestTransferTypeId", requestTransferTypeId);


                byte[] auth =( user_id + ":" + user_token).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                Log.e("requestUserid", user_id);
                Log.e("strtoken", user_token);


                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000);
                urlConnection.setConnectTimeout(60000);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
               /* if (urlConnection != null)
                    urlConnection.disconnect();*/
            }
            return null;
        }
    }


    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES,MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN,"");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN,"");
        branchID=sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID,"");
        requestLat=sharedpreferences.getString(ConstantData.KEY_FFMC_LAT,"");
        requestLong=sharedpreferences.getString(ConstantData.KEY_FFMC_LONG,"");
        requestLocation=sharedpreferences.getString(ConstantData.KEY_FFMC_AREA,"");


    }

    private void setRequestpref(int requestid, String nbc) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_requestid, requestid);
        editor.putString(ConstantData.KEY_nbc, nbc);
        editor.commit();
    }


    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Activity_Generate_Enquiry_B2B.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(Activity_Generate_Enquiry_B2B.this, Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }



    @Override
    public void onPlaceSelected(Place place) {
        Log.e("lattitude", String.valueOf(place.getLatLng()));
        LatLng queriedLocation = place.getLatLng();
        Log.e("Latitude is", "" + queriedLocation.latitude);
        Log.e("Longitude is", "" + queriedLocation.longitude);
        String city = "", state = "", country = "";
        try {

            Geocoder geocoder;
            List<Address> addresses;
            geocoder = new Geocoder(this, Locale.getDefault());

            addresses = geocoder.getFromLocation(queriedLocation.latitude, queriedLocation.longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            Log.e("Adrrsssssssssss", "" + addresses);

            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append(",");
                }
                address = strReturnedAddress.toString().trim();

                //  Log.w("My Current loction address", strReturnedAddress.toString());
            } else {
                // Log.w("My Current loction address", "No Address returned!");
            }


            // String addres = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            city = addresses.get(0).getLocality();
            state = addresses.get(0).getAdminArea();
            country = addresses.get(0).getCountryName();
            String postalCode = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL
            Log.e("city", city);
            Log.e("state", state);
            Log.e("country", country);
            Log.e("postalCode", postalCode);


            Log.e("location", "Latitude:" + latitude + ", Longitude:" + longitude);

        } catch (Exception e) {
            e.printStackTrace();
        }


        strlat = String.valueOf(queriedLocation.latitude);
        strlong = String.valueOf(queriedLocation.longitude);
        requestLat=strlat;
        requestLong=strlong;
        Log.e("place", place.getAddress().toString());
        Log.e("placename", place.getName().toString());

        String placeDetailsStr = place.getName() + "n"
                + place.getId() + "n"
                + place.getLatLng().toString() + "n"
                + place.getAddress() + "n"

                + place.getAttributions();
        Log.e("placeDetailsStr", placeDetailsStr);
        b2b_location.setText(place.getName() + "," + city + "," + state + "," + country);
        requestLocation = b2b_location.getText().toString().trim();
        // = sAreaString;

    }

    @Override
    public void onError(Status status) {
        Log.e(LOG_TAG, "onError: Status = " + status.toString());
        Toast.makeText(this, "Place selection failed: " + status.getStatusMessage(),
                Toast.LENGTH_SHORT).show();

    }
    /*
     Return method for Startactivityforresult
    */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SELECT_PLACE) {
            bArea = false;
            if (resultCode == RESULT_OK) {
                Place place = PlaceAutocomplete.getPlace(this, data);
                this.onPlaceSelected(place);
            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                this.onError(status);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

}
