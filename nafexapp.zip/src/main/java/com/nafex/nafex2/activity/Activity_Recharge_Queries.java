package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.AdapterDisputeStatus;
import com.nafex.nafex2.data.EnquiryData;
import com.nafex.nafex2.data.HistoryDispute;
import com.nafex.nafex2.data.LeadData;
import com.nafex.nafex2.interfaces.DisputeOperation;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by rahul on 11/10/17.
 */

public class Activity_Recharge_Queries extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout linearTechnical;
    private int status;
    AppGlobalData gbData;
    String user_id, user_token, branchID;
    String enquiryjson;
    int position;
    EditText edtdisputeYourMsg, edtdisputeSubject;
    TextView txt_custName;
    Button btn_submit;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    ProgressDialog progressDialog;
    List<LeadData> justdiallist;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay_generate_dispute_new);
        init();
        getSharedPref();
        status = getIntent().getIntExtra("generate", 0);

        if (status == 3) {
            linearTechnical.setVisibility(View.GONE);

        } else if (status == 2) {
            linearTechnical.setVisibility(View.VISIBLE);
            setData();
        }

       /* CalljustdialLeadAPI objustleadapi =new CalljustdialLeadAPI();
        objustleadapi.execute();*/

    }

    private void setData() {
        enquiryjson = getIntent().getStringExtra("enquiryListGson");
        position = getIntent().getIntExtra("position", 0);
        Type type = new TypeToken<List<EnquiryData>>() {
        }.getType();
        List<EnquiryData> inpList = new Gson().fromJson(enquiryjson, type);
        for (int i = 0; i < inpList.size(); i++) {
            EnquiryData x = inpList.get(position);
            Log.e("name", x.getUserName());
            System.out.println(x);
            txt_custName.setText("NBC " + x.getRequestNBC());
        }

    }

    public class CalljustdialLeadAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           // progressDialog.setMessage("Loading...");
           // progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {
            /*    adapterDisputeStatus=new AdapterDisputeStatus(getActivity(), historydisList, new DisputeOperation() {
                    @Override
                    public void OnRespondclick(String kycId) {

                    }
                });
                mRecyclerView.setAdapter(adapterDisputeStatus);*/
            } else
                CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), Error_Message);
           // progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CalljustdialLead();
            return "DONE";

        }

        private void CalljustdialLead() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.JUSTDIALLEADLIST);
                //  URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + "/jdleadlist");

                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    justdiallist = new ArrayList<LeadData>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        LeadData objleaddata = new LeadData();
                        objleaddata.setId(jsonObj.getString("id"));
                        objleaddata.setLeadId(jsonObj.getString("leadId"));
                        objleaddata.setLeadType(jsonObj.getString("leadType"));
                        objleaddata.setNamePrefix(jsonObj.getString("namePrefix"));
                        objleaddata.setPersonName(jsonObj.getString("personName"));
                        objleaddata.setPersonPhone(jsonObj.getString("personPhone"));
                        objleaddata.setPersonEmail(jsonObj.getString("personEmail"));
                        objleaddata.setLeadDate(jsonObj.getString("leadDate"));
                        objleaddata.setLeadCategory(jsonObj.getString("leadCategory"));
                        objleaddata.setLeadCity(jsonObj.getString("leadCity"));
                        objleaddata.setLeadArea(jsonObj.getString("leadArea"));
                        objleaddata.setLeadBranchArea(jsonObj.getString("leadBranchArea"));
                        objleaddata.setLeadDncMobile(jsonObj.getString("leadDncMobile"));
                        objleaddata.setLeadDncPhone(jsonObj.getString("leadDncPhone"));
                        objleaddata.setLeadCompany(jsonObj.getString("leadCompany"));
                        objleaddata.setLeadPincode(jsonObj.getString("leadPincode"));
                        objleaddata.setLeadTime(jsonObj.getString("leadTime"));
                        objleaddata.setLeadBranchPin(jsonObj.getString("leadBranchPin"));
                        objleaddata.setLeadParentId(jsonObj.getString("leadParentId"));
                        objleaddata.setCreatedOn(jsonObj.getString("createdOn"));
                        objleaddata.setLeadSaveLater(jsonObj.getString("leadSaveLater"));
                        objleaddata.setRequestType(jsonObj.getString("requestType"));
                        objleaddata.setRequestSourceCurrencyId(jsonObj.getString("requestSourceCurrencyId"));
                        objleaddata.setRequestDeliveryMode(jsonObj.getString("requestDeliveryMode"));
                        objleaddata.setRequestLocation(jsonObj.getString("requestLocation"));
                        objleaddata.setRequestProductTypeId(jsonObj.getString("requestProductTypeId"));
                        objleaddata.setRequestQuantity(jsonObj.getString("requestQuantity"));
                        objleaddata.setRequestPurposeId(jsonObj.getString("requestPurposeId"));
                        objleaddata.setRequestCountryId(jsonObj.getString("requestCountryId"));

                        justdiallist.add(objleaddata);
                    }

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
               /* if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in city data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }

    }





    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_submit:
                validationMessage();
                break;

        }
    }
    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }
    public class CallRechargeQueriesAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

          //  if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
                //  showProductAlertCustomDialog();

          /*  } else
                CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), Error_Message);*/

            // progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.SEMDMAIL);

                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("subject", edtdisputeSubject.getText().toString().trim());
                if (txt_custName.getText().toString().equalsIgnoreCase("")) {
                    postDataParams.put("enquiryNumber", "");

                } else {
                    postDataParams.put("enquiryNumber", txt_custName.getText().toString().trim());

                }
                postDataParams.put("message", edtdisputeYourMsg.getText().toString().trim());
                postDataParams.put("disputeTypeId", status);

                byte[] auth = (user_id + ":" + user_token).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
             /*   if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }

    }


    public class CallJustDialSetReminderAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), Error_Message);
                }
                //  showProductAlertCustomDialog();

            } else
                CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), Error_Message);

            // progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.LEADDETREM);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("remLeadId", "12");
                postDataParams.put("remDay", "2");
                postDataParams.put("remDate", "09/12/2017");
                postDataParams.put("remTime", "01:34 AM");
                postDataParams.put("remRemark", "testing");


                byte[] auth = (user_id + ":" + user_token).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }

    }


    public class CallDeleteLeadAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), Error_Message);
                }
                //  showProductAlertCustomDialog();

            } else
                CommonUI.showAlert(Activity_Recharge_Queries.this, getResources().getString(R.string.app_name), Error_Message);

            // progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.LEADDELETE);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("leadId", "1");
                postDataParams.put("reason", "3");
                postDataParams.put("otherReason", "");



                byte[] auth = (user_id + ":" + user_token).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }

    }















    private void init() {
        btn_submit = (Button) findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(this);
        edtdisputeYourMsg = (EditText) findViewById(R.id.edtdisputeYourMsg);
        txt_custName = (TextView) findViewById(R.id.txt_custName);
        edtdisputeSubject = (EditText) findViewById(R.id.edtdisputeSubject);
        linearTechnical = (LinearLayout) findViewById(R.id.linearTechnical);
        gbData = AppGlobalData.getInstance();
        gbData.setStatusBarColor(Activity_Recharge_Queries.this, R.color.colorPrimaryDark);
    }

    public void validationMessage() {
        String strsubject = edtdisputeSubject.getText().toString().trim();
        String strmsg = edtdisputeYourMsg.getText().toString().trim();
        if (strsubject.equalsIgnoreCase("")) {
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter subject.");

        } else {
            if (strmsg.equalsIgnoreCase("")) {
                gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter your message in details.");

            } else {
                if (gbData.isConnected(Activity_Recharge_Queries.this)) {
                    CallRechargeQueriesAPI callDisputeApi = new CallRechargeQueriesAPI();
                    callDisputeApi.execute();


                /*  //worked api for Lead list reminder
                    CallJustDialSetReminderAPI callDisputeApi = new CallJustDialSetReminderAPI();
                    callDisputeApi.execute();
*/

                    //worked api for Lead delete api
                /*    CallDeleteLeadAPI calldelete=new CallDeleteLeadAPI();
                    calldelete.execute();
*/

                   /* Intent int_leads=new Intent(Activity_Recharge_Queries.this,Activity_Leads.class);
                    startActivity(int_leads);*/

                } else {
                    CommonUI.showAlert(Activity_Recharge_Queries.this,getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");

                }
            }
        }

    }


}
