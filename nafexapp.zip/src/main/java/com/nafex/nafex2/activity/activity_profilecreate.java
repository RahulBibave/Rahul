package com.nafex.nafex2.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.Validation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class activity_profilecreate extends AppCompatActivity {

    AppGlobalData gbData;
    Context mContext = activity_profilecreate.this;

    private String sUserName, sUserEmail, sUserMobileNo;
    private EditText txtUserName, txtUserEmail, txtUserMobileNo;
    private int iUserId = -1;

    private RelativeLayout relative_button;
    private ProgressBar progressBar;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profilecreate);

        gbData = AppGlobalData.getInstance();
        init();
    }

    public void init(){
        gbData.setStatusBarColor(activity_profilecreate.this,R.color.colorPrimaryDark);
        txtUserName = (EditText) findViewById(R.id.txtUserName);
        txtUserEmail = (EditText) findViewById(R.id.txtUserEmail);
        txtUserMobileNo = (EditText) findViewById(R.id.txtUserMobileNo);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        relative_button = (RelativeLayout) findViewById(R.id.relative_button);

        relative_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HideKeybaord();
                if (validateData())
                {
                    if (gbData.isConnected(getApplicationContext())) {
                        CallProfileAPI objProfileAPI = new CallProfileAPI();
                        objProfileAPI.execute(ConstantData.PROFILE);
                    }
                    else
                        showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection with internet and try again.");

                }
            }
        });


    }

    private void HideKeybaord() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    private boolean validateData()
    {
        sUserName = txtUserName.getText().toString();
        sUserEmail = txtUserEmail.getText().toString();
        sUserMobileNo = txtUserMobileNo.getText().toString();

        if (sUserName.equalsIgnoreCase(""))
            gbData.showAlert(this,getResources().getString(R.string.app_name) , "Please provide your name.");
        else if (sUserEmail.equalsIgnoreCase(""))
            gbData.showAlert(this,getResources().getString(R.string.app_name) , "Please provide email address.");
        else if (!Validation.isEmailAddress(txtUserEmail, true))
            gbData.showAlert(this,getResources().getString(R.string.app_name) , "Invalid email address. Please enter proper email address.");
        else if (sUserMobileNo.equalsIgnoreCase(""))
            gbData.showAlert(this,getResources().getString(R.string.app_name) , "Please provide mobile number.");
        else if ((sUserMobileNo.length() <10) || (sUserMobileNo.length() >10))
            gbData.showAlert(this,getResources().getString(R.string.app_name) , "Invalid mobile number. Please enter valid mobile number.");
        else
            return true;

        return false;
    }

    public class CallProfileAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {


                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        JSONObject obj = objdata.getJSONObject("data_text");

                        String strId = obj.getString("UserId");

                        setSharedPref(Integer.parseInt(strId));

                        showAlertwithOk(getResources().getString(R.string.app_name),"Profile created successfully!" );

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                        showAlert(getResources().getString(R.string.app_name),objdata.getString("message_text") );
                    }
                }
                catch (JSONException e) {
                    Error_Message = "JSONError: Please contact Nafex support team.";
                    showAlert(getResources().getString(R.string.app_name),Error_Message);
                }
            }
            else
                showAlert(getResources().getString(R.string.app_name),Error_Message);

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {
                try {
                    URL url = new URL( ConstantData.SERVER_URL + ConstantData.BASE_URL + ConstantData.PROFILE);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    try {
                        JSONObject postDataParams = new JSONObject();
                        postDataParams.put("UserId", iUserId);
                        postDataParams.put("UserName", sUserName);
                        postDataParams.put("UserEmail", sUserEmail);
                        postDataParams.put("UserMobileNo", sUserMobileNo);
                        postDataParams.put("AreaString", "Viman Nagar, Pune, Maharashatra, INDIA");

                        //Log.e("params",postDataParams.toString());

                        urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                        urlConnection.setReadTimeout(15000 /* milliseconds */);
                        urlConnection.setConnectTimeout(15000 /* milliseconds */);
                        urlConnection.setDoInput(true);
                        urlConnection.setDoOutput(true);

                        OutputStream os = urlConnection.getOutputStream();
                        BufferedWriter writer = new BufferedWriter(
                                new OutputStreamWriter(os, "UTF-8"));
                        writer.write(gbData.getPostDataString(postDataParams));

                        writer.flush();
                        writer.close();
                        os.close();

                        int responseCode=urlConnection.getResponseCode();

                        if (responseCode == HttpsURLConnection.HTTP_OK) {
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                            StringBuilder stringBuilder = new StringBuilder();
                            String line;
                            while ((line = bufferedReader.readLine()) != null) {
                                stringBuilder.append(line).append("\n");
                            }
                            bufferedReader.close();
                            strResponse = stringBuilder.toString();
                            Log.e("Result", strResponse);
                        }
                    }
                    catch (JSONException e) {
                        Log.e("***Error:", e.getMessage() , e);
                        if (strResponse.equalsIgnoreCase(""))
                            Error_Message = "Please check your network connections.";
                        else
                            Error_Message = "JSONError: Please contact Nafex support team.";
                    }
                    catch (Exception e) {
                        Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                        Log.e("ERROR", e.getMessage(), e);
                    }
                    finally {
                        urlConnection.disconnect();
                    }
                } catch (Exception e) {
                    Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                    Log.e("ERROR", e.getMessage(), e);
                }
            return null;
        }
    }


    private void showAlert(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }

    private void showAlertwithOk(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(activity_profilecreate.this, Activity_main.class);
                        startActivity(i);
                        finish();
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }


    private void setSharedPref(int id) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_USERID, id);
        editor.putString(ConstantData.KEY_USERNAME, sUserName);
        editor.putString(ConstantData.KEY_USEREMAIL, sUserEmail);
        editor.putString(ConstantData.KEY_USERMOBILENO,sUserMobileNo);
        editor.commit();
    }


}



