package com.nafex.nafex2.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.nafex.nafex2.R;
import com.nafex.nafex2.data.City;
import com.nafex.nafex2.data.Country;
import com.nafex.nafex2.data.Currency;
import com.nafex.nafex2.data.CurrencyForexCard;
import com.nafex.nafex2.data.CurrencyMonyTransfer;
import com.nafex.nafex2.data.LocationArea;
import com.nafex.nafex2.data.Product;
import com.nafex.nafex2.data.PurposeType;
import com.nafex.nafex2.data.TransferType;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;
import com.nafex.nafex2.utilities.GPSTracker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;


public class Activity_main extends AppCompatActivity implements PlaceSelectionListener, View.OnClickListener, View.OnTouchListener {

    private static final String LOG_TAG = "Activity_main";
    private NavigationView navigationView, navForCart;
    private DrawerLayout drawerLayout;
    private FrameLayout frameLayoutForNav;
    private RelativeLayout relCity;
    private View navHeader;
    private ImageView imgNafexMenu;
    private TextView txtCurrency, txtCurrencynew;
    private TextView txtCityname;
    private TextView txtArea, txtwhatdo;
    private EditText edtMobileNo, txtQuantity, txtQuantitynew;
    LinearLayout lvBuysell;
    private RadioGroup rdMode;
    private RadioGroup rdType;
    private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 1;
    List<LocationArea> areaList;
    String ismobreg;
    String strtoken;
    ListIterator<Product> iter;
    private String sUserName, sUserEmail, sUserMobileNo;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;

    List<Product> productList;
    List<Product> productListnew;

    List<TransferType> transfertypeList;
    List<PurposeType> purposetypeList;


    List<Currency> currencyList;
    List<CurrencyForexCard>currencyListForexCard;
    List<CurrencyMonyTransfer>currenyMonyTransfers;
    List<Currency> currencyListnew;
    List<Currency> currencyListmoney;

    List<Country> countrylist;


    List<City> cityList;
    CheckBox checkBoxHome_Delivery, checkBoxPick_Up;

    private boolean bCurrency, bArea, bproduct, bCurrencynew, bCurrencymoney, bCountry, btransfertype, bpurposetype, bproductnew;

    private int iCity, iCountry = 0, iArea, iCurrency = 0, iProduct = 0, iQuantity, iCurrencynew = 0, iCurrencymoney = 0, itransfertype = 0, ipurposetype = 0, iProductnew = 0;
    private String sType, sMode, sAreaString;


    private ProgressBar progressBar;
    private LocationManager locationManager;
    AppGlobalData gbData;
    Context mContext = Activity_main.this;
    LinearLayout llMainView;
    Toolbar toolbar;
    RelativeLayout relative_button;
    private Typeface fontHelvetica;
    LinearLayout linearPlus, linearCross, lineraExtended;
    RelativeLayout rProduct, rvCurrency, rvQuantity, rvMobileno, rvArea, rvCurrencyPlus;
    private static final LatLngBounds BOUNDS_MOUNTAIN_VIEW = new LatLngBounds(
            new LatLng(37.398160, -122.180831), new LatLng(37.430610, -121.972090));
    private static final int REQUEST_SELECT_PLACE = 1000;
    private int iUserId;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;

    SharedPreferences sharedpreferencescallrequest;
    SharedPreferences.Editor editorcall;
    String address;
    double latitude, longitude;
    TextView txtproduct;
    public String requestType = "1";
    public String requestSourceCurrencyId;
    public String requestTargetCurrencyId;
    public String deliveryoption;
    public String requestLeadSourceId;
    public String requestSourceRefId;
    public String requestLocation;
    public String requestLocationdetails;
    public String strlat;
    public String strlong;
    public String requestLat;
    public String requestLong;
    public String requestPurposeId;
    public String requestTransferCountryId;
    public String requestTransferTypeId;
    public String requestProducts;
    LinearLayout linearLayoutMoneyTrans,linear_extended;
    private static final int PERMISSION_REQUEST_CODE = 200;
    GPSTracker gps;
    private RelativeLayout layQuantityMoney, layCurrencyMoney, layMobileMoney, layTransferTypeMoney, layCurrencyMoneyTrans, layCountryMoney, layPurposeMoney;
    private ImageView imgQuantityMoney, imgCurrencyMoney, imgTransferTypeMoney, imgPurposeMoney, imgCountryMoney, imgMobileMoney;
    private EditText txtQuantityMoney, txtMobileMoney;
    private TextView txtCurrencyMoney, txtPurposeMoney, txtTransferTypeMoney, txtCountryMoneyTransMoney;
    public int PERMISSIONS_REQUEST_LOCATION_REQUEST_CODE;
    public String strmobnoofuser;

    /*
      Call method Place api
     */
    @Override
    public void onPlaceSelected(Place place) {
        Log.e("lattitude", String.valueOf(place.getLatLng()));
        LatLng queriedLocation = place.getLatLng();
        Log.e("Latitude is", "" + queriedLocation.latitude);
        Log.e("Longitude is", "" + queriedLocation.longitude);
        String city = "", state = "", country = "";
        try {

            Geocoder geocoder;
            List<Address> addresses;
            geocoder = new Geocoder(this, Locale.getDefault());

            addresses = geocoder.getFromLocation(queriedLocation.latitude, queriedLocation.longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            Log.e("Adrrsssssssssss", "" + addresses);

            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append(",");
                }
                address = strReturnedAddress.toString().trim();

                //  Log.w("My Current loction address", strReturnedAddress.toString());
            } else {
                // Log.w("My Current loction address", "No Address returned!");
            }


            // String addres = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            city = addresses.get(0).getLocality();
            state = addresses.get(0).getAdminArea();
            country = addresses.get(0).getCountryName();
            String postalCode = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL
            Log.e("city", city);
            Log.e("state", state);
            Log.e("country", country);
            Log.e("postalCode", postalCode);


            Log.e("location", "Latitude:" + latitude + ", Longitude:" + longitude);
        } catch (Exception e) {
            e.printStackTrace();
        }


        strlat = String.valueOf(queriedLocation.latitude);
        strlong = String.valueOf(queriedLocation.longitude);
        Log.e("place", place.getAddress().toString());
        Log.e("placename", place.getName().toString());

        String placeDetailsStr = place.getName() + "n"
                + place.getId() + "n"
                + place.getLatLng().toString() + "n"
                + place.getAddress() + "n"

                + place.getAttributions();
        Log.e("placeDetailsStr", placeDetailsStr);
        txtArea.setText(place.getName() + "," + city + "," + state + "," + country);
        sAreaString = txtArea.getText().toString().trim();
        requestLocation = sAreaString;

    }

    @Override
    public void onError(Status status) {
        Log.e(LOG_TAG, "onError: Status = " + status.toString());
        Toast.makeText(this, "Place selection failed: " + status.getStatusMessage(),
                Toast.LENGTH_SHORT).show();

    }


    /*
      Return method for Startactivityforresult
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SELECT_PLACE) {
            bArea = false;
            if (resultCode == RESULT_OK) {
                Place place = PlaceAutocomplete.getPlace(this, data);
                this.onPlaceSelected(place);
            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                this.onError(status);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /*
    * Money Transaction initialization
    * */
    private void initMoney() {
        layQuantityMoney = (RelativeLayout) findViewById(R.id.layQuantityMoneyTrans);
        imgQuantityMoney = (ImageView) findViewById(R.id.imgQuantityMoneyTrans);
        txtQuantityMoney = (EditText) findViewById(R.id.txtQuantityMoneyTrans);
        txtQuantitynew = (EditText) findViewById(R.id.edtquantitynew);
        layCurrencyMoney = (RelativeLayout) findViewById(R.id.layCountryMoneyTrans);
        imgCurrencyMoney = (ImageView) findViewById(R.id.imgCurrencyMoneyTrans);
        txtCurrencyMoney = (TextView) findViewById(R.id.txtCurrencyMoneyTrans);
        layMobileMoney = (RelativeLayout) findViewById(R.id.layMobileMoneyTrans);
        imgMobileMoney = (ImageView) findViewById(R.id.imgMobileMoneyTrans);
        txtMobileMoney = (EditText) findViewById(R.id.txtMobileMoneyTrans);
        layTransferTypeMoney = (RelativeLayout) findViewById(R.id.layTransferTypeMoneyTrans);
        imgTransferTypeMoney = (ImageView) findViewById(R.id.imgTransferTypeMoneyTrans);
        txtTransferTypeMoney = (TextView) findViewById(R.id.txtTransferTypeMoneyTrans);
        layPurposeMoney = (RelativeLayout) findViewById(R.id.layPurposeMoneyTrans);
        imgPurposeMoney = (ImageView) findViewById(R.id.imgPurposeMoneyTrans);
        txtPurposeMoney = (TextView) findViewById(R.id.txtPurposeMoneyTrans);
        layCountryMoney = (RelativeLayout) findViewById(R.id.layCountryMoneyTrans);
        imgCountryMoney = (ImageView) findViewById(R.id.imgCountryMoneyTrans);
        txtCountryMoneyTransMoney = (TextView) findViewById(R.id.txtCountryMoneyTrans);
        layCurrencyMoneyTrans = (RelativeLayout) findViewById(R.id.layCurrencyMoneyTrans);

    }


    /*
     Custom typeface of Money transfer
     */
    private void setTypeFaceMoneyTrans() {
        txtQuantityMoney.setTypeface(FontData.setFonts(this, txtQuantityMoney, FontData.font_robotoregular));
        txtMobileMoney.setTypeface(FontData.setFonts(this, txtMobileMoney, FontData.font_robotoregular));
        txtCurrencyMoney.setTypeface(FontData.setFonts(this, txtCurrencyMoney, FontData.font_robotoregular));
        txtPurposeMoney.setTypeface(FontData.setFonts(this, txtPurposeMoney, FontData.font_robotoregular));
        txtCountryMoneyTransMoney.setTypeface(FontData.setFonts(this, txtCountryMoneyTransMoney, FontData.font_robotoregular));
        txtTransferTypeMoney.setTypeface(FontData.setFonts(this, txtTransferTypeMoney, FontData.font_robotoregular));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_n);
        checkAndRequestPermissions();
        globalData();
        getSharedPref();
        initMoney();
        initView();
        clickListnerView();
        setTypeface();
        setTypeFaceMoneyTrans();
        ontouchListner();
        checkboxlistner();


        /*
          Get current location
         */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkPermission()) {

                getLocation();
            } else {
                requestPermission();
            }
        } else {
            getLocation();
        }


        rdType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                txtQuantity.clearFocus();
                switch (checkedId) {
                    case R.id.radioBuy:
                        // do operations specific to this selection
                        Log.e("Buy", "Buy");

                        if (gbData.isConnected(Activity_main.this)) {

                            CallProductAPIinitial objcurrrencyAPI = new CallProductAPIinitial();
                            objcurrrencyAPI.execute(CommonApi.CODELIST);
                        }else {
                            CommonUI.showAlert(Activity_main.this,getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");
                        }

                        linearPlus.setVisibility(View.VISIBLE);
                        lvBuysell.setVisibility(View.VISIBLE);
                        linearLayoutMoneyTrans.setVisibility(View.GONE);
                        sType = "B";
                        requestType = "1";
                        txtproduct.setText(null);
                        txtCurrency.setText(null);
                        txtQuantity.setText(null);
                        txtArea.setText(null);
                        if (iUserId == -1) {
                            edtMobileNo.setText(null);
                        }
                        iProduct = 0;
                        iCurrency = 0;
                        iQuantity = 0;

                        break;
                    case R.id.radioSale:
                        if (gbData.isConnected(Activity_main.this)) {
                            CallProductAPIinitial objcurrrencyAPIs = new CallProductAPIinitial();
                            objcurrrencyAPIs.execute(CommonApi.CODELIST);
                        }else {
                            CommonUI.showAlert(Activity_main.this,getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");

                        }
                        // do operations specific to this selection
                        Log.e("Sale", "Sale");
                        lvBuysell.setVisibility(View.VISIBLE);
                        linearLayoutMoneyTrans.setVisibility(View.GONE);
                        linearPlus.setVisibility(View.GONE);
                        sType = "S";
                        requestType = "2";
                        lineraExtended.setVisibility(View.GONE);
                        txtproduct.setText(null);
                        txtCurrency.setText(null);
                        txtQuantity.setText(null);
                        txtArea.setText(null);
                        if (iUserId == -1) {

                            edtMobileNo.setText(null);
                        }
                        iProduct = 0;
                        iProductnew = 0;
                        txtCurrencynew.setText(null);
                        iCurrency = 0;
                        iQuantity = 0;
                        break;
                    case R.id.radioMoneyTransfer:
                        // do operations specific to this selection
                        requestType = "3";
                        linearLayoutMoneyTrans.setVisibility(View.VISIBLE);
                        lvBuysell.setVisibility(View.GONE);
                        if (iUserId == -1) {

                            txtMobileMoney.setText(null);
                        }

                        iProduct=0;
                        txtQuantityMoney.setText(null);
                        iCurrencymoney = 0;
                        txtCurrencyMoney.setText(null);
                        itransfertype = 0;
                        txtTransferTypeMoney.setText(null);
                        ipurposetype = 0;
                        txtPurposeMoney.setText(null);
                        iCountry = 0;
                        txtCountryMoneyTransMoney.setText(null);


                        Log.e("Money transfer", "Money Transfer");
                        sType = "M";
                        break;


                }
            }
        });


    }


    /*
     Getting Current Location using GPSTracker
     */
    public void getLocation() {
        gps = new GPSTracker(Activity_main.this);
        // check if GPS enabled
        if (gps.canGetLocation()) {
            try {
                latitude = gps.getLatitude();
                longitude = gps.getLongitude();
                Geocoder geocoder;
                List<Address> addresses;
                geocoder = new Geocoder(this, Locale.getDefault());

                addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                Log.e("Adrrsssssssssss", "" + addresses);

                if (addresses != null) {
                    Address returnedAddress = addresses.get(0);
                    StringBuilder strReturnedAddress = new StringBuilder("");

                    for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                        strReturnedAddress.append(returnedAddress.getAddressLine(i)).append(",");
                    }
                    address = strReturnedAddress.toString().trim();

                    //  Log.w("My Current loction address", strReturnedAddress.toString());
                } else {
                    // Log.w("My Current loction address", "No Address returned!");
                }


                // String addres = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                String city = addresses.get(0).getLocality();
                String state = addresses.get(0).getAdminArea();
                String country = addresses.get(0).getCountryName();
                String postalCode = addresses.get(0).getPostalCode();
                String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL

                Log.e("location", "Latitude:" + latitude + ", Longitude:" + longitude);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gps.showSettingsAlert();
        }
    }


    /*
     Code for delivery type selection for Request
     */
    private void checkboxlistner() {
        checkBoxHome_Delivery.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) {
                    //checked
                  //  checkBoxHome_Delivery.setChecked(true);


                    if (checkBoxHome_Delivery.isChecked()){
                        checkBoxHome_Delivery.setEnabled(false);
                    }
                    else {
                        checkBoxHome_Delivery.setChecked(true);
                    }


                    if (checkBoxPick_Up.isChecked()) {
                        checkBoxPick_Up.setChecked(false);
                        checkBoxPick_Up.setEnabled(true);
                    }
                } else {
                    //   checkBoxPick_Up.setChecked(false);

                    //not checked
                }
            }
        });

        checkBoxPick_Up.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) {
                    //checked


                    if(checkBoxPick_Up.isChecked()){
                        checkBoxPick_Up.setEnabled(false);
                    }
                    else {
                        checkBoxPick_Up.setChecked(true);
                    }
                    if (checkBoxHome_Delivery.isChecked()) {
                        checkBoxHome_Delivery.setChecked(false);
                        checkBoxHome_Delivery.setEnabled(true);
                    }
                } else {
                    // checkBoxHome_Delivery.setChecked(false);

                    //not checked
                }
            }
        });


    }


    /*
     check permission granted by user
     */
    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), ACCESS_FINE_LOCATION);
        return result == PackageManager.PERMISSION_GRANTED;
    }


    /*
     Request Permission for android 6.0 >
     */
    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, PERMISSION_REQUEST_CODE);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                    if (locationAccepted) {
                        getLocation();
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(ACCESS_FINE_LOCATION)) {
                                showMessageOKCancel("You need to allow access to both the permissions",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(new String[]{ACCESS_FINE_LOCATION},
                                                            PERMISSION_REQUEST_CODE);
                                                }
                                            }
                                        });
                                return;
                            }
                        }
                    }
                }


                break;
        }
    }


    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(Activity_main.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    /*
     validation for request api for user
     */
    public void validationofAction() {
        if (sType.equalsIgnoreCase("B")) {
            requestType = "1";
            requestSourceCurrencyId = "2";
            requestTargetCurrencyId = Integer.toString(iCurrency);

            if (checkBoxHome_Delivery.isChecked()) {
                deliveryoption = "1";
            } else {
                if (checkBoxPick_Up.isChecked())

                {
                    deliveryoption = "2";

                }

            }
            requestLeadSourceId = "12";
            if(sharedpreferences.getString(ConstantData.KEY_userRoleId, "").equalsIgnoreCase("8")){
                requestSourceRefId = "9";
            }
            else {
                requestSourceRefId = "1";
            }

            requestLocationdetails = requestLocation;
            requestLat = strlat;
            requestLong = strlong;
            requestPurposeId = "0";
            requestTransferCountryId = "0";
            requestTransferTypeId = "0";

            if (txtQuantitynew.getText().toString().length() > 0 && txtQuantity.getText().toString().length() > 0) {
                try {
                    JSONArray jArry = new JSONArray();
                    JSONObject jObjd = new JSONObject();
                    jObjd.put("productTypeId", iProduct);
                    jObjd.put("productQuantity", txtQuantity.getText().toString().trim());
                    Log.e("ppppp",""+iProduct);

                    jArry.put(jObjd);

                    JSONObject jObj2 = new JSONObject();

                    jObj2.put("productTypeId", iProductnew);
                    jObj2.put("productQuantity", txtQuantitynew.getText().toString().trim());
                    jArry.put(jObj2);


                    Log.e("requestProducts", jArry.toString());
                    requestProducts = jArry.toString();

                } catch (JSONException ex) {
                    ex.printStackTrace();
                }
            } else {

                if (txtQuantity.getText().toString().length() > 0) {
                    try {
                        JSONArray jArry = new JSONArray();
                        JSONObject jObjd = new JSONObject();
                        jObjd.put("productTypeId", iProduct);
                        Log.e("ppppp",""+iProduct);
                        jObjd.put("productQuantity", txtQuantity.getText().toString().trim());
                        jArry.put(jObjd);

                        Log.e("requestProducts", jArry.toString());
                        requestProducts = jArry.toString();

                    } catch (JSONException ex) {
                        ex.printStackTrace();
                    }

                }
            }


            setSharedPrefforBuyAndSell("", requestType, requestSourceCurrencyId, requestTargetCurrencyId, deliveryoption, requestLeadSourceId, requestSourceRefId, requestProducts, requestLocation, requestLat, requestLong, requestPurposeId, requestTransferCountryId, requestTransferTypeId);

        } else {
            if (sType.equalsIgnoreCase("S")) {
                requestType = "2";
                requestSourceCurrencyId = Integer.toString(iCurrency);
                requestTargetCurrencyId = "2";
                if (checkBoxHome_Delivery.isChecked()) {
                    deliveryoption = "1";
                } else {
                    if (checkBoxPick_Up.isChecked())

                    {
                        deliveryoption = "2";

                    }

                }
                requestLeadSourceId = "12";
                if(sharedpreferences.getString(ConstantData.KEY_userRoleId, "").equalsIgnoreCase("8")){
                    requestSourceRefId = "9";
                }
                else {
                    requestSourceRefId = "1";
                }
                requestLocationdetails = requestLocation;
                requestLat = strlat;
                requestLong = strlong;
                requestPurposeId = "0";
                requestTransferCountryId = "0";
                requestTransferTypeId = "0";
                if (txtQuantity.getText().toString().length() > 0) {
                    try {
                        JSONArray jArry = new JSONArray();
                        JSONObject jObjd = new JSONObject();
                        jObjd.put("productTypeId", iProduct);
                        Log.e("ppppp",""+iProduct);
                        jObjd.put("productQuantity", txtQuantity.getText().toString().trim());
                        jArry.put(jObjd);

                        Log.e("requestProducts", jArry.toString());
                        requestProducts = jArry.toString();

                    } catch (JSONException ex) {
                        ex.printStackTrace();
                    }

                }

                setSharedPrefforBuyAndSell("", requestType, requestSourceCurrencyId, requestTargetCurrencyId, deliveryoption, requestLeadSourceId, requestSourceRefId, requestProducts, requestLocation, requestLat, requestLong, requestPurposeId, requestTransferCountryId, requestTransferTypeId);

            } else {
                if (sType.equalsIgnoreCase("M")) {

                    requestType = "3";
                    requestSourceCurrencyId = "2";
                    requestTargetCurrencyId = Integer.toString(iCurrencymoney);
                    deliveryoption = "0";
                    requestLeadSourceId = "12";
                    if(sharedpreferences.getString(ConstantData.KEY_userRoleId, "").equalsIgnoreCase("8")){
                        requestSourceRefId = "9";
                    }
                    else {
                        requestSourceRefId = "1";
                    }
                    requestLocation = address;
                    requestLat = Double.toString(latitude);
                    requestLong = Double.toString(longitude);

                    if (txtQuantityMoney.getText().toString().length() > 0) {
                        try {
                            JSONArray jArry = new JSONArray();
                            JSONObject jObjd = new JSONObject();
                            jObjd.put("productTypeId", "2");
                            jObjd.put("productQuantity", txtQuantityMoney.getText().toString().trim());
                            jArry.put(jObjd);

                            Log.e("requestProducts", jArry.toString());
                            requestProducts = jArry.toString();

                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }

                    }


                    requestPurposeId = Integer.toString(ipurposetype);
                    requestTransferCountryId = Integer.toString(iCountry);
                    requestTransferTypeId = Integer.toString(itransfertype);
                    setSharedPrefforBuyAndSell("", requestType, requestSourceCurrencyId, requestTargetCurrencyId, deliveryoption, requestLeadSourceId, requestSourceRefId, requestProducts, requestLocation, requestLat, requestLong, requestPurposeId, requestTransferCountryId, requestTransferTypeId);

                }
            }
        }
        Log.e("requestType", requestType);
        Log.e("requestSourceCurrencyId", requestSourceCurrencyId);
        Log.e("requestTargetCurrencyId", requestTargetCurrencyId);

        //  Log.e("deliveryoption", deliveryoption);
        Log.e("requestLeadSourceId", requestLeadSourceId);
        Log.e("requestSourceRefId", requestSourceRefId);
        Log.e("requestLocationdetails", requestLocation);
        Log.e("requestLat", requestLat);
        Log.e("requestLong", requestLong);
        Log.e("requestPurposeId", requestPurposeId);
        Log.e("requestTransferCou", requestTransferCountryId);
        Log.e("requestTransferTypeId", requestTransferTypeId);
        Log.e("requestProducts", requestProducts);

    }


    /*
     Touchlistner for views
     */
    private void ontouchListner() {
        txtCurrency.setOnTouchListener(this);
        txtArea.setOnTouchListener(this);
        rvArea.setOnTouchListener(this);
        rProduct.setOnTouchListener(this);
        txtproduct.setOnTouchListener(this);
        rvCurrency.setOnTouchListener(this);
        txtCurrencynew.setOnTouchListener(this);
        rvCurrencyPlus.setOnTouchListener(this);
        rvMobileno.setOnTouchListener(this);
        rvQuantity.setOnTouchListener(this);
        txtCountryMoneyTransMoney.setOnTouchListener(this);
        layCurrencyMoney.setOnTouchListener(this);
        txtTransferTypeMoney.setOnTouchListener(this);
        layTransferTypeMoney.setOnTouchListener(this);
        txtPurposeMoney.setOnTouchListener(this);
        layPurposeMoney.setOnTouchListener(this);
        layCurrencyMoney.setOnTouchListener(this);
        txtCountryMoneyTransMoney.setOnTouchListener(this);
        layCurrencyMoneyTrans.setOnTouchListener(this);

    }

    /*
     Custom Typeface for views
     */
    private void setTypeface() {
        txtCityname.setTypeface(FontData.setFonts(Activity_main.this, txtCityname, FontData.font_robotolight));
        txtwhatdo.setTypeface(FontData.setFonts(Activity_main.this, txtwhatdo, FontData.font_robotolight));
        checkBoxPick_Up.setTypeface(FontData.setFonts(Activity_main.this, checkBoxPick_Up, FontData.font_robotomedium));
        checkBoxHome_Delivery.setTypeface(FontData.setFonts(Activity_main.this, checkBoxPick_Up, FontData.font_robotomedium));
    }

    /*
    Clicklistner for views
    */
    private void clickListnerView() {
        relative_button.setOnClickListener(this);
        relCity.setOnClickListener(this);
        linearPlus.setOnClickListener(this);
        linearCross.setOnClickListener(this);
        checkBoxHome_Delivery.setOnClickListener(this);
        checkBoxPick_Up.setOnClickListener(this);


    }

    /*
     set global data for main screen
     */
    private void globalData() {
        gbData = AppGlobalData.getInstance();
        iCountry = 1;
        iCity = 1;
        iArea = 1;
        sMode = "D";
        sType = "B";
        bCurrency = false;
        bCountry = false;
        bArea = false;
        bproduct = false;
        bproductnew = false;
        bCurrencynew = false;
        bCurrencymoney = false;
        btransfertype = false;
        bpurposetype = false;


    }


    /*
     initilialization of views
     */
    public void initView() {
        rProduct = (RelativeLayout) findViewById(R.id.rv_product);
        rvCurrency = (RelativeLayout) findViewById(R.id.rv_currency);
        rvQuantity = (RelativeLayout) findViewById(R.id.rv_quantity);
        rvArea = (RelativeLayout) findViewById(R.id.rv_area);
        rvMobileno = (RelativeLayout) findViewById(R.id.rv_mobileno);
        rvCurrencyPlus = (RelativeLayout) findViewById(R.id.rv_currencyplus);
        lvBuysell = (LinearLayout) findViewById(R.id.lv_buysell);
        linearLayoutMoneyTrans = (LinearLayout) findViewById(R.id.linearLayoutMoneyTrans);
        txtproduct = (TextView) findViewById(R.id.txtproduct);
        gbData.setStatusBarColor(Activity_main.this, R.color.colorPrimaryDark);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        relative_button = (RelativeLayout) findViewById(R.id.relative_button);
        relCity = (RelativeLayout) findViewById(R.id.relCity);
        txtCurrency = (TextView) findViewById(R.id.txtCurrency);
        txtCurrencynew = (TextView) findViewById(R.id.txtcurrencynew);
        txtCityname = (TextView) findViewById(R.id.txtCityname);
        txtArea = (TextView) findViewById(R.id.txtArea);
        edtMobileNo = (EditText) findViewById(R.id.txtMobileno);
        txtwhatdo = (TextView) findViewById(R.id.txt_whatdo);
        txtQuantity = (EditText) findViewById(R.id.txtQuantity);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        rdType = (RadioGroup) findViewById(R.id.radioGroup1);
        linearPlus = (LinearLayout) findViewById(R.id.linear_plus);
        linearCross = (LinearLayout) findViewById(R.id.linear_cross);
        lineraExtended = (LinearLayout) findViewById(R.id.linear_extended);
        checkBoxHome_Delivery = (CheckBox) findViewById(R.id.checkHomeDelivery);
        checkBoxPick_Up = (CheckBox) findViewById(R.id.checkPickUp);
        linear_extended= (LinearLayout) findViewById(R.id.linear_extended);

        setSupportActionBar(toolbar);

        if (gbData.isConnected(getApplicationContext())) {
            CallCityAPI objcityAPI = new CallCityAPI();
            objcityAPI.execute(CommonApi.CITY);
        } else
            CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");


        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        ismobreg = sharedpreferences.getString(ConstantData.KEY_USERMOBILENO, "");
        strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");
        if (!ismobreg.equalsIgnoreCase("")) {
            edtMobileNo.setText(ismobreg);
            txtMobileMoney.setText(ismobreg);
//            txtMobileMoney.setText(ismobreg);
        }

        sharedpreferencescallrequest = getSharedPreferences(ConstantData.REQUESTPREFERENCES, MODE_PRIVATE);


        if (iUserId == -1) {
            navigationView.inflateMenu(R.menu.menu_customer_new);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

            setUpNavigationViewNewUser();
        } else {
            navigationView.inflateMenu(R.menu.menu_customer);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);
            setUpNavigationView();
        }

    }


    /*
     Navigationview for New user
    */
    private void setUpNavigationViewNewUser() {
        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
//                        Intent intentmain =new Intent(Activity_main.this, Activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_signIn:
                    /*    Intent intenthistory = new Intent(Activity_main.this, Activity_login.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        CommonUI.setStrregtype("self");
                        startActivity(intenthistory);*/
                       // logoutApplication();

                        Intent intenthistory = new Intent(Activity_main.this, Activity_otpdashboard.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        editor = sharedpreferences.edit();
                        editor.putString(ConstantData.ISLEFTLOGIN, "true");
                        editor.commit();
                        startActivity(intenthistory);
                        finish();

                        break;

                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


    }


    private boolean validateData() {
        String str = "";

        if (sType.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select you would like to Buy or Sell.");
        else if (iCity == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select city.");
        else if (iQuantity < 100)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Quantity must be greater than 99. For less quantity please contact Nafex support team.");
        else if (iCurrency == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select currency which you want to Buy/Sell.");
//        else if (iArea == 0)
//            gbData.showAlert(this,getResources().getString(R.string.app_name) , "Please select your area for the transaction.");
        else if (sAreaString == null || sAreaString.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select your area for the transaction.");
        else if (sMode.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select you would like Home Delivery or Pickup.");
        else
            return true;

        return false;
    }


    /*
     validation for Buy
     */
    public boolean validateBuy() {
        if (sType.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select you would like to Buy or Sell.");
        else if (iProduct == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Product.");
        else if (iCurrency == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Currency.");
        else if (txtQuantity.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Quantity.");
        else if (Integer.parseInt(txtQuantity.getText().toString()) < 100)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Quantity must be greater than 99. For less quantity please contact Nafex support team.");
        else if (txtArea.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Area.");
        else if (edtMobileNo.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Mobile number.");
        else if ((edtMobileNo.getText().toString().length() < 10) || (edtMobileNo.getText().toString().length() > 10))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid mobile number. Please enter valid mobile number.");
        else if ((!checkBoxPick_Up.isChecked()) && (!checkBoxHome_Delivery.isChecked()))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Delivery type.");
        else if (lineraExtended.getVisibility() == View.VISIBLE) {
            if (txtQuantitynew.getText().toString().equalsIgnoreCase(""))
                gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Quantity.");
            else if (Integer.parseInt(txtQuantitynew.getText().toString()) < 100)
                gbData.showAlert(this, getResources().getString(R.string.app_name), "Quantity must be greater than 99. For less quantity please contact Nafex support team.");
            else
                return true;
        } else
            return true;

        return false;
    }

    /*
     validation for money transfer
     */
    public boolean validateMoneyTransfer() {
        if (sType.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select you would like to Buy or Sell.");
        else if (txtQuantityMoney.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Quantity.");
        else if (Integer.parseInt(txtQuantityMoney.getText().toString()) < 100)
              gbData.showAlert(this, getResources().getString(R.string.app_name), "Quantity must be greater than 99. For less quantity please contact Nafex support team.");
        else if (Integer.parseInt(txtQuantityMoney.getText().toString()) < 1)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter quantity greater than 0.");
        else if (iCurrencymoney == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Currency.");
        else if (txtMobileMoney.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Mobile number.");
        else if ((txtMobileMoney.getText().toString().length() < 10) || (txtMobileMoney.getText().toString().length() > 10))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid mobile number. Please enter valid mobile number.");
        else if (itransfertype == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Transfer type.");
        else if (ipurposetype == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Purpose type.");
        else if (iCountry == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Country.");
        else
            return true;

        return false;
    }


    /*
     validation for sell
     */
    public boolean validateSell() {
        if (sType.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select you would like to Buy or Sell.");
        else if (iProduct == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Product.");
        else if (iCurrency == 0)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Currency.");
        else if (txtQuantity.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Quantity.");
        else if (Integer.parseInt(txtQuantity.getText().toString()) < 100)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Quantity must be greater than 99. For less quantity please contact Nafex support team.");
        else if (Integer.parseInt(txtQuantity.getText().toString()) < 1)
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Quantity greater than 1.");
        else if (txtArea.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Area.");
        else if (edtMobileNo.getText().toString().equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Mobile number.");
        else if ((edtMobileNo.getText().toString().length() < 10) || (edtMobileNo.getText().toString().length() > 10))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid mobile number. Please enter valid mobile number.");
        else if ((!checkBoxPick_Up.isChecked()) && (!checkBoxHome_Delivery.isChecked()))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please select Delivery type.");

        else
            return true;

        return false;
    }


    /*
     navigation view for old user
     */
    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
//                        Intent intentmain =new Intent(Activity_main.this, Activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_trackorder:
                        Intent intenthistory = new Intent(Activity_main.this, Activity_history.class);
                        intenthistory.putExtra("Source", "");
                        startActivity(intenthistory);
                        finish();
                        break;
                    case R.id.nav_profile:
                        Intent intentprofile = new Intent(Activity_main.this, Activity_profile.class);
                        startActivity(intentprofile);
                        finish();
                        break;

                    case R.id.NBC_Details:
                        Intent intentNBC = new Intent(Activity_main.this, Activity_KycList_NBC.class);
                        startActivity(intentNBC);
                        finish();
                        break;
                    case R.id.nav_kyc:
                        Intent intentkyc = new Intent(Activity_main.this, Activity_Kyc_Listing_Menu.class);
                        startActivity(intentkyc);
                        finish();
                        break;
                    case R.id.nav_signout:

                        if (gbData.isConnected(Activity_main.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }
                       //logoutApplication();

                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }

    /*
     logout for main screens
     */
    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Activity_main.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(Activity_main.this, Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }


    /*
      Dialog code to shows country
     */
    private void showCountryAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setText("Select Country");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bCountry = false;
            }
        });


        if (countrylist != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < countrylist.size(); i++) {
                choices.add(countrylist.get(i).getCountryname());
                currencyAdapter.add(countrylist.get(i).getCountryname());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtCountryMoneyTransMoney.setText(countrylist.get(i).getCountryname());
                                                iCountry = Integer.parseInt(countrylist.get(i).getCountryid());
                                                bCountry = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    /*
     Dialog code to shows Currency for Buy and Sell
     */
    private void showCurrencyAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bCurrency = false;
            }
        });


        if (currencyList != null) {
            currencyListForexCard=new ArrayList<>();

            for (int i=0;i<currencyList.size();i++){
                if (currencyList.get(i).getProductcardoptions().equalsIgnoreCase("Y")){
                    CurrencyForexCard currencyForexCard=new CurrencyForexCard();
                    currencyForexCard.setCurrencyId(currencyList.get(i).getCurrencyId());
                    currencyForexCard.setCurrencyName(currencyList.get(i).getCurrencyName());
                    currencyForexCard.setCurrencyAbbrivation(currencyList.get(i).getCurrencyAbbrivation());
                    currencyForexCard.setCurrencySymbol(currencyList.get(i).getCurrencySymbol());
                    currencyForexCard.setCurrencyOrder(currencyList.get(i).getCurrencyOrder());
                    currencyForexCard.setRbirate(currencyList.get(i).getRbirate());
                    currencyForexCard.setBuyRate(currencyList.get(i).getBuyRate());
                    currencyForexCard.setSellRate(currencyList.get(i).getSellRate());
                    currencyForexCard.setProductcardoptions(currencyList.get(i).getProductcardoptions());
                    currencyListForexCard.add(currencyForexCard);

                }
            }



              if (iProduct==2 ){

                ArrayList<String> choices = new ArrayList<>();
                final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
                for (int i = 0; i < currencyList.size(); i++) {
                    choices.add(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
                    currencyAdapter.add(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                        R.layout.currency_list_item_n, R.id.list_item_id, choices);


                listView.setAdapter(adapter);
                /*  ArrayList<String> choices = new ArrayList<>();
                  final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
                  for (int i = 0; i < currenyMonyTransfers.size(); i++) {
                      Log.e("cccc",""+currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                      choices.add(currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                      currencyAdapter.add(currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                  }

                  ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                          R.layout.currency_list_item_n, R.id.list_item_id, choices);


                  listView.setAdapter(adapter);*/

            }else {
                  ArrayList<String> choices = new ArrayList<>();
                final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
                for (int i = 0; i < currencyListForexCard.size(); i++) {
                    choices.add(currencyListForexCard.get(i).getCurrencyName() + " - " + currencyListForexCard.get(i).getCurrencyAbbrivation());
                    currencyAdapter.add(currencyListForexCard.get(i).getCurrencyName() + " - " + currencyListForexCard.get(i).getCurrencyAbbrivation());
//                    Log.e("11111",""+currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());

                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                        R.layout.currency_list_item_n, R.id.list_item_id, choices);


                listView.setAdapter(adapter);


            }


        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtCurrency.setText(currencyList.get(i).getCurrencyName() + " - " + currencyList.get(i).getCurrencyAbbrivation());
                                                iCurrency = currencyList.get(i).getCurrencyId();
                                                bCurrency = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    /*
     Dialog code to show Currency for Money transfer
     */
    private void showCurrencyAlertCustomDialogMoney() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bCurrencymoney = false;
            }
        });


        if (currencyListmoney != null) {

            currenyMonyTransfers=new ArrayList<>();
            for (int i=0;i<currencyListmoney.size();i++){
                if (!currencyListmoney.get(i).getProductMoneyTransferOrder().equalsIgnoreCase("0")){
                    CurrencyMonyTransfer currencyMonyTrans=new CurrencyMonyTransfer();
                    currencyMonyTrans.setCurrencyId(currencyListmoney.get(i).getCurrencyId());
                    currencyMonyTrans.setCurrencyName(currencyListmoney.get(i).getCurrencyName());
                    currencyMonyTrans.setCurrencyAbbrivation(currencyListmoney.get(i).getCurrencyAbbrivation());
                    currencyMonyTrans.setCurrencySymbol(currencyListmoney.get(i).getCurrencySymbol());
                    currencyMonyTrans.setCurrencyOrder(currencyListmoney.get(i).getCurrencyOrder());
                    currencyMonyTrans.setRbirate(currencyListmoney.get(i).getRbirate());
                    currencyMonyTrans.setBuyRate(currencyListmoney.get(i).getBuyRate());
                    currencyMonyTrans.setSellRate(currencyListmoney.get(i).getSellRate());
                    currencyMonyTrans.setProductcardoptions(currencyListmoney.get(i).getProductcardoptions());
                    currenyMonyTransfers.add(currencyMonyTrans);

                }
            }

            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < currenyMonyTransfers.size(); i++) {
                choices.add(currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                currencyAdapter.add(currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);

           /* ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < currenyMonyTransfers.size(); i++) {
                Log.e("cccc",""+currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                choices.add(currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
                currencyAdapter.add(currenyMonyTransfers.get(i).getCurrencyName() + " - " + currenyMonyTransfers.get(i).getCurrencyAbbrivation());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);*/
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtCurrencyMoney.setText(currencyListmoney.get(i).getCurrencyName() + " - " + currencyListmoney.get(i).getCurrencyAbbrivation());
                                                iCurrencymoney = currencyListmoney.get(i).getCurrencyId();
                                                bCurrencymoney = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    private void showCurrencyAlertCustomDialogNew() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bCurrencynew = false;
            }
        });


        if (currencyListnew != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < currencyListnew.size(); i++) {
                choices.add(currencyListnew.get(i).getCurrencyAbbrivation() + " - " + currencyListnew.get(i).getCurrencyName());
                currencyAdapter.add(currencyListnew.get(i).getCurrencyAbbrivation() + " - " + currencyListnew.get(i).getCurrencyName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtCurrencynew.setText(currencyListnew.get(i).getCurrencyAbbrivation() + " - " + currencyListnew.get(i).getCurrencyName());
                                                iCurrencynew = currencyListnew.get(i).getCurrencyId();
                                                bCurrencynew = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    /*
     Dialog to shows City
     */
    private void showCityAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout);
        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.TOP | Gravity.RIGHT;

        wlp.width = LinearLayout.LayoutParams.MATCH_PARENT;
        wlp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        window.setAttributes(wlp);

        TextView txtAlertTitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        TextView txtAlertSubTitle = (TextView) dialog.findViewById(R.id.txtAlertSubTitle);
        txtAlertTitle.setText("Select City");
        txtAlertSubTitle.setText("In which city you are situated!");

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {

            }
        });

        if (cityList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> cityAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            cityList.get(0).setCityName("Select City");
            for (int i = 0; i < cityList.size(); i++) {
                choices.add(cityList.get(i).getCityName());
                cityAdapter.add(cityList.get(i).getCityName());
            }


            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item, R.id.list_item_id, choices);

            listView.setAdapter(adapter);
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtCityname.setText(cityList.get(i).getCityName());
                                                iCity = cityList.get(i).getCityId();
                                                Log.e("cityid", Integer.toString(iCity));
                                                dialog.dismiss();
                                                if (gbData.isConnected(getApplicationContext())) {
//                        CallAreaAPI objAreaAPI = new CallAreaAPI();
//                        objAreaAPI.execute(ConstantData.AREA);
                                                } else
                                                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                                            }
                                        }
        );
        dialog.show();
      /*  Window window1 = dialog.getWindow();
        window1.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);*/
    }

    private void showAreaAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.currency_alert_dialog_layout);
        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);
        TextView txtAlertTitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        TextView txtAlertSubTitle = (TextView) dialog.findViewById(R.id.txtAlertSubTitle);
        txtAlertTitle.setText("Select Area");
        txtAlertSubTitle.setText("");

        if (areaList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> areaAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < areaList.size(); i++) {
                choices.add(areaList.get(i).getAreaName());
                areaAdapter.add(areaList.get(i).getAreaName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item, R.id.list_item_id, choices);

            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtArea.setText(areaList.get(i).getAreaName());
                                                bArea = false;
                                                dialog.dismiss();
                                            }
                                        }
        );
        dialog.show();
    }

    /*Dialog to shows Product in Buy and Sell*/

    private void showProductAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        // tvtitle.setVisibility(View.GONE);
        tvtitle.setText("Select Product");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bproduct = false;
            }
        });

        if (sType.equalsIgnoreCase("B")) {
            try {
                Iterator<Product> iter = productList.iterator();
                while (iter.hasNext()) {
                    Product user = iter.next();
                    if (user.getCodeValue().equals("4")) {
                        //Use iterator to remove this User object.
                        iter.remove();
                    }
                }
            }catch (NullPointerException e){
                e.printStackTrace();
            }

        }
        if (sType.equalsIgnoreCase("S")) {
            try {
                Iterator<Product> iter = productList.iterator();
                while (iter.hasNext()) {
                    Product user = iter.next();
                    if (user.getCodeValue().equals("1")) {
                        //Use iterator to remove this User object.
                        iter.remove();
                    }
                    if (user.getCodeValue().equals("3")) {
                        //Use iterator to remove this User object.
                        iter.remove();
                    }
                }
            }catch (NullPointerException e){
                e.printStackTrace();
            }

        }

        if (productList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < productList.size(); i++) {
                choices.add(productList.get(i).getCodeName());
                currencyAdapter.add(productList.get(i).getCodeName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                iProduct = Integer.parseInt(productList.get(i).getCodeValue());
                                              /*  if (iProduct == iProductnew) {
                                                    iProduct = 0;
                                                    Toast.makeText(Activity_main.this, "Please select other product", Toast.LENGTH_LONG).show();
                                                } else {
                                                    txtproduct.setText(productList.get(i).getCodeName());
                                                }*/
                                                txtproduct.setText(productList.get(i).getCodeName());
                                                //changes for new product
                                                if (iProduct == 1) {
                                                    iProductnew = 2;
                                                    txtCurrencynew.setText("Currency Notes");

                                                    if (sType.equalsIgnoreCase("B")){
                                                        linearPlus.setVisibility(View.VISIBLE);
                                                    if (linear_extended.getVisibility()==View.VISIBLE){
                                                        linearPlus.setVisibility(View.GONE);
                                                    }
                                                    }

                                                } else {
                                                    if (iProduct == 2) {
                                                        iProductnew = 1;
                                                        txtCurrencynew.setText("Forex Card");
                                                        if (sType.equalsIgnoreCase("B")){
                                                            linearPlus.setVisibility(View.VISIBLE);
                                                            if (linear_extended.getVisibility()==View.VISIBLE){
                                                                linearPlus.setVisibility(View.GONE);
                                                            }
                                                        }

                                                    }
                                                    else {
                                                        linearPlus.setVisibility(View.GONE);
                                                        iProductnew=0;
                                                        txtCurrencynew.setText("");
                                                        linear_extended.setVisibility(View.GONE);
                                                    }
                                                }

                                               /* long now= SystemClock.uptimeMillis();
                                                MotionEvent myEvent = MotionEvent.obtain(now,now,MotionEvent.ACTION_DOWN, 0, 0,0);
                                                onTouch(rvCurrency, myEvent);*/

                                                bproduct = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }



    private void showProductAlertCustomDialognew() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setText("Select Product");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bproductnew = false;
            }
        });

        if (sType.equalsIgnoreCase("B")) {
            Iterator<Product> iter = productList.iterator();
            while (iter.hasNext()) {
                Product user = iter.next();
                if (user.getCodeValue().equals("4")) {
                    //Use iterator to remove this User object.
                    iter.remove();
                }
            }
        }
        if (sType.equalsIgnoreCase("S")) {
            Iterator<Product> iter = productList.iterator();
            while (iter.hasNext()) {
                Product user = iter.next();
                if (user.getCodeValue().equals("1")) {
                    //Use iterator to remove this User object.
                    iter.remove();
                }
                if (user.getCodeValue().equals("3")) {
                    //Use iterator to remove this User object.
                    iter.remove();
                }
            }
        }
        if (productListnew != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < productListnew.size(); i++) {
                choices.add(productListnew.get(i).getCodeName());
                currencyAdapter.add(productListnew.get(i).getCodeName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);

        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                iProductnew = Integer.parseInt(productListnew.get(i).getCodeValue());
                                                if (iProduct == iProductnew) {
                                                    iProductnew = 0;
                                                    Toast.makeText(Activity_main.this, "Please select another product", Toast.LENGTH_LONG).show();
                                                } else {
                                                    txtCurrencynew.setText(productListnew.get(i).getCodeName());
                                                }
                                                bproductnew = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    /*
     Dialog to show transfer type in Money transfer
     */
    private void showTransferTypeAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setText("Select Transfer Type");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                btransfertype = false;
            }
        });


        if (transfertypeList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < transfertypeList.size(); i++) {
                choices.add(transfertypeList.get(i).getCodeName());
                currencyAdapter.add(transfertypeList.get(i).getCodeName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtTransferTypeMoney.setText(transfertypeList.get(i).getCodeName());
                                                itransfertype = Integer.parseInt(transfertypeList.get(i).getCodevalue());
                                                btransfertype = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    /*
      Dialog to show Purpose type in Money Transfer
     */
    private void showPurposeTypeAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        // tvtitle.setVisibility(View.GONE);
        tvtitle.setText("Select Purpose Type");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bpurposetype = false;
            }
        });


        if (purposetypeList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_main.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < purposetypeList.size(); i++) {
                choices.add(purposetypeList.get(i).getCodeName());
                currencyAdapter.add(purposetypeList.get(i).getCodeName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtPurposeMoney.setText(purposetypeList.get(i).getCodeName());
                                                ipurposetype = Integer.parseInt(purposetypeList.get(i).getCodevalue());
                                                bpurposetype = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.relative_button:

                if (sType.equalsIgnoreCase("B")) {
                    if (validateBuy()) {
                        validationofAction();
                        if (!ismobreg.equalsIgnoreCase("")) {
                            Log.e("call request api", "call request api");
                            Log.e("strtoken", strtoken);
                            if (gbData.isConnected(getApplicationContext())) {
                                CallAddRequestApi objRequestAPI = new CallAddRequestApi();
                                objRequestAPI.execute(CommonApi.REQUEST);
                            }else{
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                            }


                        } else {

                            strmobnoofuser = edtMobileNo.getText().toString().trim();
                            if (gbData.isConnected(getApplicationContext())) {

                                CallMobileNoVerification objRequestAPI = new CallMobileNoVerification();
                                objRequestAPI.execute(CommonApi.CUSTOMER_CHECKEXIST);
                            }else {
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                            }
                        }
                    }
                } else {
                    if (sType.equalsIgnoreCase("S")) {
                        if (validateSell()) {
                            validationofAction();
                            if (!ismobreg.equalsIgnoreCase("")) {
                                Log.e("call request api", "call request api");
                                Log.e("strtoken", strtoken);
                                if (gbData.isConnected(getApplicationContext())) {

                                    CallAddRequestApi objRequestAPI = new CallAddRequestApi();
                                    objRequestAPI.execute(CommonApi.REQUEST);
                                }else {
                                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                                }
                            } else {
                                strmobnoofuser = edtMobileNo.getText().toString().trim();

                                if (gbData.isConnected(getApplicationContext())) {

                                    CallMobileNoVerification objRequestAPI = new CallMobileNoVerification();
                                    objRequestAPI.execute(CommonApi.CUSTOMER_CHECKEXIST);
                                }else {
                                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                                }
                            }
                        }

                    } else {
                        if (sType.equalsIgnoreCase("M")) {
                            if (validateMoneyTransfer()) {
                                validationofAction();

                                if (!ismobreg.equalsIgnoreCase("")) {
                                    Log.e("call request api", "call request api");
                                    Log.e("strtoken", strtoken);
                                    if (gbData.isConnected(getApplicationContext())) {

                                        CallAddRequestApi objRequestAPI = new CallAddRequestApi();
                                        objRequestAPI.execute(CommonApi.REQUEST);
                                    }else {
                                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                                    }
                                } else {
                                    strmobnoofuser = txtMobileMoney.getText().toString().trim();

                                    if (gbData.isConnected(getApplicationContext())) {

                                        String MobileNumber=txtMobileMoney.getText().toString().trim();
                                        CallMobileNoVerification objRequestAPI = new CallMobileNoVerification();
                                        objRequestAPI.execute(CommonApi.CUSTOMER_CHECKEXIST);
                                    }else {
                                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                                    }
                                }
                            }
                        }
                    }
                }


                break;

            case R.id.relCity:
                if (gbData.isConnected(getApplicationContext())) {
                    showCityAlertCustomDialog();
                } else
                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                break;
            case R.id.linear_plus:
                linearPlus.setVisibility(View.GONE);
                lineraExtended.setVisibility(View.VISIBLE);

                break;

            case R.id.linear_cross:
                iProductnew = 0;
                // txtCurrencynew.setText(null);
                txtQuantitynew.setText(null);
                lineraExtended.setVisibility(View.GONE);
                linearPlus.setVisibility(View.VISIBLE);
                break;

            case R.id.checkHomeDelivery:
                if (checkBoxHome_Delivery.isChecked()) {
                    sMode = "D";
                    // linearCross.setBackground(getResources().getDrawable(R.drawable.circle_plus_red));
                } else {
                    // linearCross.setBackground(getResources().getDrawable(R.drawable.circle_plus));
                }


                break;

            case R.id.checkPickUp:
                if (checkBoxPick_Up.isChecked()) {
                    sMode = "P";
                    //  linearCross.setBackground(getResources().getDrawable(R.drawable.circle_plus_red));
                } else {
                    // linearCross.setBackground(getResources().getDrawable(R.drawable.circle_plus));
                }
                break;
        }


    }

    public void clearallvaluefortype() {
        if (sType.equalsIgnoreCase("B")) {
            txtproduct.setText(null);
            txtCurrency.setText(null);
            txtQuantity.setText(null);
            txtArea.setText(null);
            edtMobileNo.setText(null);
            iProduct = 0;
            iProductnew = 0;
            iCurrency = 0;
            iQuantity = 0;
            txtCurrencynew.setText(null);
            txtQuantitynew.setText(null);

        } else {
            if (sType.equalsIgnoreCase("S")) {
                txtproduct.setText(null);
                txtCurrency.setText(null);
                txtQuantity.setText(null);
                txtArea.setText(null);
                edtMobileNo.setText(null);

                iProduct = 0;
                iCurrency = 0;
                iQuantity = 0;


            } else {
                txtMobileMoney.setText(null);
                txtQuantityMoney.setText(null);
                iCurrencymoney = 0;
                txtCurrencyMoney.setText(null);
                itransfertype = 0;
                txtTransferTypeMoney.setText(null);
                ipurposetype = 0;
                txtPurposeMoney.setText(null);
                iCountry = 0;
                txtCountryMoneyTransMoney.setText(null);
            }
        }

    }


    /*
    Call Request Api for application
   */
    public class CallAddRequestApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

           // if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    Log.e("callrequestres", strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        int requestid = (int) objmsgtext.get("RequestId");
                        String nbc = (String) objmsgtext.get("NBC");
                        setRequestpref(requestid, nbc);
                        sharedpreferencescallrequest.edit().clear().commit();
                        //call get callrequest
                        clearallvaluefortype();
                        if (gbData.isConnected(Activity_main.this)) {

                            CallUpdateProfileAPI objRequestAPI = new CallUpdateProfileAPI();
                                objRequestAPI.execute(CommonApi.CUSTOMER_UPDATEPROFILE);

                        } else {
                            CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }
                        Intent int_requesttrace = new Intent(Activity_main.this, Activity_requesttrace.class);
                        startActivity(int_requesttrace);
                        finish();


                    } else {
                        if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                            CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                        } else {
                            if (objdata.getString("message_code").equalsIgnoreCase("400")) {
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

                            }
                            if (objdata.getString("message_code").equalsIgnoreCase("1001")){
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

                            }
                        }
                    }
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
           /* } else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.REQUEST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("requestUserid", Integer.toString(iUserId));
                postDataParams.put("requestType", requestType);
                postDataParams.put("requestSourceCurrencyId", requestSourceCurrencyId);
                postDataParams.put("requestTargetCurrencyId", requestTargetCurrencyId);
                postDataParams.put("deliveryMode", deliveryoption);
                postDataParams.put("requestLeadSourceId", requestLeadSourceId);
                postDataParams.put("requestSourceRefId", requestSourceRefId);
                postDataParams.put("requestProducts", requestProducts);
                postDataParams.put("requestLocation", requestLocation);
                postDataParams.put("requestLat", requestLat);
                postDataParams.put("requestLong", requestLong);
                postDataParams.put("requestPurposeId", requestPurposeId);
                postDataParams.put("requestTransferCountryId", requestTransferCountryId);
                postDataParams.put("requestTransferTypeId", requestTransferTypeId);


                Log.e("requestUserid", Integer.toString(iUserId));
                Log.e("requestType", requestType);
                Log.e("requestSourceCurrencyId", requestSourceCurrencyId);
                Log.e("requestTargetCurrencyId", requestTargetCurrencyId);
                Log.e("deliveryMode", deliveryoption);
                Log.e("requestLeadSourceId", requestLeadSourceId);
                Log.e("requestSourceRefId", requestSourceRefId);
                Log.e("requestProducts", requestProducts);
                Log.e("requestLocation", requestLocation);
                Log.e("requestLat", requestLat);
                Log.e("requestLong", requestLong);
                Log.e("requestPurposeId", requestPurposeId);
                Log.e("requestTransferCountry", requestTransferCountryId);
                Log.e("requestTransferTypeId", requestTransferTypeId);


                byte[] auth = (Integer.toString(iUserId) + ":" + strtoken).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                Log.e("requestUserid", Integer.toString(iUserId));
                Log.e("strtoken", strtoken);


                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000);
                urlConnection.setConnectTimeout(60000);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
               /* if (urlConnection != null)
                    urlConnection.disconnect();*/
            }
            return null;
        }
    }


    private void setRequestpref(int requestid, String nbc) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_requestid, requestid);
        editor.putString(ConstantData.KEY_nbc, nbc);
        editor.commit();
    }


    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
            switch (view.getId()) {

                case R.id.txtCurrency:
                case R.id.rv_currency:

                    if (bCurrency == false) {

                        if (currencyList == null || currencyList.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                bCurrency = true;
                                CallCurrencyAPI objcurrrencyAPI = new CallCurrencyAPI();
                                objcurrrencyAPI.execute(CommonApi.CURRENCY);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        } else
                            showCurrencyAlertCustomDialog();
                    }

                    break;
                case R.id.txtArea:
                case R.id.rv_area:

                    if (bArea == false) {
                        bArea = true;
                        try {
                            AutocompleteFilter autocompleteFilter = new AutocompleteFilter.Builder()
                                    .setTypeFilter(Place.TYPE_COUNTRY)
                                    .setCountry("IN")
                                    .build();
                            Intent intent = new PlaceAutocomplete.IntentBuilder
                                    (PlaceAutocomplete.MODE_OVERLAY)
                                    .setFilter(autocompleteFilter)
                                    .setBoundsBias(BOUNDS_MOUNTAIN_VIEW)
                                    .build(Activity_main.this);
                            startActivityForResult(intent, REQUEST_SELECT_PLACE);

                        } catch (GooglePlayServicesRepairableException |
                                GooglePlayServicesNotAvailableException e) {
                            e.printStackTrace();
                        }
                        //showAreaAlertCustomDialog();
                    }
                    break;
                case R.id.rv_product:
                case R.id.txtproduct:

                    if (bproduct == false) {

                        if (productList == null || productList.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                bproduct = true;
                                CallProductAPI objcurrrencyAPI = new CallProductAPI();
                                objcurrrencyAPI.execute(CommonApi.CODELIST);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        } else

                            showProductAlertCustomDialog();
                    }
                    break;
                case R.id.rv_currencyplus:
                case R.id.txtcurrencynew:

                   /* if (bproductnew == false) {

                        if (productListnew == null || productListnew.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                bproductnew = true;
                                CallProductAPINew objcurrrencyAPI = new CallProductAPINew();
                                objcurrrencyAPI.execute(CommonApi.CODELIST);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        } else


                            showProductAlertCustomDialognew();
                    }*/


                    break;

                case R.id.layCountryMoneyTrans:
                case R.id.txtCountryMoneyTrans:

                    if (bCountry == false) {

                        if (countrylist == null || countrylist.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                bCountry = true;
                                CallCountryAPI objcurrrencyAPI = new CallCountryAPI();
                                objcurrrencyAPI.execute(CommonApi.COUNTRY);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        } else
                            showCountryAlertCustomDialog();
                    }


                    break;

                case R.id.layTransferTypeMoneyTrans:
                case R.id.txtTransferTypeMoneyTrans:

                    if (btransfertype == false) {

                        if (transfertypeList == null || transfertypeList.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                btransfertype = true;
                                CallTransferTypeApi objcurrrencyAPI = new CallTransferTypeApi();
                                objcurrrencyAPI.execute(CommonApi.CODELIST);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        } else
                            showTransferTypeAlertCustomDialog();
                    }


                    break;

                case R.id.layPurposeMoneyTrans:
                case R.id.txtPurposeMoneyTrans:

                    if (bpurposetype == false) {

                        if (purposetypeList == null || purposetypeList.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                bpurposetype = true;
                                CallPurposeTypeApi objcurrrencyAPI = new CallPurposeTypeApi();
                                objcurrrencyAPI.execute(CommonApi.CODELIST);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        } else
                            showPurposeTypeAlertCustomDialog();
                    }


                    break;
                case R.id.layCurrencyMoneyTrans:
                case R.id.txtCurrencyMoneyTrans:

                    if (bCurrencymoney == false) {

                        if (currencyListmoney == null || currencyListmoney.size() <= 0) {
                            if (gbData.isConnected(getApplicationContext())) {
                                bCurrencymoney = true;
                                CallCurrencyAPIMoney objcurrrencyAPI = new CallCurrencyAPIMoney();
                                objcurrrencyAPI.execute(CommonApi.CURRENCY);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                        } else
                            showCurrencyAlertCustomDialogMoney();
                    }


                    break;


                default:


                    break;


            }
        }

        return true;

    }

    /*
     Call currency api for Buy,sell and Money transfer
     */
    public class CallCurrencyAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showCurrencyAlertCustomDialog();
            else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForCurrency();
            return "DONE";

        }

        private void CallForCurrency() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CURRENCY);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    currencyList = new ArrayList<Currency>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Currency objCurrency = new Currency();
                        objCurrency.setCurrencyId(jsonObj.getInt("id"));
                        objCurrency.setCurrencyName(jsonObj.getString("currencyName"));
                        objCurrency.setCurrencyAbbrivation(jsonObj.getString("currencyAbbrevation"));
                        objCurrency.setCurrencySymbol(jsonObj.getString("currencySymbol"));
                        objCurrency.setCurrencyOrder(jsonObj.getString("currencyOrder"));
                        objCurrency.setRbirate(jsonObj.getString("rbiRate"));
                        objCurrency.setBuyRate(jsonObj.getString("buyRate"));
                        objCurrency.setSellRate(jsonObj.getString("sellRate"));
                        objCurrency.setProductcardoptions(jsonObj.getString("productCardYesNo"));
                        objCurrency.setProductMoneyTransferOrder(jsonObj.getString("productMoneyTransferOrder"));
                        currencyList.add(objCurrency);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                  //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_main.this,getResources().getString(R.string.app_name),objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    /*
     Call logout api for Customer flow
     */
    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (Error_Message.equalsIgnoreCase("")) {

                logoutApplication();
            } else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }


    /*
     Call Currency api for Money Transfer
     */
    public class CallCurrencyAPIMoney extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showCurrencyAlertCustomDialogMoney();
            else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForCurrencyMoney();
            return "DONE";

        }

        private void CallForCurrencyMoney() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CURRENCY);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    currencyListmoney = new ArrayList<Currency>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Currency objCurrency = new Currency();
                        objCurrency.setCurrencyId(jsonObj.getInt("id"));
                        objCurrency.setCurrencyName(jsonObj.getString("currencyName"));
                        objCurrency.setCurrencyAbbrivation(jsonObj.getString("currencyAbbrevation"));
                        objCurrency.setCurrencySymbol(jsonObj.getString("currencySymbol"));
                        objCurrency.setCurrencyOrder(jsonObj.getString("currencyOrder"));
                        objCurrency.setRbirate(jsonObj.getString("rbiRate"));
                        objCurrency.setBuyRate(jsonObj.getString("buyRate"));
                        objCurrency.setSellRate(jsonObj.getString("sellRate"));
                        objCurrency.setProductcardoptions(jsonObj.getString("productCardYesNo"));
                        objCurrency.setProductMoneyTransferOrder(jsonObj.getString("productMoneyTransferOrder"));
                        currencyListmoney.add(objCurrency);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }


    /*
     call Country api for Money transfer
     */
    public class CallCountryAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showCountryAlertCustomDialog();
            else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForCountry();
            return "DONE";

        }

        private void CallForCountry() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.COUNTRY);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    countrylist = new ArrayList<Country>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Country objCurrency = new Country();
                        objCurrency.setCountryid(jsonObj.getString("countryId"));
                        objCurrency.setCountryname(jsonObj.getString("countryName"));
                        objCurrency.setCountryflagimgname(jsonObj.getString("countryFlagImageName"));
                        objCurrency.setCountrymobcode(jsonObj.getString("countryMobileCode"));
                        objCurrency.setCountryorder(jsonObj.getString("countryOrder"));

                        countrylist.add(objCurrency);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                /*if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
             //   Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    /*
     Call Tranfer type api for Money Transfer
     */
    public class CallTransferTypeApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

        //    if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        transfertypeList = new ArrayList<TransferType>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            TransferType objProduct = new TransferType();
                            objProduct.setCodevalue(jsonObj.getString("codeValue"));
                            objProduct.setCodeName(jsonObj.getString("codeName"));
                            objProduct.setCodeAtrribute(jsonObj.getString("codeAttribute"));

                            transfertypeList.add(objProduct);
                        }
                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    /*Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
                showTransferTypeAlertCustomDialog();

       //     } //else
           /*     CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CODELIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("codeType", "REMITTANCETRANSFER");
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
              /*  if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }


    public class CallPurposeTypeApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

           // if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        purposetypeList = new ArrayList<PurposeType>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            PurposeType objProduct = new PurposeType();
                            objProduct.setCodevalue(jsonObj.getString("codeValue"));
                            objProduct.setCodeName(jsonObj.getString("codeName"));
                            objProduct.setCodeAtrribute(jsonObj.getString("codeAttribute"));

                            purposetypeList.add(objProduct);
                        }
                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
                showPurposeTypeAlertCustomDialog();

           /* } else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CODELIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("codeType", "REMITTANCEPURPOSE");
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
            //    Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }


    public class CallCurrencyAPINew extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase(""))
                showCurrencyAlertCustomDialogNew();
            else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForCurrencyNew();
            return "DONE";

        }

        private void CallForCurrencyNew() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CURRENCY);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    currencyListnew = new ArrayList<Currency>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        Currency objCurrency = new Currency();
                        objCurrency.setCurrencyId(jsonObj.getInt("id"));
                        objCurrency.setCurrencyName(jsonObj.getString("currencyName"));
                        objCurrency.setCurrencyAbbrivation(jsonObj.getString("currencyAbbrevation"));
                        objCurrency.setCurrencySymbol(jsonObj.getString("currencySymbol"));
                        objCurrency.setCurrencyOrder(jsonObj.getString("currencyOrder"));
                        objCurrency.setRbirate(jsonObj.getString("rbiRate"));
                        objCurrency.setBuyRate(jsonObj.getString("buyRate"));
                        objCurrency.setSellRate(jsonObj.getString("sellRate"));
                        objCurrency.setProductcardoptions(jsonObj.getString("productCardYesNo"));
                        currencyListnew.add(objCurrency);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }


    public class CallProductAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

           // if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        productList = new ArrayList<Product>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            Product objProduct = new Product();
                            objProduct.setCodeValue(jsonObj.getString("codeValue"));
                            objProduct.setCodeName(jsonObj.getString("codeName"));
                            objProduct.setCodeAtrribute(jsonObj.getString("codeAttribute"));

                            productList.add(objProduct);
                        }

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                  /*  if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
                showProductAlertCustomDialog();

           /* } else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CODELIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("codeType", "PRODUCTTYPE");
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
          //      Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }

    public class CallProductAPIinitial extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

           // if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        productList = new ArrayList<Product>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            Product objProduct = new Product();
                            objProduct.setCodeValue(jsonObj.getString("codeValue"));
                            objProduct.setCodeName(jsonObj.getString("codeName"));
                            objProduct.setCodeAtrribute(jsonObj.getString("codeAttribute"));

                            productList.add(objProduct);
                        }

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                /*    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/
                }


            /*} else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

            //   progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CODELIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("codeType", "PRODUCTTYPE");
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }


    public class CallProductAPINew extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        productListnew = new ArrayList<Product>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            Product objProduct = new Product();
                            objProduct.setCodeValue(jsonObj.getString("codeValue"));
                            objProduct.setCodeName(jsonObj.getString("codeName"));
                            objProduct.setCodeAtrribute(jsonObj.getString("codeAttribute"));

                            productListnew.add(objProduct);
                        }
                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);
                }
                showProductAlertCustomDialognew();

            } else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CODELIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("codeType", "PRODUCTTYPE");
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }
    }


    public class CallCityAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);

            //if (Error_Message.equalsIgnoreCase("")) {
                if (gbData.isConnected(getApplicationContext())) {
                    //CallAreaAPI objAreaAPI = new CallAreaAPI();
                    //objAreaAPI.execute(ConstantData.AREA);
                } else
                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
          /*  } else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CallForCity();
            return "DONE";

        }

        private void CallForCity() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CITY);
                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    cityList = new ArrayList<City>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        City objCity = new City();
                        objCity.setCityName(jsonObj.getString("cityName"));
                        objCity.setCityId(jsonObj.getInt("cityId"));
                        cityList.add(objCity);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                  //  Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_code"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                /*if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
             //   Error_Message = "Error: " + e.getClass().getName() + " in city data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }

    }

    public class CallAreaAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(View.GONE);
            setProgressBarIndeterminateVisibility(false);

         //  if (Error_Message.equalsIgnoreCase("")) {
                //Idle Do nothing
                if (areaList == null || areaList.size() == 0)
                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);
          /*  } else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CallForLocation();

            return "DONE";

        }

        private void CallForLocation() {

            String myjsonstring = "";
            HttpURLConnection urlConnection = null;
            try {
                URL url = new URL(ConstantData.SERVER_URL + ConstantData.BASE_URL + iCity + "/" + ConstantData.AREA);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("data_text");
                    areaList = new ArrayList<LocationArea>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        LocationArea objArea = new LocationArea();
                        objArea.setAreaName(jsonObj.getString("areaName"));
                        objArea.setAreaId(jsonObj.getInt("areaId"));
                        areaList.add(objArea);
                    }
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                   // Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_main.this,getResources().getString(R.string.app_name),objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
               /* if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
               // Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }

    /*
     Call getting OTP message for Buy,sell and Money Transfer
     */
    public class CallMobileNoVerification extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

         //   if (Error_Message.equalsIgnoreCase("")) {

                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    Log.e("strResponse", strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        String regType = (String) objmsgtext.get("regType");
                        Log.e("regType", regType);
                        String userName = "";
                        String userMobileNo = "";
                        String userEmail = "";
                        String struserId = "";
                        String strusertoken = "";
                        Log.e("userid", struserId);

                        if (regType.equalsIgnoreCase("autoLogin")) {
                            struserId = (String) objmsgtext.get("userId");

                            userName = (String) objmsgtext.get("userName");
                            userMobileNo = (String) objmsgtext.get("userMobileNo");
                            userEmail = (String) objmsgtext.get("userEmail");
                        }

                        if (regType.equalsIgnoreCase("autoReg")) {
                            struserId = (String) objmsgtext.get("userId");
                            Log.e("userid", struserId);
                            setSharedPrefforSignup(struserId, userName, userEmail, strmobnoofuser, regType);
                            clearallvaluefortype();

                            Intent int_signup = new Intent(Activity_main.this, Activity_signup.class);
                            startActivity(int_signup);
                            //  finish();

                        } else {
                            clearallvaluefortype();

                            setSharedPrefforSignup(struserId, userName, userEmail, userMobileNo, regType);
                            //already registered
                            Intent int_checkotp = new Intent(Activity_main.this, Activity_otpverification.class);
                            startActivity(int_checkotp);
                            //  finish();


                          /*  if (gbData.isConnected(getApplicationContext())) {
                                CallRequestAPI objRequestAPI = new CallRequestAPI();
                                objRequestAPI.execute(ConstantData.REQUEST);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection and try again.");*/
                        }


                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    /*if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
            /*} else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_CHECKEXIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                if (sType.equalsIgnoreCase("M"))
                    postDataParams.put("userMobileNo", txtMobileMoney.getText().toString().trim());
                else
                    postDataParams.put("userMobileNo", edtMobileNo.getText().toString().trim());

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team."*/;

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }


    private void setSharedPrefforSignup(String id, String name, String email, String mobileno, String regtype) {
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_USERID, Integer.parseInt(id));
        editor.putString(ConstantData.KEY_USERNAME, name);
        editor.putString(ConstantData.KEY_USEREMAIL, email);
        editor.putString(ConstantData.KEY_USERMOBILENO, mobileno);
        editor.putString(ConstantData.KEY_REGTYPE, regtype);
        editor.commit();
    }

    private void setSharedPrefforBuyAndSell(String requestuserid, String requestType, String requestSourceCurrencyId, String requestTargetCurrencyId, String deliveryMode, String requestLeadSourceId, String requestSourceRefId, String requestProducts, String requestLocation, String requestLat, String requestLong, String requestPurposeId, String requestTransferCountryId, String requestTransferTypeId) {
        editorcall = sharedpreferencescallrequest.edit();
        editorcall.putString(ConstantData.KEY_requestUserid, requestuserid);
        editorcall.putString(ConstantData.KEY_requestType, requestType);
        editorcall.putString(ConstantData.KEY_requestSourceCurrencyId, requestSourceCurrencyId);
        editorcall.putString(ConstantData.KEY_requestTargetCurrencyId, requestTargetCurrencyId);
        editorcall.putString(ConstantData.KEY_deliveryMode, deliveryMode);
        editorcall.putString(ConstantData.KEY_requestLeadSourceId, requestLeadSourceId);
        editorcall.putString(ConstantData.KEY_requestSourceRefId, requestSourceRefId);
        editorcall.putString(ConstantData.KEY_requestProducts, requestProducts);
        editorcall.putString(ConstantData.KEY_requestLocation, requestLocation);
        editorcall.putString(ConstantData.KEY_requestLat, requestLat);
        editorcall.putString(ConstantData.KEY_requestLong, requestLong);
        editorcall.putString(ConstantData.KEY_requestPurposeId, requestPurposeId);
        editorcall.putString(ConstantData.KEY_requestTransferCountryId, requestTransferCountryId);
        editorcall.putString(ConstantData.KEY_requestTransferTypeId, requestTransferTypeId);
        editorcall.commit();
    }


    public class CallRequestAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

          //  if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        JSONObject obj = objdata.getJSONObject("data_text");
                        strNBC = obj.getString("NBC");
                        Intent i = new Intent(Activity_main.this, Activity_requesttrace.class);
                        i.putExtra("NBC", strNBC);
                        i.putExtra("Source", "NEWREQUEST");
                        startActivity(i);
                        finish();

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
            /*} else
                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), Error_Message);*/

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(ConstantData.SERVER_URL + ConstantData.BASE_URL + ConstantData.REQUEST);
                urlConnection = (HttpURLConnection) url.openConnection();
                sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);


                JSONObject postDataParams = new JSONObject();
                postDataParams.put("Type", sType);
                postDataParams.put("Currency", Integer.toString(iCurrency));
                postDataParams.put("Quantity", Integer.toString(iQuantity));
                postDataParams.put("Mode", sMode);
                postDataParams.put("RegisteredId", sharedpreferences.getInt(ConstantData.KEY_USERID, -1));
                postDataParams.put("AreaString", sAreaString);
                //postDataParams.put("AreaId", Integer.toString(iArea));

                //Log.e("params", postDataParams.toString());

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
               // Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }






    /*
  Call for Updating profile
  */
    public class CallUpdateProfileAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           /* pd_login.setMessage("Please Wait...");
            pd_login.setCancelable(false);
            pd_login.show();*/
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            String strNBC = "";

            if(Error_Message.equalsIgnoreCase("java.io.File Not FoundException"))
            {
                //call autologin api
/*

                if (gbData.isConnected(getApplicationContext())) {
                    CallMobileNoVerification objRequestAPI = new CallMobileNoVerification();
                    objRequestAPI.execute(CommonApi.CUSTOMER_CHECKEXIST);
                }
*/




            }else {

                //Log.d("Response: ", strResponse);
                if (Error_Message.equalsIgnoreCase("")) {
                    try {
                        JSONObject objdata = new JSONObject(strResponse);
                        JSONArray jsonArray;
                        if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                            // JSONObject obj = objdata.getJSONObject("message_text");
                            Log.e("Profileeee",""+objdata.getString("message_text"));
                            //  String strId = obj.getString("UserId");
                            setSharedPref(sUserName, sUserEmail, sUserMobileNo);
                        //    showAlertwithOk(getResources().getString(R.string.app_name), objdata.getString("message_text"));


                        } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                           // showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                              Log.e("Profileeee",""+objdata.getString("message_code"));
                        }
                    } catch (JSONException e) {
                        Error_Message = "JSONError: Please contact Nafex support team.";
                      //  showAlert(getResources().getString(R.string.app_name), Error_Message);
                    }
                } else{

                }
                   // showAlert(getResources().getString(R.string.app_name), Error_Message);
            }
            //pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_UPDATEPROFILE);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("userName", sUserName);
                    postDataParams.put("userEmail", sUserEmail);
                    postDataParams.put("userMobileNo", sUserMobileNo);
                    Log.e("params", postDataParams.toString());

                    byte[] auth = (iUserId + ":" + strtoken).getBytes();

                    String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                    urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(60000 /* milliseconds */);
                    urlConnection.setConnectTimeout(60000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();
                    Log.e("responseCode",Integer.toString(responseCode));
                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    }else
                    {
                        if(responseCode==400)
                        {
                            Error_Message="java.io.File Not FoundException";
                        }
                        if(responseCode==401)
                        {
                            Error_Message="java.io.File Not FoundException";
                        }
                    }
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";*/
                } catch (Exception e) {
                    //Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                    Log.e("ERROR", e.getMessage(), e);
                } /*finally {
                    urlConnection.disconnect();
                }*/
            } catch (Exception e) {
                // Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                Log.e("ERROR", e.getMessage(), e);
            }

            return null;
        }
    }

    private void setSharedPref(String username,String useremail,String usermobno) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putString(ConstantData.KEY_USERNAME, username);
        editor.putString(ConstantData.KEY_USEREMAIL, useremail);
        editor.putString(ConstantData.KEY_USERMOBILENO, usermobno);
        editor.commit();
    }
    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        sUserName=sharedpreferences.getString(ConstantData.KEY_USERNAME, "");
        sUserEmail=sharedpreferences.getString(ConstantData.KEY_USEREMAIL, "");
        sUserMobileNo=sharedpreferences.getString(ConstantData.KEY_USERMOBILENO, "");
        strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");

    }
    private  boolean checkAndRequestPermissions() {
        int camera = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA);
        int storage = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int loc = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION);
        int loc2 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION);
        List<String> listPermissionsNeeded = new ArrayList<>();

        if (camera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.CAMERA);
        }
        if (storage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (loc2 != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (loc != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (!listPermissionsNeeded.isEmpty())
        {
            ActivityCompat.requestPermissions(this,listPermissionsNeeded.toArray
                    (new String[listPermissionsNeeded.size()]),REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }
}