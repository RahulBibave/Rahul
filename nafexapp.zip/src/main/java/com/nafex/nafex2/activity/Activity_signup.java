package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;
import com.nafex.nafex2.utilities.Validation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;


public class Activity_signup extends AppCompatActivity implements View.OnClickListener {

    private TextView txtSignuptext, txtSubmit, txtMoneyChanger;
    private EditText edtName;
    private EditText edMobileno;
    private EditText edtEmail;
    private EditText edtPassword, edOtp;
    private RelativeLayout btnLogin;
    ProgressDialog pd_login;
    private AppGlobalData gbData;

    private String sUserName, sUserEmail, sUserMobileNo;
    private int iUserId;
    private String strregtype, struserid;
    private String strisleft;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    public String requestUserid;
    public String requestType;
    public String requestSourceCurrencyId;
    public String requestTargetCurrencyId;
    public String deliveryoption;
    public String requestLeadSourceId;
    public String requestSourceRefId;
    public String requestLocation;
    public String requestLocationdetails;
    public String strlat;
    public String strlong;
    public String requestLat;
    public String requestLong;
    public String requestPurposeId;
    public String requestTransferCountryId;
    public String requestTransferTypeId;
    public String requestProducts;
    SharedPreferences sharedpreferencescallrequest;
    SharedPreferences.Editor editorcall;
    public String strtoken;
    private String strmobno;
    private String otpVerification;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        Intent intent = getIntent();
        otpVerification=intent.getStringExtra(Activity_OTPVerification_request.OTP_CODE);
        findViews();
        setTypeface();
        clickListner();

    }

    /*
    Clicklistner of view
    */
    private void clickListner() {

        btnLogin.setOnClickListener(this);
        txtSubmit.setOnClickListener(this);
    }

    /*
    Custom typeface of views
    */
    private void setTypeface() {
        edtName.setTypeface(FontData.setFonts(Activity_signup.this, edtName, FontData.font_robotoregular));
        edMobileno.setTypeface(FontData.setFonts(Activity_signup.this, edMobileno, FontData.font_robotoregular));
        edtEmail.setTypeface(FontData.setFonts(Activity_signup.this, edtEmail, FontData.font_robotoregular));
        edtPassword.setTypeface(FontData.setFonts(Activity_signup.this, edtPassword, FontData.font_robotoregular));
        txtSignuptext.setTypeface(FontData.setFonts(Activity_signup.this, txtSignuptext, FontData.font_robotoregular));
        txtSubmit.setTypeface(FontData.setFonts(Activity_signup.this, txtSubmit, FontData.font_robotoregular));
        txtMoneyChanger.setTypeface(FontData.setFonts(Activity_signup.this, txtMoneyChanger, FontData.font_robotolight));

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        clearSharedPref();
        finish();


    }

    public void clearSharedPref()
    {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.clear();
        editor.commit();
    }

    /**
     * Find the Views in the layout<br />
     * <br />
     */
    private void findViews() {
        gbData = AppGlobalData.getInstance();
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        txtSignuptext = (TextView) findViewById(R.id.txt_signuptext);
        edOtp = (EditText) findViewById(R.id.edt_otp);
        edtName = (EditText) findViewById(R.id.edt_name);
        edMobileno = (EditText) findViewById(R.id.ed_mobileno);
        edtEmail = (EditText) findViewById(R.id.edt_email);
        edtPassword = (EditText) findViewById(R.id.edt_password);
        btnLogin = (RelativeLayout) findViewById(R.id.btnLogin);
        txtSubmit = (TextView) findViewById(R.id.txt_submit);
        txtMoneyChanger = (TextView) findViewById(R.id.txt_moneychanger);
        pd_login = new ProgressDialog(Activity_signup.this);

        if(otpVerification!=null){
            edOtp.setText(otpVerification);
            edOtp.setEnabled(false);
        }
        strmobno= sharedpreferences.getString(ConstantData.KEY_USERMOBILENO, "");
        Log.e("mobno",strmobno);
        if(!strmobno.equalsIgnoreCase(""))
        {
            edMobileno.setText(strmobno);
        }

    }

    /*
     OnClick
    */
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.txt_submit:
            case R.id.btnLogin:

                submitRegistartionForm();
                break;

        }

    }


    private boolean validateData() {
        String sUserName = edtName.getText().toString().trim();
        String sUserMbno = edMobileno.getText().toString().trim();
        String sUseremail = edtEmail.getText().toString().trim();
        String sUserpassword = edtPassword.getText().toString().trim();
        String sUserotp = edOtp.getText().toString();


        if (sUserName.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Your Name.");
        else if (sUserMbno.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Mobile number.");
        else if ((sUserMbno.length() < 10) || (sUserMbno.length() > 10))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid mobile number. Please enter valid mobile number.");
        else if (sUseremail.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Email address.");
        else if (!Validation.isEmailAddress(edtEmail, true))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid email address. Please enter proper email address.");
        else if (sUserpassword.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Password.");
        else if (sUserotp.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter OTP.");
        else
            return true;

        return false;
    }


    /*
        OnClick
       */
    private void submitRegistartionForm() {

        getSharedPrefFprSignup();

        HideKeybaord();
        if (validateData()) {
            if (gbData.isConnected(getApplicationContext())) {
                //validation
                CallRegisterApi objRequestAPI = new CallRegisterApi();
                objRequestAPI.execute(CommonApi.CUSTOMER_COMMONREGISTRATION);
            }
        }
    }

    private void getSharedPrefFprSignup() {
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        strregtype = sharedpreferences.getString(ConstantData.KEY_REGTYPE, "autoReg");
        strisleft = sharedpreferences.getString(ConstantData.ISLEFTLOGIN, "false");

    }


    private void setSharedPref(int id, String username, String useremail, String usermobno, String strtoken) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_USERID, id);
        editor.putString(ConstantData.KEY_USERNAME, username);
        editor.putString(ConstantData.KEY_USEREMAIL, useremail);
        editor.putString(ConstantData.KEY_USERMOBILENO, usermobno);
        editor.putString(ConstantData.KEY_REGToken, strtoken);
        editor.commit();
    }


    private void HideKeybaord() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }


    /*
 Check Request Api
   */
    public class CallAddRequestApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

           // if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    Log.e("callrequestres", strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        int requestid = (int) objmsgtext.get("RequestId");
                        String nbc = (String) objmsgtext.get("NBC");
                        setRequestpref(requestid, nbc);
                        sharedpreferencescallrequest.edit().clear().commit();
                        //call get callrequest
                        Intent int_requesttrace = new Intent(Activity_signup.this, Activity_requesttrace.class);
                        startActivity(int_requesttrace);
                        finish();


                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
           /* } else
                CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), Error_Message);*/

            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.REQUEST);
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("requestUserid", requestUserid);
                postDataParams.put("requestType", requestType);
                postDataParams.put("requestSourceCurrencyId", requestSourceCurrencyId);
                postDataParams.put("requestTargetCurrencyId", requestTargetCurrencyId);
                postDataParams.put("deliveryMode", deliveryoption);
                postDataParams.put("requestLeadSourceId", requestLeadSourceId);
                postDataParams.put("requestSourceRefId", requestSourceRefId);
                postDataParams.put("requestProducts", requestProducts);
                postDataParams.put("requestLocation", requestLocation);
                postDataParams.put("requestLat", requestLat);
                postDataParams.put("requestLong", requestLong);
                postDataParams.put("requestPurposeId", requestPurposeId);
                postDataParams.put("requestTransferCountryId", requestTransferCountryId);
                postDataParams.put("requestTransferTypeId", requestTransferTypeId);




                Log.e("requestUserid", requestUserid);
               Log.e("requestType", requestType);
               Log.e("requestSourceCurrencyId", requestSourceCurrencyId);
               Log.e("requestTargetCurrencyId", requestTargetCurrencyId);
               Log.e("deliveryMode", deliveryoption);
               Log.e("requestLeadSourceId", requestLeadSourceId);
               Log.e("requestSourceRefId", requestSourceRefId);
               Log.e("requestProducts", requestProducts);
               Log.e("requestLocation", requestLocation);
               Log.e("requestLat", requestLat);
               Log.e("requestLong", requestLong);
               Log.e("requestPurposeId", requestPurposeId);
               Log.e("requestTransferCountry", requestTransferCountryId);
               Log.e("requestTransferTypeId", requestTransferTypeId);


                byte[] auth = (requestUserid + ":" + strtoken).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);





                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
                /*if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }

    private void setRequestpref(int requestid, String nbc) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_requestid, requestid);
        editor.putString(ConstantData.KEY_nbc, nbc);
        editor.commit();
    }

    public void getSharedPref() {

        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        sharedpreferencescallrequest = getSharedPreferences(ConstantData.REQUESTPREFERENCES, MODE_PRIVATE);

        requestUserid = sharedpreferencescallrequest.getString(ConstantData.KEY_requestUserid, "");
        if (requestUserid.equalsIgnoreCase("")) {
            int userids = sharedpreferences.getInt(ConstantData.KEY_USERID, 0);
            requestUserid = Integer.toString(userids);
            strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");

        }
        requestType = sharedpreferencescallrequest.getString(ConstantData.KEY_requestType, "");
        requestSourceCurrencyId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestSourceCurrencyId, "");
        requestTargetCurrencyId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestTargetCurrencyId, "");
        deliveryoption = sharedpreferencescallrequest.getString(ConstantData.KEY_deliveryMode, "");
        requestLeadSourceId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestLeadSourceId, "");
        requestSourceRefId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestSourceRefId, "");
        requestProducts = sharedpreferencescallrequest.getString(ConstantData.KEY_requestProducts, "");
        requestLocation = sharedpreferencescallrequest.getString(ConstantData.KEY_requestLocation, "");
        requestLat = sharedpreferencescallrequest.getString(ConstantData.KEY_requestLat, "");
        requestLong = sharedpreferencescallrequest.getString(ConstantData.KEY_requestLong, "");
        requestPurposeId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestPurposeId, "");
        requestTransferCountryId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestTransferCountryId, "");
        requestTransferTypeId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestTransferTypeId, "");
        Log.e("requestUserid", requestUserid);
        Log.e("requestType", requestType);
        Log.e("requestSourceCurrencyId", requestSourceCurrencyId);
        Log.e("requestTargetCurrencyId", requestTargetCurrencyId);
        Log.e("deliveryoption", deliveryoption);
        Log.e("requestLeadSourceId", requestLeadSourceId);
        Log.e("requestSourceRefId", requestSourceRefId);
        Log.e("requestProducts", requestProducts);
        Log.e("requestLocation", requestLocation);
        Log.e("requestLat", requestLat);
        Log.e("requestLong", requestLong);
        Log.e("requestPurposeId", requestPurposeId);
        Log.e("requestTransferCountry", requestTransferCountryId);
        Log.e("requestTransferTypeId", requestTransferTypeId);


    }


    public class CallRegisterApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd_login.dismiss();
           // if (Error_Message.equalsIgnoreCase("")) {
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                        JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        String userId = (String) objmsgtext.get("userId");
                        String userName = (String) objmsgtext.get("userName");
                        String userMobileNo = (String) objmsgtext.get("userMobileNo");
                        String userEmail = (String) objmsgtext.get("userEmail");
                        String userToken = (String) objmsgtext.get("userToken");
                        setSharedPref(Integer.parseInt(userId), userName, userEmail, userMobileNo, userToken);

                        CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), "Profile created successfully!");

                        if (strregtype.equalsIgnoreCase("autoReg")) {
                            if (strisleft.equalsIgnoreCase("false")) {
                                getSharedPref();
                                if (gbData.isConnected(getApplicationContext())) {
                                    CallAddRequestApi objRequestAPI = new CallAddRequestApi();
                                    objRequestAPI.execute(CommonApi.REQUEST);
                                }
                            }else
                            {
                                Intent int_main=new Intent(Activity_signup.this,Activity_main.class);
                                startActivity(int_main);
                                finish();
                            }
                            //call request api
                            Log.e("call request api", "call request api");
                        } else {
                            if (strregtype.equalsIgnoreCase("autoReg")) {

                            }
                        }

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    /*if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
            /*} else
                CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), Error_Message);*/


        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_COMMONREGISTRATION);
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
               /* if (strisleft.equalsIgnoreCase("false")) {
                    postDataParams.put("regType", strregtype);
                } else {
                    postDataParams.put("regType", "self");
                }*/

                postDataParams.put("regType", strregtype);
                postDataParams.put("userName", edtName.getText().toString().trim());
                postDataParams.put("userMobileNo", edMobileno.getText().toString().trim());
                postDataParams.put("userEmail", edtEmail.getText().toString().trim());
                postDataParams.put("userPassword", edtPassword.getText().toString().trim());
                postDataParams.put("userId", iUserId);
                postDataParams.put("userOTP", edOtp.getText().toString().trim());
                Log.e("regType", strregtype);
                Log.e("userName", edtName.getText().toString().trim());
                Log.e("userMobileNo", edMobileno.getText().toString().trim());
                Log.e("userEmail", edtEmail.getText().toString().trim());
                Log.e("userPassword", edtPassword.getText().toString().trim());
                Log.e("userId", Integer.toString(iUserId));
                Log.e("userOTP", edOtp.getText().toString().trim());

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }

}
