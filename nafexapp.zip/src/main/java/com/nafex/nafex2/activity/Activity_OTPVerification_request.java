package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Swarup on 9/11/2017.
 */

public class Activity_OTPVerification_request extends AppCompatActivity implements View.OnClickListener {
    private TextView txtOtpverification;
    private EditText edtOTPVerification;
    private RelativeLayout btnCheck;
    private TextView txtCheck;
    public static String OTP_CODE="OTP_CODE";
    ProgressDialog pd_login;

    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;

    SharedPreferences sharedpreferencescallrequest;
    SharedPreferences.Editor editorcall;

    private AppGlobalData gbData;
    String strmobileno = "";
    public String requestUserid;
    public String requestType;
    public String requestSourceCurrencyId;
    public String requestTargetCurrencyId;
    public String deliveryoption;
    public String requestLeadSourceId;
    public String requestSourceRefId;
    public String requestLocation;
    public String requestLocationdetails;
    public String strlat;
    public String strlong;
    public String requestLat;
    public String requestLong;
    public String requestPurposeId;
    public String requestTransferCountryId;
    public String requestTransferTypeId;
    public String requestProducts;
    public String strtoken;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverification);
        findViews();
        setTypeface();
        clickListner();

    }

    private void clickListner() {
        btnCheck.setOnClickListener(this);
        txtCheck.setOnClickListener(this);


    }

    private void setTypeface() {
        edtOTPVerification.setTypeface(FontData.setFonts(Activity_OTPVerification_request.this, edtOTPVerification, FontData.font_robotoregular));
        txtCheck.setTypeface(FontData.setFonts(Activity_OTPVerification_request.this, txtCheck, FontData.font_robotoregular));
        txtOtpverification.setTypeface(FontData.setFonts(Activity_OTPVerification_request.this, txtCheck, FontData.font_robotoregular));


    }


    /*
  Check OTP  Api
  */
    public class CallCheckOTPApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //if (Error_Message.equalsIgnoreCase("")) {
                pd_login.dismiss();
                String strNBC = "";
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        String userId = (String) objmsgtext.get("userId");
//                        String regType = (String) objmsgtext.get("regType");
                        Log.e("userid", userId);
                        //  Log.e("regType", regType);
                        String userName = (String) objmsgtext.get("userName");
                        String userMobileNo = (String) objmsgtext.get("userMobileNo");
                        String userEmail = (String) objmsgtext.get("userEmail");
                        String userToken = (String) objmsgtext.get("userToken");

                        setSharedPref(Integer.parseInt(userId), userName, userEmail, userMobileNo, userToken);

                        Intent int_signup = new Intent(Activity_OTPVerification_request.this, Activity_signup.class);
                        int_signup.putExtra(OTP_CODE,edtOTPVerification.getText().toString().trim());

                        startActivity(int_signup);

                        //call request api
                        Log.e("call request api", "call request api");


                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_OTPVerification_request.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    /*if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_OTPVerification_request.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
           /* } else
                CommonUI.showAlert(Activity_OTPVerification_request.this, getResources().getString(R.string.app_name), Error_Message);*/

            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_CHECK_OTP);
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("userMobileNo", strmobileno);
                postDataParams.put("userOTP", edtOTPVerification.getText().toString().trim());


                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.commit();
    }




    public void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        sharedpreferencescallrequest = getSharedPreferences(ConstantData.REQUESTPREFERENCES, MODE_PRIVATE);

        requestUserid = sharedpreferencescallrequest.getString(ConstantData.KEY_requestUserid, "");
        if (requestUserid.equalsIgnoreCase("")) {
            int userids = sharedpreferences.getInt(ConstantData.KEY_USERID, 0);
            strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");

            requestUserid = Integer.toString(userids);
        }
        requestType = sharedpreferencescallrequest.getString(ConstantData.KEY_requestType, "");
        requestSourceCurrencyId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestSourceCurrencyId, "");
        requestTargetCurrencyId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestTargetCurrencyId, "");
        deliveryoption = sharedpreferencescallrequest.getString(ConstantData.KEY_deliveryMode, "");
        requestLeadSourceId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestLeadSourceId, "");
        requestSourceRefId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestSourceRefId, "");
        requestProducts = sharedpreferencescallrequest.getString(ConstantData.KEY_requestProducts, "");
        requestLocation = sharedpreferencescallrequest.getString(ConstantData.KEY_requestLocation, "");
        requestLat = sharedpreferencescallrequest.getString(ConstantData.KEY_requestLat, "");
        requestLong = sharedpreferencescallrequest.getString(ConstantData.KEY_requestLong, "");
        requestPurposeId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestPurposeId, "");
        requestTransferCountryId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestTransferCountryId, "");
        requestTransferTypeId = sharedpreferencescallrequest.getString(ConstantData.KEY_requestTransferTypeId, "");
        Log.e("requestUserid", requestUserid);
        Log.e("requestType", requestType);
        Log.e("requestSourceCurrencyId", requestSourceCurrencyId);
        Log.e("requestTargetCurrencyId", requestTargetCurrencyId);
        Log.e("deliveryoption", deliveryoption);
        Log.e("requestLeadSourceId", requestLeadSourceId);
        Log.e("requestSourceRefId", requestSourceRefId);
        Log.e("requestProducts", requestProducts);
        Log.e("requestLocation", requestLocation);
        Log.e("requestLat", requestLat);
        Log.e("requestLong", requestLong);
        Log.e("requestPurposeId", requestPurposeId);
        Log.e("requestTransferCountry", requestTransferCountryId);
        Log.e("requestTransferTypeId", requestTransferTypeId);


    }


    private void setSharedPref(int id, String username, String useremail, String usermobno, String strtoken) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_USERID, id);
        editor.putString(ConstantData.KEY_USERNAME, username);
        editor.putString(ConstantData.KEY_USEREMAIL, useremail);
        editor.putString(ConstantData.KEY_USERMOBILENO, usermobno);
        editor.putString(ConstantData.KEY_REGToken, strtoken);
        editor.commit();
    }

    private void setRequestpref(int requestid, String nbc) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_requestid, requestid);
        editor.putString(ConstantData.KEY_nbc, nbc);
        editor.commit();
    }


    /**
     * initialization of views
     */
    private void findViews() {
        pd_login = new ProgressDialog(Activity_OTPVerification_request.this);

        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        sharedpreferencescallrequest = getSharedPreferences(ConstantData.REQUESTPREFERENCES, MODE_PRIVATE);
        editorcall = sharedpreferencescallrequest.edit();

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        gbData = AppGlobalData.getInstance();
        gbData.setStatusBarColor(Activity_OTPVerification_request.this, R.color.colorPrimaryDark);
        txtOtpverification = (TextView) findViewById(R.id.txt_otpverification);
        edtOTPVerification = (EditText) findViewById(R.id.edtOTPVerification);
        btnCheck = (RelativeLayout) findViewById(R.id.btnCheck);
        txtCheck = (TextView) findViewById(R.id.txt_check);
    }

    private void HideKeybaord() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    private boolean validateData() {
        String sUserOTP = edtOTPVerification.getText().toString().trim();

        if (sUserOTP.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please provide OTP for verification.");

        else
            return true;


        return false;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnCheck:
            case R.id.txt_check:
                HideKeybaord();
                if (validateData()) {
                    if (gbData.isConnected(getApplicationContext())) {

                        getsharedMobNo();

                        CallCheckOTPApi objRequestAPI = new CallCheckOTPApi();
                        objRequestAPI.execute(CommonApi.CUSTOMER_CHECK_OTP);
                    } else {
                        CommonUI.showAlert(Activity_OTPVerification_request.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                    }
                }

                break;


        }

    }

    private void getsharedMobNo() {

        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        strmobileno = sharedpreferences.getString(ConstantData.KEY_USERMOBILENO, "");


    }
}
