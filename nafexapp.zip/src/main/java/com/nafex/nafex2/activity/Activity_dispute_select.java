package com.nafex.nafex2.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.AdapterKycListing;
import com.nafex.nafex2.adapters.AdapterSelect_Dispute;

import com.nafex.nafex2.data.DisputeType;
import com.nafex.nafex2.data.DocType;
import com.nafex.nafex2.data.EnquiriesData;
import com.nafex.nafex2.data.EnquiryData;
import com.nafex.nafex2.data.HistoryDispute;
import com.nafex.nafex2.interfaces.EnquiryOperations;
import com.nafex.nafex2.interfaces.KYCOperation;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by rahul on 5/10/17.
 */

public class Activity_dispute_select extends AppCompatActivity {
    private Toolbar toolbarTop;
    private TextView txtHeder;
    private TextView txtGenerateDispute;
    private TextView txtSelectDispute;
    private TextView txtEnterNBCNumber;
    private EditText edSearchNBCNumber;
    private TextView txtSelectEnquiryNumber;
    private TextView txtEnqDate;
    private TextView txtEnqNo;
    private TextView txtBS;
    private TextView txtQnt;
    private TextView txtCUR;
    private RecyclerView recyclerSalectEnquiry;
    private AdapterSelect_Dispute adapterSelectDispute;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id, user_token, branchID;
    AppGlobalData gbData;
    private boolean bdispute;
    private int idispute = 0;
    RelativeLayout rv_disputeList;
    List<DisputeType> disputetypeList;
    List<EnquiryData> enquiryList;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay_dispute);
        findViews();
        setFonts();

        getSharedPref();
        getEnquiry();


    }

    public class CallEnquirylistAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            /*if (Error_Message.equalsIgnoreCase("")) {


            }*/
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CallForKYCList();
            return "DONE";

        }

        private void CallForKYCList() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.GETREQUESTHISTORYCUSTOMER);
                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                   String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                  urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                //api call
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = null;
                try {
                   objdata = new JSONObject(CommonApi.GenerateDispute1);
                   // objdata = new JSONObject(myjsonstring);

                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        enquiryList = new ArrayList<EnquiryData>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            JSONArray jsonDataset1 = jsonObj.getJSONArray("requestProducts");
                            int numberOfProduct = jsonDataset1.length();
                            for (int i1 = 0; i1 < jsonDataset1.length(); i1++) {

                                Log.e("requestId", jsonObj.getString("requestId"));
                                EnquiryData objenq = new EnquiryData();
                                objenq.setRequestId(jsonObj.getString("requestId"));
                                objenq.setRequestType(jsonObj.getString("requestType"));
                                objenq.setRequestSourceCurrencyId(jsonObj.getString("requestSourceCurrencyId"));
                                objenq.setRequestTargetCurrencyId(jsonObj.getString("requestTargetCurrencyId"));
                                objenq.setRequestDeliveryMode(jsonObj.getString("requestDeliveryMode"));
                                objenq.setRequestAreaId(jsonObj.getString("requestAreaId"));
                                objenq.setRequestCityId(jsonObj.getString("requestCityId"));
                                objenq.setRequestStateId(jsonObj.getString("requestStateId"));
                                objenq.setRequestCountryId(jsonObj.getString("requestCountryId"));
                                objenq.setRequestLeadSourceId(jsonObj.getString("requestLeadSourceId"));
                                objenq.setRequestSourceRefId(jsonObj.getString("requestSourceRefId"));
                                objenq.setRequestLeadSourceId(jsonObj.getString("requestLeadSourceId"));
                                objenq.setRequestSourceRef(jsonObj.getString("requestSourceRef"));
                                objenq.setRequestNBC(jsonObj.getString("requestNBC"));
                                objenq.setRequestStateId(jsonObj.getString("requestStatusId"));
                                objenq.setRequestSMSStatusId(jsonObj.getString("requestSMSStatusId"));
                                objenq.setRequestEmailStatusId(jsonObj.getString("requestEmailStatusId"));
                                objenq.setRequestDisputeId(jsonObj.getString("requestDisputeId"));
                                objenq.setRequestWinnerFFMCId(jsonObj.getString("requestWinnerFFMCId"));
                                objenq.setRequestAcceptedBidId(jsonObj.getString("requestAcceptedBidId"));
                                objenq.setRequestBidAcceptedDateTime(jsonObj.getString("requestBidAcceptedDateTime"));
                                objenq.setRequestBidAcceptedSource(jsonObj.getString("requestBidAcceptedSource"));
                                objenq.setRequestOpraterId(jsonObj.getString("requestOpraterId"));
                                objenq.setRequestBidAcceptedUserId(jsonObj.getString("requestBidAcceptedUserId"));
                                objenq.setCreatedById(jsonObj.getString("createdById"));
                                objenq.setLastModifiedById(jsonObj.getString("lastModifiedById"));
                                objenq.setRequestLat(jsonObj.getString("requestLat"));
                                objenq.setRequestLong(jsonObj.getString("requestLong"));
                                objenq.setRequestUnixTime(jsonObj.getString("requestUnixTime"));
                                objenq.setDisputeId(jsonObj.getString("disputeId"));
                                objenq.setDisputeStatusId(jsonObj.getString("disputeStatusId"));
                                objenq.setRemaining(jsonObj.getString("remaining"));
                                objenq.setLastModifiedOn(jsonObj.getString("lastModifiedOn"));
                                objenq.setRequestUserId(jsonObj.getString("requestUserId"));
                                objenq.setUserName(jsonObj.getString("userName"));
                                objenq.setUserMobileNo(jsonObj.getString("userMobileNo"));
                                objenq.setRequestTypeName(jsonObj.getString("requestTypeName"));
                                objenq.setRequestDeliveryModeName(jsonObj.getString("requestDeliveryModeName"));
                                objenq.setRequestLeadSourceName(jsonObj.getString("requestLeadSourceName"));
                                objenq.setRequestStatusName(jsonObj.getString("requestStatusName"));
                                objenq.setRequestSourceCurrencyName(jsonObj.getString("requestSourceCurrencyName"));
                                objenq.setRequestTargetCurrencyName(jsonObj.getString("requestTargetCurrencyName"));
                                objenq.setLocationName(jsonObj.getString("locationName"));
                                JSONObject businessObject = jsonObj.getJSONObject("locationName");
                                objenq.setCountryName(businessObject.getString("countryName"));
                                objenq.setStateName(businessObject.getString("stateName"));
                                objenq.setCityName(businessObject.getString("cityName"));
                                objenq.setAreaName(businessObject.getString("areaName"));

                                JSONObject commisionobject = jsonObj.getJSONObject("commissionData");
                                objenq.setRequestQuantity1(commisionobject.getString("requestQuantity"));
                                objenq.setCommissionRate(commisionobject.getString("commissionRate"));



                                  /*  JSONObject jloc=jsonObj.getJSONObject("locationName");
                                    objenq.setCountryName(jloc.getJSONObject("countryName").toString());
                                    objenq.setStateName(jloc.getJSONObject("stateName").toString());
                                    objenq.setCityName(jloc.getJSONObject("cityName").toString());
*/


                                if (numberOfProduct == 1) {
                                    JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                                    String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                                    String requestQuantity = jsonObjectInner.getString("requestQuantity");
                                    String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");
                                    objenq.setRequestProductTypeId(requestProductTypeId);
                                    objenq.setRequestQuantity(requestQuantity);
                                    objenq.setRequestProductTypeName(requestProductTypeName);
                                    objenq.setRequestBids(jsonObj.getString("requestBids"));
                                    enquiryList.add(objenq);

                                }
                                if (numberOfProduct == 2) {
                                      /*  JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                                        String requestProductTypeId1 = jsonObjectInner.getString("requestProductTypeId");
                                        String requestQuantity1 = jsonObjectInner.getString("requestQuantity");
                                        String requestProductTypeName1 = jsonObjectInner.getString("requestProductTypeName");
                                        JSONObject jsonObjectInner2 = jsonDataset1.getJSONObject(1);
                                        String requestProductTypeId2 = jsonObjectInner2.getString("requestProductTypeId");
                                        String requestQuantity2 = jsonObjectInner2.getString("requestQuantity");
                                        String requestProductTypeName2 = jsonObjectInner2.getString("requestProductTypeName");
                                        //requestQuantity = Integer.toString(Integer.parseInt(requestQuantity1) + Integer.parseInt(requestQuantity2));
                                        // txtRequestData.setText("You are requested to " + requesttype + " " + requestQuantity + " " + requesttargetcurrency);
                                        objenq.setRequestProductTypeId1(requestProductTypeId1);
                                        objenq.setRequestQuantity1(requestQuantity1);
                                        objenq.setRequestProductTypeName1(requestProductTypeName1);

                                        objenq.setRequestProductTypeId2(requestProductTypeId2);
                                        objenq.setRequestQuantity2(requestQuantity2);
                                        objenq.setRequestProductTypeName2(requestProductTypeName2);
                                        objenq.setRequestBids(jsonObj.getString("requestBids"));*/

                                    JSONObject jsonObjectInner = jsonDataset1.getJSONObject(i1);
                                    String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                                    String requestQuantity = jsonObjectInner.getString("requestQuantity");
                                    String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");
                                    objenq.setRequestProductTypeId(requestProductTypeId);
                                    objenq.setRequestQuantity(requestQuantity);
                                    objenq.setRequestProductTypeName(requestProductTypeName);
                                    objenq.setRequestBids(jsonObj.getString("requestBids"));


                                    enquiryList.add(objenq);
                                }
                            }


                        }

                        adapterSelectDispute = new AdapterSelect_Dispute(Activity_dispute_select.this, enquiryList, new EnquiryOperations() {
                            @Override
                            public void OnRespondclick(int position, int selectdisputeid) {
                                if (idispute == 1) {
                                    Log.e("Generate Dispute", "Generate Dispute");
                                    Intent intent_generatedisp = new Intent(Activity_dispute_select.this, ActivityGenerate_Despute.class);
                                    String json = new Gson().toJson(enquiryList);
                                    intent_generatedisp.putExtra("enquiryListGson", json);
                                    intent_generatedisp.putExtra("position", position);
                                    startActivity(intent_generatedisp);
                                } else {
                                    if (idispute == 2) {
                                        Log.e("Recharge Queries", "Recharge Queries");
                                        Intent intent_rechage = new Intent(Activity_dispute_select.this, Activity_Recharge_Queries.class);
                                        intent_rechage.putExtra("generate", idispute);
                                        String json = new Gson().toJson(enquiryList);
                                        intent_rechage.putExtra("enquiryListGson", json);
                                        intent_rechage.putExtra("position", position);
                                        startActivity(intent_rechage);

                                    } else {
                                           /* if (idispute == 3) {
                                                Log.e("Technical issue", "Technical issue");
                                                Intent intent_rechage = new Intent(Activity_dispute_select.this, Activity_Recharge_Queries.class);
                                                intent_rechage.putExtra("generate", 2);
                                                startActivity(intent_rechage);

                                            }*/
                                    }
                                }

                            }
                        }, idispute);
                       runOnUiThread(new Runnable() {
                           @Override
                           public void run() {
                               recyclerSalectEnquiry.setAdapter(adapterSelectDispute);
                               adapterSelectDispute.notifyDataSetChanged();

                           }
                       });


                    } else {
                        if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                           // Error_Message = objdata.getString("message_text");
                            CommonUI.showAlert(Activity_dispute_select.this,getResources().getString(R.string.app_name),objdata.getString("message_text"));
                   /* runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mRecyclerView.setVisibility(View.GONE);
                            lv_nodoc.setVisibility(View.VISIBLE);
                        }
                    });*/

                        }
                    }


                } catch (Exception e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }


    public void getEnquiry() {

        edSearchNBCNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (edSearchNBCNumber.getText().toString().trim().equals("")) {
                    //write your code here
                    enquiryList.clear();
                    adapterSelectDispute.notifyDataSetChanged();
                } else {

                    if (gbData.isConnected(getApplicationContext())) {
                        CallEnquirylistAPI objcurrrencyAPI = new CallEnquirylistAPI();
                        objcurrrencyAPI.execute(CommonApi.GETREQUESTHISTORYCUSTOMER);
                    }else {
                        CommonUI.showAlert(Activity_dispute_select.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                    }


                }
            }
        });

    }


    public class CallDisputeAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

           // if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        disputetypeList = new ArrayList<DisputeType>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            DisputeType objProduct = new DisputeType();
                            objProduct.setCodevalue(jsonObj.getString("codeValue"));
                            objProduct.setCodeName(jsonObj.getString("codeName"));
                            objProduct.setCodeAtrribute(jsonObj.getString("codeAttribute"));

                            disputetypeList.add(objProduct);
                        }

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_dispute_select.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_dispute_select.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
                showDisputeAlertCustomDialognew();

            /*} else
                CommonUI.showAlert(Activity_dispute_select.this, getResources().getString(R.string.app_name), Error_Message);*/

            // progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CODELIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("codeType", "DISPUTETYPE");
                Log.e("codeType", "DISPUTETYPE");
                //  byte[] auth = (user_id + ":" + user_token).getBytes();

                // String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                //  urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
              /*  if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
*/
            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }

    private void showDisputeAlertCustomDialognew() {
        final Dialog dialog = new Dialog(Activity_dispute_select.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setText("Select Dispute Type");
        tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bdispute = false;
            }
        });


        if (disputetypeList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(Activity_dispute_select.this, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < disputetypeList.size(); i++) {
                choices.add(disputetypeList.get(i).getCodeName());
                currencyAdapter.add(disputetypeList.get(i).getCodeName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(Activity_dispute_select.this,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                txtSelectDispute.setText(disputetypeList.get(i).getCodeName());
                                                idispute = Integer.parseInt(disputetypeList.get(i).getCodevalue());
                                                bdispute = false;
                                                if (idispute == 3) {
                                                    Log.e("Technical issue", "Technical issue");
                                                    Intent intent_rechage = new Intent(Activity_dispute_select.this, Activity_Recharge_Queries.class);
                                                    intent_rechage.putExtra("generate", idispute);
                                                    startActivity(intent_rechage);

                                                }

                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");


    }

    private void findViews() {
        gbData = AppGlobalData.getInstance();
        gbData.setStatusBarColor(Activity_dispute_select.this, R.color.colorPrimaryDark);

        rv_disputeList = (RelativeLayout) findViewById(R.id.rv_disputeList);
        rv_disputeList.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (bdispute == false) {

                    if (disputetypeList == null || disputetypeList.size() <= 0) {
                        if (gbData.isConnected(getApplicationContext())) {
                            bdispute = true;
                            CallDisputeAPI objcurrrencyAPI = new CallDisputeAPI();
                            objcurrrencyAPI.execute(CommonApi.CODELIST);
                        } else
                            CommonUI.showAlert(Activity_dispute_select.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                    } else
                        showDisputeAlertCustomDialognew();
                }


                return false;
            }
        });
        toolbarTop = (Toolbar) findViewById(R.id.toolbar_top);
        txtHeder = (TextView) findViewById(R.id.txt_heder);
        txtGenerateDispute = (TextView) findViewById(R.id.txtGenerateDispute);
        txtSelectDispute = (TextView) findViewById(R.id.txtSelectDispute);
        txtEnterNBCNumber = (TextView) findViewById(R.id.txtEnterNBCNumber);
        edSearchNBCNumber = (EditText) findViewById(R.id.edSearchNBCNumber);
        txtSelectEnquiryNumber = (TextView) findViewById(R.id.txtSelectEnquiryNumber);
        txtEnqDate = (TextView) findViewById(R.id.txtEnqDate);
        txtEnqNo = (TextView) findViewById(R.id.txtEnqNo);
        txtBS = (TextView) findViewById(R.id.txtBS);
        txtQnt = (TextView) findViewById(R.id.txtQnt);
        txtCUR = (TextView) findViewById(R.id.txtCUR);
        recyclerSalectEnquiry = (RecyclerView) findViewById(R.id.recycler_SalectEnquiry);

        recyclerSalectEnquiry.setLayoutManager(new LinearLayoutManager(this));

    }

    private void setFonts() {
        txtGenerateDispute.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtGenerateDispute, FontData.font_robotoregular));
        txtEnterNBCNumber.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtEnterNBCNumber, FontData.font_robotoregular));
        txtSelectEnquiryNumber.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtSelectEnquiryNumber, FontData.font_robotoregular));
        txtSelectDispute.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtSelectDispute, FontData.font_robotoregular));
        edSearchNBCNumber.setTypeface(FontData.setFonts(Activity_dispute_select.this, edSearchNBCNumber, FontData.font_robotoregular));
        txtEnqDate.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtEnqDate, FontData.font_robotomedium));
        txtEnqNo.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtEnqNo, FontData.font_robotomedium));
        txtBS.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtBS, FontData.font_robotomedium));
        txtQnt.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtQnt, FontData.font_robotomedium));
        txtCUR.setTypeface(FontData.setFonts(Activity_dispute_select.this, txtCUR, FontData.font_robotomedium));

    }
}



