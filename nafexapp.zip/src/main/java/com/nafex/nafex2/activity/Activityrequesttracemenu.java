package com.nafex.nafex2.activity;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.BidAdapter;
import com.nafex.nafex2.adapters.CustomerRequestAdapter;
import com.nafex.nafex2.data.BidRequest;
import com.nafex.nafex2.data.CustomerRequest;
import com.nafex.nafex2.data.RequestBid;
import com.nafex.nafex2.interfaces.OnBidAccept;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Swarup on 10/26/2017.
 */

public class Activityrequesttracemenu extends AppCompatActivity {


    private ImageView imgNafexMenu;
    private TextView txtINR, txtDate;

    private TextView txtCountDown;
    private TextView txtRequestData;
    private TextView txtStatus;
    private TextView txtMessageName;
    private ImageView imgBack;
    ListView list_bids;
    int intprogress;
    String[] split;
    RelativeLayout rel_timer;
    LinearLayout linear_forex;


    private BidAdapter objBidAdapter;

    private CustomerRequestAdapter objcustAdapter;


    private CountDownTimer cdt, cdtHitApi;
    LinearLayout llMainView;
    TextView txtorderNo;
    Toolbar toolbar;
    RelativeLayout relative_button;

    private int SecondsCounter;
    SharedPreferences sharedpreferences;

    String NBC = "";
    //int RequestId, FFMCId;
    //String Status="";
    //int WinnerFFMCId;
    //int Quantity;
    //String Currency;
    BidRequest objRequest;
    String Source;

    List<RequestBid> bidList;

    List<CustomerRequest> bidCustReq;
    List<CustomerRequest> bidCustbidreates;
    double totalbidrate;


    private ProgressBar progressBar;
    AppGlobalData gbData;
    Context mContext = Activityrequesttracemenu.this;

    private int FIVE_SECONDS = 30000;

    int RefeshCountDown = 1000; //MS
    int RefreshCounter = 10; //Sec
    int RefeshAfter = 300000; //MS
    RelativeLayout linearOpen;
    String nbcsource;
    int requestid;
    int userids;
    String requesttargetcurrency = "";
    private CircularProgressBar circularProgressBar;
    int animationDuration = 500000; // 2500ms = 2,5s
    Handler handler;
    ProgressBar pg_circular;
    public String isfirsttime="false";
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requesttrace);

        gbData = AppGlobalData.getInstance();
        init();
        setTypeFace();
        getRequestTrace();
        // getCircularProgress();

        // NBC = getIntent().getStringExtra("NBC");
        //Source = getIntent().getStringExtra("Source");

        if (gbData.isConnected(getApplicationContext())) {
            CallRequestAPI objRequestAPI = new CallRequestAPI();
            objRequestAPI.execute(CommonApi.GETREQUEST);
        } else
            showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");


       /* if (NBC == null || NBC.equalsIgnoreCase(""))
            txtorderNo.setText("-");
        else {
            txtorderNo.setText("Order Number: " + NBC);

            if (gbData.isConnected(getApplicationContext())) {
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        CallRequestAPI objRequestAPI = new CallRequestAPI();
                        objRequestAPI.execute(CommonApi.GETREQUEST);
                        //Do something after 20 seconds
                        handler.postDelayed(this, 10000);
                    }
                }, 20000);  //the time is in miliseconds

            } else
                showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");
        }
*/


        //    callAsynchronousTask();


/*
        if (gbData.isConnected(getApplicationContext())) {
            handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    CallRequestAPI objRequestAPI = new CallRequestAPI();
                    objRequestAPI.execute(CommonApi.GETREQUEST);
                    //Do something after 20 seconds
                    handler.postDelayed(this, 1000);
                }
            }, 20000);  //the time is in miliseconds

        }*/


        SecondsCounter = RefreshCounter;

      /*  linearOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Activity_requesttrace.this,Activity_bidsuccess.class);
                startActivity(intent);
            }
        });*/
    }

    private void getCircularProgress() {
        // circularProgressBar = (CircularProgressBar) findViewById(R.id.circularProgressbar);
        // circularProgressBar.setProgressWithAnimation(65);

    }

    private void CountDownTimerTick(long millisUntilFinished) {

        long remaining = millisUntilFinished / RefeshCountDown;
        String disp = String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished),
                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))
        );
        // txtCountDown.setText(disp);
        txtCountDown.setText(disp);
        SecondsCounter = SecondsCounter - 1;

        if (SecondsCounter == 0) {
            SecondsCounter = RefreshCounter;
            intprogress = intprogress + 5;
            CallRequestAPI objRequestBidsAPI = new CallRequestAPI();
            objRequestBidsAPI.execute(CommonApi.REQUEST);
        }

    }


    private void getRequestTrace() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        NBC = sharedpreferences.getString(ConstantData.KEY_nbc, "");
        nbcsource = sharedpreferences.getString(ConstantData.KEY_requestType, "");
        requestid = sharedpreferences.getInt(ConstantData.KEY_requestid, 0);
        userids = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);

        if (nbcsource.equalsIgnoreCase("1")) {
            Source = "Buy";
        } else {
            if (nbcsource.equalsIgnoreCase("2")) {
                Source = "Sell";
            } else {
                if (nbcsource.equalsIgnoreCase("3")) {
                    Source = "Money Transfer";
                }
            }
        }

    }


    @Override
    public void onBackPressed() {
        if (cdtHitApi != null) {
            cdtHitApi.cancel();
        }

        finish();
    }

    public void init() {
        pg_circular = (ProgressBar) findViewById(R.id.myProgress);
        gbData.setStatusBarColor(Activityrequesttracemenu.this, R.color.colorPrimaryDark);

        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        txtINR = (TextView) findViewById(R.id.txtINR66);
        txtDate = (TextView) findViewById(R.id.txtInrDate);

        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        txtorderNo = (TextView) findViewById(R.id.txtorderNo);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        txtCountDown = (TextView) findViewById(R.id.txtCountDown);
        txtRequestData = (TextView) findViewById(R.id.txtRequestData);
        txtStatus = (TextView) findViewById(R.id.txtStatus);
        imgBack = (ImageView) findViewById(R.id.imgBack);
        list_bids = (ListView) findViewById(R.id.list_bids);
        txtMessageName = (TextView) findViewById(R.id.txtMessageName);
        linearOpen = (RelativeLayout) findViewById(R.id.linear_open);
        rel_timer= (RelativeLayout) findViewById(R.id.rel_timer);
        linear_forex= (LinearLayout) findViewById(R.id.linear_forex);


        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
       // txtMessageName.setText(sharedpreferences.getString(ConstantData.KEY_USERNAME, "") + ", you will see real time bids from various money changers on this page. Please stay logged in.");
        username=sharedpreferences.getString(ConstantData.KEY_USERNAME, "");
        setSupportActionBar(toolbar);
        //getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        objRequest = new BidRequest();


    }

    public void setTypeFace() {
        txtorderNo.setTypeface(FontData.setFonts(Activityrequesttracemenu.this, txtorderNo, FontData.font_robotomedium));
        txtCountDown.setTypeface(FontData.setFonts(Activityrequesttracemenu.this, txtCountDown, FontData.font_robotomedium));
        txtRequestData.setTypeface(FontData.setFonts(Activityrequesttracemenu.this, txtRequestData, FontData.font_robotoregular));
        txtStatus.setTypeface(FontData.setFonts(Activityrequesttracemenu.this, txtStatus, FontData.font_robotolight));
        txtMessageName.setTypeface(FontData.setFonts(Activityrequesttracemenu.this, txtMessageName, FontData.font_robotomedium));
        txtINR.setTypeface(FontData.setFonts(Activityrequesttracemenu.this, txtINR, FontData.font_robotoregular));
        txtDate.setTypeface(FontData.setFonts(Activityrequesttracemenu.this, txtDate, FontData.font_robotomedium));


    }


    public class CallRequestAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            String strNBC = "";
            Log.d("Response-requestid: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                JSONArray jsonArray;
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    JSONObject obj = objdata.getJSONObject("message_text");
                    requestid = Integer.parseInt(obj.getString("requestId"));
                    userids = Integer.parseInt(obj.getString("requestUserId"));
                    String requesttype = obj.getString("requestTypeName");
                    String requestcurrencyname = obj.getString("requestSourceCurrencyName");
                    String requesttarget = obj.getString("requestTargetCurrencyName");

                    txtorderNo.setText("Order Number: " + obj.getString("requestSourceRef"));


                    String requeststatusname = obj.getString("requestStatusName");
                    if (requeststatusname.equalsIgnoreCase("Open")) {
                        txtStatus.setText(requeststatusname);
                    } else {
                        txtStatus.setText(requeststatusname);

                    }
                    Log.e("lastModifiedOn",obj.getString("requestUnixTime"));
                    long time= Long.parseLong(obj.getString("requestUnixTime"));
                    String OUTPUT_DATE_FORMATE="MMM dd - h:mm a";
                    getDateFromUTCTimestamp(time,OUTPUT_DATE_FORMATE);

                    if (intprogress >= 100 ) {
                        if (txtCountDown.getText().toString().equalsIgnoreCase("00:00")) {
                            pg_circular.setProgress(100);

                        }
                    } else {
                        pg_circular.setProgress(intprogress);
                    }




                    try {
                        String[] split = obj.getString("remainingTime").split(":");
                        Log.e("split0", split[0]);
                        Log.e("split1", split[1]);

                        if(split[0].equalsIgnoreCase("00"))
                        {
                            intprogress = 100;
                            pg_circular.setProgress(100);

                        }else {


                            if (split[1].equalsIgnoreCase("04")) {
                                intprogress = 5;
                                pg_circular.setProgress(10);

                            } else {
                                if (split[1].equalsIgnoreCase("03")) {
                                    intprogress = 15;
                                    pg_circular.setProgress(20);

                                } else {
                                    if (split[1].equalsIgnoreCase("02")) {
                                        intprogress = 30;
                                        pg_circular.setProgress(35);

                                    } else {
                                        if (split[1].equalsIgnoreCase("01")) {
                                            intprogress = 50;
                                            pg_circular.setProgress(55);

                                        } else {
                                            if (split[1].equalsIgnoreCase("00")) {
                                                // intprogress = 100;
                                                //   pg_circular.setProgress(100);

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }catch (Exception e)
                    {
                        e.printStackTrace();
                    }


                    Log.e("intprogress", Integer.toString(intprogress));

                    if (isfirsttime.equalsIgnoreCase("false")) {
                        ObjectAnimator anim = ObjectAnimator.ofInt(pg_circular, "progress", 5, intprogress);
                        anim.setDuration(15000);
                        anim.setInterpolator(new AccelerateInterpolator());
                        anim.start();
                        //pg_circular.setProgress(intprogress +  10);

                        isfirsttime="true";
                        try {
                            String[] split = obj.getString("remainingTime").split(":");
                            Log.e("split0", split[0]);
                            Log.e("split1", split[1]);
                            if (split[1].equalsIgnoreCase("04")) {
                                intprogress = 5;
                                pg_circular.setProgress(10);

                            } else {
                                if (split[1].equalsIgnoreCase("03")) {
                                    intprogress = 15;
                                    pg_circular.setProgress(20);

                                } else {
                                    if (split[1].equalsIgnoreCase("02")) {
                                        intprogress = 30;
                                        pg_circular.setProgress(35);

                                    } else {
                                        if (split[1].equalsIgnoreCase("01")) {
                                            intprogress = 50;
                                            pg_circular.setProgress(55);

                                        }else
                                        {
                                            if(split[1].equalsIgnoreCase("00"))
                                            {
                                                // intprogress = 100;
                                                pg_circular.setProgress(100);

                                            }
                                        }
                                    }
                                }
                            }
                            if (Integer.parseInt(split[0]) == 0 && Integer.parseInt(split[1]) <= 5) {

                                if (!split[0].substring(0, 1).equalsIgnoreCase("-")) {
                                    txtCountDown.setText("00:00");
                                    intprogress = 5;


                                    if (cdtHitApi == null) {
                                        cdtHitApi = new CountDownTimer((Integer.parseInt(split[1]) * 60000 + 1000 * Integer.parseInt(split[2])), RefeshAfter) {

                                            public void onTick(long millisUntilFinished) {
                        /*    CallRequestBidsAPI objRequestBidsAPI = new CallRequestBidsAPI();
                            objRequestBidsAPI.execute(ConstantData.BIDLIST);*/
                                               /* CallRequestAPI objRequestAPI = new CallRequestAPI();
                                                objRequestAPI.execute(CommonApi.GETREQUEST);
*/
                                            }

                                            public void onFinish() {
                                                pg_circular.setProgress(100);

                                                txtCountDown.setText("00:00");

                                            }
                                        }.start();
                                    }
                                } else {
                                    txtCountDown.setText(split[1] + ":" + split[2]);
                                    //60000 * 5;
                                    cdt = new CountDownTimer((Integer.parseInt(split[1]) * 60000 + 1000 * Integer.parseInt(split[2])), RefeshCountDown) {

                                        public void onTick(long millisUntilFinished) {
                                            CountDownTimerTick(millisUntilFinished);
                                        }

                                        public void onFinish() {
                                            pg_circular.setProgress(100);

                                            txtCountDown.setText("00:00");
                                            //showAlert(getResources().getString(R.string.app_name), "All options are available below, please accept any one to proceed.");
                                            //showAlert(getResources().getString(R.string.app_name), "Unfortunately, no options came during five minutes. Nafex support team will contact you soon with options.");

                     /*   if (bidList != null && bidList.size() > 0)
                            txtMessageName.setText("All options are available below, please accept any one to proceed.");
                        else
                            txtMessageName.setText("Unfortunately, no options came during five minutes. Nafex support team will contact you soon with options.");*/

                                            if (cdtHitApi == null) {
                                                cdtHitApi = new CountDownTimer(60000 * 30, RefeshAfter) {

                                                    public void onTick(long millisUntilFinished) {
                                    /*CallRequestBidsAPI objRequestBidsAPI = new CallRequestBidsAPI();
                                    objRequestBidsAPI.execute(ConstantData.BIDLIST);*/

                                                    /*    CallRequestAPI objRequestAPI = new CallRequestAPI();
                                                        objRequestAPI.execute(CommonApi.GETREQUEST);*/


                                                    }

                                                    public void onFinish() {
                                                        pg_circular.setProgress(100);

                                                        txtCountDown.setText("00:00");
                                                    }
                                                }.start();
                                            }
                                        }
                                    }.start();
                                }
                            } else if (Integer.parseInt(split[0]) == 0 && Integer.parseInt(split[1]) < 30) {
                                pg_circular.setProgress(100);

                                txtCountDown.setText("00:00");

                                if (cdtHitApi == null) {
                                    cdtHitApi = new CountDownTimer((Integer.parseInt(split[1]) * 60000 + 1000 * Integer.parseInt(split[2])), RefeshAfter) {

                                        public void onTick(long millisUntilFinished) {
                                           /* CallRequestAPI objRequestAPI = new CallRequestAPI();
                                            objRequestAPI.execute(CommonApi.GETREQUEST);*/
                                        }

                                        public void onFinish() {
                                            pg_circular.setProgress(100);
                                            txtCountDown.setText("00:00");
                                        }
                                    }.start();
                                }
                            }


                        } catch (Exception e) {
                            // This can happen if you are trying to parse an invalid date, e.g., 25:19:12.
                            // Here, you should log the error and decide what to do next
                            e.printStackTrace();
                        }

                    }


                    String requestQuantity = "";
                    JSONArray jsonDataset1 = obj.getJSONArray("requestProducts");
                    int numberOfProduct = jsonDataset1.length();
                    if (numberOfProduct == 1) {
                        JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                        String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                        requestQuantity = jsonObjectInner.getString("requestQuantity");
                        String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");
                        if (requestProductTypeName.equalsIgnoreCase("Forex Card Reload")||requestProductTypeName.equalsIgnoreCase("Forex Card Encashment")){
                            txtMessageName.setText( username+ ",Thank you for your request. Our call center team will get in touch with you soon regards to your request.");
                            rel_timer.setVisibility(View.GONE);
                            linear_forex.setVisibility(View.VISIBLE);
                        }else {
                            txtMessageName.setText( username+ ", you will see real time bids from various money changers on this page. Please stay logged in.");

                            linear_forex.setVisibility(View.GONE);
                            rel_timer.setVisibility(View.VISIBLE);
                        }
                        Log.e("requestProductTypeId", requestProductTypeId);
                        Log.e("requestQuantity", requestQuantity);
                        Log.e("requestProductTypeName", requestProductTypeName);
                        txtRequestData.setText("You have requested to " + requesttype + " " + requestQuantity + " " + requesttargetcurrency);

                    }
                    if (numberOfProduct == 2) {
                        JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                        String requestProductTypeId1 = jsonObjectInner.getString("requestProductTypeId");
                        String requestQuantity1 = jsonObjectInner.getString("requestQuantity");
                        String requestProductTypeName1 = jsonObjectInner.getString("requestProductTypeName");
                        JSONObject jsonObjectInner2 = jsonDataset1.getJSONObject(1);
                        String requestProductTypeId2 = jsonObjectInner2.getString("requestProductTypeId");
                        String requestQuantity2 = jsonObjectInner2.getString("requestQuantity");
                        String requestProductTypeName2 = jsonObjectInner2.getString("requestProductTypeName");
                        requestQuantity = Integer.toString(Integer.parseInt(requestQuantity1) + Integer.parseInt(requestQuantity2));
                        txtRequestData.setText("You have requested to " + requesttype + " " + requestQuantity + " " + requesttargetcurrency);

                    }


                   /* for (int i = 0; i < jsonDataset1.length(); i++) {
                        JSONObject jsonObjectInner = jsonDataset1.getJSONObject(i);
                        String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                        requestQuantity = jsonObjectInner.getString("requestQuantity");
                        String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");
                        Log.e("requestProductTypeId", requestProductTypeId);
                        Log.e("requestQuantity", requestQuantity);
                        Log.e("requestProductTypeName", requestProductTypeName);
                        txtRequestData.setText("You are requested to " + requesttype + " " + requestQuantity + " " + requesttargetcurrency);
                    }*/


                    if (requesttype.equalsIgnoreCase("Buy")) {
                        requesttargetcurrency = requesttarget;
                        txtINR.setText(requestcurrencyname + " " + requestQuantity + " / " + requesttargetcurrency);

                    } else {
                        if (requesttype.equalsIgnoreCase("Sell")) {
                            requesttargetcurrency = requestcurrencyname;
                            txtINR.setText(requesttarget + " " + requestQuantity + " / " + requesttargetcurrency);

                        } else {
                            if (requesttype.equalsIgnoreCase("Money Transfer")) {
                                requesttargetcurrency = requesttarget;
                                txtINR.setText(requesttarget + " " + requestQuantity);
                            }
                        }
                    }

                    bidCustReq = new ArrayList<CustomerRequest>();
                    bidCustbidreates = new ArrayList<CustomerRequest>();
                    JSONArray jsonDataset2 = obj.getJSONArray("requestBids");
                    JSONObject jsonObjectInner = null;
                    CustomerRequest objBid = null;
                    for (int i = 0; i < jsonDataset2.length(); i++) {
                        jsonObjectInner = jsonDataset2.getJSONObject(i);
                        String bidid = jsonObjectInner.getString("bidId");
                        String bidFFMC = jsonObjectInner.getString("bidFFMCId");
                        String ffmc = jsonObjectInner.getString("ffmcAreaId");
                        String ffmcDistance = jsonObjectInner.getString("ffmcDistance");
                        String averageRate = jsonObjectInner.getString("averageRate");
                        String averageAmount = jsonObjectInner.getString("averageAmount");
                        String taxAmount = jsonObjectInner.getString("taxAmount");
                        String deliveryCharges = jsonObjectInner.getString("deliveryCharges");
                        String otherCharges = jsonObjectInner.getString("otherCharges");
                        String remittanceCharges = jsonObjectInner.getString("remittanceCharges");
                        String bidOperaterId = jsonObjectInner.getString("bidOperaterId");
                        String createdById = jsonObjectInner.getString("createdById");
                        String ffmcname = jsonObjectInner.getString("ffmcName");

                        String ffmcAreaName = jsonObjectInner.getString("ffmcAreaName");

                        objBid = new CustomerRequest();
                        objBid.setBidId(bidid);
                        objBid.setBidFFMCId(bidFFMC);
                        objBid.setFfmcAreaId(ffmc);
                        objBid.setFfmcDistance(ffmcDistance);
                        objBid.setAverageRate(averageRate);
                        objBid.setAverageAmount(averageAmount);
                        objBid.setTaxAmount(taxAmount);
                        objBid.setDeliveryCharges(deliveryCharges);
                        objBid.setOtherCharges(otherCharges);
                        objBid.setRemittanceCharges(remittanceCharges);
                        objBid.setBidOperaterId(bidOperaterId);
                        objBid.setCreatedById(createdById);
                        objBid.setFfmcAreaName(ffmcAreaName);

                        JSONArray jsonbidrates = jsonObjectInner.getJSONArray("bidRates");
                        if (jsonbidrates.length() > 0) {
                            int numberOfItemsInResp = jsonbidrates.length();
                            Log.e("numberOfItemsInResp", Integer.toString(numberOfItemsInResp));
                            JSONObject json;
                            double requestbidrate1 = 0;
                            double requestbidrate2 = 0;

                            if (numberOfItemsInResp == 1) {
                                json = jsonbidrates.getJSONObject(0);
                                requestbidrate1 = Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                totalbidrate = Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                Log.e("totalbidrate", Double.toString(totalbidrate));
                                Log.e("requestinr", String.valueOf(totalbidrate * Integer.parseInt(requestQuantity)));

                            }
                            if (numberOfItemsInResp == 2) {
                                JSONObject json1 = jsonbidrates.getJSONObject(0);
                                requestbidrate1 = Double.parseDouble(json1.getString("requestBidRate").toString().trim());
                                json = jsonbidrates.getJSONObject(1);
                                Double totalbidrates = requestbidrate1 + Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                totalbidrate = totalbidrates / 2;
                                Log.e("totalbidrate-2", Double.toString(totalbidrate));
                                Log.e("requestinr-2", String.valueOf(totalbidrate * Integer.parseInt(requestQuantity)));
                            }

                            for (int ins = 0; ins < numberOfItemsInResp; ins++) {
                                if (numberOfItemsInResp == 1) {
                                    json = jsonbidrates.getJSONObject(0);
                                    requestbidrate1 = Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                    totalbidrate = Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                    Log.e("totalbidrate", Double.toString(totalbidrate));
                                    Log.e("requestinr", String.valueOf(totalbidrate * Integer.parseInt(requestQuantity)));
                                    objBid.setReuestProductTypeId(json.getString("reuestProductTypeId"));
                                    objBid.setRequestQuantity(json.getString("requestQuantity"));
                                    objBid.setRequestBidRate(json.getString("requestBidRate"));

                                }
                                if (numberOfItemsInResp == 2) {
                                    JSONObject json1 = jsonbidrates.getJSONObject(0);
                                    requestbidrate1 = Double.parseDouble(json1.getString("requestBidRate").toString().trim());
                                    json = jsonbidrates.getJSONObject(1);
                                    Double totalbidrates = Double.parseDouble(json1.getString("requestBidRate").toString().trim()) + Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                    totalbidrate = totalbidrates / 2;
                                    Log.e("totalbidrate-2", Double.toString(totalbidrate));
                                    Log.e("requestinr-2", String.valueOf(totalbidrate * Integer.parseInt(requestQuantity)));
                                    objBid.setReuestProductTypeId(json.getString("reuestProductTypeId"));
                                    objBid.setRequestQuantity(json.getString("requestQuantity"));
                                    objBid.setRequestBidRate(Double.toString(Double.parseDouble(new DecimalFormat("##.####").format(totalbidrate))));

                                }


                                Log.e("ins", Integer.toString(ins));

                            }
                            bidCustReq.add(objBid);
                            String bidids=getMax(bidCustReq);
                            Log.e("maxvalue",bidids);
                            String minvalue=getMin(bidCustReq);
                            Log.e("minvalue",minvalue);



                        }

                    }

                    Collections.sort(bidCustReq, new Comparator<CustomerRequest>() {
                        @Override
                        public int compare(CustomerRequest p1, CustomerRequest p2) {
                            //return p1.getAverageRate()+"".compareTo(p2.getAverageRate()+""); //sort by age
                            return p1.getAverageRate().toString().compareTo(p2.getAverageRate().toString()); // if you want to short by name
                        }
                    });


                    if (requesttype.equalsIgnoreCase("Sell")){
                        /*Collections.sort(bidCustReq, new Comparator<CustomerRequest>() {
                            @Override
                            public int compare(CustomerRequest p1, CustomerRequest p2) {
                                //return p1.getAverageRate()+"".compareTo(p2.getAverageRate()+""); //sort by age
                                return p1.getAverageRate().toString().compareTo(p2.getAverageRate().toString()); // if you want to short by name
                            }
                        });*/
                        Collections.reverse(bidCustReq);

                    }


                    objcustAdapter = new CustomerRequestAdapter(mContext, bidCustReq, new OnBidAccept() {
                        @Override
                        public void onAcceptButtonClicked(int requestid, int requestBidId, int requestbidaccaptedsource, int requestbidaccepteduserid) {
                            Log.e("requestid", Integer.toString(requestid));
                            if (gbData.isConnected(getApplicationContext())) {
                                objRequest.setRequestId(requestid);
                                objRequest.setRequestBidId(requestBidId);
                                objRequest.setRequestBidAcceptedSource(requestbidaccaptedsource);
                                objRequest.setRequestBidAcceptedUserId(requestbidaccepteduserid);


                                CallAcceptBidAPI objRequestAPI = new CallAcceptBidAPI();
                                objRequestAPI.execute(CommonApi.ACCEPTBID);


                            }
                        }
                    }, requesttargetcurrency, totalbidrate, Integer.toString(requestid), userids,requesttype);
                    list_bids.setAdapter(objcustAdapter);
                    objcustAdapter.notifyDataSetChanged();
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {
            try {

                try {
                    URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.GETREQUEST);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    try {
                        JSONObject postDataParams = new JSONObject();
                        //  postDataParams.put("requestId", requestid);
                        postDataParams.put("requestId", requestid);
                        Log.e("params", postDataParams.toString());
                        urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                        urlConnection.setReadTimeout(15000 /* milliseconds */);
                        urlConnection.setConnectTimeout(15000 /* milliseconds */);
                        urlConnection.setDoInput(true);
                        urlConnection.setDoOutput(true);

                        OutputStream os = urlConnection.getOutputStream();
                        BufferedWriter writer = new BufferedWriter(
                                new OutputStreamWriter(os, "UTF-8"));
                        writer.write(gbData.getPostDataString(postDataParams));

                        writer.flush();
                        writer.close();
                        os.close();

                        int responseCode = urlConnection.getResponseCode();

                        if (responseCode == HttpsURLConnection.HTTP_OK) {
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                            StringBuilder stringBuilder = new StringBuilder();
                            String line;
                            while ((line = bufferedReader.readLine()) != null) {
                                stringBuilder.append(line).append("\n");
                            }
                            bufferedReader.close();
                            strResponse = stringBuilder.toString();
                            Log.e("Result", strResponse);
                        }
                    } finally {
                        urlConnection.disconnect();
                    }
                } catch (Exception e) {
                    Log.e("ERROR", e.getMessage(), e);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }


    }


    public String getMax(List <CustomerRequest> con){
        double max = Double.MIN_VALUE;
        String bidid="";
        for(int i=0; i<con.size(); i++){
            if(Double.parseDouble(con.get(i).getRequestBidRate()) > max){
                max = Double.parseDouble(con.get(i).getRequestBidRate());
                Log.e("position",Integer.toString(i));
                bidid=con.get(i).getBidId();

            }
        }
        return bidid;
    }
    public String getMin(List <CustomerRequest> con){
        double min = Double.MAX_VALUE;
        String bidid="";

        for(int i=0; i<con.size(); i++){
            if(Double.parseDouble(con.get(i).getRequestBidRate()) < min){
                min = Double.parseDouble(con.get(i).getRequestBidRate());
                Log.e("position",Integer.toString(i));
                bidid=con.get(i).getBidId();

            }
        }
        return bidid;
    }

    public class CallAcceptBidAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    Log.e("response", strResponse);
                    JSONArray jsonArray;
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                        //  handler.removeMessages(0);
                        if (cdtHitApi != null) {
                            cdtHitApi.cancel();
                        }
                        txtStatus.setText("Accepted");
                        showAlertwithOk(getResources().getString(R.string.app_name), objdata.getString("message_text"));


                        /*Intent i = new Intent(Activity_requesttrace.this, Activity_bidsuccess.class);
                        i.putExtra("NBC", NBC);
                        startActivity(i);
                        finish();*/

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                        showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    }
                } catch (JSONException e) {
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "No data received from server. Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";
                }
            } else
                showAlert(getResources().getString(R.string.app_name), Error_Message);

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.ACCEPTBID);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("requestId", objRequest.getRequestId());
                    postDataParams.put("requestBidId", objRequest.getRequestBidId());
                   // postDataParams.put("requestBidAcceptedSource", objRequest.getRequestBidAcceptedSource());
                    postDataParams.put("requestBidAcceptedSource","3");
                    postDataParams.put("requestBidAcceptedUserId", objRequest.getRequestBidAcceptedUserId());
                    Log.e("requestId", Integer.toString(objRequest.getRequestId()));
                    Log.e("requestBidId", Integer.toString(objRequest.getRequestBidId()));
                    Log.e("requestBidAcceptedSo", Integer.toString(objRequest.getRequestBidAcceptedSource()));
                    Log.e("requestBidAcceptedUse", Integer.toString(objRequest.getRequestBidAcceptedUserId()));

                    // Log.e("params",postDataParams.toString());

                    urlConnection.setRequestMethod(CommonApi.METHOD_POST);
                    urlConnection.setReadTimeout(15000 /* milliseconds */);
                    urlConnection.setConnectTimeout(15000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));
                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();

                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        //Log.e("Result", strResponse);
                    }
                } catch (Exception e) {
                    Log.e("ERROR", e.getMessage(), e);
                    Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in request accept. Please contact Nafex support team.";
            }

            return null;
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cdtHitApi != null)
            cdtHitApi.cancel();


    }

    private void showAlert(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                       /* Intent i = new Intent(Activity_requesttrace.this, Activity_bidsuccess.class);
                        i.putExtra("NBC", NBC);
                        startActivity(i);
                        finish();
*/
                        // continue with delete
                    }
                })

                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void showAlertwithOk(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(Activityrequesttracemenu.this, Activity_bidsuccess.class);
                        i.putExtra("source", "requeststatus");

                        i.putExtra("requestId", requestid);
                        startActivity(i);
                        finish();
                    }
                })

                .setIcon(R.drawable.ic_error)
                .show();
    }


    public String getDateFromUTCTimestamp(long mTimestamp, String mDateFormate) {
        String date = null;
        try {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+05:30"));
            cal.setTimeInMillis(mTimestamp * 1000L);
            date = DateFormat.format(mDateFormate, cal.getTimeInMillis()).toString();

            SimpleDateFormat formatter = new SimpleDateFormat(mDateFormate);
            formatter.setTimeZone(TimeZone.getTimeZone("GMT+05:30"));
            Date value = formatter.parse(date);

            SimpleDateFormat dateFormatter = new SimpleDateFormat(mDateFormate);
            dateFormatter.setTimeZone(TimeZone.getDefault());
            date = dateFormatter.format(value);
            txtDate.setText(date);
            return date;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }


}
