package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;
import com.nafex.nafex2.utilities.Validation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;



/**
 * Created by rahul on 9/9/17.
 */

public class Activity_ForgotPassword extends AppCompatActivity implements View.OnClickListener{

    private TextView txtforgotpwdtext;
    private TextView txtenteremailtext;
    private EditText txtUserEmail;
    private RelativeLayout btnSend;
    private TextView txtsend;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    private AppGlobalData gbData;
    ProgressDialog pd_login;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpassword);
        findViews();
        setTypeface();
        clickListener();
    }

    private void clickListener() {
        btnSend.setOnClickListener(this);
        txtsend.setOnClickListener(this);
    }


    private void setTypeface() {
        txtUserEmail.setTypeface(FontData.setFonts(Activity_ForgotPassword.this, txtUserEmail, FontData.font_robotoregular));
        txtenteremailtext.setTypeface(FontData.setFonts(Activity_ForgotPassword.this, txtenteremailtext, FontData.font_robotolight));
        txtsend.setTypeface(FontData.setFonts(Activity_ForgotPassword.this, txtsend, FontData.font_robotoregular));
        txtforgotpwdtext.setTypeface(FontData.setFonts(Activity_ForgotPassword.this, txtUserEmail, FontData.font_robotoregular));
    }


    /**
     *initialization of views
     */
    private void findViews() {
        pd_login = new ProgressDialog(Activity_ForgotPassword.this);

        txtforgotpwdtext = (TextView)findViewById( R.id.txtforgotpwdtext );
        txtenteremailtext = (TextView)findViewById( R.id.txtenteremailtext );
        txtUserEmail = (EditText)findViewById( R.id.txtUseEmail );
        btnSend = (RelativeLayout)findViewById( R.id.btnSend );
        txtsend = (TextView)findViewById( R.id.txt_send );
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();

        gbData = AppGlobalData.getInstance();
        gbData.setStatusBarColor(Activity_ForgotPassword.this, R.color.colorPrimaryDark);
    }

    private void HideKeybaord() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {

            case R.id.btnSend:
            case R.id.txt_send:
                HideKeybaord();

                if (gbData.isConnected(Activity_ForgotPassword.this)) {
                    if (validateData()) {
                        CallForgotPasswordLoginApi objRequestAPI = new CallForgotPasswordLoginApi();
                        objRequestAPI.execute(CommonApi.CUSTOMER_ForgotPassword);
                    }
                } else {
                    CommonUI.showAlert(Activity_ForgotPassword.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                }

                break;


        }
    }

    /*
     ForgotPassword Api
     */
    public class CallForgotPasswordLoginApi extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

           // if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        showAlert(Activity_ForgotPassword.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_ForgotPassword.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_ForgotPassword.this, getResources().getString(R.string.app_name), Error_Message);*/
                }
            /*} else
                CommonUI.showAlert(Activity_ForgotPassword.this, getResources().getString(R.string.app_name), Error_Message);*/

            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_ForgotPassword);
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("userEmail", txtUserEmail.getText().toString().trim());
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage() , e);
              /*  if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
               // Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }



    private boolean validateData() {
        String sUserEmail = txtUserEmail.getText().toString().trim();
        if (sUserEmail.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter email address.");
        else if (!Validation.isEmailAddress(txtUserEmail, true))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid email address. Please enter proper email address.");
        else
            return true;


        return false;
    }


    public  void showAlert(Context mycontext, String title, String message) {
        new AlertDialog.Builder(mycontext)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        txtUserEmail.setText(null);
                        finish();
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })

                .show();
    }


}
