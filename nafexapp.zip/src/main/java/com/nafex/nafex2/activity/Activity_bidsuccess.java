package com.nafex.nafex2.activity;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.adapters.CustomerRequestAdapter;
import com.nafex.nafex2.data.CustomerRequest;
import com.nafex.nafex2.interfaces.OnBidAccept;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class Activity_bidsuccess extends AppCompatActivity {

    // txtRequestData, txtRequestDate,
    private TextView txtCongratulation, txtRequestData1, txtServiceTax, txtMessage, txtThank, txtpleaseNote, txtINR, txtST,
            txtOurRBI, txtDiss, txtOther, txt1, txt2, txt3, txt4, txt5, txtWantTo, txtWantToPay, plusdelivarycongo, txt_bidsoper;

    private TextView txtStatus,plusnew;
    private ImageView imgBack;
    private RelativeLayout relative_button;
    private RelativeLayout relative_button_uploadKYC;
    private LinearLayout kyc_info,linear_del_new;
    private TextView txtAmountOffered,txt_bidsoper1,txttax,txtdelivery,plusdelivary,txtothercharges;



    LinearLayout llMainView, layMessageName, layConfirmation,bidSuccess;
    TextView txtorderNo;
    Toolbar toolbar;
    private TextView txtRateOffered,txtAreaOffered,txt_distance;

    SharedPreferences sharedpreferences;

    int requestId;
    int RequestId, FFMCId;
    String Status = "";
    int WinnerFFMCId;
    int Quantity;
    String Currency;
    String sUserName;

    private ProgressBar progressBar;
    AppGlobalData gbData;
    Context mContext = Activity_bidsuccess.this;
    ArrayList<CustomerRequest> object;
    Double totalbidrate;
    String requesttargetcurrency;
    String strsource;
    LinearLayout lv_kycoptions;
    LinearLayout lybidconfirmation,lybidcanceled;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bidsuccess_n);

        gbData = AppGlobalData.getInstance();
        init();
        setTypeface();


        requestId = getIntent().getIntExtra("requestId", 0);
        strsource = getIntent().getStringExtra("source");
       /* if(strsource.equalsIgnoreCase("history"))
        {
            lv_kycoptions.setVisibility(View.GONE);
            toolbar.setVisibility(View.VISIBLE);

        }else
        {
            toolbar.setVisibility(View.GONE);
            lv_kycoptions.setVisibility(View.VISIBLE);

        }
*/
        if (gbData.isConnected(getApplicationContext())) {
            CallRequestAPI objRequestAPI = new CallRequestAPI();
            objRequestAPI.execute(CommonApi.GETREQUEST);
        } else
            showAlert(getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");


        relative_button_uploadKYC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Activity_bidsuccess.this, Activity_Kyc_Listing.class);
                startActivity(intent);
            }
        });
        if (sharedpreferences.getString(ConstantData.KEY_USERROLE_LFFCMLOGIN,"").equalsIgnoreCase("7")){
            lv_kycoptions.setVisibility(View.GONE);
            txtpleaseNote.setVisibility(View.GONE);
            kyc_info.setVisibility(View.GONE);

        }
        else {
            lv_kycoptions.setVisibility(View.VISIBLE);
            txtpleaseNote.setVisibility(View.VISIBLE);
            kyc_info.setVisibility(View.VISIBLE);
        }

    }
    public void onBackPressed() {
        if (sharedpreferences.getString(ConstantData.KEY_USERROLE_LFFCMLOGIN,"").equalsIgnoreCase("7")){
           Intent intent=new Intent(Activity_bidsuccess.this,activity_enquiries.class);
           startActivity(intent);
           finish();
        }
        else {
            Intent i = new Intent(Activity_bidsuccess.this, Activity_main.class);
            startActivity(i);
            finish();
        }

    }

    public class CallRequestAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            String strNBC = "";
            Log.d("Response-requestid: ", strResponse);
            try {
                JSONObject objdata = new JSONObject(strResponse);
                JSONArray jsonArray;
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    JSONObject obj = objdata.getJSONObject("message_text");


                   /* if (sharedpreferences.getString(ConstantData.KEY_USERROLE_LFFCMLOGIN,"").equalsIgnoreCase("7")){
                        txtCongratulation.setText("Congratulations " + obj.getString("userName")+", you will get a call from Nafex.com representative & the RBI licensed Money Changer to fulfill your transaction.");
                    }*/

                    txtCongratulation.setText(obj.getString("userName")+", you will get a call from Nafex.com representative & the RBI licensed Money Changer to fulfill your transaction.");


                    String requesttype = obj.getString("requestTypeName");
                    String requestcurrencyname = obj.getString("requestSourceCurrencyName");
                    String requesttarget = obj.getString("requestTargetCurrencyName");
                    String requestAcceptedBidId = obj.getString("requestAcceptedBidId");
                    String requestWinnerFFMCID = obj.getString("requestWinnerFFMCId");


                    String requestQuantity = "";
                    JSONArray jsonDataset1 = obj.getJSONArray("requestProducts");
                    int numberOfProduct = jsonDataset1.length();
                    if (numberOfProduct == 1) {
                        JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                        String requestProductTypeId = jsonObjectInner.getString("requestProductTypeId");
                        requestQuantity = jsonObjectInner.getString("requestQuantity");
                        String requestProductTypeName = jsonObjectInner.getString("requestProductTypeName");
                        Log.e("requestProductTypeId", requestProductTypeId);
                        Log.e("requestQuantity", requestQuantity);
                        Log.e("requestProductTypeName", requestProductTypeName);

                    }
                    if (numberOfProduct == 2) {
                        JSONObject jsonObjectInner = jsonDataset1.getJSONObject(0);
                        String requestProductTypeId1 = jsonObjectInner.getString("requestProductTypeId");
                        String requestQuantity1 = jsonObjectInner.getString("requestQuantity");
                        String requestProductTypeName1 = jsonObjectInner.getString("requestProductTypeName");
                        JSONObject jsonObjectInner2 = jsonDataset1.getJSONObject(1);
                        String requestProductTypeId2 = jsonObjectInner2.getString("requestProductTypeId");
                        String requestQuantity2 = jsonObjectInner2.getString("requestQuantity");
                        String requestProductTypeName2 = jsonObjectInner2.getString("requestProductTypeName");
                        requestQuantity = Integer.toString(Integer.parseInt(requestQuantity1) + Integer.parseInt(requestQuantity2));

                    }
                    txtorderNo.setText("Order Number: " + obj.getString("requestSourceRef"));
                    String requeststatusname = obj.getString("requestStatusName");
                    if (requeststatusname.equalsIgnoreCase("Open")) {
                        lybidcanceled.setVisibility(View.GONE);
                        lybidconfirmation.setVisibility(View.VISIBLE);
                        bidSuccess.setVisibility(View.VISIBLE);
                        txtStatus.setText(requeststatusname);
                    } else {
                        if(requeststatusname.equalsIgnoreCase("Accepted"))
                        {
                            lybidcanceled.setVisibility(View.GONE);
                            lybidconfirmation.setVisibility(View.VISIBLE);
                            bidSuccess.setVisibility(View.VISIBLE);
                            txtStatus.setText(requeststatusname);

                        }else
                        {
                            if(requeststatusname.equalsIgnoreCase("Expired"))
                            {
                                lybidcanceled.setVisibility(View.VISIBLE);
                                lybidconfirmation.setVisibility(View.GONE);
                                bidSuccess.setVisibility(View.GONE);
                                txtStatus.setText(requeststatusname);

                            }
                        }

                    }


                    if (requesttype.equalsIgnoreCase("Buy")) {
                        requesttargetcurrency = requesttarget;
                        //txtINR.setText(requestcurrencyname + " " + requestQuantity + " / " + requesttargetcurrency);

                    } else {
                        if (requesttype.equalsIgnoreCase("Sell")) {
                            requesttargetcurrency = requestcurrencyname;
                            // txtINR.setText(requesttarget + " " + requestQuantity + " / " + requesttargetcurrency);

                        } else {
                            if (requesttype.equalsIgnoreCase("Money Transfer")) {
                                requesttargetcurrency = requesttarget;
                                //  txtINR.setText(requesttarget + " " + requestQuantity);
                            }
                        }
                    }


                    JSONArray jsonDataset2 = obj.getJSONArray("requestBids");
                    JSONObject jsonObjectInner = null;
                    CustomerRequest objBid = null;
                    for (int i = 0; i < jsonDataset2.length(); i++) {
                        jsonObjectInner = jsonDataset2.getJSONObject(i);
                        String bidid = jsonObjectInner.getString("bidId");
                        String bidFFMC = jsonObjectInner.getString("bidFFMCId");
                        String ffmc = jsonObjectInner.getString("ffmcAreaId");
                        String ffmcDistance = jsonObjectInner.getString("ffmcDistance");
                        String averageRate = jsonObjectInner.getString("averageRate");
                        String averageAmount = jsonObjectInner.getString("averageAmount");
                        String taxAmount = jsonObjectInner.getString("taxAmount");
                        String deliveryCharges = jsonObjectInner.getString("deliveryCharges");
                        String otherCharges = jsonObjectInner.getString("otherCharges");
                        String remittanceCharges = jsonObjectInner.getString("remittanceCharges");
                        String bidOperaterId = jsonObjectInner.getString("bidOperaterId");
                        String createdById = jsonObjectInner.getString("createdById");
                        String ffmcname = jsonObjectInner.getString("ffmcName");
                        String ffmcAreaName = jsonObjectInner.getString("ffmcAreaName");


                        if(bidFFMC.equalsIgnoreCase(requestWinnerFFMCID)) {
                            txt_distance.setText(ffmcDistance);
                            txtAreaOffered.setText(ffmcAreaName);


                            txtST.setText("GST: " + taxAmount);
                            txttax.setText("GST: " + taxAmount);
                            if (Float.parseFloat(deliveryCharges) == 0) {
                                txtDiss.setVisibility(View.GONE);
                                plusdelivarycongo.setVisibility(View.GONE);
                                txtdelivery.setVisibility(View.GONE);
                                plusdelivary.setVisibility(View.GONE);
                                linear_del_new.setVisibility(View.GONE);
                            }
                            txtDiss.setText("Delivery Charges: " + deliveryCharges);
                            txtOther.setText("Handling Charges: " + otherCharges);
                            txtINR.setText("INR " + averageAmount);
                            txtAmountOffered.setText("INR " + averageAmount);
                            txtdelivery.setText("Delivery Charges: " + deliveryCharges);
                            txtothercharges.setText("Handling Charges: " + otherCharges);

                            if (requesttype.equalsIgnoreCase("Buy")) {
                                txt_bidsoper.setText("+");
                                txt_bidsoper1.setText("+");
                            } else {
                                if (requesttype.equalsIgnoreCase("Sell")) {
                                    txt_bidsoper.setText("-");
                                    txt_bidsoper1.setText("-");

                                }
                            }
                            if (sharedpreferences.getString(ConstantData.KEY_USERROLE_LFFCMLOGIN,"").equalsIgnoreCase("7")){
                                txtST.setVisibility(View.GONE);
                                txttax.setVisibility(View.GONE);
                               // txtDiss.setVisibility(View.GONE);
                                txtOther.setVisibility(View.GONE);
                               // txtdelivery.setVisibility(View.GONE);
                                txtothercharges.setVisibility(View.GONE);
                                txt_bidsoper.setVisibility(View.GONE);
                                txt_bidsoper1.setVisibility(View.GONE);
                                plusnew.setVisibility(View.GONE);
                            }
                            else {
                                txtST.setVisibility(View.VISIBLE);
                                txttax.setVisibility(View.VISIBLE);
                                // txtDiss.setVisibility(View.GONE);
                                txtOther.setVisibility(View.VISIBLE);
                                // txtdelivery.setVisibility(View.GONE);
                                txtothercharges.setVisibility(View.VISIBLE);
                                txt_bidsoper.setVisibility(View.VISIBLE);
                                txt_bidsoper1.setVisibility(View.VISIBLE);
                                plusnew.setVisibility(View.VISIBLE);
                            }

                        }
                        JSONArray jsonbidrates = jsonObjectInner.getJSONArray("bidRates");
                        if (jsonbidrates.length() > 0) {
                            int numberOfItemsInResp = jsonbidrates.length();
                            Log.e("numberOfItemsInResp", Integer.toString(numberOfItemsInResp));
                            JSONObject json;
                            double requestbidrate1 = 0;
                            double requestbidrate2 = 0;
                            if (requestAcceptedBidId.equalsIgnoreCase(bidid)) {
                                if (numberOfItemsInResp == 1) {
                                    json = jsonbidrates.getJSONObject(0);
                                    requestbidrate1 = Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                    totalbidrate = Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                    Log.e("totalbidrate", Double.toString(totalbidrate));
                                    Log.e("requestinr", String.valueOf(totalbidrate * Integer.parseInt(requestQuantity)));
                                    txtRequestData1.setText(  averageRate + "/ " + requesttargetcurrency);
                                    txtRateOffered.setText("INR " + averageRate + "/ " + requesttargetcurrency);


                                }
                                if (numberOfItemsInResp == 2) {
                                    JSONObject json1 = jsonbidrates.getJSONObject(0);
                                    Double requestbidrate1db = Double.parseDouble(json1.getString("requestBidRate").toString().trim());
                                    json = jsonbidrates.getJSONObject(1);
                                    Double totalbidrates = requestbidrate1db + Double.parseDouble(json.getString("requestBidRate").toString().trim());
                                    Double totalbidrate = totalbidrates / 2;
                                    Log.e("totalbidrate-2", Double.toString(totalbidrate));
                                    Log.e("requestinr-2", String.valueOf(totalbidrate * Integer.parseInt(requestQuantity)));
                                    txtRequestData1.setText(averageRate + "/ " + requesttargetcurrency);
                                    txtRateOffered.setText("INR " + averageRate + "/ " + requesttargetcurrency);

                                }

                            }
                        }


                    }


                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {
            try {

                try {
                    URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.GETREQUEST);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    try {
                        JSONObject postDataParams = new JSONObject();
                        //  postDataParams.put("requestId", requestid);
                        postDataParams.put("requestId", requestId);
                        Log.e("params", postDataParams.toString());
                        urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                        urlConnection.setReadTimeout(60000 /* milliseconds */);
                        urlConnection.setConnectTimeout(60000 /* milliseconds */);
                        urlConnection.setDoInput(true);
                        urlConnection.setDoOutput(true);

                        OutputStream os = urlConnection.getOutputStream();
                        BufferedWriter writer = new BufferedWriter(
                                new OutputStreamWriter(os, "UTF-8"));
                        writer.write(gbData.getPostDataString(postDataParams));

                        writer.flush();
                        writer.close();
                        os.close();

                        int responseCode = urlConnection.getResponseCode();

                        if (responseCode == HttpsURLConnection.HTTP_OK) {
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                            StringBuilder stringBuilder = new StringBuilder();
                            String line;
                            while ((line = bufferedReader.readLine()) != null) {
                                stringBuilder.append(line).append("\n");
                            }
                            bufferedReader.close();
                            strResponse = stringBuilder.toString();
                            Log.e("Result", strResponse);
                        }
                    } finally {
                        urlConnection.disconnect();
                    }
                } catch (Exception e) {
                    Log.e("ERROR", e.getMessage(), e);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }




    public void init() {
        txtorderNo = (TextView) findViewById(R.id.txtorderNo);
        lv_kycoptions = (LinearLayout) findViewById(R.id.lv_kycoptions);
        lybidconfirmation=(LinearLayout)findViewById(R.id.layConfirmation);
        lybidcanceled=(LinearLayout)findViewById(R.id.ly_canceled);
        gbData.setStatusBarColor(Activity_bidsuccess.this, R.color.colorPrimaryDark);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        relative_button = (RelativeLayout) findViewById(R.id.relative_button);
        layConfirmation = (LinearLayout) findViewById(R.id.layConfirmation);
        layMessageName = (LinearLayout) findViewById(R.id.layMessageName);
        txtRateOffered= (TextView) findViewById(R.id.txtRateOffered);
        txt_distance= (TextView) findViewById(R.id.txt_distance);
        txtAreaOffered= (TextView) findViewById(R.id.txtAreaOffered);
        plusnew=(TextView) findViewById(R.id.plusnew1);

        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        relative_button_uploadKYC = (RelativeLayout) findViewById(R.id.relative_button_uploadKYC);
        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        txtorderNo = (TextView) findViewById(R.id.txtorderNo);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        //txtRequestData = (TextView) findViewById(R.id.txtRequestData);
        txtStatus = (TextView) findViewById(R.id.txtStatus);
        imgBack = (ImageView) findViewById(R.id.imgBack);
        kyc_info= (LinearLayout) findViewById(R.id.kyc_cust);
        bidSuccess= (LinearLayout) findViewById(R.id.bidSuccess);


        txtMessage = (TextView) findViewById(R.id.txtMessageName);
        //txtRequestDate = (TextView) findViewById(R.id.txtRequestDate);


        txtCongratulation = (TextView) findViewById(R.id.txtCongratulation);
        txtRequestData1 = (TextView) findViewById(R.id.txtRequestData1);
        txtINR = (TextView) findViewById(R.id.congoInR);
        txtST = (TextView) findViewById(R.id.congoST);
        txtDiss = (TextView) findViewById(R.id.congoDiss);
        plusdelivarycongo = (TextView) findViewById(R.id.plusdelivarycongo);
        txtOther = (TextView) findViewById(R.id.congoOther);
        txtServiceTax = (TextView) findViewById(R.id.txtServiceTaxUpto);
        txtThank = (TextView) findViewById(R.id.txtThankYou);
        txtOurRBI = (TextView) findViewById(R.id.txtOurRBI);
        txtpleaseNote = (TextView) findViewById(R.id.pleaseNote);
        txt1 = (TextView) findViewById(R.id.txt1);
        txt2 = (TextView) findViewById(R.id.txt2);
        txt3 = (TextView) findViewById(R.id.txt3);
        txt4 = (TextView) findViewById(R.id.txt4);
        txt5 = (TextView) findViewById(R.id.txt5);
        txtWantTo = (TextView) findViewById(R.id.txtWantTo);
        txtWantToPay = (TextView) findViewById(R.id.txtWantToPay);
        txt_bidsoper = (TextView) findViewById(R.id.txt_bidsoper);
        txtAmountOffered= (TextView) findViewById(R.id.txtAmountOffered);
        txt_bidsoper1= (TextView) findViewById(R.id.txt_bidsoper1);
        txttax= (TextView) findViewById(R.id.txttax);
        txtdelivery= (TextView) findViewById(R.id.txtdelivery);
        plusdelivary= (TextView) findViewById(R.id.plusdelivary);
        txtothercharges= (TextView) findViewById(R.id.txtothercharges);
        linear_del_new= (LinearLayout) findViewById(R.id.linear_del_new);


        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        sUserName = sharedpreferences.getString(ConstantData.KEY_USERNAME, "");


        setSupportActionBar(toolbar);

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        relative_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    private void setTypeface() {
        txtorderNo.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtorderNo, FontData.font_robotomedium));
        txtStatus.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtStatus, FontData.font_robotolight));

        txtCongratulation.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtCongratulation, FontData.font_robotoregular));
        txtRequestData1.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtRequestData1, FontData.font_robotoregular));
        txtINR.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtINR, FontData.font_robotoregular));
        txtST.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtST, FontData.font_robotoregular));
        txtDiss.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtDiss, FontData.font_robotoregular));
        txtOther.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtOther, FontData.font_robotoregular));
        txtServiceTax.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtServiceTax, FontData.font_robotoregular));
        txtThank.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtThank, FontData.font_robotoBold));
        txtOurRBI.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtOurRBI, FontData.font_robotoregular));
        txtpleaseNote.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtpleaseNote, FontData.font_robotomedium));
        txt1.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txt1, FontData.font_robotoregular));
        txt2.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txt2, FontData.font_robotoregular));
        txt3.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txt3, FontData.font_robotoregular));
        txt4.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txt4, FontData.font_robotoregular));
        txt5.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txt5, FontData.font_robotoregular));
        txtWantTo.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtWantTo, FontData.font_robotoregular));
        txtWantToPay.setTypeface(FontData.setFonts(Activity_bidsuccess.this, txtWantToPay, FontData.font_robotoregular));


    }


    private void showAlert(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }

}
