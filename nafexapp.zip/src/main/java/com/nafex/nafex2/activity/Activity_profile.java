package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class Activity_profile extends AppCompatActivity implements View.OnClickListener {

    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    //private ImageView imgNafexMenu;
    private View navHeader;
    LinearLayout llMainView;
    Toolbar toolbar;

    private RelativeLayout relative_button;
    private ProgressBar progressBar;
    AppGlobalData gbData;
    Context mContext = Activity_profile.this;

    private String sUserName, sUserEmail, sUserMobileNo, sOldpassword, sNewpassword, sConfirmpassword;
    private EditText txtUserName, txtUserEmail, txtUserMobileNo;
    private int iUserId;
    String strtoken;

    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    EditText edtOldPassword, edtNewPassword, edtConfirmPassword;
    ImageView img_Tick;
    ProgressDialog pd_login;
    private RelativeLayout btnSubmitUpdateProfile;
    private TextView updateProfile,txtChangepwd;
    private RelativeLayout btnSubmitChangePassword;
    private TextView savePassword, txtProfile;
    TextView txtProfiletext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_n);
        init();
        clickListener();
        navigationDrawerLogic();
    }

    /*
     Navigation drawer login for login instance
     */
    private void navigationDrawerLogic() {

        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        if (iUserId == -1) {
            navigationView.inflateMenu(R.menu.menu_customer_new);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);

            setUpNavigationViewNewUser();
        } else {
            navigationView.inflateMenu(R.menu.menu_customer);
            navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);
            setUpNavigationView();
        }


    }


    /*
      click listner for all views
     */
    private void clickListener() {
        btnSubmitUpdateProfile.setOnClickListener(this);
        updateProfile.setOnClickListener(this);
        btnSubmitChangePassword.setOnClickListener(this);
        savePassword.setOnClickListener(this);
    }

    public void init() {
        gbData = AppGlobalData.getInstance();
        txtProfiletext= (TextView) findViewById(R.id.txtTrackYourOrder);
        txtProfiletext.setTypeface(FontData.setFonts(Activity_profile.this,txtProfiletext,FontData.font_robotomedium));
        txtProfile = (TextView) findViewById(R.id.txtprofile);
        btnSubmitUpdateProfile = (RelativeLayout) findViewById(R.id.btnSubmitUpdateProfile);
        updateProfile = (TextView) findViewById(R.id.updateProfile);
        btnSubmitChangePassword = (RelativeLayout) findViewById(R.id.btnSubmitChangePassword);
        savePassword = (TextView) findViewById(R.id.savePassword);
        txtChangepwd=(TextView)findViewById(R.id.txtChangepwd) ;

        gbData.setStatusBarColor(Activity_profile.this, R.color.colorPrimaryDark);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);

        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        //    relative_button = (RelativeLayout) findViewById(R.id.relative_button);
        pd_login = new ProgressDialog(Activity_profile.this);

        txtUserName = (EditText) findViewById(R.id.txtUserName);
        txtUserEmail = (EditText) findViewById(R.id.txtUserEmail);
        txtUserMobileNo = (EditText) findViewById(R.id.txtUserMobileNo);
        edtOldPassword = (EditText) findViewById(R.id.edt_OldPassword);
        edtNewPassword = (EditText) findViewById(R.id.edt_NewPassword);
        edtConfirmPassword = (EditText) findViewById(R.id.edt_ConfirmPassword);
        //img_Tick = (ImageView) findViewById(R.id.img_tick);
        //  img_Tick.setVisibility(View.GONE);
        setSupportActionBar(toolbar);
        setUpNavigationView();

        getSharedPref();
        setTypeface();

    }


    /*
     Custom typeface for views
     */
    private void setTypeface() {
        txtProfile.setTypeface(FontData.setFonts(Activity_profile.this, txtProfile, FontData.font_robotomedium));
        txtUserName.setTypeface(FontData.setFonts(Activity_profile.this, txtUserName, FontData.font_robotoregular));
        txtUserEmail.setTypeface(FontData.setFonts(Activity_profile.this, txtUserEmail, FontData.font_robotoregular));
        txtUserMobileNo.setTypeface(FontData.setFonts(Activity_profile.this, txtUserMobileNo, FontData.font_robotoregular));
        updateProfile.setTypeface(FontData.setFonts(Activity_profile.this, updateProfile, FontData.font_robotoregular));
        edtOldPassword.setTypeface(FontData.setFonts(Activity_profile.this, edtOldPassword, FontData.font_robotoregular));
        edtNewPassword.setTypeface(FontData.setFonts(Activity_profile.this, edtNewPassword, FontData.font_robotoregular));
        edtConfirmPassword.setTypeface(FontData.setFonts(Activity_profile.this, edtConfirmPassword, FontData.font_robotoregular));
        txtChangepwd.setTypeface(FontData.setFonts(Activity_profile.this, txtChangepwd, FontData.font_robotomedium));
    }

    /*
     Hide keyboard
     */
    private void HideKeybaord() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }


    /*
     Validation of Change Password
     */
    private boolean validatePassword() {
        sOldpassword = edtOldPassword.getText().toString().trim();
        sNewpassword = edtNewPassword.getText().toString().trim();
        sConfirmpassword = edtConfirmPassword.getText().toString().trim();

        if (sOldpassword.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Old Password.");
        else if (sNewpassword.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter New Password.");
        else if (sConfirmpassword.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Confirm  Password.");
        else if (!sNewpassword.equalsIgnoreCase(sConfirmpassword))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please Confirm New Password.");
        else
            return true;

        return false;
    }

    /*
      validation of Update profile
     */
    private boolean validateProfile() {
        sUserName = txtUserName.getText().toString();
         sUserEmail = txtUserEmail.getText().toString();
        sUserMobileNo = txtUserMobileNo.getText().toString();

        if (sUserName.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please provide your name.");
        else if (sUserEmail.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please provide email address.");
        else if (!sUserEmail.matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+"))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid Email. Please enter proper email address.");
        else if (sUserMobileNo.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please provide mobile no.");
        else if ((sUserMobileNo.length() < 10) || (sUserMobileNo.length() > 10))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid Mobile number! Please provide valid mobile number.");
        else
            return true;

        return false;
    }

    /*
     navigation drawer logic
     */
    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
                        Intent intentmain =new Intent(Activity_profile.this, Activity_main.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_trackorder:
                        Intent intenthistory = new Intent(Activity_profile.this, Activity_history.class);
                        intenthistory.putExtra("Source", "");
                        startActivity(intenthistory);
                        finish();
                        break;
                    case R.id.nav_profile:
                        /*Intent intentprofile = new Intent(Activity_profile.this, Activity_profile.class);
                        startActivity(intentprofile);
                        finish();*/
                        break;
                    case R.id.NBC_Details:
                        Intent intentNBC = new Intent(Activity_profile.this, Activity_KycList_NBC.class);
                        startActivity(intentNBC);
                        finish();
                        break;
                    case R.id.nav_kyc:
                        Intent intentprofile = new Intent(Activity_profile.this, Activity_Kyc_Listing_Menu.class);
                        startActivity(intentprofile);
                        finish();
                        break;
                    case R.id.nav_signout:
                        /*if (gbData.isConnected(Activity_profile.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(Activity_profile.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }*/
                        logoutApplication();
                        break;
                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }


    /*
     Dialog for logout application
     */
    public void logoutApplication()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(Activity_profile.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh=new Intent(Activity_profile.this,Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }


    /*
     Call for Logout functionality
     */
    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
           // if (Error_Message.equalsIgnoreCase("")) {

                logoutApplication();
            /*} else
                CommonUI.showAlert(Activity_profile.this, getResources().getString(R.string.app_name), Error_Message);
*/
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                   // Error_Message = objdata.getString("message_text");
                    CommonUI.showAlert(Activity_profile.this,getResources().getString(R.string.app_name),objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                /*if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
               // Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }


    private void setUpNavigationViewNewUser() {
        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_home:
//                        Intent intentmain =new Intent(Activity_main.this, Activity_main.class);
//                        startActivity(intentmain);
//                        finish();
                        break;
                    case R.id.nav_signIn:

                        Intent intenthistory = new Intent(Activity_profile.this, Activity_otpdashboard.class);
                        intenthistory.putExtra("Source", "NavLogin");
                        editor = sharedpreferences.edit();
                        editor.putString(ConstantData.ISLEFTLOGIN, "true");
                        editor.commit();
                        startActivity(intenthistory);
                        finish();

                        break;

                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();


    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSubmitUpdateProfile:
            case R.id.updateProfile:
                HideKeybaord();
                if (gbData.isConnected(Activity_profile.this)) {
                    if (validateProfile()) {
                        CallUpdateProfileAPI objRequestAPI = new CallUpdateProfileAPI();
                        objRequestAPI.execute(CommonApi.CUSTOMER_UPDATEPROFILE);
                    }
                } else {
                    CommonUI.showAlert(Activity_profile.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                }


                break;
            case R.id.btnSubmitChangePassword:
            case R.id.savePassword:
                HideKeybaord();
                if (gbData.isConnected(Activity_profile.this)) {
                    if (validatePassword()) {
                        CallChangePasswordAPI objRequestAPI = new CallChangePasswordAPI();
                        objRequestAPI.execute(CommonApi.CUSTOMER_CHANGEPWD);
                    }
                } else {
                    CommonUI.showAlert(Activity_profile.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                }

                break;


        }
    }


    /*
     Call for Updating profile
     */
    public class CallUpdateProfileAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Please Wait...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            String strNBC = "";

            if(Error_Message.equalsIgnoreCase("java.io.File Not FoundException"))
            {
             //call autologin api
/*

                if (gbData.isConnected(getApplicationContext())) {
                    CallMobileNoVerification objRequestAPI = new CallMobileNoVerification();
                    objRequestAPI.execute(CommonApi.CUSTOMER_CHECKEXIST);
                }
*/




            }else {

                //Log.d("Response: ", strResponse);
                if (Error_Message.equalsIgnoreCase("")) {
                    try {
                        JSONObject objdata = new JSONObject(strResponse);
                        JSONArray jsonArray;
                        if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                            // JSONObject obj = objdata.getJSONObject("message_text");

                            //  String strId = obj.getString("UserId");
                            setSharedPref(sUserName, sUserEmail, sUserMobileNo);
                            showAlertwithOk(getResources().getString(R.string.app_name), objdata.getString("message_text"));


                        } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                            showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                        }
                    } catch (JSONException e) {
                        Error_Message = "JSONError: Please contact Nafex support team.";
                        showAlert(getResources().getString(R.string.app_name), Error_Message);
                    }
                } else
                    showAlert(getResources().getString(R.string.app_name), Error_Message);
            }
            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_UPDATEPROFILE);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("userName", sUserName);
                    postDataParams.put("userEmail", sUserEmail);
                    postDataParams.put("userMobileNo", sUserMobileNo);
                    Log.e("params", postDataParams.toString());

                    byte[] auth = (iUserId + ":" + strtoken).getBytes();

                    String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                    urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(60000 /* milliseconds */);
                    urlConnection.setConnectTimeout(60000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();
                     Log.e("responseCode",Integer.toString(responseCode));
                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    }else
                    {
                        if(responseCode==400)
                        {
                            Error_Message="java.io.File Not FoundException";
                        }
                        if(responseCode==401)
                        {
                            Error_Message="java.io.File Not FoundException";
                        }
                    }
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";*/
                } catch (Exception e) {
                    //Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                    Log.e("ERROR", e.getMessage(), e);
                } /*finally {
                    urlConnection.disconnect();
                }*/
            } catch (Exception e) {
               // Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                Log.e("ERROR", e.getMessage(), e);
            }

            return null;
        }
    }


    public class CallMobileNoVerification extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           /* pd_login.setMessage("Please Wait...");
            pd_login.show();*/
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    Log.e("strResponse", strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        String regType = (String) objmsgtext.get("regType");
                        Log.e("regType", regType);
                        String userName = "";
                        String userMobileNo = "";
                        String userEmail = "";
                        String struserId = "";
                        String strusertoken = "";

                        if (regType.equalsIgnoreCase("autoLogin")) {
                            struserId = (String) objmsgtext.get("userId");
                            Log.e("userid", struserId);

                            userName = (String) objmsgtext.get("userName");
                            userMobileNo = (String) objmsgtext.get("userMobileNo");
                            userEmail = (String) objmsgtext.get("userEmail");
                        }

                        if (regType.equalsIgnoreCase("autoReg")) {
                            struserId = (String) objmsgtext.get("userId");
                            Log.e("userid", struserId);
                            setSharedPrefforSignup(struserId, userName, userEmail,txtUserMobileNo.getText().toString().trim() , regType);

                        } else {
                            setSharedPrefforSignup(struserId, userName, userEmail, userMobileNo, regType);
                            //already registered


                          /*  if (gbData.isConnected(getApplicationContext())) {
                                CallRequestAPI objRequestAPI = new CallRequestAPI();
                                objRequestAPI.execute(ConstantData.REQUEST);
                            } else
                                CommonUI.showAlert(Activity_main.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection and try again.");*/
                        }
                        CallUpdateProfileAPI objRequestAPI = new CallUpdateProfileAPI();
                        objRequestAPI.execute(CommonApi.CUSTOMER_UPDATEPROFILE);

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_profile.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(Activity_profile.this, getResources().getString(R.string.app_name), Error_Message);
                }
            } else
                CommonUI.showAlert(Activity_profile.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_CHECKEXIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("userMobileNo", txtUserMobileNo.getText().toString().trim());
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
              /*  if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }


    private void setSharedPrefforSignup(String id, String name, String email, String mobileno, String regtype) {
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_USERID, Integer.parseInt(id));
        editor.putString(ConstantData.KEY_USERNAME, name);
        editor.putString(ConstantData.KEY_USEREMAIL, email);
        editor.putString(ConstantData.KEY_USERMOBILENO, mobileno);
        editor.putString(ConstantData.KEY_REGTYPE, regtype);
        editor.commit();
    }



    private void setSharedPref(String username,String useremail,String usermobno) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putString(ConstantData.KEY_USERNAME, username);
        editor.putString(ConstantData.KEY_USEREMAIL, useremail);
        editor.putString(ConstantData.KEY_USERMOBILENO, usermobno);
        editor.commit();
    }

    private void setSharedPrefPassword(String oldpassword,String newpassword) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putString(ConstantData.KEY_OLDPASSWORD, oldpassword);
        editor.putString(ConstantData.KEY_NEWPASSWORD, newpassword);
        editor.commit();
    }



    /*
     Call for change Password
     */
    public class CallChangePasswordAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            String strNBC = "";
            //Log.d("Response: ", strResponse);
            if (Error_Message.equalsIgnoreCase("")) {
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    JSONArray jsonArray;
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        edtOldPassword.setText("");
                        edtNewPassword.setText("");
                        edtConfirmPassword.setText("");
                        showAlertwithOk(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                        showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                    }
                } catch (JSONException e) {
                    Error_Message = "JSONError: Please contact Nafex support team.";
                    showAlert(getResources().getString(R.string.app_name), Error_Message);
                }
            } else
                showAlert(getResources().getString(R.string.app_name), Error_Message);

            pd_login.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CUSTOMER_CHANGEPWD);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("oldPassword", edtOldPassword.getText().toString().trim());
                    postDataParams.put("newPassword", edtNewPassword.getText().toString().trim());
                    Log.e("params", postDataParams.toString());

                    byte[] auth = (iUserId + ":" + strtoken).getBytes();
                    String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                    urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(60000 /* milliseconds */);
                    urlConnection.setConnectTimeout(60000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();

                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    }else
                    {
                        if(responseCode==400)
                        {
                            Error_Message="java.io.File Not FoundException";
                        }
                        if(responseCode==401)
                        {
                            Error_Message="java.io.File Not FoundException";
                        }
                    }
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";
                } catch (Exception e) {
                    Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                    Log.e("ERROR", e.getMessage(), e);
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                Log.e("ERROR", e.getMessage(), e);
            }

            return null;
        }
    }


    private void showAlertwithOk(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(Activity_profile.this, Activity_main.class);
                        startActivity(i);
                        finish();
                    }
                })

                .setIcon(R.drawable.ic_error)
                .show();
    }

    private void showAlert(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                    }
                })

                .setIcon(R.drawable.ic_error)
                .show();
    }

   /* private void setSharedPref(int id) {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_USERID, id);
        editor.putString(ConstantData.KEY_USERNAME, sUserName);
        editor.putString(ConstantData.KEY_USEREMAIL, sUserEmail);
        editor.putString(ConstantData.KEY_USERMOBILENO, sUserMobileNo);
        editor.commit();
    }*/

    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        iUserId = sharedpreferences.getInt(ConstantData.KEY_USERID, -1);
        txtUserName.setText(sharedpreferences.getString(ConstantData.KEY_USERNAME, ""));
        txtUserEmail.setText(sharedpreferences.getString(ConstantData.KEY_USEREMAIL, ""));
        txtUserMobileNo.setText(sharedpreferences.getString(ConstantData.KEY_USERMOBILENO, ""));
        strtoken = sharedpreferences.getString(ConstantData.KEY_REGToken, "");

    }

}
