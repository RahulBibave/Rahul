package com.nafex.nafex2.activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Sunil on 1/16/2018.
 */

public class Activity_TravelAgent_Otp extends AppCompatActivity {
    private EditText mEdtOtp;
    private RelativeLayout mBtnSubmit;
    ProgressDialog pd_login;
    String mobile;
    String userid;
    private AppGlobalData gbData;
    TextView txt_Title;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverification);
        init();
        mBtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (gbData.isConnected(Activity_TravelAgent_Otp.this)) {
                    CallOtpVirification objRequestAPI = new CallOtpVirification();
                    objRequestAPI.execute();
                }else {
                    CommonUI.showAlert(Activity_TravelAgent_Otp.this,getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");

                }

            }
        });

    }

    private void init() {
        gbData = AppGlobalData.getInstance();
        mEdtOtp= (EditText) findViewById(R.id.edtOTPVerification);
        mBtnSubmit= (RelativeLayout) findViewById(R.id.btnCheck);
        txt_Title=(TextView)findViewById(R.id.txt_otpverification) ;
        txt_Title.setText("TRAVEL AGENT OTP VARIFICATION");
        pd_login = new ProgressDialog(Activity_TravelAgent_Otp.this);
         mobile = getIntent().getStringExtra("mobile");
         userid = getIntent().getStringExtra("userid");

    }


    public class CallOtpVirification extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd_login.setMessage("Loading...");
            pd_login.setCancelable(false);
            pd_login.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd_login.dismiss();
          //  if (Error_Message.equalsIgnoreCase("")) {
                //Log.e("Response: ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                        showAlert("Nafex","OTP Verified Successfully.\n Please check your email for password.");

                        /*Intent intentOtp=new Intent(Activity_TravelAgent_Otp.this,Activity_login.class);
                        startActivity(intentOtp);
*/
                       /* JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        String userId = (String) objmsgtext.get("userId");
                        String userName = (String) objmsgtext.get("userName");
                        String userMobileNo = (String) objmsgtext.get("userMobileNo");
                        String userEmail = (String) objmsgtext.get("userEmail");
                        String userToken = (String) objmsgtext.get("userToken");
                        setSharedPref(Integer.parseInt(userId), userName, userEmail, userMobileNo, userToken);

                        CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), "Profile created successfully!");*/

                     /*   if (strregtype.equalsIgnoreCase("autoReg")) {
                            if (strisleft.equalsIgnoreCase("false")) {
                                getSharedPref();
                                if (gbData.isConnected(getApplicationContext())) {
                                    Activity_signup.CallAddRequestApi objRequestAPI = new Activity_travel_Agent.CallAddRequestApi();
                                    objRequestAPI.execute(CommonApi.REQUEST);
                                }
                            }else
                            {
                                Intent int_main=new Intent(Activity_travel_Agent.this,Activity_main.class);
                                startActivity(int_main);
                                finish();
                            }
                            //call request api
                            Log.e("call request api", "call request api");
                        }*//* else {
                            if (strregtype.equalsIgnoreCase("autoReg")) {

                            }
                        }*/

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_TravelAgent_Otp.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (Exception e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";*/

                 //   CommonUI.showAlert(Activity_TravelAgent_Otp.this, getResources().getString(R.string.app_name), ""+e);
                }
            /*} else
                CommonUI.showAlert(Activity_TravelAgent_Otp.this, getResources().getString(R.string.app_name), Error_Message);*/


        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.TRAVAL_AGENT_OTP);
                urlConnection = (HttpURLConnection) url.openConnection();
                JSONObject postDataParams = new JSONObject();
               /* if (strisleft.equalsIgnoreCase("false")) {
                    postDataParams.put("regType", strregtype);
                } else {
                    postDataParams.put("regType", "self");
                }*/

                // postDataParams.put("regType", strregtype);
                postDataParams.put("userID", userid);
                postDataParams.put("taMobileNo",mobile);
                postDataParams.put("taOtp",mEdtOtp.getText().toString().trim());

                Log.e("userName", userid);
                Log.e("userMobileNo", mobile);
                Log.e("userEmail", mEdtOtp.getText().toString().trim());


                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {

               // CommonUI.showAlert(Activity_TravelAgent_Otp.this, getResources().getString(R.string.app_name), ""+e);
                //Log.e("ERROR", e.getMessage(), e);
            //   Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }



    public  void showAlert( String title, String message) {
        new AlertDialog.Builder(Activity_TravelAgent_Otp.this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        Intent intentOtp=new Intent(Activity_TravelAgent_Otp.this,Activity_login.class);
                        startActivity(intentOtp);
                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }


}
