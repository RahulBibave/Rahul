package com.nafex.nafex2.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;
import com.nafex.nafex2.utilities.Validation;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Sunil on 1/16/2018.
 */

public class Activity_travel_Agent extends AppCompatActivity implements PlaceSelectionListener {
    EditText edt_AgentName,edt_AgentCompany,edt_AgentPhoneNo,edt_AgentEmail,edt_AgentLocation;

    private static final LatLngBounds BOUNDS_MOUNTAIN_VIEW = new LatLngBounds(
            new LatLng(37.398160, -122.180831), new LatLng(37.430610, -121.972090));
    private static final int REQUEST_SELECT_PLACE = 1000;
    private boolean  bArea;
    String address;
    public String strlat;
    public String strlong;
    RelativeLayout btn_Register;
    TextView txtRegister;
    ProgressDialog pd_login;
    private AppGlobalData gbData;
    String areaLocation,agentCompany;
    private RelativeLayout mBtnScanCard;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_travel_agent);
        init();
        setTypeface();

      /*  edt_AgentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (bArea == false) {
                    bArea = true;
                    try {
                        AutocompleteFilter autocompleteFilter = new AutocompleteFilter.Builder()
                                .setTypeFilter(Place.TYPE_COUNTRY)
                                .setCountry("IN")
                                .build();
                        Intent intent = new PlaceAutocomplete.IntentBuilder
                                (PlaceAutocomplete.MODE_OVERLAY)
                                .setFilter(autocompleteFilter)
                                .setBoundsBias(BOUNDS_MOUNTAIN_VIEW)
                                .build(Activity_travel_Agent.this);
                        startActivityForResult(intent, REQUEST_SELECT_PLACE);

                    } catch (GooglePlayServicesRepairableException |
                            GooglePlayServicesNotAvailableException e) {
                        e.printStackTrace();
                    }
                    //showAreaAlertCustomDialog();
                }

            }
        });*/

        edt_AgentLocation.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (bArea == false) {
                    bArea = true;
                    try {
                        AutocompleteFilter autocompleteFilter = new AutocompleteFilter.Builder()
                                .setTypeFilter(Place.TYPE_COUNTRY)
                                .setCountry("IN")
                                .build();
                        Intent intent = new PlaceAutocomplete.IntentBuilder
                                (PlaceAutocomplete.MODE_OVERLAY)
                                .setFilter(autocompleteFilter)
                                .setBoundsBias(BOUNDS_MOUNTAIN_VIEW)
                                .build(Activity_travel_Agent.this);
                        startActivityForResult(intent, REQUEST_SELECT_PLACE);

                    } catch (GooglePlayServicesRepairableException |
                            GooglePlayServicesNotAvailableException e) {
                        e.printStackTrace();
                    }
                    //showAreaAlertCustomDialog();
                }
                return true;
            }
        });
        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent intent=new Intent(Activity_travel_Agent.this,Activity_TravelAgent_Otp.class);
                startActivity(intent);*/
               submitRegistartionForm();

            }
        });


        mBtnScanCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(new Intent(Activity_travel_Agent.this, MainActivity1.class),1);
                //startActivity(new Intent(this, MainActivity1.class));
               // startActivityForResult(intent,1);
            }
        });

    }


    private void submitRegistartionForm() {

      /*  getSharedPrefFprSignup();

        HideKeybaord();*/

      if (strlat==null){
          strlat="0";
      }
      if (strlong==null){
          strlong="0";
      }
      if (edt_AgentLocation.getText().toString().trim().equalsIgnoreCase("")){
          areaLocation="0";
      }else {
          areaLocation=edt_AgentLocation.getText().toString().trim();
      }

      if (edt_AgentCompany.getText().toString().trim().equalsIgnoreCase(""))
      {

          agentCompany="0";
      }else {
          agentCompany=edt_AgentCompany.getText().toString().trim();
      }
        if (validateData()) {
            String loginCust=edt_AgentPhoneNo.getText().toString().trim();
                //validation\
            /* if (loginCust.substring(0,1).equalsIgnoreCase("5")||loginCust.substring(0,1).equalsIgnoreCase("4")||
                    loginCust.substring(0,1).equalsIgnoreCase("1")||loginCust.substring(0,1).equalsIgnoreCase("2")||loginCust.substring(0,1).equalsIgnoreCase("3")||loginCust.substring(0,1).equalsIgnoreCase("0") ){
                 gbData.showAlert(this, getResources().getString(R.string.app_name), "Mobile number should start with  6,7,8 or 9");
             }else {*/
                 if (gbData.isConnected(Activity_travel_Agent.this)) {
                     CallRegisterAgentApi objRequestAPI = new CallRegisterAgentApi();
                     objRequestAPI.execute();
                 }else {
                     CommonUI.showAlert(Activity_travel_Agent.this,getResources().getString(R.string.app_name), "Oops! No internet connection. Please connection with internet and try again.");
                 }

        }
    }

    private boolean validateData() {

        String sUserName = edt_AgentName.getText().toString().trim();
        String sUserMbno = edt_AgentPhoneNo.getText().toString().trim();
        String sUseremail = edt_AgentEmail.getText().toString().trim();



        if (sUserName.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Your Name.");
        else if (sUserMbno.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Mobile number.");
        else if (sUserMbno.substring(0,1).equalsIgnoreCase("5")||sUserMbno.substring(0,1).equalsIgnoreCase("4")||
                sUserMbno.substring(0,1).equalsIgnoreCase("1")||sUserMbno.substring(0,1).equalsIgnoreCase("2")||sUserMbno.substring(0,1).equalsIgnoreCase("3")||sUserMbno.substring(0,1).equalsIgnoreCase("0") ){
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Mobile number should start with  6,7,8 or 9");
        }
        else if ((sUserMbno.length() < 10) || (sUserMbno.length() > 10))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid mobile number. Please enter valid mobile number.");
        else if (sUseremail.equalsIgnoreCase(""))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Please enter Email address.");
        else if (!Validation.isEmailAddress(edt_AgentEmail, true))
            gbData.showAlert(this, getResources().getString(R.string.app_name), "Invalid email address. Please enter proper email address.");
        else
            return true;

        return false;


    }

    public void init(){
        gbData = AppGlobalData.getInstance();
        edt_AgentName= (EditText) findViewById(R.id.agent_edt_name);
        edt_AgentCompany= (EditText) findViewById(R.id.agent_edt_company);
        edt_AgentPhoneNo= (EditText) findViewById(R.id.agent_edt_phone);
        edt_AgentEmail= (EditText) findViewById(R.id.agent_edt_emai);
        edt_AgentLocation= (EditText) findViewById(R.id.agent_edt_location);
        btn_Register=(RelativeLayout) findViewById(R.id.agent_btn_register);
        txtRegister=(TextView)findViewById(R.id.agent_txt_submit);
        mBtnScanCard= (RelativeLayout) findViewById(R.id.rel_cam);
        pd_login = new ProgressDialog(Activity_travel_Agent.this);

    }
    private void setTypeface() {
        edt_AgentName.setTypeface(FontData.setFonts(Activity_travel_Agent.this, edt_AgentName, FontData.font_robotoregular));
        edt_AgentCompany.setTypeface(FontData.setFonts(Activity_travel_Agent.this, edt_AgentCompany, FontData.font_robotoregular));
        edt_AgentPhoneNo.setTypeface(FontData.setFonts(Activity_travel_Agent.this, edt_AgentPhoneNo, FontData.font_robotoregular));
        edt_AgentEmail.setTypeface(FontData.setFonts(Activity_travel_Agent.this, edt_AgentEmail, FontData.font_robotoregular));
        edt_AgentLocation.setTypeface(FontData.setFonts(Activity_travel_Agent.this, edt_AgentLocation, FontData.font_robotoregular));
        txtRegister.setTypeface(FontData.setFonts(Activity_travel_Agent.this, txtRegister, FontData.font_robotoregular));


    }
    @Override
    public void onPlaceSelected(Place place) {
        Log.e("lattitude", String.valueOf(place.getLatLng()));
        LatLng queriedLocation = place.getLatLng();
        Log.e("Latitude is", "" + queriedLocation.latitude);
        Log.e("Longitude is", "" + queriedLocation.longitude);
        String city = "", state = "", country = "";
        try {

            Geocoder geocoder;
            List<Address> addresses;
            geocoder = new Geocoder(this, Locale.getDefault());

            addresses = geocoder.getFromLocation(queriedLocation.latitude, queriedLocation.longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            Log.e("Adrrsssssssssss", "" + addresses);

            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append(",");
                }
                 address = strReturnedAddress.toString().trim();

                //  Log.w("My Current loction address", strReturnedAddress.toString());
            } else {
                // Log.w("My Current loction address", "No Address returned!");
            }


            // String addres = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            city = addresses.get(0).getLocality();
            state = addresses.get(0).getAdminArea();
            country = addresses.get(0).getCountryName();
            String postalCode = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL
            Log.e("city", city);
            Log.e("state", state);
            Log.e("country", country);
            Log.e("postalCode", postalCode);


          //  Log.e("location", "Latitude:" + latitude + ", Longitude:" + longitude);
        } catch (Exception e) {
            e.printStackTrace();
        }


        strlat = String.valueOf(queriedLocation.latitude);
        strlong = String.valueOf(queriedLocation.longitude);
        Log.e("place", place.getAddress().toString());
        Log.e("placename", place.getName().toString());

        String placeDetailsStr = place.getName() + "n"
                + place.getId() + "n"
                + place.getLatLng().toString() + "n"
                + place.getAddress() + "n"

                + place.getAttributions();
        Log.e("placeDetailsStr", placeDetailsStr);
        edt_AgentLocation.setText(place.getName() + "," + city + "," + state + "," + country);
       /* sAreaString = txtArea.getText().toString().trim();
        requestLocation = sAreaString;*/

    }

    @Override
    public void onError(Status status) {
        Log.e("", "onError: Status = " + status.toString());
        Toast.makeText(this, "Place selection failed: " + status.getStatusMessage(),
                Toast.LENGTH_SHORT).show();

    }


    /*
      Return method for Startactivityforresult
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SELECT_PLACE) {
            bArea = false;
            if (resultCode == RESULT_OK) {
                Place place = PlaceAutocomplete.getPlace(this, data);
                this.onPlaceSelected(place);
            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                this.onError(status);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==1) {
            String scanInfo="";
            try {
                scanInfo= data.getStringExtra("data");
            }catch (NullPointerException e){
                e.printStackTrace();
            }





            // edt.setText(scanInfo);

//        String[] arr = scanInfo.split("\n");
            // mTxtName.setText(arr[0]);
        /*for (String w : arr) {
            if (w.contains("Email")) {
                String email = w.substring(w.indexOf(" ") + 1);
                String[] emailID = email.split(":");
                edt_AgentEmail.setText(emailID[1]);
            }
            else if (w.contains("email")) {
                String email = w.substring(w.indexOf(" ") + 1);
                String[] emailID = email.split(":");
                edt_AgentEmail.setText(emailID[1]);
            }
            else if (w.contains("E-mail")) {
                String email = w.substring(w.indexOf(" ") + 1);
                String[] emailID = email.split(":");
                edt_AgentEmail.setText(emailID[1]);
            }
            else if (w.contains("@")){
                String email=w.substring(w.indexOf(" ") +1);
                edt_AgentEmail.setText(email);
            }

            if (w.contains("+91")) {
                String phNo = w.substring(w.indexOf(" ") + 1);
                String[] ph = phNo.split(":");
               edt_AgentPhoneNo.setText(ph[1]);
            }
            else if (w.contains("+91")){
                String phNo=w.substring(w.indexOf(" ") +1);
               // String[]ph=phNo.split("+91");
                String tempPhoneNo=phNo.substring(3,13);
                Log.e("Phone Nooooooo",""+tempPhoneNo);

            }
           *//* if (w.contains("pvt.")){
                String company=w.substring(w.indexOf(" "));
                mTxtCompany.setText(company);
            }*//*
        }*/
            try {
                Pattern regex = Pattern.compile("(?:\\d+\\s*)+");
                Matcher regexMatcher = regex.matcher(scanInfo);
                if (regexMatcher.find()) {
                    String no=regexMatcher.group(0).trim();
                    String mobileno=no.replaceAll("\\s","");
                    if (mobileno.length()>=10) {
                        String newNo = mobileno.substring(mobileno.length() - 10);
                        edt_AgentPhoneNo.setText(newNo);
                    }
                }
            } catch (PatternSyntaxException ex) {
                ex.printStackTrace();
                // Syntax error
            }
            try {
           /* String s = "*** test@gmail.com&&^ test2@gmail.com((& ";*/
                Matcher m = Pattern.compile("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+").matcher(scanInfo);
                while (m.find()) {
                    edt_AgentEmail.setText(m.group());
                }
            } catch (PatternSyntaxException ex) {
                ex.getDescription();
                // Syntax error
            }

        }

    }

      public  class CallRegisterAgentApi extends AsyncTask<String, Void, String> {

            private String strResponse = "";
            String Error_Message = "";


            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd_login.setMessage("Loading...");
                pd_login.setCancelable(false);
                pd_login.show();
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd_login.dismiss();
                //    if (Error_Message.equalsIgnoreCase("")) {
                Log.e("Response:123333333 ", strResponse);
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                        showAlert("Nafex","Thank you for registering with Nafex.com. Your Password is sent via SMS and Email to you . ");


                       /* Intent intentOtp=new Intent(Activity_travel_Agent.this,Activity_TravelAgent_Otp.class);
                        startActivity(intentOtp);*/

                       /* JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        String userId = objmsgtext.getString("userId");
                        //String userName = objdata.getString("userName");
                        String userMobileNo = objmsgtext.getString("userMobileNo");
                        //  String userEmail = objdata.getString("userEmail");
                        Log.e("Mobile No*******", "" + userMobileNo);

                        Intent intentOtp = new Intent(Activity_travel_Agent.this, Activity_TravelAgent_Otp.class);
                        intentOtp.putExtra("mobile", userMobileNo);
                        intentOtp.putExtra("userid", userId);
                        startActivity(intentOtp);*/



                       /* JSONObject objmsgtext = objdata.getJSONObject("message_text");
                        String userId = (String) objmsgtext.get("userId");
                        String userName = (String) objmsgtext.get("userName");
                        String userMobileNo = (String) objmsgtext.get("userMobileNo");
                        String userEmail = (String) objmsgtext.get("userEmail");
                        String userToken = (String) objmsgtext.get("userToken");
                        setSharedPref(Integer.parseInt(userId), userName, userEmail, userMobileNo, userToken);

                        CommonUI.showAlert(Activity_signup.this, getResources().getString(R.string.app_name), "Profile created successfully!");*/

                     /*   if (strregtype.equalsIgnoreCase("autoReg")) {
                            if (strisleft.equalsIgnoreCase("false")) {
                                getSharedPref();
                                if (gbData.isConnected(getApplicationContext())) {
                                    Activity_signup.CallAddRequestApi objRequestAPI = new Activity_travel_Agent.CallAddRequestApi();
                                    objRequestAPI.execute(CommonApi.REQUEST);
                                }
                            }else
                            {
                                Intent int_main=new Intent(Activity_travel_Agent.this,Activity_main.class);
                                startActivity(int_main);
                                finish();
                            }
                            //call request api
                            Log.e("call request api", "call request api");
                        }*//* else {
                            if (strregtype.equalsIgnoreCase("autoReg")) {

                            }
                        }*/

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(Activity_travel_Agent.this, getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    //   CommonUI.showAlert(Activity_travel_Agent.this, getResources().getString(R.string.app_name),""+e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";*/

                    // CommonUI.showAlert(Activity_travel_Agent.this, getResources().getString(R.string.app_name), Error_Message);
                }
            /*} else
                CommonUI.showAlert(Activity_travel_Agent.this, getResources().getString(R.string.app_name), Error_Message);*/


            }

            @Override
            protected String doInBackground(String... strings) {

                HttpURLConnection urlConnection = null;

                try {
                    URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.TRAVAL_AGENT_SIGNUP);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    JSONObject postDataParams = new JSONObject();
               /* if (strisleft.equalsIgnoreCase("false")) {
                    postDataParams.put("regType", strregtype);
                } else {
                    postDataParams.put("regType", "self");
                }*/

                    // postDataParams.put("regType", strregtype);
                    postDataParams.put("taName", edt_AgentName.getText().toString().trim());
                    postDataParams.put("taMobileNo", edt_AgentPhoneNo.getText().toString().trim());
                    postDataParams.put("taMail", edt_AgentEmail.getText().toString().trim());
                    postDataParams.put("taLocationLat", strlat);
                    postDataParams.put("taLocationLong", strlong);
                    postDataParams.put("taLocationArea", areaLocation);
                    postDataParams.put("taCompany", agentCompany);


                    Log.e("userName", edt_AgentName.getText().toString().trim());
                    Log.e("userMobileNo", edt_AgentPhoneNo.getText().toString().trim());
                    Log.e("userEmail", edt_AgentEmail.getText().toString().trim());
                    Log.e("userPassword", strlat);
                    Log.e("userId", strlong);
                    Log.e("userOTP", areaLocation);

                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(60000 /* milliseconds */);
                    urlConnection.setConnectTimeout(60000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();

                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    }
                } catch (JSONException e) {
                    //Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
*/
                } catch (Exception e) {
                    // CommonUI.showAlert(Activity_travel_Agent.this, getResources().getString(R.string.app_name),""+e);

                    Log.e("ERROR", e.getMessage(), e);
                    //   Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
                } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
                return null;
            }
        }


    public  void showAlert( String title, String message) {
        new AlertDialog.Builder(Activity_travel_Agent.this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        Intent intentOtp=new Intent(Activity_travel_Agent.this,Activity_login.class);
                        startActivity(intentOtp);
                        // continue with delete
                    }
                })
//                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // do nothing
//                    }
//                })
                .setIcon(R.drawable.ic_error)
                .show();
    }





}
