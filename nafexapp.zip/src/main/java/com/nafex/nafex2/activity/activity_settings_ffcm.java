package com.nafex.nafex2.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Sunil on 7/28/2017.
 */
public class activity_settings_ffcm extends AppCompatActivity {

    Toolbar toolbar;

    private NavigationView navigationView;
    private View navHeader;
    private DrawerLayout drawerLayout;
    private ProgressBar progressBar;
    private LinearLayout llMainView;

    private LinearLayout linearMain;
    private Toolbar toolbarTop;
    private TextView txtorderSetting;
    private TextView txtHeadingFfmc;
    private ImageView imgSettingEdit;
    private TextView txtSettingCity;
    private EditText edtSettingCity;
    private EditText edtSettingEmail;
    private EditText edtSettingPhone;
    private EditText edtSettingUserType;
    private EditText edtFfmcHeadOffice;
    private EditText edtSetingNotification;
    private CheckBox checkSettingSMS;
    private CheckBox checkSettingEmail;
    private TextView txtSettingDate;
    private EditText edtSettingPartnerType;
    private EditText edtSettingLicenceType;
    private EditText edtSettingLicenceNumber;
    private EditText edtSettingExpiryDate;
    private EditText edtSettingProductDealingWith;
    private EditText edtSettingCurrentWalletBalance;
    private EditText edtSettingLastRechargeDate;
    private EditText edtSettingLastRechargeAmmount;
    private RadioButton radioSettingUnder10;
    private RadioButton radioSettingUnder15;
    private RadioButton radioSettingUnder20;
    private RadioButton radioSettingUnder30;
    private RadioButton radioSettingUnder50;
    private RadioButton radioSettingUnder100;
    private Button btnSettingResetPassword;
    private EditText edtSettingName;
    private EditText edtSettingMobileNo;
    private EditText edtSettingEmailAdd;
    private EditText edtSettingCountry;
    private EditText edtSettingCityName;
    private EditText edtSettingArea;
    private EditText edtSettingLatitude;
    private EditText edtSettingLongitude;
    private TextView txtUsercreation;
    private TextView txtPartnerType;
    private TextView txtLicenceType;
    private TextView txtLicenceNumber;
    private TextView txtExpiryDate;
    private TextView txtProductDealingWith;
    private TextView txtCurrentWalletBalance;
    private TextView txtLastRechargeDate;
    private TextView txtLastRechargeAmmount;
    private TextView txtSelectThe;
    private TextView txtUserDetails;
    private TextView txtName;
    private TextView txtMobileNumber;
    private TextView txtEmailAddress;
    private TextView txtCountry;
    private TextView txtCity;
    private TextView txtArea;
    private TextView txtLatitude;
    private TextView txtLongitude;
    private FrameLayout frameLayoutForNav;
    private FrameLayout frameLayoutForProgress;
    private NavigationView navView;
    AppGlobalData gbData;
    String user_id, user_token, branchID;
    private SharedPreferences sharedpreferences;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_ffmc);
        init();

        //navigationView.inflateMenu(R.menu.menu_ffmc);
        navigationView.inflateMenu(R.menu.menu_ffmc);
        navHeader = navigationView.inflateHeaderView(R.layout.lay_nav_header);
    }

    private void getSharedPref() {
        sharedpreferences = getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }

    public void init(){
        gbData = AppGlobalData.getInstance();
        getSharedPref();
        toolbar = (Toolbar) findViewById(R.id.toolbar_top);
        llMainView = (LinearLayout) findViewById(R.id.linear_main);
        //imgNafexMenu = (ImageView) findViewById(R.id.imgNafexMenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        linearMain = (LinearLayout)findViewById( R.id.linear_main );
        toolbarTop = (Toolbar)findViewById( R.id.toolbar_top );
        txtorderSetting = (TextView)findViewById( R.id.txtorderSetting );
        txtHeadingFfmc = (TextView)findViewById( R.id.txt_heading_ffmc );
        imgSettingEdit = (ImageView)findViewById( R.id.img_setting_edit );
        txtSettingCity = (TextView)findViewById( R.id.txt_setting_city );
        edtSettingCity = (EditText)findViewById( R.id.edt_setting_city );
        edtSettingEmail = (EditText)findViewById( R.id.edt_setting_email );
        edtSettingPhone = (EditText)findViewById( R.id.edt_setting_phone );
        edtSettingUserType = (EditText)findViewById( R.id.edt_setting_user_type );
        edtFfmcHeadOffice = (EditText)findViewById( R.id.edt_ffmc_head_office );
        edtSetingNotification = (EditText)findViewById( R.id.edt_seting_notification );
        checkSettingSMS = (CheckBox)findViewById( R.id.checkSettingSMS );
        checkSettingEmail = (CheckBox)findViewById( R.id.checkSettingEmail );
        txtSettingDate = (TextView)findViewById( R.id.txt_setting_date );
        edtSettingPartnerType = (EditText)findViewById( R.id.edt_setting_PartnerType );
        edtSettingLicenceType = (EditText)findViewById( R.id.edt_setting_LicenceType );
        edtSettingLicenceNumber = (EditText)findViewById( R.id.edt_setting_LicenceNumber );
        edtSettingExpiryDate = (EditText)findViewById( R.id.edt_setting_ExpiryDate );
        edtSettingProductDealingWith = (EditText)findViewById( R.id.edt_setting_ProductDealingWith );
        edtSettingCurrentWalletBalance = (EditText)findViewById( R.id.edt_setting_CurrentWalletBalance );
        edtSettingLastRechargeDate = (EditText)findViewById( R.id.edt_setting_LastRechargeDate );
        edtSettingLastRechargeAmmount = (EditText)findViewById( R.id.edt_setting_LastRechargeAmmount );
        radioSettingUnder10 = (RadioButton)findViewById( R.id.radio_setting_Under10 );
        radioSettingUnder15 = (RadioButton)findViewById( R.id.radio_setting_Under15 );
        radioSettingUnder20 = (RadioButton)findViewById( R.id.radio_setting_Under20 );
        radioSettingUnder30 = (RadioButton)findViewById( R.id.radio_setting_Under30 );
        radioSettingUnder50 = (RadioButton)findViewById( R.id.radio_setting_Under50 );
        radioSettingUnder100 = (RadioButton)findViewById( R.id.radio_setting_Under100 );
        btnSettingResetPassword = (Button)findViewById( R.id.btn_setting_ResetPassword );
        edtSettingName = (EditText)findViewById( R.id.edt_setting_Name );
        edtSettingMobileNo = (EditText)findViewById( R.id.edt_setting_MobileNo );
        edtSettingEmailAdd = (EditText)findViewById( R.id.edt_setting_EmailAdd );
        edtSettingCountry = (EditText)findViewById( R.id.edt_setting_Country );
        edtSettingCityName = (EditText)findViewById( R.id.edt_setting_CityName );
        edtSettingArea = (EditText)findViewById( R.id.edt_setting_Area );
        edtSettingLatitude = (EditText)findViewById( R.id.edt_setting_Latitude );
        edtSettingLongitude = (EditText)findViewById( R.id.edt_setting_Longitude );
        frameLayoutForNav = (FrameLayout)findViewById( R.id.frameLayoutForNav );
        frameLayoutForProgress = (FrameLayout)findViewById( R.id.frameLayoutForProgress );
        progressBar = (ProgressBar)findViewById( R.id.progressBar );
        navView = (NavigationView)findViewById( R.id.nav_view );
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setUpNavigationView();




        txtUsercreation = (TextView)findViewById( R.id.txtUsercreation );
        txtPartnerType = (TextView)findViewById( R.id.txtPartnerType );
        txtLicenceType = (TextView)findViewById( R.id.txtLicenceType );
        txtLicenceNumber = (TextView)findViewById( R.id.txtLicenceNumber );
        txtExpiryDate = (TextView)findViewById( R.id.txtExpiryDate );
        txtProductDealingWith = (TextView)findViewById( R.id.txtProductDealingWith );
        txtCurrentWalletBalance = (TextView)findViewById( R.id.txtCurrentWalletBalance );
        txtLastRechargeDate = (TextView)findViewById( R.id.txtLastRechargeDate );
        txtLastRechargeAmmount = (TextView)findViewById( R.id.txtLastRechargeAmmount );
        txtSelectThe = (TextView)findViewById( R.id.txtSelectThe );

        txtUserDetails = (TextView)findViewById( R.id.txtUserDetails );
        txtName = (TextView)findViewById( R.id.txtName );
        txtMobileNumber = (TextView)findViewById( R.id.txtMobileNumber );
        txtEmailAddress = (TextView)findViewById( R.id.txtEmailAddress );
        txtCountry = (TextView)findViewById( R.id.txtCountry );
        txtCity = (TextView)findViewById( R.id.txtCity );
        txtArea = (TextView)findViewById( R.id.txtArea );
        txtLatitude = (TextView)findViewById( R.id.txtLatitude );
        txtLongitude = (TextView)findViewById( R.id.txtLongitude );

    }

    public class CallLogoutAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (Error_Message.equalsIgnoreCase("")) {
                ConstantData constantData = new ConstantData();
                constantData.clearSharedPref(activity_settings_ffcm.this);
                Intent intent = new Intent(activity_settings_ffcm.this, Activity_main.class);
                startActivity(intent);
                finish();
            } else
                CommonUI.showAlert(activity_settings_ffcm.this, getResources().getString(R.string.app_name), Error_Message);

        }

        @Override
        protected String doInBackground(String... strings) {
            CallForLogout();
            return "DONE";

        }

        private void CallForLogout() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.FFMC_LOGOUT);

                urlConnection = (HttpURLConnection) url.openConnection();
                byte[] auth = (user_id + ":" + user_token).getBytes();

                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }
    }


    private void setUpNavigationView() {

        //Setting Navigation View Item Selected Listener to handle the item click of the navigation menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {

                //Check to see which item was being clicked and perform appropriate action
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    //Replacing the main content with ContentFragment Which is our Inbox View;

                    case R.id.nav_dashboard:
                        Intent intentmain =new Intent(activity_settings_ffcm.this, activity_ffmcmain.class);
                        startActivity(intentmain);
                        finish();
                        break;
                    case R.id.nav_enquiries:
                        Intent intentEnquiries=new Intent(activity_settings_ffcm.this,activity_enquiries.class);
                        startActivity(intentEnquiries);
                        finish();
                        break;
                    case R.id.nav_dispute:
                        Intent intentDispute=new Intent(activity_settings_ffcm.this,activity_dispute.class);
                        startActivity(intentDispute);
                        finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_reports:
                        Intent intentReport=new Intent(activity_settings_ffcm.this,activity_reports.class);
                        startActivity(intentReport);
                        finish();
                        break;
                    case R.id.nav_passbook:
                        Intent intentpassbook=new Intent(activity_settings_ffcm.this,activity_passbook.class);
                        startActivity(intentpassbook);
                        finish();

                        //Intent intentpassbook=new Intent(activity_settings_ffcm.this,activity_settings_ffcm.class);
                        //startActivity(intentpassbook);
                        //finish();
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;
                    case R.id.nav_b2b:
                        Intent intent_b2b=new Intent(activity_settings_ffcm.this,Activity_Generate_Enquiry_B2B.class);
                        startActivity(intent_b2b);
                        finish();
                        break;
                    case R.id.nav_settings:
//                        Intent intentprofile = new Intent(activity_ffmcmain.this, Activity_profile.class);
//                        startActivity(intentprofile);
//                        finish();
                        break;

                    case R.id.nav_logout:
                       /* if (gbData.isConnected(activity_settings_ffcm.this)) {
                            CallLogoutAPI logoutapi = new CallLogoutAPI();
                            logoutapi.execute();
                        } else {
                            CommonUI.showAlert(activity_settings_ffcm.this, getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");

                        }*/
                       logoutApplication();

                        break;


                }


                return true;
            }
        });


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);

            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }


            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                llMainView.setTranslationX(slideOffset * drawerView.getWidth());
                drawerLayout.bringChildToFront(drawerView);
                drawerLayout.requestLayout();
            }
        };

        //Setting the actionbarToggle to drawer layout
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        //calling sync state is necessary or else your hamburger icon wont show up
        actionBarDrawerToggle.syncState();
    }



    private void setTypeface() {
        txtorderSetting.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtorderSetting, FontData.font_robotomedium));
        txtHeadingFfmc.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtHeadingFfmc, FontData.font_robotomedium));
        txtSettingCity.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtSettingCity, FontData.font_robotoregular));
        edtSettingCity.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingCity, FontData.font_robotoregular));
        edtSettingEmail.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingEmail, FontData.font_robotoregular));
        edtSettingPhone.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingPhone, FontData.font_robotoregular));
        edtSettingUserType.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingUserType, FontData.font_robotomedium));
        edtFfmcHeadOffice.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtFfmcHeadOffice, FontData.font_robotoregular));
        edtSetingNotification.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSetingNotification, FontData.font_robotomedium));
        txtSettingDate.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtSettingDate, FontData.font_robotomedium));

        edtSettingPartnerType.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingPartnerType, FontData.font_robotomedium));
        edtSettingLicenceType.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingLicenceType, FontData.font_robotomedium));
        edtSettingLicenceNumber.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingLicenceNumber, FontData.font_robotomedium));
        edtSettingExpiryDate.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingExpiryDate, FontData.font_robotomedium));
        edtSettingProductDealingWith.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingProductDealingWith, FontData.font_robotomedium));
        edtSettingCurrentWalletBalance.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingCurrentWalletBalance, FontData.font_robotomedium));
        edtSettingLastRechargeDate.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingLastRechargeDate, FontData.font_robotomedium));
        edtSettingLastRechargeAmmount.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingLastRechargeAmmount, FontData.font_robotomedium));


        edtSettingName.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingName, FontData.font_robotoregular));
        edtSettingMobileNo.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingMobileNo, FontData.font_robotoregular));
        edtSettingEmailAdd.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingEmailAdd, FontData.font_robotoregular));
        edtSettingCountry.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingCountry, FontData.font_robotoregular));
        edtSettingCityName.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingCityName, FontData.font_robotoregular));
        edtSettingArea.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingArea, FontData.font_robotoregular));
        edtSettingLatitude.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingLatitude, FontData.font_robotoregular));
        edtSettingLongitude.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingLongitude, FontData.font_robotoregular));


        txtUserDetails.setTypeface(FontData.setFonts(activity_settings_ffcm.this, edtSettingLongitude, FontData.font_robotomedium));
        txtName.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtName, FontData.font_robotoregular));
        txtMobileNumber.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtMobileNumber, FontData.font_robotoregular));
        txtEmailAddress.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtEmailAddress, FontData.font_robotoregular));
        txtCountry.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtCountry, FontData.font_robotoregular));
        txtCity.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtCity, FontData.font_robotoregular));

        txtArea.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtArea, FontData.font_robotoregular));
        txtLatitude.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtLatitude, FontData.font_robotoregular));
        txtLongitude.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtLongitude, FontData.font_robotoregular));

        txtPartnerType.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtPartnerType, FontData.font_robotoregular));
        txtLicenceType.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtLicenceType, FontData.font_robotoregular));
        txtLicenceNumber.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtLicenceNumber, FontData.font_robotoregular));
        txtExpiryDate.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtExpiryDate, FontData.font_robotoregular));
        txtProductDealingWith.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtProductDealingWith, FontData.font_robotoregular));
        txtCurrentWalletBalance.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtCurrentWalletBalance, FontData.font_robotoregular));
        txtLastRechargeDate.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtLastRechargeDate, FontData.font_robotoregular));
        txtLastRechargeAmmount.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtLastRechargeAmmount, FontData.font_robotoregular));
        txtSelectThe.setTypeface(FontData.setFonts(activity_settings_ffcm.this, txtSelectThe, FontData.font_robotomedium));
        txtUsercreation.setTypeface(FontData.setFonts(activity_settings_ffcm.this,txtUsercreation, FontData.font_robotomedium));



        checkSettingSMS.setTypeface(FontData.setFonts(activity_settings_ffcm.this,checkSettingSMS, FontData.font_robotomedium));
        checkSettingEmail.setTypeface(FontData.setFonts(activity_settings_ffcm.this,checkSettingEmail, FontData.font_robotomedium));



        radioSettingUnder10.setTypeface(FontData.setFonts(activity_settings_ffcm.this,radioSettingUnder10, FontData.font_robotoregular));
        radioSettingUnder15.setTypeface(FontData.setFonts(activity_settings_ffcm.this,radioSettingUnder15, FontData.font_robotoregular));
        radioSettingUnder20.setTypeface(FontData.setFonts(activity_settings_ffcm.this,radioSettingUnder20, FontData.font_robotoregular));
        radioSettingUnder30.setTypeface(FontData.setFonts(activity_settings_ffcm.this,radioSettingUnder30, FontData.font_robotoregular));
        radioSettingUnder50.setTypeface(FontData.setFonts(activity_settings_ffcm.this,radioSettingUnder50, FontData.font_robotoregular));
        radioSettingUnder100.setTypeface(FontData.setFonts(activity_settings_ffcm.this,radioSettingUnder100, FontData.font_robotoregular));


    }
    public void logoutApplication() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity_settings_ffcm.this);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setMessage("Do you want to logout from application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences preferences = getSharedPreferences(ConstantData.MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                        Intent intrefresh = new Intent(activity_settings_ffcm.this, Activity_otpdashboard.class);
                        startActivity(intrefresh);
                        finish();


                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}
