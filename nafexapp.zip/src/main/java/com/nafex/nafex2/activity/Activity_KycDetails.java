package com.nafex.nafex2.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nafex.nafex2.R;
import com.nafex.nafex2.data.DocType;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.FontData;

import java.lang.reflect.Type;
import java.util.List;

/**
 * Created by Swarup on 10/3/2017.
 */

public class Activity_KycDetails extends AppCompatActivity implements View.OnClickListener {
    private Toolbar toolbarTop;
    private ImageView imgNafexback;
    private TextView txtTrackYourOrder;
    private ImageView imgClick;
    private TextView txtDocType;
    private RelativeLayout layDocumentType;
    private TextView txtSelect;
    private TextView txtDocNo;
    private EditText edtDocNo;
    private EditText txtNameAsPer;
    private TextView txtOtherFiles;
    private RelativeLayout rvOtherfield;
    private TextView txtOtherField;
    private TextView txtOtherInfo;
    private RelativeLayout rvOtherinfo;
    private EditText edtxtotherinfo;
    private TextView txtUpload;
    private TextView txtSelectFileToUpload;
    private Button btnBrowse;
    AppGlobalData gbData;
    RelativeLayout rv_expiredate;
    EditText edtxtexpiredate;
String strdocurl;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kycdetails);
        findViews();
        getIntentvalues();


    }

    private void getIntentvalues() {
        String docListAsString = getIntent().getStringExtra("jsonDocs");
        int position = getIntent().getIntExtra("position", 0);
        Gson gson = new Gson();
        Type type = new TypeToken<List<DocType>>() {
        }.getType();
        List<DocType> carsList = gson.fromJson(docListAsString, type);
        txtSelect.setText(carsList.get(position).getDocTypeName());
        edtDocNo.setText(carsList.get(position).getDocNumber());
        txtNameAsPer.setText(carsList.get(position).getDocName());
        strdocurl="http://13.59.118.35/nafex2dev/api/"+carsList.get(position).getDocFile();
        Log.e("docurl",strdocurl);
        if (carsList.get(position).getOtherTypeName().equalsIgnoreCase("")) {
            rvOtherfield.setVisibility(View.GONE);
            txtOtherFiles.setVisibility(View.GONE);
        } else {
            txtOtherField.setText(carsList.get(position).getOtherTypeName());
            rvOtherfield.setVisibility(View.VISIBLE);
            txtOtherFiles.setVisibility(View.VISIBLE);
        }


        if (carsList.get(position).getOtherTypeInfo().equalsIgnoreCase("")) {
            rvOtherinfo.setVisibility(View.GONE);
            txtOtherInfo.setVisibility(View.GONE);

        } else {
            if (carsList.get(position).getOtherTypeId().equalsIgnoreCase("7")) {
                rv_expiredate.setVisibility(View.VISIBLE);
                String[] split = carsList.get(position).getOtherTypeInfo().split(":");
                edtxtotherinfo.setText(split[0]);
                edtxtexpiredate.setText(split[1]);

            } else {
                if (carsList.get(position).getOtherTypeId().equalsIgnoreCase("6")) {
                    rv_expiredate.setVisibility(View.VISIBLE);
                    String[] split = carsList.get(position).getOtherTypeInfo().split(":");
                    edtxtotherinfo.setText(split[0]);
                    edtxtexpiredate.setText(split[1]);
                } else {
                    rv_expiredate.setVisibility(View.GONE);
                    edtxtotherinfo.setText(carsList.get(position).getOtherTypeInfo());

                }
            }
            rvOtherinfo.setVisibility(View.VISIBLE);
            txtOtherInfo.setVisibility(View.VISIBLE);
        }


        txtSelectFileToUpload.setText(carsList.get(position).getDocFile());

    }


    private void findViews() {
        toolbarTop = (Toolbar) findViewById(R.id.toolbar_top);
        imgNafexback = (ImageView) findViewById(R.id.imgNafexback);
        txtTrackYourOrder = (TextView) findViewById(R.id.txtTrackYourOrder);
        txtTrackYourOrder.setTypeface(FontData.setFonts(Activity_KycDetails.this, txtTrackYourOrder, FontData.font_robotomedium));
        rv_expiredate = (RelativeLayout) findViewById(R.id.rv_expiredate);
        edtxtexpiredate = (EditText) findViewById(R.id.edtxtexpiredate);

        imgClick = (ImageView) findViewById(R.id.img_click);
        txtDocType = (TextView) findViewById(R.id.txtDocType);
        layDocumentType = (RelativeLayout) findViewById(R.id.layDocumentType);
        txtSelect = (TextView) findViewById(R.id.txtSelect);
        txtDocNo = (TextView) findViewById(R.id.txtDocNo);
        edtDocNo = (EditText) findViewById(R.id.edtDocNo);
        txtNameAsPer = (EditText) findViewById(R.id.txtNameAsPer);
        txtOtherFiles = (TextView) findViewById(R.id.txtOtherFiles);
        rvOtherfield = (RelativeLayout) findViewById(R.id.rv_otherfield);
        txtOtherField = (TextView) findViewById(R.id.txtOtherField);
        txtOtherInfo = (TextView) findViewById(R.id.txtOtherInfo);
        rvOtherinfo = (RelativeLayout) findViewById(R.id.rv_otherinfo);
        edtxtotherinfo = (EditText) findViewById(R.id.edtxtotherinfo);
        txtUpload = (TextView) findViewById(R.id.txtUpload);
        txtSelectFileToUpload = (TextView) findViewById(R.id.txtSelectFileToUpload);
        btnBrowse = (Button) findViewById(R.id.btnBrowse);

        btnBrowse.setOnClickListener(this);
        setSupportActionBar(toolbarTop);
        gbData = AppGlobalData.getInstance();

        gbData.setStatusBarColor(Activity_KycDetails.this, R.color.colorPrimaryDark);

        imgNafexback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
    private class Callback extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(
                WebView view, String url) {
            return(false);
        }
    }

    @Override
    public void onClick(View v) {
        if (v == btnBrowse) {
            // Handle clicks for btnBrowse
            if (strdocurl.toString().contains(".doc") || strdocurl.toString().contains(".docx")) {
                // Word document
                AlertDialog.Builder alert = new AlertDialog.Builder(Activity_KycDetails.this);

                WebView wv = new WebView(Activity_KycDetails.this);
                // wv.setWebViewClient(new AppWebViewClients());
                wv.getSettings().setPluginState(WebSettings.PluginState.ON);
                wv.setWebViewClient(new Callback());

                // String pdfURL = "http://dl.dropboxusercontent.com/u/37098169/Course%20Brochures/AND101.pdf";
                wv.loadUrl(
                        "http://docs.google.com/gview?embedded=true&url=" + strdocurl);

                wv.getSettings().setJavaScriptEnabled(true);
                wv.getSettings().setUseWideViewPort(true);
                // wv.loadUrl(kycId);
                WebSettings webSettings = wv.getSettings();
                webSettings.setBuiltInZoomControls(true);
                webSettings.setSupportZoom(true);
                alert.setView(wv);
                alert.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                alert.show();



                                    /*Intent intentdoc = new Intent(Intent.ACTION_VIEW);
                                    intentdoc.setDataAndType(Uri.parse(kycId), "application/msword");
                                    intentdoc.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intentdoc);
*/
            }  else if(strdocurl.toString().contains(".pdf")) {
                // PDF file

                AlertDialog.Builder alert = new AlertDialog.Builder(Activity_KycDetails.this);

                WebView wv = new WebView(Activity_KycDetails.this);
                // wv.setWebViewClient(new AppWebViewClients());
                wv.getSettings().setPluginState(WebSettings.PluginState.ON);
                wv.setWebViewClient(new Callback());

                // String pdfURL = "http://dl.dropboxusercontent.com/u/37098169/Course%20Brochures/AND101.pdf";
                wv.loadUrl(
                        "http://docs.google.com/gview?embedded=true&url=" + strdocurl);

                wv.getSettings().setJavaScriptEnabled(true);
                wv.getSettings().setUseWideViewPort(true);
                // wv.loadUrl(kycId);
                WebSettings webSettings = wv.getSettings();
                webSettings.setBuiltInZoomControls(true);
                webSettings.setSupportZoom(true);
                alert.setView(wv);
                alert.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                alert.show();






                                   /* Intent intentpdf = new Intent(Intent.ACTION_VIEW);
                                    intentpdf.setDataAndType(Uri.parse(kycId), "application/pdf");
                                    intentpdf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intentpdf);*/

            }else {


                AlertDialog.Builder alert = new AlertDialog.Builder(Activity_KycDetails.this);

                WebView wv = new WebView(Activity_KycDetails.this);
                wv.loadUrl(strdocurl);
                wv.getSettings().setLoadWithOverviewMode(true);
                wv.getSettings().setUseWideViewPort(true);
                wv.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        view.loadUrl(url);

                        return true;
                    }
                });

                alert.setView(wv);
                alert.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                alert.show();

            }



        }
    }
}
