package com.nafex.nafex2.interfaces;

/**
 * Created by Swarup on 10/10/2017.
 */

public interface EnquiryOperations {
    public abstract void OnRespondclick(int position, int selectdisputeid);



}
