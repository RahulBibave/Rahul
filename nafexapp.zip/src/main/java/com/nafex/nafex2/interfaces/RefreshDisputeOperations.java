package com.nafex.nafex2.interfaces;

/**
 * Created by Swarup on 10/28/2017.
 */

public interface RefreshDisputeOperations {
    void onRefreshdisputelist (String value);

}
