package com.nafex.nafex2.interfaces;

/**
 * Created by Swarup on 10/2/2017.
 */

public interface KYCOperation {
    public abstract void onDeleteKyc(String kycId);
    public abstract void onViewClick(String kycId);


}
