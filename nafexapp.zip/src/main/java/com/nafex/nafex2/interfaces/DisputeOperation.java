package com.nafex.nafex2.interfaces;

/**
 * Created by Swarup on 10/6/2017.
 */

public interface DisputeOperation {
    public abstract void OnRespondclick(String kycId);



}
