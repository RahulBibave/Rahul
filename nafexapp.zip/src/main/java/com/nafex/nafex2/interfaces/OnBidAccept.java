package com.nafex.nafex2.interfaces;

/**
 * Created by Sunil on 3/3/2017.
 */
public  interface OnBidAccept {

    public abstract void onAcceptButtonClicked(int requestid,int requestBidId,int requestbidaccaptedsource,int requestbidaccepteduserid);


}
