package com.nafex.nafex2.utilities;

import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Swarup on 9/1/2017.
 */

public class FontData {
   /* android:fontFamily="sans-serif"           // roboto regular
    android:fontFamily="sans-serif-light"     // roboto light
    android:fontFamily="sans-serif-condensed" // roboto condensed
    android:fontFamily="sans-serif-thin"      // roboto thin (android 4.2)
    android:fontFamily="sans-serif-medium"    // roboto medium (android 5.0)

*/

   public static final String font_robotoregular="fonts/Roboto-Regular.ttf";
   public static final String font_robotolight="fonts/Roboto-Light.ttf";
   public static final String font_robotomedium="fonts/Roboto-Medium.ttf";
    public static final String font_robotoBold="fonts/Roboto-Bold.ttf";



    public static Typeface setFonts(Context con, TextView view,String fontstyle)
   {
       Typeface type = Typeface.createFromAsset(con.getAssets(),fontstyle);
       view.setTypeface(type);
       return  type;
   }

    public static Typeface setFonts(Context con, EditText view,String fontstyle)
    {
        Typeface type = Typeface.createFromAsset(con.getAssets(),fontstyle);
        view.setTypeface(type);
        return  type;

    }




}
