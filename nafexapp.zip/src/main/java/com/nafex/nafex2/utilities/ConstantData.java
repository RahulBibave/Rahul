package com.nafex.nafex2.utilities;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by torinit01 on 6/9/16.
 */
public class ConstantData {


    public final static String METHOD_GET  = "GET";
    public final static String METHOD_POST  = "POST";
    public static final String MyPREFERENCES = "NafexPrefrences";

    public final static String KEY_USERID  = "UserId";
    public final static String KEY_USERNAME  = "UserName";
    public final static String KEY_USEREMAIL  = "UserEmail";
    public final static String KEY_USERMOBILENO  = "UserMobileNo";
    public final static String KEY_REGTYPE  = "REGTYPE";
    public final static String KEY_REGToken  = "REGTOKEN";
    public final static String KEY_OLDPASSWORD  = "OldPassword";
    public final static String KEY_NEWPASSWORD  = "NewPassword";
    public final static String KEY_userReferenceId  = "userReferenceId";
    public final static String KEY_userRoleId  = "userRoleId";


    /*
     Buy sharedpreferences
     */
    public static final String REQUESTPREFERENCES = "RequestPreferences";

    public final static String KEY_requestUserid  = "requestUserid";
    public final static String KEY_requestType  = "requestType";
    public final static String KEY_requestSourceCurrencyId  = "requestSourceCurrencyId";
    public final static String KEY_requestTargetCurrencyId  = "requestTargetCurrencyId";
    public final static String KEY_deliveryMode  = "deliveryMode";
    public final static String KEY_requestLeadSourceId  = "requestLeadSourceId";
    public final static String KEY_requestSourceRefId  = "requestSourceRefId";
    public final static String KEY_requestProducts  = "requestProducts";
    public final static String KEY_requestLocation = "requestLocation";
    public final static String KEY_requestLat = "requestLat";
    public final static String KEY_requestLong = "requestLong";
    public final static String KEY_requestPurposeId = "requestPurposeId";
    public final static String KEY_requestTransferCountryId = "requestTransferCountryId";
    public final static String KEY_requestTransferTypeId = "requestTransferTypeId";



    public final static String KEY_USERID_LFFCMLOGIN  = "UserIdffcmlogin";
    public final static String KEY_USERNAME_LFFCMLOGIN  = "UserNameffcmlogin";
    public final static String KEY_USERTOKEN_LFFCMLOGIN  = "Usertokenffcmlogin";
    public final static String KEY_USEREMAIL_LFFCMLOGIN  = "UserEmailffcmlogin";
    public final static String KEY_USERMOBILENO_LFFCMLOGIN  = "UserMobileNoffcmlogin";
    public final static String KEY_USERTYPE_LFFCMLOGIN  = "Usertypeffcmlogin";
    public final static String KEY_USERROLE_LFFCMLOGIN  = "Userroleffcmlogin";
    public final static String KEY_ISLOGIN="islogin";
    public final static String KEY_FFCM_BRANCHID="branchID";
    public final static String KEY_FFMC_LAT="userLatitude";
    public final static String KEY_FFMC_LONG="userLongitude";
    public final static String KEY_FFMC_AREA="areaName";



    public static String USERID;
    public static String token;
    public static String branchId;


    /*
     Request sharedpref
     */
    public final static String KEY_requestid = "RequestId";
    public final static String KEY_nbc = "NBC";









    //public final static String SERVER_URL = "http://nafex.theapptest.xyz";
    //Production URL
   /* public final static String SERVER_URL = "http://nafex.com";
    public final static String BASE_URL = "/api/nafex/";*/
    //Development URL
    public final static String SERVER_URL = "http://13.59.118.35/";
    public final static String BASE_URL = "nafex2dev/api/nafex";

    public final static String AREA  = "area";
    public final static String CURRENCY  = "currency";
    public final static String CITY  = "city";
    public final static String REQUEST  = "request";
    public final static String GETREQUEST  = "getrequest";
    public final static String GETREQUESTS  = "getrequests";
    public final static String BIDLIST  = "bidlist";
    public final static String PROFILE  = "user";
    public final static String BIDACCEPT  = "bidaccept";

    public final static String FFMCREQUEST  = "ffmcrequests";

    public final static String FFMCBID  = "bid";
    public final static String ISLEFTLOGIN  = "IsLeftLogin";


    private SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;

    //public final static String AREA_URL = SERVER_URL + BASE_URL + AREA;
    public final static String CURRENCY_URL = SERVER_URL + BASE_URL + CURRENCY;
    //public final static String CITY_URL = SERVER_URL + BASE_URL + CITY;
    public  void clearSharedPref(Context context) {
        sharedpreferences = context.getSharedPreferences(ConstantData.MyPREFERENCES, context.MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.clear();
        editor.commit();
    }





}
