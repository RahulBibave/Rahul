package com.nafex.nafex2.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.RequestHistory;
import com.nafex.nafex2.utilities.FontData;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by Swarup on 10/27/2017.
 */

public class RequestAdapterProgress extends BaseAdapter {

    Context context;
    LayoutInflater inflater;
    private List<RequestHistory> reqhistory = null;
    Calendar calendar;
    DateFormat f2 ;
    DateFormat f1;
    Date d;


    public RequestAdapterProgress(Context context,
                                 List<RequestHistory> request) {
        this.context = context;
        this.reqhistory = request;
        if(context!=null)
        this.inflater = LayoutInflater.from(context);
        calendar = Calendar.getInstance();
        f2 = new SimpleDateFormat("h:mma");;
        f1 = new SimpleDateFormat("HH:mm:ss");

    }

    public class ViewHolder {

        TextView txtNBC, txtStatus, txtRequestDate, txtRequestRate, txtRequestData, txtArea, txtMode, txtBUY, txtqty, txtAbbrivation, txtDelivery;
        TextView txtBuySellHead, txtCurrencyHead, txtDeliveryHead, txtQuantity, txtAreaHead, txtAbbrivationFrom,txt_hitory_cardType;
        ImageView imgInfo;
        LinearLayout linearLayoutInfo,linear_buysell,linear_delivary,linear_currencyFrom,linear_currencyTo,linear_currency,linear_transferType,linear_purpose,linear_country;
        TextView txtCountry,txt_country_head,txt_currenctxt,txt_currency_h,txt_transferType,txt_transfer_type_head,txt_PURPOSE,txt_PURPOSE_head;



    }

    @Override
    public int getCount() {
        return reqhistory.size();

    }


    @Override
    public Object getItem(int position) {
        return reqhistory.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View view, final ViewGroup parent) {
        final ViewHolder holder;
        boolean flag = false;
        if (view == null) {
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.lay_fragment_inprogress_history_n, null);
            // Locate the TextViews in listview_item.xml


            holder.txtNBC = (TextView) view.findViewById(R.id.txtNBC);
            holder.txtStatus = (TextView) view.findViewById(R.id.txtStatus);
            holder.txtRequestDate = (TextView) view.findViewById(R.id.txtRequestDate);
            holder.txtRequestRate = (TextView) view.findViewById(R.id.txtRequestRate);
            holder.txtRequestData = (TextView) view.findViewById(R.id.txtRequestData);
            holder.txtArea = (TextView) view.findViewById(R.id.txtArea);
            // txtMode=(TextView)holder.itemView.findViewById(R.id.txtMode);
            holder.imgInfo = (ImageView) view.findViewById(R.id.imgInfo);
            holder.txtBUY = (TextView) view.findViewById(R.id.txt_hitory_buysell);
            holder.txtqty = (TextView) view.findViewById(R.id.txt_historyqty);
            holder.txtAbbrivation = (TextView) view.findViewById(R.id.txt_historyAbbrivation);
            holder.txtAbbrivationFrom = (TextView) view.findViewById(R.id.txt_historyAbbrivation_From);
            holder.txtDelivery = (TextView) view.findViewById(R.id.txtDeliveryMode);
            holder.linearLayoutInfo = (LinearLayout) view.findViewById(R.id.linear_info);

            holder.txtBuySellHead = (TextView) view.findViewById(R.id.txt_buySell_head);
            holder.txtCurrencyHead = (TextView) view.findViewById(R.id.txt_currency_head);
            holder.txtQuantity = (TextView) view.findViewById(R.id.txt_qunt_head);
            holder.txtAreaHead = (TextView) view.findViewById(R.id.txt_AREA_head);
            holder.txtDeliveryHead = (TextView) view.findViewById(R.id.txt_delivery_head);

            holder.txt_hitory_cardType= (TextView) view.findViewById(R.id.txt_hitory_cardType);

            holder.linear_buysell= (LinearLayout) view.findViewById(R.id.linear_buysell);
            holder.linear_delivary= (LinearLayout) view.findViewById(R.id.linear_delivary);
            holder.linear_currencyFrom= (LinearLayout) view.findViewById(R.id.linear_currencyFrom);
            holder.linear_currencyTo= (LinearLayout) view.findViewById(R.id.linear_currencyTo);
            holder.linear_currency= (LinearLayout) view.findViewById(R.id.linear_currency);
            holder.linear_transferType= (LinearLayout) view.findViewById(R.id.linear_transferType);
            holder.linear_purpose= (LinearLayout) view.findViewById(R.id.linear_purpose);
            holder.linear_country= (LinearLayout) view.findViewById(R.id.linear_country);

            holder.txtCountry= (TextView) view.findViewById(R.id.txtCountry);
            holder.txt_country_head= (TextView) view.findViewById(R.id.txt_country_head);
            holder.txt_currenctxt= (TextView) view.findViewById(R.id.txt_currenctxt);
            holder.txt_currency_h= (TextView) view.findViewById(R.id.txt_currency_h);

            holder.txt_transferType= (TextView) view.findViewById(R.id.txt_transferType);
            holder.txt_transfer_type_head= (TextView) view.findViewById(R.id.txt_transfer_type_head);

            holder.txt_PURPOSE= (TextView) view.findViewById(R.id.txt_PURPOSE);
            holder.txt_PURPOSE_head= (TextView) view.findViewById(R.id.txt_PURPOSE_head);


            //settypeface


            holder.txtBuySellHead.setTypeface(FontData.setFonts(context, holder.txtBuySellHead, FontData.font_robotomedium));
            holder.txtCurrencyHead.setTypeface(FontData.setFonts(context, holder.txtCurrencyHead, FontData.font_robotomedium));
            holder.txtQuantity.setTypeface(FontData.setFonts(context, holder.txtQuantity, FontData.font_robotomedium));
            holder.txtAreaHead.setTypeface(FontData.setFonts(context, holder.txtAreaHead, FontData.font_robotomedium));
            holder.txtDeliveryHead.setTypeface(FontData.setFonts(context, holder.txtDeliveryHead, FontData.font_robotomedium));
            holder.txt_country_head.setTypeface(FontData.setFonts(context, holder.txt_country_head, FontData.font_robotomedium));
            holder.txt_currency_h.setTypeface(FontData.setFonts(context, holder.txt_currency_h, FontData.font_robotomedium));
            holder.txt_transfer_type_head.setTypeface(FontData.setFonts(context, holder.txt_transfer_type_head, FontData.font_robotomedium));
            holder.txt_PURPOSE_head.setTypeface(FontData.setFonts(context, holder.txt_PURPOSE_head, FontData.font_robotomedium));

            holder.txt_transferType.setTypeface(FontData.setFonts(context, holder.txt_transferType, FontData.font_robotoregular));
            holder.txt_PURPOSE_head.setTypeface(FontData.setFonts(context, holder.txt_PURPOSE_head, FontData.font_robotoregular));
            holder.txtCountry.setTypeface(FontData.setFonts(context, holder.txtCountry, FontData.font_robotoregular));
            holder.txt_currenctxt.setTypeface(FontData.setFonts(context, holder.txt_currenctxt, FontData.font_robotoregular));


            holder.txtNBC.setTypeface(FontData.setFonts(context, holder.txtNBC, FontData.font_robotoregular));
            holder.txtStatus.setTypeface(FontData.setFonts(context, holder.txtStatus, FontData.font_robotoregular));
            holder.txtRequestDate.setTypeface(FontData.setFonts(context, holder.txtRequestDate, FontData.font_robotoregular));
            holder.txtRequestRate.setTypeface(FontData.setFonts(context, holder.txtRequestRate, FontData.font_robotoregular));
            holder.txtRequestData.setTypeface(FontData.setFonts(context, holder.txtRequestData, FontData.font_robotomedium));
            holder.txtArea.setTypeface(FontData.setFonts(context, holder.txtArea, FontData.font_robotoregular));
            holder.txtBUY.setTypeface(FontData.setFonts(context, holder.txtBUY, FontData.font_robotoregular));
            holder.txtAbbrivation.setTypeface(FontData.setFonts(context, holder.txtAbbrivation, FontData.font_robotoregular));
            holder.txtAbbrivationFrom.setTypeface(FontData.setFonts(context, holder.txtAbbrivationFrom, FontData.font_robotoregular));

            holder.txtDelivery.setTypeface(FontData.setFonts(context, holder.txtDelivery, FontData.font_robotoregular));


            view.setTag(holder);
            flag = false;
        } else {
            holder = (RequestAdapterProgress.ViewHolder) view.getTag();
            flag = true;
        }
        // Set the results into TextViews
        try {

            if (reqhistory.get(position).getRequestStatusName().equalsIgnoreCase("Expired")) {
                holder.txtRequestRate.setText(reqhistory.get(position).getRequestTargetCurrencyName() + " " + reqhistory.get(position).getRequestQuantity() + "/" + reqhistory.get(position).getRequestSourceCurrencyName());
            } else {
                if (reqhistory.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")) {
                    holder.txtRequestRate.setText(reqhistory.get(position).getRequestTargetCurrencyName() + " " + reqhistory.get(position).getRequestQuantity() + "/" + reqhistory.get(position).getRequestSourceCurrencyName());

                }else
                {
                    if(reqhistory.get(position).getRequestStatusName().equalsIgnoreCase("Open"))
                    {
                        holder.txtRequestRate.setText(reqhistory.get(position).getRequestTargetCurrencyName() + " " + reqhistory.get(position).getRequestQuantity() + "/" + reqhistory.get(position).getRequestSourceCurrencyName());

                    }
                }
            }
            holder.txtRequestDate.setText(reqhistory.get(position).getCreatedOn());

            holder.linear_buysell.setVisibility(View.VISIBLE);
            holder.linear_delivary.setVisibility(View.VISIBLE);
            holder.linear_currencyFrom.setVisibility(View.VISIBLE);
            holder.linear_currencyTo.setVisibility(View.VISIBLE);
            holder.linear_currency.setVisibility(View.GONE);
            holder.linear_transferType.setVisibility(View.GONE);
            holder.linear_purpose.setVisibility(View.GONE);
            holder.linear_country.setVisibility(View.GONE);
            if (reqhistory.get(position).getNewProduct().equalsIgnoreCase("2")){
                holder.txtqty.setText(reqhistory.get(position).getNewProductQnt());
            }
            if (reqhistory.get(position).getRequestTypeName().equalsIgnoreCase("Money Transfer")){
                Log.e("eeeeeeeeee",""+reqhistory.get(position).getRequestTypeName());
                holder.txtRequestData.setText("You have requested to remittance "+reqhistory.get(position).getRequestQuantity() + " " + reqhistory.get(position).getRequestTargetCurrencyName());
                holder.txt_hitory_cardType.setText(reqhistory.get(position).getRequestTypeName());
                holder.linear_buysell.setVisibility(View.GONE);
                holder.linear_delivary.setVisibility(View.GONE);
                holder.linear_currencyFrom.setVisibility(View.GONE);
                holder.linear_currencyTo.setVisibility(View.GONE);
                holder.linear_currency.setVisibility(View.VISIBLE);
                holder.linear_transferType.setVisibility(View.VISIBLE);
                holder.linear_purpose.setVisibility(View.VISIBLE);
                holder.linear_country.setVisibility(View.VISIBLE);
                holder.txt_currenctxt.setText(reqhistory.get(position).getRequestTargetCurrencyName());
                holder.txtCountry.setText(reqhistory.get(position).getRequestCountryName());
                holder.txt_PURPOSE.setText(reqhistory.get(position).getRequestPurposeName());
                holder.txt_transferType.setText(reqhistory.get(position).getRequestTransferTypeName());
            } /*else {


                holder.linear_buysell.setVisibility(View.VISIBLE);
                holder.linear_delivary.setVisibility(View.VISIBLE);
                holder.linear_currencyFrom.setVisibility(View.VISIBLE);
                holder.linear_currencyTo.setVisibility(View.VISIBLE);
                holder.linear_currency.setVisibility(View.GONE);
                holder.linear_transferType.setVisibility(View.GONE);
                holder.linear_purpose.setVisibility(View.GONE);
                holder.linear_country.setVisibility(View.GONE);
                holder.txtNBC.setText(reqhistory.get(position).getRequestNBC());
                holder.txtStatus.setText(reqhistory.get(position).getRequestStatusName());
                holder.txtBUY.setText(reqhistory.get(position).getRequestTypeName());
                holder.txtArea.setText(reqhistory.get(position).getAreaName()+", "+reqhistory.get(position).getCityName()+", "+reqhistory.get(position).getStateName());
                holder.txtDelivery.setText(reqhistory.get(position).getRequestDeliveryModeName());

                if(reqhistory.get(position).getRequestTypeName().equalsIgnoreCase("Buy")) {
                    // holder.txtAbbrivationFrom.setText(reqhistory.get(position).getRequestSourceCurrencyName());
                    //holder.txtAbbrivation.setText(reqhistory.get(position).getRequestTargetCurrencyName());
                    holder.txtAbbrivationFrom.setText(reqhistory.get(position).getRequestSourceCurrencyName());
                    holder.txtAbbrivation.setText(reqhistory.get(position).getRequestTargetCurrencyName());
                    holder.txtRequestData.setText("You have requested to buy "+reqhistory.get(position).getRequestQuantity() + " " + reqhistory.get(position).getRequestTargetCurrencyName());
                    holder.txt_hitory_cardType.setText(reqhistory.get(position).getRequestProductTypeName());
                }else
                {
                    if(reqhistory.get(position).getRequestTypeName().equalsIgnoreCase("Sell"))
                    {
                        //holder.txtAbbrivationFrom.setText(reqhistory.get(position).getRequestTargetCurrencyName());
                        // holder.txtAbbrivation.setText(reqhistory.get(position).getRequestSourceCurrencyName());
                        holder.txt_hitory_cardType.setText(reqhistory.get(position).getRequestProductTypeName());
                        holder.txtAbbrivationFrom.setText(reqhistory.get(position).getRequestTargetCurrencyName());
                        holder.txtAbbrivation.setText(reqhistory.get(position).getRequestSourceCurrencyName());
                        holder.txtRequestData.setText("You have requested to sell "+reqhistory.get(position).getRequestQuantity() + " " + reqhistory.get(position).getRequestTargetCurrencyName());


                    }
                }


            }*/







         /*   String dateTime[]=reqhistory.get(position).getCreatedOn().split(" ");
            String time=dateTime[1];
            String dateSplit[]=dateTime[0].split("-");
            Log.e("Month nooooooo",""+dateSplit[1]);
            Log.e("Time*********",""+time);


            calendar.set(Calendar.MONTH, Integer.parseInt(dateSplit[1])-1);
            //Log.e("Month********",""+calendar.getTime());
            String month= String.valueOf(calendar.getTime());
            String datefinalMonth[]=month.split(" ");

            Log.e("Date Splittttttttt",""+dateSplit[0]);
            Log.e("Monthhhhhhhhhh****",""+datefinalMonth[1]);
          //  holder.txtRequestDate.setText(reqhistory.get(position).getCreatedOn());
            d = f1.parse(time);
            String finalTime= f2.format(d).toLowerCase();
           // Log.e("finalTIMEEEEEEEEEEE",""+finalTime);

            holder.txtRequestDate.setText(dateSplit[0]+" "+datefinalMonth[1]+" "+finalTime);*/



           // holder.txtRequestData.setText("You inquriy to " + reqhistory.get(position).getRequestQuantity() + " " + reqhistory.get(position).getRequestTargetCurrencyName() + " through " + reqhistory.get(position).getRequestSourceCurrencyName());

        } catch (Exception e) {
            e.printStackTrace();
        }


        return view;
    }

}
