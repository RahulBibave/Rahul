package com.nafex.nafex2.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.ReportData;
import com.nafex.nafex2.utilities.FontData;

import java.util.ArrayList;

/**
 * Created by Sunil on 5/13/2017.
 */
public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ViewHolder> {

    Context context;
    ArrayList<ReportData> listOfReports;

    public ReportAdapter(Context context, ArrayList<ReportData> listOfReports) {
        this.context = context;
        this.listOfReports = listOfReports;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View itemView=inflater.inflate(R.layout.lay_report_view,parent,false);

       return new ViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        if (listOfReports.get(position).getStatus().equalsIgnoreCase("WON")) {
            holder.txtCustomer.setText(listOfReports.get(position).getName() + "\n" + listOfReports.get(position).getMobileNo());
            holder.txtBid.setBackground(context.getDrawable(R.drawable.bidwon_background));
        }
        else {
            holder.txtCustomer.setText(listOfReports.get(position).getCustomer());
            holder.txtBid.setBackground(context.getDrawable(R.drawable.bid_background));
        }

        holder.txtDate.setText(listOfReports.get(position).getDate());
        holder.txtNBCNo.setText(listOfReports.get(position).getNbcNo());
        holder.txtBid.setText(listOfReports.get(position).getStatus());

    }

    @Override
    public int getItemCount() {
        return listOfReports.size();
        //return 5;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtDate,txtTime,txtNBCNo,txtBid,txtCustomer,txtNumber;


        public ViewHolder(View itemView) {
            super(itemView);
            txtDate = (TextView)itemView.findViewById( R.id.txt_Date );
            txtTime = (TextView)itemView.findViewById( R.id.txtTime );
            txtNBCNo = (TextView)itemView.findViewById( R.id.txt_NBCNo );
            txtBid = (TextView)itemView.findViewById( R.id.txt_Bid );
            txtCustomer = (TextView)itemView.findViewById( R.id.txt_Customer );
            txtNumber = (TextView)itemView.findViewById( R.id.txt_number );


            txtDate.setTypeface(FontData.setFonts(context,txtDate, FontData.font_robotoregular));
            txtTime.setTypeface(FontData.setFonts(context,txtTime, FontData.font_robotoregular));
            txtNBCNo.setTypeface(FontData.setFonts(context,txtNBCNo, FontData.font_robotomedium));
            txtBid.setTypeface(FontData.setFonts(context,txtBid, FontData.font_robotoregular));
            txtCustomer.setTypeface(FontData.setFonts(context,txtCustomer, FontData.font_robotoregular));
            txtNumber.setTypeface(FontData.setFonts(context,txtNumber, FontData.font_robotoregular));










        }
    }
}
