package com.nafex.nafex2.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.EnquiriesOpen;
import com.nafex.nafex2.data.RequestProduct;
import com.nafex.nafex2.fragments.fragment_open;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Sunil on 5/13/2017.
 */
public class EnquiryOneAdapter extends RecyclerView.Adapter<EnquiryOneAdapter.ViewHolder> {
    Context context;
    ArrayList<EnquiriesOpen> listOfEnquiryData;
    AppGlobalData gbData;

    OnBidOpen objBidOpen;
    ProgressDialog progressDialog;
    ArrayList<RequestProduct> listOfRequestProduct;
    boolean istwoProduct = false;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id, user_token, responce_BidID, responceMsg,branchID;
    private CountDownTimer cdt, cdtHitApi;
    int RefeshCountDown = 1000; //MS
    int RefreshCounter = 30; //Sec
    int RefeshAfter = 300000; //MS
    fragment_open fragment_open;


    public EnquiryOneAdapter(Context context, OnBidOpen objBO, ArrayList<EnquiriesOpen> listOfEnquiryData,fragment_open fragment_open) {
        this.context = context;
        this.listOfEnquiryData = listOfEnquiryData;
        this.objBidOpen = objBO;
        try {
            progressDialog = new ProgressDialog(context);
        }catch (NullPointerException e){
            Log.e("Exception e",""+e);
        }


        this.fragment_open=fragment_open;
        try {
            getSharedPref();
        }catch (NullPointerException e){
            Log.e("Exception e",""+e);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.lay_fragment_open_view, parent, false);
        gbData = AppGlobalData.getInstance();
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        setFonts(holder);
        holder.txtModeImage.setImageDrawable(context.getDrawable(R.drawable.bid_delivery_new));
        if (listOfEnquiryData.get(position).getRequestDeliveryMode().equalsIgnoreCase("2")){
            holder.txtModeImage.setImageDrawable(context.getDrawable(R.drawable.ic_pickup_icon_progress));
        }

        if (listOfEnquiryData.get(position).getRequestSourceRefId().equalsIgnoreCase("3")||listOfEnquiryData.get(position).getRequestSourceRefId().equalsIgnoreCase("5")||listOfEnquiryData.get(position).getRequestSourceRefId().equalsIgnoreCase("6")){
            holder.txt_requestCustomer.setText("Money Changer wants to");
            holder.nbc_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bidsource_ffmc));
            if (listOfEnquiryData.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_sell));
                holder.txt_fromCurrency.setText(" through" + " " +listOfEnquiryData.get(position).getRequestTargetCurrencyName() );
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity()+" "+listOfEnquiryData.get(position).getRequestSourceCurrencyName());

            }else if (listOfEnquiryData.get(position).getRequestTypeName().equalsIgnoreCase("Buy")){
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_buy));
                holder.txt_fromCurrency.setText(" through" + " " + listOfEnquiryData.get(position).getRequestSourceCurrencyName());
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity()+" "+listOfEnquiryData.get(position).getRequestTargetCurrencyName());

            }
           // holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity());
        }else if (listOfEnquiryData.get(position).getRequestSourceRefId().equalsIgnoreCase("7")){
            holder.txt_requestCustomer.setText("Travel Agent  wants to ");
            holder.nbc_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bidsource_ta));
            if (listOfEnquiryData.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_sell));
                holder.txt_fromCurrency.setText(" through" + " " +listOfEnquiryData.get(position).getRequestTargetCurrencyName() );
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity()+" "+listOfEnquiryData.get(position).getRequestSourceCurrencyName());

            }else if (listOfEnquiryData.get(position).getRequestTypeName().equalsIgnoreCase("Buy")){
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_buy));
                holder.txt_fromCurrency.setText(" through" + " " + listOfEnquiryData.get(position).getRequestSourceCurrencyName());
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity()+" "+listOfEnquiryData.get(position).getRequestTargetCurrencyName());

            }else if (listOfEnquiryData.get(position).getRequestTypeName().equalsIgnoreCase("Money Transfer")){
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_inprogress_monytransfer));
                holder.txt_fromCurrency.setText(" through" + " " + listOfEnquiryData.get(position).getRequestSourceCurrencyName());
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity()+" "+listOfEnquiryData.get(position).getRequestTargetCurrencyName());

            }
        }
        else {
            holder.nbc_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.ic_info_icon_progress));
            if (listOfEnquiryData.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_for_sell_inprogess));
                holder.txt_fromCurrency.setText(" through" + " " +listOfEnquiryData.get(position).getRequestTargetCurrencyName() );
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity()+" "+listOfEnquiryData.get(position).getRequestSourceCurrencyName());

            }else if (listOfEnquiryData.get(position).getRequestTypeName().equalsIgnoreCase("Buy")){
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.background_black_rounded));
                holder.txt_fromCurrency.setText(" through" + " " + listOfEnquiryData.get(position).getRequestSourceCurrencyName());
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity()+" "+listOfEnquiryData.get(position).getRequestTargetCurrencyName());

            }
            else {
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_inprogress_monytransfer));
                holder.txt_fromCurrency.setText(" through" + " " + listOfEnquiryData.get(position).getRequestSourceCurrencyName());
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity()+" "+listOfEnquiryData.get(position).getRequestTargetCurrencyName());

            }

        }

     //   holder.txt_fromCurrency.setText( listOfEnquiryData.get(position).getRequestTargetCurrencyName()+" through" + " " + listOfEnquiryData.get(position).getRequestSourceCurrencyName());
        holder.txtNBC.setText(listOfEnquiryData.get(position).getRequestSourceRef());
        String time = listOfEnquiryData.get(position).getRemaining();
        // String time_split[]=time.split(":");

      /*  String time_n[]=listOfEnquiryData.get(position).getRemaining().split(":");
        String actual_time*/



        holder.txtRequestTime.setText(listOfEnquiryData.get(position).getRemaining());
        holder.txtRequestTime2.setText(listOfEnquiryData.get(position).getRemaining());
        holder.txtLocation.setText(listOfEnquiryData.get(position).getAreaName() + " " + listOfEnquiryData.get(position).getCityName()+" "+"-"+" "+listOfEnquiryData.get(position).getDistance()+" "+"Kms");
        holder.txtMode.setText(listOfEnquiryData.get(position).getRequestDeliveryModeName());
        holder.txt_Currency_open.setText(listOfEnquiryData.get(position).getRequestProductTypeName());
        if (listOfEnquiryData.get(position).getRequestProductTypeName().equalsIgnoreCase("Forex Card")){
            holder.imgcurrency_open.setImageResource(R.drawable.demovisiting);
        }
        if(listOfEnquiryData.get(position).getRequestProductTypeName().equalsIgnoreCase("Currency Notes")){
            holder.imgcurrency_open.setImageResource(R.drawable.bidproduct);
        }
        if (listOfEnquiryData.get(position).getRequestProductTypeName().equalsIgnoreCase("Money Transfer")){
            holder.imgcurrency_open.setImageResource(R.drawable.moneytransfer);
        }
        holder.edt_cash1.setHint(listOfEnquiryData.get(position).getWatermarkRate());
        holder.edt_cash2.setHint(listOfEnquiryData.get(position).getWatermarkRate());



        if (listOfEnquiryData.get(position).getRequestProductTypeId_2().equalsIgnoreCase("0") && listOfEnquiryData.get(position).getRequestQuantity_2().equalsIgnoreCase("0") &&
                listOfEnquiryData.get(position).getRequestProductTypeName_2().equalsIgnoreCase("0")) {

            //istwoProduct = false;
        } else {
            if (listOfEnquiryData.get(position).getRequestSourceRefId().equalsIgnoreCase("7")){
                holder.txtRequestTitle.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_buy));
                holder.txt_requestCustomer.setText("Travel Agent  wants to ");
                holder.nbc_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bidsource_ta));
            }
            else {
                holder.nbc_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.ic_info_icon_progress));
            }

            double a,b,c;
            a= Double.parseDouble(listOfEnquiryData.get(position).getRequestQuantity());
            b= Double.parseDouble(listOfEnquiryData.get(position).getRequestQuantity_2());
            c=a+b;
            int d= (int) c;
                holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + d+" "+listOfEnquiryData.get(position).getRequestTargetCurrencyName());
            holder.txt_Currency_open.setText(listOfEnquiryData.get(position).getRequestProductTypeName()+"+"+"CurrencyNotes");
            holder.imgcurrency_open.setImageResource(R.drawable.cardcash);
        }


        if (listOfEnquiryData.get(position).getBidFFMCId().equalsIgnoreCase(branchID)) {
            Log.e("FFMCID**********", "" + listOfEnquiryData.get(position).getBidFFMCId());

            holder.btnBidNow.setVisibility(View.GONE);
            holder.linearLayout_watch_time1.setVisibility(View.GONE);
            holder.relativeLayout_OpenBid.setVisibility(View.VISIBLE);
            holder.linearLayout_watch_time2.setVisibility(View.VISIBLE);
            holder.relativeLayout_submitt.setVisibility(View.VISIBLE);
            holder.btn_submit.setVisibility(View.GONE);
            if (listOfEnquiryData.get(position).getRequestProductTypeId_2().equalsIgnoreCase("0") && listOfEnquiryData.get(position).getRequestQuantity_2().equalsIgnoreCase("0") &&
                    listOfEnquiryData.get(position).getRequestProductTypeName_2().equalsIgnoreCase("0")) {
                holder.txt_cash2.setVisibility(View.GONE);
                holder.edt_cash2.setVisibility(View.GONE);
                holder.txt_buy2.setVisibility(View.GONE);
                holder.edt_cash1.setBackgroundColor(context.getResources().getColor(R.color.dashboard_green));
                holder.edt_cash1.setEnabled(false);
                holder.edt_cash1.setText(listOfEnquiryData.get(position).getAverageRate());
            //    holder.txt_buy1.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity() + " " + listOfEnquiryData.get(position).getRequestTargetCurrencyName());
                holder.txt_buy1.setText("(" + "" + listOfEnquiryData.get(position).getRequestQuantity() + "" + ")");


            } else {
                holder.txt_cash1.setText("Card");
                holder.edt_cash1.setBackgroundColor(context.getResources().getColor(R.color.dashboard_green));
                holder.edt_cash1.setEnabled(false);
                holder.edt_cash2.setBackgroundColor(context.getResources().getColor(R.color.dashboard_green));
                holder.edt_cash2.setEnabled(false);
                holder.edt_cash1.setText(listOfEnquiryData.get(position).getAverageRate());
                holder.edt_cash2.setText(listOfEnquiryData.get(position).getAverageRate2());
             //   holder.txt_buy1.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity() + " " + listOfEnquiryData.get(position).getRequestTargetCurrencyName());
             //   holder.txt_buy2.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity_2() + " " + listOfEnquiryData.get(position).getRequestTargetCurrencyName());

                holder.txt_buy1.setText("(" + "" + listOfEnquiryData.get(position).getRequestQuantity() + "" +")");
                holder.txt_buy2.setText("("+ "" + listOfEnquiryData.get(position).getRequestQuantity_2() + "" + ")");

            }

        } else if (listOfEnquiryData.get(position).getBidFFMCId().equalsIgnoreCase("0")) {

            holder.btnBidNow.setVisibility(View.VISIBLE);
            holder.linearLayout_watch_time1.setVisibility(View.VISIBLE);
            holder.relativeLayout_OpenBid.setVisibility(View.GONE);
            holder.linearLayout_watch_time2.setVisibility(View.GONE);
            holder.relativeLayout_submitt.setVisibility(View.GONE);


        }

        holder.btnBidNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                holder.btnBidNow.setVisibility(View.GONE);
                holder.linearLayout_watch_time1.setVisibility(View.GONE);
                holder.relativeLayout_OpenBid.setVisibility(View.VISIBLE);
                holder.linearLayout_watch_time2.setVisibility(View.VISIBLE);
                holder.relativeLayout_submitt.setVisibility(View.VISIBLE);

                if (listOfEnquiryData.get(position).getRequestProductTypeId_2().equalsIgnoreCase("0") && listOfEnquiryData.get(position).getRequestQuantity_2().equalsIgnoreCase("0") &&
                        listOfEnquiryData.get(position).getRequestProductTypeName_2().equalsIgnoreCase("0")) {
                //    holder.txt_buy1.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity() + " " + listOfEnquiryData.get(position).getRequestTargetCurrencyName());
                    holder.txt_buy1.setText("(" + "" + listOfEnquiryData.get(position).getRequestQuantity() + "" + ")");
                    holder.txt_cash2.setVisibility(View.GONE);
                    holder.edt_cash2.setVisibility(View.GONE);
                    holder.txt_buy2.setVisibility(View.GONE);
                    istwoProduct = false;
                } else {
                    istwoProduct = true;
                    holder.txt_cash1.setText("Card");
                   // holder.txt_buy1.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity() + " " + listOfEnquiryData.get(position).getRequestTargetCurrencyName());
                    //holder.txt_buy2.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + listOfEnquiryData.get(position).getRequestQuantity_2() + " " + listOfEnquiryData.get(position).getRequestTargetCurrencyName());
                    holder.txt_buy1.setText("("+ "" + listOfEnquiryData.get(position).getRequestQuantity() + "" + ")");
                    holder.txt_buy2.setText("("+ "" + listOfEnquiryData.get(position).getRequestQuantity_2() + "" + ")");
/*
                    double a,b,c;
                    a= Double.parseDouble(listOfEnquiryData.get(position).getRequestQuantity());
                    b= Double.parseDouble(listOfEnquiryData.get(position).getRequestQuantity_2());
                    c=a+b;
                    holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getRequestTypeName() + " " + c);
                    holder.txt_Currency_open.setText(listOfEnquiryData.get(position).getRequestProductTypeName()+"+"+"CurrencyNotes");*/
                }


               /* listOfRequestProduct=new ArrayList<RequestProduct>();
                RequestProduct  requestProduct=new RequestProduct("1","200","64.00");
                listOfRequestProduct.add(requestProduct);
               *//* RequestProduct  requestProduct1=new RequestProduct("1","300","65.00");
                listOfRequestProduct.add(requestProduct1);*//*
               CallFFMCRequestbid callFFMCRequestbid=new CallFFMCRequestbid("373","1","4",listOfRequestProduct); //373
                callFFMCRequestbid.execute();*/
            }
        });


        holder.btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (istwoProduct) {
                    if ((holder.edt_cash1.getText().toString().equalsIgnoreCase(""))) {

                        CommonUI.showAlert(context, "Nafex", "please add product rate in both the edit fields");

                    }else {
                        if (holder.edt_cash2.getText().toString().trim().equalsIgnoreCase("")) {

                            CommonUI.showAlert(context, "Nafex", "please add product rate in both the edit fields");

                        } else {

                        Double min, max, edt1, edt2;
                        edt1 = Double.valueOf(holder.edt_cash1.getText().toString().trim());
                        edt2 = Double.valueOf(holder.edt_cash2.getText().toString().trim());
                        min = Double.valueOf(listOfEnquiryData.get(position).getThresholdMinRate().substring(0, listOfEnquiryData.get(position).getThresholdMinRate().length() - 2));
                        max = Double.valueOf(listOfEnquiryData.get(position).getThresholdMaxRate().substring(0, listOfEnquiryData.get(position).getThresholdMaxRate().length() - 2));

                        if (edt1 >= min && edt2 >= min) {

                            if (edt1 <= max && edt2 <= max) {


                                listOfRequestProduct = new ArrayList<RequestProduct>();
                                RequestProduct requestProduct = new RequestProduct(listOfEnquiryData.get(position).getRequestProductTypeId(), listOfEnquiryData.get(position).getRequestQuantity(), holder.edt_cash1.getText().toString().trim());
                                listOfRequestProduct.add(requestProduct);
                                RequestProduct requestProduct1 = new RequestProduct(listOfEnquiryData.get(position).getRequestProductTypeId_2(), listOfEnquiryData.get(position).getRequestQuantity_2(), holder.edt_cash2.getText().toString().trim());
                                listOfRequestProduct.add(requestProduct1);
                                CallFFMCRequestbid callFFMCRequestbid = new CallFFMCRequestbid(listOfEnquiryData.get(position).getRequestId(), branchID, "4", listOfRequestProduct, holder); //373
                                callFFMCRequestbid.execute();
                            } else {
                                CommonUI.showAlert(context, "Nafex", "You are exceeding threshold limit (" + listOfEnquiryData.get(position).getThresholdMinRate() + "-" + listOfEnquiryData.get(position).getThresholdMaxRate() + ")");
                            }
                        } else {
                            CommonUI.showAlert(context, "Nafex", "You are exceeding threshold limit (" + listOfEnquiryData.get(position).getThresholdMinRate() + "-" + listOfEnquiryData.get(position).getThresholdMaxRate() + ")");
                        }

                    }
                }
                    /*else {
                        CommonUI.showAlert(context, "Nafex", "please add product rate in both the edit fields");
                    }*/


                } else {
                    if (holder.edt_cash1.getText().toString().equalsIgnoreCase("")) {
                        CommonUI.showAlert(context, "Nafex", "please add product rate in edit field");
                    }else {
                        Double min_n ,max_n,edt1_n,edt2;
                        edt1_n= Double.valueOf(holder.edt_cash1.getText().toString().trim());

                       /* min_n = Double.valueOf(listOfEnquiryData.get(position).getThresholdMinRate());
                        max_n= Double.valueOf(listOfEnquiryData.get(position).getThresholdMaxRate());*/
                        min_n = Double.valueOf(listOfEnquiryData.get(position).getThresholdMinRate().substring(0,listOfEnquiryData.get(position).getThresholdMinRate().length()-2));
                        max_n= Double.valueOf(listOfEnquiryData.get(position).getThresholdMaxRate().substring(0,listOfEnquiryData.get(position).getThresholdMaxRate().length()-2));

                        if (edt1_n>=min_n) {

                            if (edt1_n<=max_n) {

                                listOfRequestProduct = new ArrayList<RequestProduct>();
                                RequestProduct requestProduct = new RequestProduct(listOfEnquiryData.get(position).getRequestProductTypeId(), listOfEnquiryData.get(position).getRequestQuantity(), holder.edt_cash1.getText().toString().trim());
                                listOfRequestProduct.add(requestProduct);
                                CallFFMCRequestbid callFFMCRequestbid = new CallFFMCRequestbid(listOfEnquiryData.get(position).getRequestId(), branchID, "4", listOfRequestProduct, holder); //373
                                callFFMCRequestbid.execute();
                            }else {
                                CommonUI.showAlert(context, "Nafex", "You are exceeding threshold limit ("+listOfEnquiryData.get(position).getThresholdMinRate()+"-"+listOfEnquiryData.get(position).getThresholdMaxRate()+")");
                            }
                        }else {
                            CommonUI.showAlert(context, "Nafex", "You are exceeding threshold limit ("+listOfEnquiryData.get(position).getThresholdMinRate()+"-"+listOfEnquiryData.get(position).getThresholdMaxRate()+")");
                        }

                    } /*else {
                        CommonUI.showAlert(context, "Nafex", "please add product rate in edit field");
                    }*/
                }
            }
        });

        String[] arr = listOfEnquiryData.get(position).getRemaining().split(":");


        if (Integer.parseInt(arr[0]) == 0 && Integer.parseInt(arr[1]) <= 5 ) {

            if (!arr[0].substring(0, 1).equalsIgnoreCase("-")) {
                holder.txtRequestTime.setText("00:00");
                holder.txtRequestTime2.setText("00:00");
                Log.e("timerStop","onFinish1");
                if (listOfEnquiryData.get(position).getRequestId()!=null) {
                    fragment_open.timerStop(listOfEnquiryData.get(position).getRequestId());
                }

                if (cdtHitApi == null) {
                    cdtHitApi = new CountDownTimer((Integer.parseInt(arr[1]) * 60000 + 1000 * Integer.parseInt(arr[2])), RefeshAfter) {

                        public void onTick(long millisUntilFinished) {
                        /*    CallRequestBidsAPI objRequestBidsAPI = new CallRequestBidsAPI();
                            objRequestBidsAPI.execute(ConstantData.BIDLIST);*/
                        }

                        public void onFinish() {
                            holder.txtRequestTime.setText("00:00");
                            holder.txtRequestTime2.setText("00:00");
                            Log.e("timerStop","Inside On finish");

                            fragment_open.timerStop(listOfEnquiryData.get(position).getRequestId());


                        }
                    }.start();
                }
            } else {
                holder.txtRequestTime.setText(arr[1] + ":" + arr[2]);
                holder.txtRequestTime2.setText(arr[1] + ":" + arr[2]);
                //60000 * 5;
                cdt = new CountDownTimer((Integer.parseInt(arr[1]) * 60000 + 1000 * Integer.parseInt(arr[2])), RefeshCountDown) {

                    public void onTick(long millisUntilFinished) {
                        CountDownTimerTick(millisUntilFinished, holder);
                    }

                    public void onFinish() {
                        Log.e("timerStop","onFinish");
                        holder.txtRequestTime.setText("00:00");
                        holder.txtRequestTime2.setText("00:00");

                        if (listOfEnquiryData.size()!=0) {
                          try {
                              fragment_open.timerStop(listOfEnquiryData.get(position).getRequestId());
                          }catch (IndexOutOfBoundsException e){
                              e.printStackTrace();
                          }
                          //  fragment_open.timerStop(listOfEnquiryData.get(position).getRequestId());
                        }
                        //showAlert(getResources().getString(R.string.app_name), "All options are available below, please accept any one to proceed.");
                        //showAlert(getResources().getString(R.string.app_name), "Unfortunately, no options came during five minutes. Nafex support team will contact you soon with options.");

                     /*   if (bidList != null && bidList.size() > 0)
                            txtMessageName.setText("All options are available below, please accept any one to proceed.");
                        else
                            txtMessageName.setText("Unfortunately, no options came during five minutes. Nafex support team will contact you soon with options.");*/

                        if (cdtHitApi == null) {
                            cdtHitApi = new CountDownTimer(60000 * 30, RefeshAfter) {

                                public void onTick(long millisUntilFinished) {
                                    /*CallRequestBidsAPI objRequestBidsAPI = new CallRequestBidsAPI();
                                    objRequestBidsAPI.execute(ConstantData.BIDLIST);*/
                                }

                                public void onFinish() {

                                    holder.txtRequestTime.setText("00:00");
                                    holder.txtRequestTime2.setText("00:00");
                                    Log.e("timerStop","onFinish1");
                                   fragment_open.timerStop(listOfEnquiryData.get(position).getRequestId());
                                }
                            }.start();
                        }
                    }
                }.start();
            }
        } else if (Integer.parseInt(arr[0]) == 0 && Integer.parseInt(arr[1]) < 30 ) {
            holder.txtRequestTime.setText("00:00");
            holder.txtRequestTime2.setText("00:00");
            Log.e("timerStop","onFinish1");
            fragment_open.timerStop(listOfEnquiryData.get(position).getRequestId());

            if (cdtHitApi == null) {
                cdtHitApi = new CountDownTimer((Integer.parseInt(arr[1]) * 60000 + 1000 * Integer.parseInt(arr[2])), RefeshAfter) {

                    public void onTick(long millisUntilFinished) {
                       /* CallRequestBidsAPI objRequestBidsAPI = new CallRequestBidsAPI();
                        objRequestBidsAPI.execute(ConstantData.BIDLIST);*/
                    }

                    public void onFinish() {
                        holder.txtRequestTime.setText("00:00");
                        holder.txtRequestTime2.setText("00:00");
                        Log.e("timerStop","onFinish1");
                        fragment_open.timerStop(listOfEnquiryData.get(position).getRequestId());
                    }
                }.start();
            }
        }


       /* if (listOfEnquiryData.get(position).getsta().equalsIgnoreCase("BID_DONE")) {
            //holder.btnBidNow.setVisibility(View.GONE);
            holder.btnBidNow.setBackground(context.getDrawable(R.drawable.rounded_corner_button_border_green));
            holder.btnBidNow.setText("INR " + listOfEnquiryData.get(position).getreqBidRate());
            holder.btnBidNow.setTextColor(Color.BLACK);
        }
        else if (listOfEnquiryData.get(position).getreqBidStatus().equalsIgnoreCase("BID_WON"))
        {
            holder.btnBidNow.setBackground(context.getDrawable(R.drawable.rounded_corner_button_border_green));
            holder.btnBidNow.setText("INR " + listOfEnquiryData.get(position).getreqBidRate());
            holder.btnBidNow.setTextColor(Color.BLACK);
        }
        else {
            //holder.btnBidNow.setVisibility(View.VISIBLE);
            holder.btnBidNow.setBackground(context.getDrawable(R.drawable.rounded_corner_green_button));
            holder.btnBidNow.setText("BID NOW");
            holder.btnBidNow.setTextColor(Color.WHITE);

            final int pos = position;
            holder.btnBidNow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    objBidOpen.onBidNowButtonClicked(pos, listOfEnquiryData.get(pos).getreqId());
                }
            });

        }

        holder.txtRequestTitle.setText(listOfEnquiryData.get(position).getreqType() + " " + listOfEnquiryData.get(position).getreqQuantity() + " " + listOfEnquiryData.get(position).getreqCurrencyName());
        holder.txtNBC.setText(listOfEnquiryData.get(position).getNBC());


        if (listOfEnquiryData.get(position).getReqDateTime()!= "") {
            String[] arr = listOfEnquiryData.get(position).getReqDateTime().split(":");
            holder.txtRequestTime.setText(arr[1] + ":" + arr[2]);
        }
        else
            holder.txtRequestTime.setText(listOfEnquiryData.get(position).getReqDateTime());

        holder.txtLocation.setText(listOfEnquiryData.get(position).getreqLocation());
        holder.txtMode.setText(listOfEnquiryData.get(position).getreqMode());

        holder.txtModeImage.setImageDrawable(context.getDrawable(R.drawable.deliverygrey_128));

        if (listOfEnquiryData.get(position).getreqStatus().equalsIgnoreCase("O") || listOfEnquiryData.get(position).getreqStatus().equalsIgnoreCase("F")) {
            holder.layreqStatus.setVisibility(View.GONE);
        }
        else
        {
            holder.layreqStatus.setVisibility(View.VISIBLE);
            holder.txtStatus.setText(gbData.PrepareStatusString(listOfEnquiryData.get(position).getreqStatus()));
        }
*/
    }

    @Override
    public int getItemCount() {
        return listOfEnquiryData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtRequestTitle, txtNBC, txtRequestTime, txtLocation, txtMode, txtStatus, txtRequestTime2, txt_cash1, txt_buy1, txt_cash2, txt_buy2, txt_fromCurrency, txt_Currency_open, txt_requestCustomer;
        Button btnBidNow, btn_submit;
        ImageView txtModeImage,imgcurrency_open,nbc_icon;
        LinearLayout layreqStatus, linearLayout_watch_time1, linearLayout_watch_time2;
        RelativeLayout relativeLayout_OpenBid, relativeLayout_submitt;
        EditText edt_cash1, edt_cash2;



        public ViewHolder(View itemView) {
            super(itemView);
            txtRequestTitle = (TextView) itemView.findViewById(R.id.txtRequestTitle);
            txtNBC = (TextView) itemView.findViewById(R.id.txtNBC);
            txtRequestTime = (TextView) itemView.findViewById(R.id.txtRequestTime);
            txtLocation = (TextView) itemView.findViewById(R.id.txtLocation);
            txtMode = (TextView) itemView.findViewById(R.id.txtMode);
            txtStatus = (TextView) itemView.findViewById(R.id.txtreqStatus);
            imgcurrency_open= (ImageView) itemView.findViewById(R.id.imgcurrency_open);

            btnBidNow = (Button) itemView.findViewById(R.id.btnBidNow);
            nbc_icon= (ImageView) itemView.findViewById(R.id.nbc_icon);

            txtModeImage = (ImageView) itemView.findViewById(R.id.txtModeImage);

            layreqStatus = (LinearLayout) itemView.findViewById(R.id.layreqStatus);

            linearLayout_watch_time1 = (LinearLayout) itemView.findViewById(R.id.linear_watch_time1);
            linearLayout_watch_time2 = (LinearLayout) itemView.findViewById(R.id.linear_watch_time2);
            relativeLayout_OpenBid = (RelativeLayout) itemView.findViewById(R.id.relative_openBid);
            relativeLayout_submitt = (RelativeLayout) itemView.findViewById(R.id.relative_submit);

            txtRequestTime2 = (TextView) itemView.findViewById(R.id.txtRequestTime2);
            txt_cash1 = (TextView) itemView.findViewById(R.id.txt_cash1);
            txt_buy1 = (TextView) itemView.findViewById(R.id.txt_buy1);
            txt_cash2 = (TextView) itemView.findViewById(R.id.txt_cash2);
            txt_buy2 = (TextView) itemView.findViewById(R.id.txt_buy2);
            edt_cash1 = (EditText) itemView.findViewById(R.id.edt_Cash_1);
            edt_cash2 = (EditText) itemView.findViewById(R.id.edtCash2);
            btn_submit = (Button) itemView.findViewById(R.id.btn_Submit);
            txt_fromCurrency = (TextView) itemView.findViewById(R.id.txt_fromCurrency);
            txt_Currency_open = (TextView) itemView.findViewById(R.id.txt_Currency_open);
            txt_requestCustomer = (TextView) itemView.findViewById(R.id.txt_requestCustomer);

           /* edt_cash1.setFilters(new InputFilter[] {
                    new DigitsKeyListener(Boolean.FALSE, Boolean.TRUE) {
                        int beforeDecimal = 2, afterDecimal = 4;

                        @Override
                        public CharSequence filter(CharSequence source, int start, int end,
                                                   Spanned dest, int dstart, int dend) {
                            String temp = edt_cash1.getText() + source.toString();

                            if (temp.equals(".")) {
                                return "0.";
                            }
                            else if (temp.toString().indexOf(".") == -1) {
                                // no decimal point placed yet
                                if (temp.length() > beforeDecimal) {
                                    return "";
                                }
                            } else {
                                temp = temp.substring(temp.indexOf(".") + 1);
                                if (temp.length() > afterDecimal) {
                                    return "";
                                }
                            }

                            return super.filter(source, start, end, dest, dstart, dend);
                        }
                    }
            });*/


        }
    }


    public class CallFFMCRequestbid extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";
        String bidRequestId_n;
        String bidFFMCId_n;
        String nrequestBidSource_n;
        ArrayList<RequestProduct> listProduct_n;
        ViewHolder holder_n;


        public CallFFMCRequestbid(String bidRequestId, String bidFFMCId, String nrequestBidSource, ArrayList<RequestProduct> listProduct, ViewHolder holder) {
            this.bidRequestId_n = bidRequestId;
            this.bidFFMCId_n = bidFFMCId;
            this.nrequestBidSource_n = nrequestBidSource;
            listProduct_n = new ArrayList<>();
            this.listProduct_n.addAll(listProduct);
            this.holder_n = holder;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //if (Error_Message.equalsIgnoreCase("")) {
                String strNBC = "";

               // Log.e("Responsesss ", );
                try {
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {

                        JSONObject jsonObjectMsgText = objdata.getJSONObject("message_text");
                        responce_BidID = jsonObjectMsgText.getString("bidId");
                        responceMsg = jsonObjectMsgText.getString("successMessage");
                        CommonUI.showAlert(context, context.getResources().getString(R.string.app_name), responceMsg);
                        holder_n.btn_submit.setVisibility(View.GONE);
                       // fragment_open.timerStop(bidRequestId_n);
                        holder_n.edt_cash1.setBackgroundColor(context.getResources().getColor(R.color.dashboard_green));
                        holder_n.edt_cash2.setBackgroundColor(context.getResources().getColor(R.color.dashboard_green));
                        holder_n.edt_cash1.setEnabled(false);
                        holder_n.edt_cash2.setEnabled(false);
                        CallBidWebService bidWebService=new CallBidWebService(bidRequestId_n,bidFFMCId_n);
                        bidWebService.execute();
                    /*  try{
                          fragment_open.timerStop(bidRequestId_n);
                      }catch (ConcurrentModificationException e){
                          e.printStackTrace();
                      }*/
                   fragment_open.refresh();



                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(context, context.getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                   /* if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(context, context.getResources().getString(R.string.app_name), Error_Message);*/
                }
           /* } else
                CommonUI.showAlert(context, context.getResources().getString(R.string.app_name), Error_Message);*/

            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.FFMC_ADD_REQUEST_BID);
                Log.e("APIIIIIIIIIIIII", "" + url);
                Log.e("bidRequestId", bidRequestId_n);
                Log.e("bidFFMCId", bidFFMCId_n);
                Log.e("requestBidSource", nrequestBidSource_n);
                for (int i = 0; i < listProduct_n.size(); i++) {
                    Log.e("IN AARRAY LISTTTTTT", "" + listProduct_n.get(i).getProductQuantity());
                }


                urlConnection = (HttpURLConnection) url.openConnection();
                String userPass = ConstantData.USERID + ":" + ConstantData.token;
                Log.e("USER____ID", "" + ConstantData.USERID);
                Log.e("USER____token", "" + ConstantData.token);


                JSONObject postDataParams = new JSONObject();
                postDataParams.put("bidRequestId", bidRequestId_n);
                postDataParams.put("bidFFMCId", bidFFMCId_n);
               // postDataParams.put("requestBidSource", nrequestBidSource_n);
                postDataParams.put("requestBidSource", "2");

                JSONArray jsonArrayRequestProduct = new JSONArray();
                for (int j = 0; j < listProduct_n.size(); j++) {
                    JSONObject jsonObjectInner = new JSONObject();
                    jsonObjectInner.put("productTypeId", listProduct_n.get(j).getProductTypeId());
                    jsonObjectInner.put("productQuantity", listProduct_n.get(j).getProductQuantity());
                    jsonObjectInner.put("productRate", listProduct_n.get(j).getProductRate());
                    jsonArrayRequestProduct.put(jsonObjectInner);
                }
                String jsonArray = jsonArrayRequestProduct.toString();
                Log.e("JSON ARRAY TO STRIGG", "" + jsonArray);
                postDataParams.put("requestProducts", jsonArrayRequestProduct);
                //        String authorizationString = "Basic " + Base64.encodeToString((ConstantData.USERID+":"+ConstantData.token).getBytes(), Base64.NO_WRAP);
                String authorizationString = "Basic " + Base64.encodeToString((user_id + ":" + user_token).getBytes(), Base64.NO_WRAP);
                Log.e("user_idddd",""+user_id+"  "+user_token);
                urlConnection.setRequestProperty("Authorization", authorizationString);
                urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(60000 /* milliseconds */);
                urlConnection.setConnectTimeout(60000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                   /* urlConnection.connect();*/

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();

                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result333", strResponse);
                }
            } catch (JSONException e) {
               // Log.e("***Error:", e.getMessage() , e);
               /* if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/

            } catch (Exception e) {
             //  Log.e("ERRORww", e.getMessage(), e);
              //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } /*finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
            return null;
        }
    }


    private void getSharedPref() {
        sharedpreferences = context.getSharedPreferences(ConstantData.MyPREFERENCES, context.MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID=sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID,"");

    }


    public void setFonts(ViewHolder holder) {
        holder.txt_requestCustomer.setTypeface(FontData.setFonts(context, holder.txt_requestCustomer, FontData.font_robotomedium));
        holder.txtRequestTitle.setTypeface(FontData.setFonts(context, holder.txtRequestTitle, FontData.font_robotomedium));
        holder.txt_fromCurrency.setTypeface(FontData.setFonts(context, holder.txt_fromCurrency, FontData.font_robotomedium));

        holder.txtNBC.setTypeface(FontData.setFonts(context, holder.txtNBC, FontData.font_robotomedium));
        //   holder.txt_Currency_open.setTypeface(FontData.setFonts(context,holder.txtRequestTitle,FontData.font_robotoBold));
        holder.txtRequestTime.setTypeface(FontData.setFonts(context, holder.txtRequestTime, FontData.font_robotomedium));
        holder.txtRequestTime2.setTypeface(FontData.setFonts(context, holder.txtRequestTime, FontData.font_robotomedium));

        holder.btnBidNow.setTypeface(FontData.setFonts(context, holder.btnBidNow, FontData.font_robotoBold));
        holder.txt_cash1.setTypeface(FontData.setFonts(context, holder.txt_cash1, FontData.font_robotoregular));
        holder.txt_cash2.setTypeface(FontData.setFonts(context, holder.txt_cash2, FontData.font_robotoregular));
        holder.edt_cash1.setTypeface(FontData.setFonts(context, holder.edt_cash1, FontData.font_robotoregular));
        holder.edt_cash2.setTypeface(FontData.setFonts(context, holder.edt_cash2, FontData.font_robotoregular));
        holder.txt_buy1.setTypeface(FontData.setFonts(context, holder.txt_buy1, FontData.font_robotoregular));
        holder.txt_buy2.setTypeface(FontData.setFonts(context, holder.txt_buy2, FontData.font_robotoregular));
        holder.btn_submit.setTypeface(FontData.setFonts(context, holder.btn_submit, FontData.font_robotoBold));

        holder.txtLocation.setTypeface(FontData.setFonts(context, holder.txtLocation, FontData.font_robotoregular));
        holder.txt_Currency_open.setTypeface(FontData.setFonts(context, holder.txt_Currency_open, FontData.font_robotoregular));
        holder.txtMode.setTypeface(FontData.setFonts(context, holder.txtMode, FontData.font_robotoregular));


    }


    private void CountDownTimerTick(long millisUntilFinished, ViewHolder holder) {

        long remaining = millisUntilFinished / RefeshCountDown;
        String disp = String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished),
                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))
        );
        // txtCountDown.setText(disp);
        holder.txtRequestTime.setText(disp);
        holder.txtRequestTime2.setText(disp);
      /*  SecondsCounter = SecondsCounter -1;

        if (SecondsCounter == 0)
        {
            SecondsCounter = RefreshCounter;
            *//*CallRequestBidsAPI objRequestBidsAPI =  new CallRequestBidsAPI();
            objRequestBidsAPI.execute(ConstantData.BIDLIST);*//*
        }*/

    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }



    public class CallBidWebService extends AsyncTask<String, Void, String> {

        String Error_Message = "";
        String bidRequestId_n_new;
        String bidId;

        public CallBidWebService(String bidRequestId_n_new, String bidId) {
            this.bidRequestId_n_new = bidRequestId_n_new;
            this.bidId = bidId;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // progressBar.setVisibility(View.VISIBLE);
            // setProgressBarIndeterminateVisibility(true);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            // progressBar.setVisibility(View.GONE);
            // setProgressBarIndeterminateVisibility(false);
            if (Error_Message.equalsIgnoreCase("")) {

            }
            //  showCurrencyAlertCustomDialog();
           // else
               // CommonUI.showAlert(context, getResources().getString(R.string.app_name), Error_Message);
        }

        @Override
        protected String doInBackground(String... strings) {
            CallForCurrency();
            return "DONE";

        }

        private void CallForCurrency() {
            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL("http://13.59.118.35:2020/broadcast?token=NEWB|" + bidRequestId_n_new + "|" + bidId);

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod(CommonApi.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("ResultsBidFFMC", myjsonstring);

                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    ///  currencyList = new ArrayList<Currency>();
                   /* for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);

                    }*/
                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    //  Error_Message = objdata.getString("message_text");
                    // CommonUI.showAlert(context,getResources().getString(R.string.app_name),objdata.getString("message_text"));
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
              /*  if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";*/
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                //  Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            }/* finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }*/
        }
    }
}

