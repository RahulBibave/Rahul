package com.nafex.nafex2.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.EnquiryData;
import com.nafex.nafex2.interfaces.EnquiryOperations;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.FontData;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by rahul on 5/10/17.
 */

public class AdapterSelect_Dispute extends RecyclerView.Adapter<AdapterSelect_Dispute.ViewHolderSelect> {


    private Context mContext;
    private List<EnquiryData> enquiryList = null;
    EnquiryOperations encoperation = null;
    int intdisputeid;


    public AdapterSelect_Dispute(Context mContext, List<EnquiryData> enqrList, EnquiryOperations oper, int disputeid) {
        this.mContext = mContext;
        this.enquiryList = enqrList;
        encoperation = oper;
        intdisputeid = disputeid;
    }

    @Override
    public ViewHolderSelect onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.lay_select_enquiry_view, parent, false);
        ViewHolderSelect viewHolderSelect = new ViewHolderSelect(view);
        return viewHolderSelect;
    }

    @Override
    public void onBindViewHolder(ViewHolderSelect holder, final int position) {
        holder.txtEnqNo.setText(enquiryList.get(position).getRequestSourceRef());
        holder.txtBS.setText(enquiryList.get(position).getRequestTypeName());
        holder.txtEnqNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (encoperation != null) {
                  /*  if (intdisputeid == 0) {
                        CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), "Please select dispute type from dropdownlist");

                    } else {
                        encoperation.OnRespondclick(position,intdisputeid);

                    }*/
                    encoperation.OnRespondclick(position, intdisputeid);
                }
            }
        });
        //   holder.txtBS.setText(enquiryList.get(position).getRequestTypeName());
        try {


            Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).parse(enquiryList.get(position).getLastModifiedOn());
            String stringdd = new SimpleDateFormat("dd", Locale.US).format(date).toUpperCase(Locale.ROOT);
            String stringmm = new SimpleDateFormat("MM", Locale.US).format(date).toUpperCase(Locale.ROOT);
            Log.e("stringdd", stringdd);
            Log.e("stringmm", stringmm);

            holder.txtEnqDate.setText(stringdd + " / " + stringmm);
            /*if (enquiryList.get(position).getRequestQuantity().equalsIgnoreCase("")) {
                holder.txtQnt.setText(enquiryList.get(position).getRequestQuantity1());

            } else {
                holder.txtQnt.setText(enquiryList.get(position).getRequestQuantity());

            }*/

            holder.txtQnt.setText(enquiryList.get(position).getRequestQuantity());


            holder.txtCUR.setText(enquiryList.get(position).getRequestSourceCurrencyName() + " to " + enquiryList.get(position).getRequestTargetCurrencyName());


        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        return enquiryList.size();
    }

    public class ViewHolderSelect extends RecyclerView.ViewHolder {

        private TextView txtEnqDate, txtEnqNo, txtBS, txtQnt, txtCUR;

        public ViewHolderSelect(View itemView) {
            super(itemView);

            txtEnqDate = (TextView) itemView.findViewById(R.id.txtEnqDate);
            txtEnqNo = (TextView) itemView.findViewById(R.id.txtEnqNo);
            txtBS = (TextView) itemView.findViewById(R.id.txtBS);
            txtQnt = (TextView) itemView.findViewById(R.id.txtQnt);
            txtCUR = (TextView) itemView.findViewById(R.id.txtCUR);


            txtEnqDate.setTypeface(FontData.setFonts(mContext, txtEnqDate, FontData.font_robotomedium));
            txtEnqNo.setTypeface(FontData.setFonts(mContext, txtEnqNo, FontData.font_robotomedium));
            txtBS.setTypeface(FontData.setFonts(mContext, txtBS, FontData.font_robotomedium));
            txtQnt.setTypeface(FontData.setFonts(mContext, txtQnt, FontData.font_robotomedium));
            txtCUR.setTypeface(FontData.setFonts(mContext, txtCUR, FontData.font_robotomedium));


        }
    }


}