package com.nafex.nafex2.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.EnquiriesInProgressData;
import com.nafex.nafex2.utilities.FontData;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Sunil on 5/15/2017.
 */
public class EnquiryInprogressAdapter extends RecyclerView.Adapter<EnquiryInprogressAdapter.ViewHolder> {

    Context context;
    ArrayList<EnquiriesInProgressData> listOfInprogress;
    Calendar calendar;
    DateFormat f2 ;
    DateFormat f1;
    Date d;

    public EnquiryInprogressAdapter(Context context, ArrayList<EnquiriesInProgressData> listOfInprogress) {
        this.context = context;
        this.listOfInprogress = listOfInprogress;
        calendar = Calendar.getInstance();
        f2 = new SimpleDateFormat("h:mma");;
        f1 = new SimpleDateFormat("HH:mm:ss");
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.lay_fragment_inprogress_view,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        setFonts(holder);
        holder.layout1.setVisibility(View.VISIBLE);
        holder.layout2.setVisibility(View.VISIBLE);
        holder.txt_dual_product_bid.setVisibility(View.GONE);
        holder.txt_Avg.setVisibility(View.GONE);
       // holder.txt_dual_product_bid.setVisibility(View.VISIBLE);
        if (listOfInprogress.get(position).getRequestSourceRefId().equalsIgnoreCase("5")||listOfInprogress.get(position).getRequestSourceRefId().equalsIgnoreCase("3")||listOfInprogress.get(position).getRequestSourceRefId().equalsIgnoreCase("6")){
            holder.img_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bidsource_ffmc));
            if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                holder.txt_requestTitle.setText("Money Changer  ");
            }else {
                holder.txt_requestTitle.setText("Money Changer wants to ");
            }

           /* holder.txt_inprogress_bought.setVisibility(View.GONE);
            holder.txt_inprogress_bought_monyTrans.setVisibility(View.GONE);
            holder.txt_inprogress_bought_sale.setVisibility(View.GONE);*/
            if(listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                    holder.txt_inprogress_bought.setText("Sold"+" "+listOfInprogress.get(position).getRequestQuantity()+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());
                }else {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+listOfInprogress.get(position).getRequestQuantity()+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());
                }
                holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_sell));

               /* holder.txt_inprogress_moneychanger_buy.setVisibility(View.GONE);
                holder.txt_inprogress_moneychanger_sell.setVisibility(View.VISIBLE);*/
                holder.txt_inprogress_requestTitle2.setText(" through"+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());

            }
            else if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Buy")){
                if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                    holder.txt_inprogress_bought.setText("Bought"+" "+listOfInprogress.get(position).getRequestQuantity()+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());
                }else {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+listOfInprogress.get(position).getRequestQuantity()+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());
                }
                holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_buy));
            /*    holder.txt_inprogress_moneychanger_buy.setVisibility(View.VISIBLE);
                holder.txt_inprogress_moneychanger_sell.setVisibility(View.GONE);*/
                holder.txt_inprogress_requestTitle2.setText(" through"+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());

            }
        }
        else if (listOfInprogress.get(position).getRequestSourceRefId().equalsIgnoreCase("7")){
            if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                holder.txt_requestTitle.setText("Travel Agent ");
            }else {
                holder.txt_requestTitle.setText("Travel Agent  wants to ");
            }

            holder.img_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bidsource_ta));
            if(listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                    holder.txt_inprogress_bought.setText("Sold"+" "+listOfInprogress.get(position).getRequestQuantity()+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());
                }else {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+listOfInprogress.get(position).getRequestQuantity()+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());
                }
                holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_sell));

               /* holder.txt_inprogress_moneychanger_buy.setVisibility(View.GONE);
                holder.txt_inprogress_moneychanger_sell.setVisibility(View.VISIBLE);*/
                holder.txt_inprogress_requestTitle2.setText(" through"+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());

            }
            else if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Buy")){
                if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                    holder.txt_inprogress_bought.setText("Bought"+" "+listOfInprogress.get(position).getRequestQuantity()+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());
                }else {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+listOfInprogress.get(position).getRequestQuantity()+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());
                }
                holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_buy));
            /*    holder.txt_inprogress_moneychanger_buy.setVisibility(View.VISIBLE);
                holder.txt_inprogress_moneychanger_sell.setVisibility(View.GONE);*/
                holder.txt_inprogress_requestTitle2.setText(" through"+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());

            }else if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Money Transfer")){

                holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_inprogress_monytransfer));
            /*    holder.txt_inprogress_moneychanger_buy.setVisibility(View.VISIBLE);
                holder.txt_inprogress_moneychanger_sell.setVisibility(View.GONE);*/
                holder.txt_inprogress_requestTitle2.setText(" through"+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());

            }
        }
        else {
            if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                holder.txt_requestTitle.setText("Customer ");
            }else {
                holder.txt_requestTitle.setText("Customer wants to ");
            }

            holder.img_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.ic_info_icon));
            if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Sell")) {
                if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                    holder.txt_inprogress_bought.setText("Sold" + " " + listOfInprogress.get(position).getRequestQuantity() + " " + listOfInprogress.get(position).getRequestSourceCurrencyName());
                }
                else {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName() + " " + listOfInprogress.get(position).getRequestQuantity() + " " + listOfInprogress.get(position).getRequestSourceCurrencyName());
                }
                holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_for_sell_inprogess));
                /*holder.txt_inprogress_bought_sale.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought.setVisibility(View.GONE);
                holder.txt_inprogress_bought_monyTrans.setVisibility(View.GONE);*/
                holder.txt_inprogress_requestTitle2.setText(" through" + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());

            } else if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Buy")) {
                if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                    holder.txt_inprogress_bought.setText("Bought" + " " + listOfInprogress.get(position).getRequestQuantity() + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());
                }
                else {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName() + " " + listOfInprogress.get(position).getRequestQuantity() + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());
                }

                holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.background_black_rounded));

                /*holder.txt_inprogress_bought_sale.setVisibility(View.GONE);
                holder.txt_inprogress_bought.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought_monyTrans.setVisibility(View.GONE);*/
                holder.txt_inprogress_requestTitle2.setText(" through" + " " + listOfInprogress.get(position).getRequestSourceCurrencyName());

            } else {
               /* if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName() + " " + listOfInprogress.get(position).getRequestQuantity() + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());
                }
                else {
                }*/
                holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName() + " " + listOfInprogress.get(position).getRequestQuantity() + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());

                holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName() + " " + listOfInprogress.get(position).getRequestQuantity() + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());
                holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_inprogress_monytransfer));
               /* holder.txt_inprogress_bought_monyTrans.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought_sale.setVisibility(View.GONE);
                holder.txt_inprogress_bought.setVisibility(View.GONE);*/
                holder.txt_inprogress_requestTitle2.setText(" through" + " " + listOfInprogress.get(position).getRequestSourceCurrencyName());

            }
        }




        holder.txt_NBCNo.setText(listOfInprogress.get(position).getRequestSourceRef());
        holder.txt_Status.setText(listOfInprogress.get(position).getRequestStatusName());
        if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
            holder.txt_Status.setText("Lost");
            holder.txt_Status.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.oval_backround_red));
        }else {
            holder.txt_Status.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.oval_bg_blue));
        }
      //  holder.txt_DatenTime.setText(listOfInprogress.get(position).getRequestBidAcceptedDateTime());
        holder.txt_location.setText(listOfInprogress.get(position).getAreaName()+" "+listOfInprogress.get(position).getCityName()+" - "+listOfInprogress.get(position).getDistance());

        if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Money Transfer")){
            holder.txt_Currency.setText("Money Transfer");
        }
        else {
            holder.txt_Currency.setText(listOfInprogress.get(position).getRequestProductTypeName());
        }
        Log.e("wwww",""+listOfInprogress.get(position).getRequestProductTypeName()+"  "+listOfInprogress.get(position).getRequestStatusName());

        if (listOfInprogress.get(position).getSize().equalsIgnoreCase("2")){
            holder.imgCurrencyO.setImageResource(R.drawable.cardcash);
            holder.txt_dual_product_bid.setVisibility(View.VISIBLE);
            holder.txt_dual_product_bid.setText(" @ "+listOfInprogress.get(position).getProductName()+"("+listOfInprogress.get(position).getRequestBidQuantity()+"):"+listOfInprogress.get(position).getRequestBidRate()+" + "+listOfInprogress.get(position).getProductName1()+"("+listOfInprogress.get(position).getRequestBidQuantity1()+"):"+listOfInprogress.get(position).getRequestBidRate1());
        }
        else {
            Log.e("qqqqaaq",""+listOfInprogress.get(position).getSize());
            if (listOfInprogress.get(position).getRequestProductTypeName().equalsIgnoreCase("Currency Notes")){
                holder.imgCurrencyO.setImageResource(R.drawable.bidproduct);
            }
            if (listOfInprogress.get(position).getRequestProductTypeName().equalsIgnoreCase("Forex Card")){
                holder.imgCurrencyO.setImageResource(R.drawable.demovisiting);
            }
            if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Money Transfer")){
                holder.imgCurrencyO.setImageResource(R.drawable.moneytransfer);
            }
        }

       // holder.txt_Mode.setText(listOfInprogress.get(position).getRequestDeliveryModeName());
        if (listOfInprogress.get(position).getRequestDeliveryModeName()!=null){
            if (listOfInprogress.get(position).getRequestDeliveryModeName().equalsIgnoreCase("Home Delivery")){
                holder.imgDelivaryO.setImageResource(R.drawable.bid_delivery_new);
            }
            holder.txt_Mode.setText(listOfInprogress.get(position).getRequestDeliveryModeName());
        }
        if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Open")){
            if (listOfInprogress.get(position).getRequestBidRate()!=null) {
                DecimalFormat decimalFormat = new DecimalFormat(".####");
            //    double input = Double.parseDouble("@ " +listOfInprogress.get(position).getRequestBidRate());
              //  holder.txt_Avg.setText("@ " + decimalFormat.format(input));
                if (listOfInprogress.get(position).getSize().equalsIgnoreCase("3")){

                }else {
                    holder.txt_Avg.setText("@ "+listOfInprogress.get(position).getRequestBidRate());
                }

                if (listOfInprogress.get(position).getSize().equalsIgnoreCase("2")){
                    holder.txt_Avg.setVisibility(View.GONE);
                }else {
                    holder.txt_Avg.setVisibility(View.VISIBLE);
                }


            }
        }
        if (listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Expired")||listOfInprogress.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
            holder.layout1.setVisibility(View.GONE);
            holder.layout2.setVisibility(View.GONE);
            holder.txt_Avg.setVisibility(View.GONE);
            holder.txt_dual_product_bid.setVisibility(View.GONE);
        }

       /* String []arrDateTime=listOfInprogress.get(position).getRequestBidAcceptedDateTime().split(" ");
        String[] arrDate=arrDateTime[0].split("-");
        Log.e("Date Timeeeeeeeeeeeeeee",""+arrDate[2]+"-"+arrDate[1]+"-"+arrDate[0]+" "+arrDateTime[1]);
        holder.txt_DatenTime.setText(arrDate[2]+"-"+arrDate[1]+"-"+arrDate[0]+" "+arrDateTime[1]);*/

/*
        String dateTime[]=listOfInprogress.get(position).getRequestBidAcceptedDateTime().split(" ");
        String time=dateTime[1];
        String dateSplit[]=dateTime[0].split("-");
            *//*Log.e("Month nooooooo",""+dateSplit[1]);
            Log.e("Time*********",""+time);*//*


        calendar.set(Calendar.MONTH, Integer.parseInt(dateSplit[1])-1);
        //Log.e("Month********",""+calendar.getTime());
        String month= String.valueOf(calendar.getTime());
        String datefinalMonth[]=month.split(" ");

            *//*Log.e("Date Splittttttttt",""+dateSplit[0]);
            Log.e("Monthhhhhhhhhh****",""+datefinalMonth[1]);*//*
        //  holder.txtRequestDate.setText(reqhistory.get(position).getCreatedOn());
        try {
            d = f1.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String finalTime= f2.format(d).toLowerCase();
        // Log.e("finalTIMEEEEEEEEEEE",""+finalTime);

        holder.txt_DatenTime.setText(dateSplit[0]+" "+datefinalMonth[1]+" "+finalTime);*/

        holder.txt_DatenTime.setText(listOfInprogress.get(position).getRequestBidAcceptedDateTime());

        if (listOfInprogress.get(position).getRequestProductTypeId_2().equalsIgnoreCase("0")&&listOfInprogress.get(position).getRequestQuantity_2().equalsIgnoreCase("0")&&listOfInprogress.get(position).getRequestProductTypeName_2().equalsIgnoreCase("0")){


        }else {

            int a,b,c;
            a= Integer.parseInt(listOfInprogress.get(position).getRequestQuantity());
            b= Integer.parseInt(listOfInprogress.get(position).getRequestQuantity_2());
            c=a+b;
            holder.txt_requestTitle.setText("Customer wanted to ");
            if (listOfInprogress.get(position).getRequestSourceRefId().equalsIgnoreCase("7")){
                holder.txt_requestTitle.setText("Travel Agent  wants to ");
                holder.img_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bidsource_ta));
                if(listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                    holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_sell));
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+c+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());

               /* holder.txt_inprogress_moneychanger_buy.setVisibility(View.GONE);
                holder.txt_inprogress_moneychanger_sell.setVisibility(View.VISIBLE);*/
                    holder.txt_inprogress_requestTitle2.setText(" through"+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());

                }
                else if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Buy")){
                    holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_buy));
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+c+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());
            /*    holder.txt_inprogress_moneychanger_buy.setVisibility(View.VISIBLE);
                holder.txt_inprogress_moneychanger_sell.setVisibility(View.GONE);*/
                    holder.txt_inprogress_requestTitle2.setText(" through"+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());

                }else if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Money Transfer")){
                    holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_inprogress_monytransfer));
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+c+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());
            /*    holder.txt_inprogress_moneychanger_buy.setVisibility(View.VISIBLE);
                holder.txt_inprogress_moneychanger_sell.setVisibility(View.GONE);*/
                    holder.txt_inprogress_requestTitle2.setText(" through"+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());

                }



            }
            else {
                holder.txt_requestTitle.setText("Customer wants to ");
                holder.img_icon.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.ic_info_icon));
                if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Sell")) {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName() + " " + c + " " + listOfInprogress.get(position).getRequestSourceCurrencyName());
                    holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_for_sell_inprogess));
                /*holder.txt_inprogress_bought_sale.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought.setVisibility(View.GONE);
                holder.txt_inprogress_bought_monyTrans.setVisibility(View.GONE);*/
                    holder.txt_inprogress_requestTitle2.setText(" through" + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());

                } else if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Buy")) {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName() + " " + c + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());
                    holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.background_black_rounded));

                /*holder.txt_inprogress_bought_sale.setVisibility(View.GONE);
                holder.txt_inprogress_bought.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought_monyTrans.setVisibility(View.GONE);*/
                    holder.txt_inprogress_requestTitle2.setText(" through" + " " + listOfInprogress.get(position).getRequestSourceCurrencyName());

                } else {
                    holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName() + " " + c + " " + listOfInprogress.get(position).getRequestTargetCurrencyName());
                    holder.txt_inprogress_bought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_inprogress_monytransfer));
               /* holder.txt_inprogress_bought_monyTrans.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought_sale.setVisibility(View.GONE);
                holder.txt_inprogress_bought.setVisibility(View.GONE);*/
                    holder.txt_inprogress_requestTitle2.setText(" through" + " " + listOfInprogress.get(position).getRequestSourceCurrencyName());

                }
            }

        /*    if(listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+c+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());
               *//* holder.txt_inprogress_bought_sale.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought.setVisibility(View.GONE);
                holder.txt_inprogress_bought_monyTrans.setVisibility(View.GONE);*//*
                holder.txt_inprogress_bought_sale.setText(" through"+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());

            }
            else if (listOfInprogress.get(position).getRequestTypeName().equalsIgnoreCase("Buy")){
                holder.txt_inprogress_bought.setText(listOfInprogress.get(position).getRequestTypeName()+" "+c+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());
             *//*   holder.txt_inprogress_bought_sale.setVisibility(View.GONE);
                holder.txt_inprogress_bought.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought_monyTrans.setVisibility(View.GONE);*//*
                holder.txt_inprogress_bought_sale.setText(" through"+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());
            }
            else {
                holder.txt_inprogress_bought_monyTrans.setText(listOfInprogress.get(position).getRequestTypeName()+" "+c+" "+listOfInprogress.get(position).getRequestTargetCurrencyName());
                holder.txt_inprogress_bought_monyTrans.setVisibility(View.VISIBLE);
                holder.txt_inprogress_bought_sale.setVisibility(View.GONE);
                holder.txt_inprogress_bought.setVisibility(View.GONE);
                holder.txt_inprogress_bought_sale.setText(" through"+" "+listOfInprogress.get(position).getRequestSourceCurrencyName());

            }

*/
            holder.txt_Currency.setText(listOfInprogress.get(position).getRequestProductTypeName()+" + "+listOfInprogress.get(position).getRequestProductTypeName_2());


        }



    }

    @Override
    public int getItemCount() {
        return listOfInprogress.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_requestTitle,txt_inprogress_requestTitle2,txt_inprogress_moneychanger_sell,txt_inprogress_moneychanger_buy,txt_inprogress_bought_monyTrans,txt_inprogress_bought_sale,txt_NBCNo,txt_Status,txt_DatenTime,txt_location,txt_Currency,txt_Mode,txt_Avg,txt_dual_product_bid,txt_inprogress_bought;
        LinearLayout layout1,layout2;
        ImageView imgDelivaryO,imgCurrencyO,img_icon ;
        public ViewHolder(View itemView) {
            super(itemView);
            txt_inprogress_moneychanger_sell= (TextView) itemView.findViewById(R.id.txt_inprogress_moneychanger_sell);
            txt_inprogress_moneychanger_buy= (TextView) itemView.findViewById(R.id.txt_inprogress_moneychanger_buy);
            txt_inprogress_bought_monyTrans= (TextView) itemView.findViewById(R.id.txt_inprogress_bought_monyTrans);
            txt_inprogress_bought_sale= (TextView) itemView.findViewById(R.id.txt_inprogress_bought_sale);
            txt_inprogress_bought= (TextView) itemView.findViewById(R.id.txt_inprogress_bought);
            txt_inprogress_requestTitle2= (TextView) itemView.findViewById(R.id.txt_inprogress_requestTitle2);
            txt_requestTitle=(TextView)itemView.findViewById(R.id.txt_inprogress_requestTitle);
            txt_NBCNo=(TextView)itemView.findViewById(R.id.txt_inprogress_NBCno);
            txt_Status=(TextView)itemView.findViewById(R.id.txt_inprogress_Status);
            txt_DatenTime=(TextView)itemView.findViewById(R.id.txt_inprogress_datentime);
            txt_location=(TextView)itemView.findViewById(R.id.txt_inprogress_location);
            txt_Currency=(TextView)itemView.findViewById(R.id.txt_inprogress_currency);
            txt_Mode=(TextView)itemView.findViewById(R.id.txt_inprogress_mode);
            txt_Avg= (TextView) itemView.findViewById(R.id.txt_Avg);
            layout1= (LinearLayout) itemView.findViewById(R.id.linear1);
            img_icon= (ImageView) itemView.findViewById(R.id.img_icon);
            layout2= (LinearLayout) itemView.findViewById(R.id.linear2);
            imgDelivaryO= (ImageView) itemView.findViewById(R.id.imgDelivaryO);
            imgCurrencyO= (ImageView) itemView.findViewById(R.id.imgcurrencyO);
            txt_dual_product_bid= (TextView) itemView.findViewById(R.id.txt_dual_product_bid);


        }
    }





    public void setFonts(ViewHolder holder){
        holder.txt_requestTitle.setTypeface(FontData.setFonts(context,holder.txt_requestTitle, FontData.font_robotoBold));
        holder.txt_NBCNo.setTypeface(FontData.setFonts(context,holder.txt_NBCNo, FontData.font_robotomedium));
        holder.txt_Status.setTypeface(FontData.setFonts(context,holder.txt_Status, FontData.font_robotolight));
        holder.txt_DatenTime.setTypeface(FontData.setFonts(context,holder.txt_DatenTime, FontData.font_robotomedium));
        holder.txt_location.setTypeface(FontData.setFonts(context,holder.txt_location, FontData.font_robotoregular));
        holder.txt_Currency.setTypeface(FontData.setFonts(context,holder.txt_Currency, FontData.font_robotoregular));
        holder.txt_Mode.setTypeface(FontData.setFonts(context,holder.txt_Mode, FontData.font_robotoregular));



    }
}
