package com.nafex.nafex2.adapters;

/**
 * Created by Sunil on 3/3/2017.
 */
public  interface OnBidOpen {

    public void onBidNowButtonClicked(int index, int reqId);


}
