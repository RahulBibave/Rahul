package com.nafex.nafex2.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.NbcHistory;
import com.nafex.nafex2.utilities.FontData;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rahul on 12/9/17.
 */

public class AdapterKycListNBC extends RecyclerView.Adapter<AdapterKycListNBC.ViewHolderKycList> {
    Context context;
    List<NbcHistory> listnbc;


    public AdapterKycListNBC(Context context, List<NbcHistory> arrlist) {
        this.context = context;
        listnbc = arrlist;

    }

    @Override
    public ViewHolderKycList onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.lay_nbc_details, parent, false);
        return new ViewHolderKycList(view);
    }

    @Override
    public void onBindViewHolder(ViewHolderKycList holder, int position) {
        holder.txtNBC123.setText(listnbc.get(position).getRequestNBC());
        holder.txtAudToInr.setText(listnbc.get(position).getRequestQuantity() + "  " + listnbc.get(position).getRequestTargetCurrencyName() + " To " + listnbc.get(position).getRequestSourceCurrencyName());
        holder.txtDateClosed.setText(listnbc.get(position).getCreatedOn()+ "  "+ listnbc.get(position).getRequestStatusName());
    }

    @Override
    public int getItemCount() {
        return listnbc.size();
    }


    public class ViewHolderKycList extends RecyclerView.ViewHolder {
        TextView txtNBC123, txtAudToInr, txtDateClosed, txtvisa, txtTicket, txtDock;
        CheckBox checkVisa, checkTickets, checkDocuments;

        public ViewHolderKycList(View itemView) {
            super(itemView);
            txtNBC123 = (TextView) itemView.findViewById(R.id.txtNBC123);
            txtAudToInr = (TextView) itemView.findViewById(R.id.txtAudToInr);
            txtDateClosed = (TextView) itemView.findViewById(R.id.txtDateClosed);
            checkVisa = (CheckBox) itemView.findViewById(R.id.checkVisa);
            checkTickets = (CheckBox) itemView.findViewById(R.id.checkTickets);
            checkDocuments = (CheckBox) itemView.findViewById(R.id.checkDocuments);
            txtvisa = (TextView) itemView.findViewById(R.id.txtcheckVisa);
            txtTicket = (TextView) itemView.findViewById(R.id.txtcheckTickets);
            txtDock = (TextView) itemView.findViewById(R.id.txtcheckDocuments);

            txtNBC123.setTypeface(FontData.setFonts(context, txtNBC123, FontData.font_robotoregular));
            txtAudToInr.setTypeface(FontData.setFonts(context, txtAudToInr, FontData.font_robotomedium));
            txtDateClosed.setTypeface(FontData.setFonts(context, txtDateClosed, FontData.font_robotoregular));
            txtvisa.setTypeface(FontData.setFonts(context, txtvisa, FontData.font_robotoregular));
            txtTicket.setTypeface(FontData.setFonts(context, txtTicket, FontData.font_robotoregular));
            txtDock.setTypeface(FontData.setFonts(context, txtDock, FontData.font_robotoregular));
        }
    }
}
