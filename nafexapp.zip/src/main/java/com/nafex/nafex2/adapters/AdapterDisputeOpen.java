package com.nafex.nafex2.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.OpenDispute;
import com.nafex.nafex2.interfaces.DisputeOperation;
import com.nafex.nafex2.utilities.FontData;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Created by rahul on 4/10/17.
 */

public class AdapterDisputeOpen extends RecyclerView.Adapter<AdapterDisputeOpen.ViewHolderOpen>{

    private Context mContext;
    private List<OpenDispute> disputeList = null;
    DisputeOperation kycoperation=null;

    public AdapterDisputeOpen(Context mContext, List<OpenDispute> bidList, DisputeOperation oper) {
        this.mContext = mContext;
        this.disputeList = bidList;
        kycoperation=oper;

    }

    @Override
    public ViewHolderOpen onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.lay_dispute_open_view,parent,false);
        ViewHolderOpen viewHolderOpen=new ViewHolderOpen(view);
        return viewHolderOpen;
    }
    @Override
    public int getItemViewType(int position)
    {
        return position;
    }

    @Override
    public void onBindViewHolder(ViewHolderOpen holder, int position) {
        holder.txtVimalForex.setText(disputeList.get(position).getFFMCCompany());
        holder.txtBuy.setText(disputeList.get(position).getRequestTypeName()+"-"+disputeList.get(position).getRequestQuantity()+"-"+disputeList.get(position).getRequestSourceCurrencyName()+" to "+disputeList.get(position).getRequestTargetCurrencyName());
        holder.txtDIS27.setText("DIS"+disputeList.get(position).getDisputeId()+"/"+" "+"NBC"+disputeList.get(position).getRequestNBCNumber());


        long time= Long.parseLong(disputeList.get(position).getLastModifiedOn());
        String OUTPUT_DATE_FORMATE="yyyy-MM-dd HH:mm:ss ";

        getDateFromUTCTimestamp(holder.txtDate,time,OUTPUT_DATE_FORMATE);

        if(disputeList.get(position).getDisputeStatusId().equalsIgnoreCase("1"))
        {
            holder.btnResponded.setText("WAITING");
        }else
        {
            if(disputeList.get(position).getDisputeStatusId().equalsIgnoreCase("4"))
            {
                holder.btnResponded.setText("RESPONDED");

            }else
            {
                if(disputeList.get(position).getDisputeStatusId().equalsIgnoreCase("0"))
                {
                    holder.btnResponded.setText("REJECTED");
                    holder.btnResponded.setBackground(mContext.getDrawable(R.drawable.rounded_corner_red_button));

                }
            }
        }
    }

    @Override
    public int getItemCount() {
        try {
            return disputeList.size();
        }catch (NullPointerException e){

            Log.e("ExceptionEEEEEEE",""+e);
            return 0;
        }

    }

    public class ViewHolderOpen extends RecyclerView.ViewHolder{
        private TextView txtDIS27,txtBuy,txtVimalForex,txtDate;
        private Button btnResponded;
        public ViewHolderOpen(View itemView) {
            super(itemView);

            txtDIS27 = (TextView)itemView.findViewById( R.id.txtDIS27 );
            txtBuy = (TextView)itemView.findViewById( R.id.txtBuy );
            txtVimalForex = (TextView)itemView.findViewById( R.id.txtVimalForex );
            txtDate = (TextView)itemView.findViewById( R.id.txtDate );
            btnResponded = (Button)itemView.findViewById( R.id.btnResponded );



            txtDIS27.setTypeface(FontData.setFonts(mContext,txtDIS27, FontData.font_robotomedium));
            txtBuy.setTypeface(FontData.setFonts(mContext,txtBuy, FontData.font_robotomedium));
            txtVimalForex.setTypeface(FontData.setFonts(mContext,txtVimalForex, FontData.font_robotoregular));
            txtDate.setTypeface(FontData.setFonts(mContext,txtDate, FontData.font_robotomedium));
            btnResponded.setTypeface(FontData.setFonts(mContext,btnResponded, FontData.font_robotoBold));


        }
    }

    public String getDateFromUTCTimestamp(TextView tv,long mTimestamp, String mDateFormate) {
        String date = null;
        try {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+11:00"));
            cal.setTimeInMillis(mTimestamp * 1000L);
            date = DateFormat.format(mDateFormate, cal.getTimeInMillis()).toString();

            SimpleDateFormat formatter = new SimpleDateFormat(mDateFormate);
            formatter.setTimeZone(TimeZone.getTimeZone("GMT+11:00"));
            Date value = formatter.parse(date);

            SimpleDateFormat dateFormatter = new SimpleDateFormat(mDateFormate);
            dateFormatter.setTimeZone(TimeZone.getDefault());
            date = dateFormatter.format(value);
            tv.setText(date);
            return date;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }
}




