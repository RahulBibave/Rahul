package com.nafex.nafex2.adapters;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.activity.Activity_Dispute_Comment_List;
import com.nafex.nafex2.activity.Activity_dispute_select;
import com.nafex.nafex2.data.DisputeComment;
import com.nafex.nafex2.data.HistoryDispute;
import com.nafex.nafex2.data.OpenDispute;
import com.nafex.nafex2.interfaces.DisputeOperation;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by rahul on 4/10/17.
 */

public class AdapterDisputeStatus extends RecyclerView.Adapter<AdapterDisputeStatus.ViewHolderStatus> {
    private Context mContext;
    private List<HistoryDispute> disputeList = null;
    DisputeOperation kycoperation = null;
    ProgressDialog progressDialog;
    String disputeid;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String user_id, user_token, branchID;
    AppGlobalData gbData;
    String requestId, requestNBCNumber, disputeId, createdById, txtcomment;
    List<DisputeComment> discomment;
    String disputeCommentId;


    public AdapterDisputeStatus(Context mContext, List<HistoryDispute> bidList, DisputeOperation oper) {
        this.mContext = mContext;
        this.disputeList = bidList;
        kycoperation = oper;
        try {


            progressDialog = new ProgressDialog(mContext);
        }catch (NullPointerException e){
            Log.e("Exception e",""+e);
        }


    }

    @Override
    public ViewHolderStatus onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.lay_dispute_status_view, parent, false);
        gbData = AppGlobalData.getInstance();

        ViewHolderStatus viewHolderStatus = new ViewHolderStatus(view);
        return viewHolderStatus;
    }

    @Override
    public void onBindViewHolder(final ViewHolderStatus holder, final int position) {

        holder.txtDis27.setText("DIS" + disputeList.get(position).getDisputeId() + "/" + " " + "NBC" + disputeList.get(position).getRequestNBCNumber());


      //  holder.txtDateDispute.setText(disputeList.get(position).getLastModifiedOn());


        long time= Long.parseLong(disputeList.get(position).getLastModifiedOn());
        String OUTPUT_DATE_FORMATE="yyyy-MM-dd HH:mm:ss ";
        getDateFromUTCTimestamp(holder.txtDateDispute,time,OUTPUT_DATE_FORMATE);



        holder.txtVimalForex.setText(disputeList.get(position).getFFMCCompany());
        holder.txtbuy2300.setText(disputeList.get(position).getRequestTypeName() + "-" + disputeList.get(position).getRequestQuantity() + "-" + disputeList.get(position).getRequestSourceCurrencyName() + " to " + disputeList.get(position).getRequestTargetCurrencyName());
        holder.linearViewMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.txtMode.getText().toString().equalsIgnoreCase("HIDE DETAILS")) {
                    holder.txtMode.setText("VIEW MORE");

                    holder.linear_comment.setVisibility(View.GONE);
                } else {
                    holder.txtMode.setText("HIDE DETAILS");

                    sharedpreferences = mContext.getSharedPreferences(ConstantData.MyPREFERENCES, mContext.MODE_PRIVATE);
                    user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
                    user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
                    branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");
                    requestId = disputeList.get(position).getRequestId();
                    requestNBCNumber = disputeList.get(position).getRequestNBCNumber();
                    disputeid = disputeList.get(position).getDisputeId();
                    createdById = disputeList.get(position).getCreatedById();

                    //call get comment
                  /*  CallDisputeCommentAPI api = new CallDisputeCommentAPI();
                    api.execute();*/

                    Log.e("disputeid", disputeList.get(position).getDisputeId());
                    //   disputeid = disputeList.get(position).getDisputeId();
                    holder.linear_comment.setVisibility(View.VISIBLE);

                }
            }
        });
        if (disputeList.get(position).getDisputeStatusId().equalsIgnoreCase("9")) {
            //   holder.btnResponded.setText("WAITING");
            holder.btnWaiting.setText("REJECTED");
            holder.btnWaiting.setBackground(mContext.getDrawable(R.drawable.rounded_corner_red_button));
        } else {
            if (disputeList.get(position).getDisputeStatusId().equalsIgnoreCase("4")) {
                //     holder.btnResponded.setText("RESPONDED");

            }
            else if (disputeList.get(position).getDisputeStatusId().equalsIgnoreCase("6")){
                holder.btnWaiting.setText("APPROVED");
            }


        }

        holder.btnWaiting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*  Intent ints=new Intent(mContext
                , Activity_dispute_select.class);
                mContext.startActivity(ints);*/
            }
        });


        holder.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.ed_addcomment.getText().toString() != null) {
                    HideKeybaord(view);
                    txtcomment = holder.ed_addcomment.getText().toString().trim();
                    CallAddCommentDisputeAPI api = new CallAddCommentDisputeAPI();
                    api.execute();
                }
            }
        });
    }
    private void HideKeybaord(View v) {
        InputMethodManager imm = (InputMethodManager) v.getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);


    }
    @Override
    public int getItemViewType(int position) {
        return position;
    }


    public class CallDisputeCommentAPI extends AsyncTask<String, Void, String> {

        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //  progressDialog.setMessage("Loading...");
            //  progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {
                showTransferTypeAlertCustomDialog();
            } else
                CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), Error_Message);
            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            //eventToCall = strings[0];
            CallForOpenDispute();
            return "DONE";

        }

        private void CallForOpenDispute() {

            HttpURLConnection urlConnection = null;
            String myjsonstring = "";

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.DISPUTECOMMENTLIST + disputeid);
                Log.e("url", url.toString());
                urlConnection = (HttpURLConnection) url.openConnection();

                byte[] auth = (user_id + ":" + user_token).getBytes();



                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);

                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                 //   Log.e("userid",user_id);
               // Log.e("user_token",user_token);


                urlConnection.setRequestMethod(ConstantData.METHOD_GET);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                myjsonstring = stringBuilder.toString();
                Log.e("Result", myjsonstring);
                JSONArray jsonArray;
                JSONObject jsonObj;
                JSONObject objdata = new JSONObject(myjsonstring);
                if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                    jsonArray = objdata.getJSONArray("message_text");
                    discomment = new ArrayList<DisputeComment>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        jsonObj = jsonArray.getJSONObject(i);
                        DisputeComment objdiscmt = new DisputeComment();
                        objdiscmt.setDisputeCommentId(jsonObj.getString("disputeCommentId"));
                        objdiscmt.setRequestId(jsonObj.getString("requestId"));
                        objdiscmt.setRequestNBCNumber(jsonObj.getString("requestNBCNumber"));
                        objdiscmt.setDisputeId(jsonObj.getString("disputeId"));
                        objdiscmt.setCreatedById(jsonObj.getString("createdById"));
                        objdiscmt.setCreatedOn(jsonObj.getString("createdOn"));
                        objdiscmt.setCallComment(jsonObj.getString("callComment"));
                        objdiscmt.setCallNextAction(jsonObj.getString("callNextAction"));
                        discomment.add(objdiscmt);
                    }


                } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                    Error_Message = objdata.getString("message_text");
                }
            } catch (JSONException e) {
                Log.e("***Error:", e.getMessage(), e);
                if (myjsonstring.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in city data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
        }

    }

    public class CallAddCommentDisputeAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Please Wait...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            String strNBC = "";

            if (Error_Message.equalsIgnoreCase("java.io.File Not FoundException")) {
                //call autologin api
/*

                if (gbData.isConnected(getApplicationContext())) {
                    CallMobileNoVerification objRequestAPI = new CallMobileNoVerification();
                    objRequestAPI.execute(CommonApi.CUSTOMER_CHECKEXIST);
                }
*/


            } else {

                //Log.d("Response: ", strResponse);
                if (Error_Message.equalsIgnoreCase("")) {
                    try {
                        JSONObject objdata = new JSONObject(strResponse);
                        JSONArray jsonArray;
                        if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                            CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), objdata.getString("message_text"));

                        } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                            //showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                        }
                    } catch (JSONException e) {
                        Error_Message = "JSONError: Please contact Nafex support team.";
                        //showAlert(getResources().getString(R.string.app_name), Error_Message);
                    }
                } else
                    Log.e("xzc", "xvc");
                //showAlert(getResources().getString(R.string.app_name), Error_Message);
            }
            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.NEWDISPUTECOMMENT);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("requestId", requestId);
                    postDataParams.put("requestNBCNumber", requestNBCNumber);
                    postDataParams.put("disputeId", disputeid);
                    postDataParams.put("createdById", createdById);
                    postDataParams.put("callComment", txtcomment);
                    postDataParams.put("callNextAction", "This is call next action");

                    Log.e("params", postDataParams.toString());

                    byte[] auth = (user_id + ":" + user_token).getBytes();

                    String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                    urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(15000 /* milliseconds */);
                    urlConnection.setConnectTimeout(15000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();
                    Log.e("responseCode", Integer.toString(responseCode));
                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    } else {
                        if (responseCode == 400) {
                            Error_Message = "java.io.File Not FoundException";
                        }
                        if (responseCode == 401) {
                            Error_Message = "java.io.File Not FoundException";
                        }
                    }
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";
                } catch (Exception e) {
                    Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                    Log.e("ERROR", e.getMessage(), e);
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                Log.e("ERROR", e.getMessage(), e);
            }

            return null;
        }
    }


    public class CallUpdateCommentDisputeAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Please Wait...");
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            if (Error_Message.equalsIgnoreCase("java.io.File Not FoundException")) {


            } else {

                //Log.d("Response: ", strResponse);
                if (Error_Message.equalsIgnoreCase("")) {
                    try {
                        JSONObject objdata = new JSONObject(strResponse);
                        JSONArray jsonArray;
                        if (objdata.getString("message_code").equalsIgnoreCase("1000")) {


                        } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                            //showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                        }
                    } catch (JSONException e) {
                        Error_Message = "JSONError: Please contact Nafex support team.";
                        //showAlert(getResources().getString(R.string.app_name), Error_Message);
                    }
                } else
                    Log.e("xzc", "xvc");
                //showAlert(getResources().getString(R.string.app_name), Error_Message);
            }
            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.DISPUTECOMMENTUPDATE);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("disputeCommentId", disputeCommentId);
                    postDataParams.put("callComment", "call dispute");
                    postDataParams.put("callNextAction", "Dispute call");

                    Log.e("params", postDataParams.toString());

                    byte[] auth = (user_id + ":" + user_token).getBytes();

                    String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                    urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(15000 /* milliseconds */);
                    urlConnection.setConnectTimeout(15000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();
                    Log.e("responseCode", Integer.toString(responseCode));
                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    } else {
                        if (responseCode == 400) {
                            Error_Message = "java.io.File Not FoundException";
                        }
                        if (responseCode == 401) {
                            Error_Message = "java.io.File Not FoundException";
                        }
                    }
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";
                } catch (Exception e) {
                    Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                    Log.e("ERROR", e.getMessage(), e);
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                Log.e("ERROR", e.getMessage(), e);
            }

            return null;
        }
    }


    private void showTransferTypeAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
       // tvtitle.setText("Select Transfer Type");
        tvtitle.setVisibility(View.GONE);
        // tvtitle.setTypeface(FontData.setFonts(this, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                //       btransfertype = false;
            }
        });


        if (discomment != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(mContext, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < discomment.size(); i++) {
                choices.add(discomment.get(i).getCallComment());
                currencyAdapter.add(discomment.get(i).getDisputeCommentId());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                Log.e("id", discomment.get(i).getDisputeCommentId());
                                                disputeCommentId = discomment.get(i).getDisputeCommentId();
                                                CallUpdateCommentDisputeAPI api = new CallUpdateCommentDisputeAPI();
                                                api.execute();
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }


    @Override
    public int getItemCount() {
        try {
            return disputeList.size();
        }catch (NullPointerException e){
            Log.e("Exception eeee",""+e);
            return 0;
        }
    }

    public class ViewHolderStatus extends RecyclerView.ViewHolder {

        private TextView txtDis27, txtbuy2300, txtVimalForex, txtDateDispute, txtMode;
        private Button btnWaiting, btnAdd;
        private LinearLayout linearViewMore, linear_comment;
        private ImageView txtModeImage;
        private EditText ed_addcomment;

        public ViewHolderStatus(View itemView) {
            super(itemView);
            txtDis27 = (TextView) itemView.findViewById(R.id.txt_dis27);
            txtbuy2300 = (TextView) itemView.findViewById(R.id.txtbuy_2300);
            btnWaiting = (Button) itemView.findViewById(R.id.btnWaiting);
            btnAdd = (Button) itemView.findViewById(R.id.btnAdd);
            txtVimalForex = (TextView) itemView.findViewById(R.id.txtVimalForex);
            txtDateDispute = (TextView) itemView.findViewById(R.id.txt_date_dispute);
            linearViewMore = (LinearLayout) itemView.findViewById(R.id.linear_ViewMore);
            txtMode = (TextView) itemView.findViewById(R.id.txtMode);
            ed_addcomment = (EditText) itemView.findViewById(R.id.txtcomment);
            txtModeImage = (ImageView) itemView.findViewById(R.id.txtModeImage);
            linear_comment = (LinearLayout) itemView.findViewById(R.id.linear_comment);
            txtDis27.setTypeface(FontData.setFonts(mContext, txtDis27, FontData.font_robotomedium));
            txtbuy2300.setTypeface(FontData.setFonts(mContext, txtbuy2300, FontData.font_robotomedium));
            txtVimalForex.setTypeface(FontData.setFonts(mContext, txtVimalForex, FontData.font_robotoregular));
            txtDateDispute.setTypeface(FontData.setFonts(mContext, txtDateDispute, FontData.font_robotomedium));
            txtMode.setTypeface(FontData.setFonts(mContext, txtMode, FontData.font_robotoBold));
            btnWaiting.setTypeface(FontData.setFonts(mContext, btnWaiting, FontData.font_robotoBold));


            //Long Press
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    Intent intdispcmtlist=new Intent(mContext, Activity_Dispute_Comment_List.class);
                    intdispcmtlist.putExtra("disputeid",disputeList.get(getAdapterPosition()).disputeId);
                    mContext.startActivity(intdispcmtlist);
                    return true;
                }
            });



        }
    }

    public String getDateFromUTCTimestamp(TextView tv,long mTimestamp, String mDateFormate) {
        String date = null;
        try {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+11:00"));
            cal.setTimeInMillis(mTimestamp * 1000L);
            date = DateFormat.format(mDateFormate, cal.getTimeInMillis()).toString();

            SimpleDateFormat formatter = new SimpleDateFormat(mDateFormate);
            formatter.setTimeZone(TimeZone.getTimeZone("GMT+11:00"));
            Date value = formatter.parse(date);

            SimpleDateFormat dateFormatter = new SimpleDateFormat(mDateFormate);
            dateFormatter.setTimeZone(TimeZone.getDefault());
            date = dateFormatter.format(value);
            tv.setText(date);
            return date;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }
}



