package com.nafex.nafex2.adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.CustomerRequest;
import com.nafex.nafex2.interfaces.OnBidAccept;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import java.util.List;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Swarup on 9/16/2017.
 */

public class CustomerRequestAdapter extends BaseAdapter {

    // Declare Variables
    Context context;
    LayoutInflater inflater;

    private List<CustomerRequest> bidList = null;
    private List<CustomerRequest> bidListreates = null;

    OnBidAccept objBidAcceptCheck = null;
    String requestTargetCurrencyName;
    double strbidrate;
    String requestId;
    int userid;
    String requesttype;
    SharedPreferences sharedpreferences;





   /* public CustomerRequestAdapter(Context context,
                                  List<CustomerRequest> bidList, OnBidAccept oBidAcceptCheck, BidRequest oRequest,String strtargate) {
        this.context = context;
        this.bidList = bidList;
        this.requestTargetCurrencyName=strtargate;
        this.objBidAcceptCheck = oBidAcceptCheck;
        inflater = LayoutInflater.from(context);

    }*/

    public CustomerRequestAdapter(Context context,
                                  List<CustomerRequest> bidList, OnBidAccept accept, String strtargate, double bidrate, String requestId, int userid, String strreqtype) {
        this.context = context;
        this.bidList = bidList;
        objBidAcceptCheck = accept;
        this.requestTargetCurrencyName = strtargate;
        strbidrate = bidrate;
        this.requestId = requestId;
        this.userid = userid;
        this.requesttype = strreqtype;
        inflater = LayoutInflater.from(context);
        sharedpreferences = context.getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);

    }


  /*  public CustomerRequestAdapter(Context context,
                                  List<CustomerRequest> bidList, List<CustomerRequest> bidListreates, String strtargate) {
        this.context = context;
        this.bidList = bidList;
        this.bidListreates = bidListreates;

        this.requestTargetCurrencyName = strtargate;
        inflater = LayoutInflater.from(context);

    }
*/

    public class ViewHolder {

        TextView txtRateOffered;
        TextView txtAreaOffered;
        TextView txtAmountOffered;
        Button btnAcceptRate;
        TextView txt_distance;
        TextView txttax;
        TextView txtdelivery;
        TextView txtothercharges, plusdelivary;
        TextView txt_bidsoper,txtBestQuote;

    }

    @Override
    public int getCount() {
        return bidList.size();

    }


    @Override
    public Object getItem(int position) {
        return bidList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View view, final ViewGroup parent) {
        final ViewHolder holder;
        boolean flag = false;
        if (view == null) {
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.bid_list_item_n, null);
            // Locate the TextViews in listview_item.xml

            holder.txtRateOffered = (TextView) view.findViewById(R.id.txtRateOffered);
            holder.txtAreaOffered = (TextView) view.findViewById(R.id.txtAreaOffered);
            holder.txtAmountOffered = (TextView) view.findViewById(R.id.txtAmountOffered);
            holder.btnAcceptRate = (Button) view.findViewById(R.id.btn_AcceptRate);
            holder.txttax = (TextView) view.findViewById(R.id.txttax);
            holder.txtdelivery = (TextView) view.findViewById(R.id.txtdelivery);
            holder.plusdelivary = (TextView) view.findViewById(R.id.plusdelivary);
            holder.txtothercharges = (TextView) view.findViewById(R.id.txtothercharges);
            holder.txt_distance = (TextView) view.findViewById(R.id.txt_distance);
            holder.txtBestQuote= (TextView) view.findViewById(R.id.txtBestQuote);
            holder.txt_bidsoper = (TextView) view.findViewById(R.id.txt_bidsoper);


            //settypeface
            holder.txtRateOffered.setTypeface(FontData.setFonts(context, holder.txtRateOffered, FontData.font_robotomedium));
            holder.txtAreaOffered.setTypeface(FontData.setFonts(context, holder.txtAreaOffered, FontData.font_robotoregular));
            holder.txtAmountOffered.setTypeface(FontData.setFonts(context, holder.txtAmountOffered, FontData.font_robotoregular));
            holder.txtAmountOffered.setTypeface(FontData.setFonts(context, holder.txtAmountOffered, FontData.font_robotoregular));
            holder.txttax.setTypeface(FontData.setFonts(context, holder.txttax, FontData.font_robotoregular));
            holder.txtdelivery.setTypeface(FontData.setFonts(context, holder.txtdelivery, FontData.font_robotoregular));
            holder.txtothercharges.setTypeface(FontData.setFonts(context, holder.txtothercharges, FontData.font_robotoregular));
            holder.btnAcceptRate.setTypeface(FontData.setFonts(context, holder.btnAcceptRate, FontData.font_robotoregular));
            holder.txt_distance.setTypeface(FontData.setFonts(context, holder.txt_distance, FontData.font_robotoregular));


            view.setTag(holder);
            flag = false;
        } else {
            holder = (ViewHolder) view.getTag();
            flag = true;
        }
        // Set the results into TextViews
        try {


          /*  JSONArray jsonArray = new JSONArray(bidList.get(position).getBidRates());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject explrObject = jsonArray.getJSONObject(i);
                String reuestProductTypeId = explrObject.getString("reuestProductTypeId");
                String requestQuantity = explrObject.getString("requestQuantity");
                String requestBidRate = explrObject.getString("requestBidRate");
                holder.txtRateOffered.setText("INR " + String.format("%.2f", requestBidRate) + "/ " + requestTargetCurrencyName);

            }*/
//            Log.e("bidrate",bidList.get(position).getRequestBidRate());


            String bidids = getMax(bidList);
            Log.e("maxvalue", bidids);
            String minvalue = getMin(bidList);
            Log.e("minvalue", minvalue);
            if(bidList.size()>=2) {
                if (position==0){
                    holder.txtRateOffered.setTextColor(Color.parseColor("#91bf34"));
                    holder.txtBestQuote.setVisibility(View.VISIBLE);
                }
                else {
                    holder.txtRateOffered.setTextColor(Color.parseColor("#EF7F1A"));
                    holder.txtBestQuote.setVisibility(View.GONE);
                }
                /*if (requesttype.equalsIgnoreCase("Sell")) {
                    if (bidids.equalsIgnoreCase(bidList.get(position).getBidId())) {
                        holder.txtRateOffered.setTextColor(Color.parseColor("#91bf34"));
                        holder.txtBestQuote.setVisibility(View.VISIBLE);

                    }else
                    {
                        holder.txtRateOffered.setTextColor(Color.parseColor("#EF7F1A"));
                        holder.txtBestQuote.setVisibility(View.GONE);

                    }
                }
                if (requesttype.equalsIgnoreCase("Buy")) {

                    if (minvalue.equalsIgnoreCase(bidList.get(position).getBidId())) {
                        holder.txtRateOffered.setTextColor(Color.parseColor("#91bf34"));
                        holder.txtBestQuote.setVisibility(View.VISIBLE);

                    }else
                    {
                        holder.txtRateOffered.setTextColor(Color.parseColor("#EF7F1A"));
                        holder.txtBestQuote.setVisibility(View.GONE);

                    }

                }else {
                    if(requesttype.equalsIgnoreCase("Money Transfer")){

                        if (minvalue.equalsIgnoreCase(bidList.get(position).getBidId())) {
                            holder.txtRateOffered.setTextColor(Color.parseColor("#91bf34"));
                            holder.txtBestQuote.setVisibility(View.VISIBLE);

                        }else
                        {
                            holder.txtRateOffered.setTextColor(Color.parseColor("#EF7F1A"));
                            holder.txtBestQuote.setVisibility(View.GONE);

                        }

                    }
                }*/
            }

                holder.txtRateOffered.setText("INR " + bidList.get(position).getAverageRate() + "/ " + requestTargetCurrencyName);
            holder.txt_distance.setText(bidList.get(position).getFfmcDistance() + " away");
            holder.txtAreaOffered.setText(bidList.get(position).getFfmcAreaName());
            holder.txtAmountOffered.setText("INR" + " " + bidList.get(position).getAverageAmount());
            if (requesttype.equalsIgnoreCase("Buy")) {
                holder.txt_bidsoper.setText("+");
            } else {
                if (requesttype.equalsIgnoreCase("Sell")) {
                    holder.txt_bidsoper.setText("-");

                }
            }
            holder.txttax.setText("GST:" + " " + bidList.get(position).getTaxAmount());

            if (Float.parseFloat(bidList.get(position).getDeliveryCharges()) == 0) {
                holder.txtdelivery.setVisibility(View.GONE);
                // holder.plusdelivary.setVisibility(View.GONE);
            } else {
                holder.txtdelivery.setText("delivery:" + " " + bidList.get(position).getDeliveryCharges());

            }

            holder.txtothercharges.setText("Handling Charges:" + " " + bidList.get(position).getOtherCharges());


            if (sharedpreferences.getString(ConstantData.KEY_USERROLE_LFFCMLOGIN,"").equalsIgnoreCase("7")){
                holder.txtothercharges.setVisibility(View.GONE);
                holder.txtdelivery.setVisibility(View.GONE);
                holder.txttax.setVisibility(View.GONE);
                holder.txt_bidsoper.setVisibility(View.GONE);
                holder.plusdelivary.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        holder.btnAcceptRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("button click", "button click");
                if (objBidAcceptCheck != null) {
                   // objBidAcceptCheck.onAcceptButtonClicked(Integer.parseInt(requestId), Integer.parseInt(bidList.get(position).getBidId()), 3, userid);

                    objBidAcceptCheck.onAcceptButtonClicked(Integer.parseInt(requestId), Integer.parseInt(bidList.get(position).getBidId()), 4, userid);
                }
            }
        });


        return view;
    }

    public String getMax(List<CustomerRequest> con) {
        double max = Double.MIN_VALUE;
        String bidid = "";
        for (int i = 0; i < con.size(); i++) {
            if (Double.parseDouble(con.get(i).getRequestBidRate()) > max) {
                max = Double.parseDouble(con.get(i).getRequestBidRate());
                Log.e("position", Integer.toString(i));
                bidid = con.get(i).getBidId();

            }
        }
        return bidid;
    }

    public String getMin(List<CustomerRequest> con) {
        double min = Double.MAX_VALUE;
        String bidid = "";

        for (int i = 0; i < con.size(); i++) {
            if (Double.parseDouble(con.get(i).getRequestBidRate()) < min) {
                min = Double.parseDouble(con.get(i).getRequestBidRate());
                Log.e("position", Integer.toString(i));
                bidid = con.get(i).getBidId();

            }
        }
        return bidid;
    }


}
