package com.nafex.nafex2.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.nafex.nafex2.R;
import com.nafex.nafex2.activity.Activity_KycDetails;
import com.nafex.nafex2.data.CustomerRequest;
import com.nafex.nafex2.data.DocType;
import com.nafex.nafex2.interfaces.KYCOperation;
import com.nafex.nafex2.interfaces.OnBidAccept;
import com.nafex.nafex2.utilities.FontData;

import java.util.List;

/**
 * Created by rahul on 15/9/17.
 */

public class AdapterKycListing extends RecyclerView.Adapter<AdapterKycListing.ViewHolderList> {

    private Context mContext;
    private List<DocType> doctypeList = null;
    KYCOperation kycoperation=null;
    TextView txtKycDocType,txtPassport;
    ImageView imgDelete,imgEdit;
    public AdapterKycListing(Context mContext, List<DocType> bidList,KYCOperation oper) {
        this.mContext = mContext;
        this.doctypeList = bidList;
        kycoperation=oper;


    }

    @Override
    public ViewHolderList onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.lay_kyc_listing,parent,false);
        ViewHolderList viewHolderList=new ViewHolderList(view);
        return viewHolderList;
    }

    @Override
    public void onBindViewHolder(ViewHolderList holder, final int position) {
        txtPassport.setText(doctypeList.get(position).docTypeName+" - "+doctypeList.get(position).getDocNumber());
        imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("button click","button click");
                if(kycoperation != null) {

                    kycoperation.onDeleteKyc(doctypeList.get(position).getId());
                }
            }
        });
        imgEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("button click","button click");
                if(kycoperation != null) {

                    kycoperation.onViewClick("http://13.59.118.35/nafex2dev/api/"+doctypeList.get(position).getDocFile());
                }
            }
        });
        txtPassport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Gson gson = new Gson();

                String jsonDocs = gson.toJson(doctypeList);
                Intent int_details = new Intent(mContext, Activity_KycDetails.class);
                int_details.putExtra("jsonDocs", jsonDocs);
                int_details.putExtra("position", position);
                mContext.startActivity(int_details);
            }
        });
    }

    @Override
    public int getItemCount() {
        return doctypeList.size();
    }

    public class ViewHolderList extends RecyclerView.ViewHolder {

        public ViewHolderList(View itemView) {
            super(itemView);
            imgDelete = (ImageView)itemView.findViewById( R.id.img_delete );
            imgEdit = (ImageView)itemView.findViewById( R.id.img_edit );
            txtKycDocType = (TextView)itemView.findViewById( R.id.txtKycDocType );
            txtPassport = (TextView)itemView.findViewById( R.id.txtPassport );

            txtKycDocType.setTypeface(FontData.setFonts(mContext,txtKycDocType, FontData.font_robotoregular));
            txtPassport.setTypeface(FontData.setFonts(mContext,txtPassport, FontData.font_robotoregular));



        }
    }




}
