package com.nafex.nafex2.adapters;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.activity.Activity_Dispute_Comment_List;
import com.nafex.nafex2.data.DisputeComment;
import com.nafex.nafex2.interfaces.RefreshDisputeOperations;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.ConstantData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;


public class AdapterDisputeComment extends RecyclerView.Adapter<AdapterDisputeComment.ViewHolderComment> {
    private Context mContext;
    List<DisputeComment> lscomment;
    SharedPreferences sharedpreferences;
    String user_id, user_token, branchID;
    int commentposition;
    String strupdatecomment;
    AppGlobalData gbData;
    private RefreshDisputeOperations moperations;


    public AdapterDisputeComment(Context mContext) {
        this.mContext = mContext;
    }

    public AdapterDisputeComment(Context mContext, List<DisputeComment> discomment, RefreshDisputeOperations listener) {
        this.mContext = mContext;
        this.lscomment = discomment;
        this.moperations = listener;
    }

    @Override
    public ViewHolderComment onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.dispute_comment_item_view, parent, false);
        gbData = AppGlobalData.getInstance();

        return new ViewHolderComment(view);
    }


    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(ViewHolderComment holder, final int position) {
        holder.txtName.setText(lscomment.get(position).getCreatedById());
        holder.txtComment.setText(lscomment.get(position).getCallComment());
        holder.txtDateDispute.setText(lscomment.get(position).getCreatedOn());
        sharedpreferences = mContext.getSharedPreferences(ConstantData.MyPREFERENCES, mContext.MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");


        holder.img_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callEditComment(position);

            }
        });
    }

    public void callEditComment(final int position) {
        LayoutInflater li = LayoutInflater.from(mContext);
        View promptsView = li.inflate(R.layout.lay_updatecomment, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                mContext);
        alertDialogBuilder.setTitle("Update Dispute Comment");

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);

        final EditText userInput = (EditText) promptsView
                .findViewById(R.id.edt_comment);

        // set dialog message
        alertDialogBuilder
                .setCancelable(false)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // get user input and set it to result
                                // edit text
                                commentposition = position;
                                strupdatecomment = userInput.getText().toString().trim();
                                Log.e("positions", Integer.toString(commentposition));
                                Log.e("strupdatecomment", strupdatecomment);

                                if (gbData.isConnected(mContext)) {
                                    CallUpdateCommentDisputeAPI objupdate = new CallUpdateCommentDisputeAPI();
                                    objupdate.execute();
                                } else {

                                }


                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
    }


    public class CallUpdateCommentDisputeAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //  progressDialog.setMessage("Please Wait...");
            // progressDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            if (Error_Message.equalsIgnoreCase("java.io.File Not FoundException")) {


            } else {

                //Log.d("Response: ", strResponse);
                if (Error_Message.equalsIgnoreCase("")) {
                    try {
                        JSONObject objdata = new JSONObject(strResponse);
                        JSONArray jsonArray;
                        if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                            moperations.onRefreshdisputelist("true");
                            //  delegate.updateDisputeApi("update");

                        } else if (objdata.getString("message_code").equalsIgnoreCase("999")) {
                            //showAlert(getResources().getString(R.string.app_name), objdata.getString("message_text"));
                        }
                    } catch (JSONException e) {
                        Error_Message = "JSONError: Please contact Nafex support team.";
                        //showAlert(getResources().getString(R.string.app_name), Error_Message);
                    }
                } else
                    Log.e("xzc", "xvc");
                //showAlert(getResources().getString(R.string.app_name), Error_Message);
            }
            // progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.DISPUTECOMMENTUPDATE);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    JSONObject postDataParams = new JSONObject();
                    postDataParams.put("disputeCommentId", lscomment.get(commentposition).getDisputeCommentId());
                    postDataParams.put("callComment", strupdatecomment);
                    postDataParams.put("callNextAction", "Dispute call");

                    Log.e("params", postDataParams.toString());

                    byte[] auth = (user_id + ":" + user_token).getBytes();

                    String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                    urlConnection.setRequestProperty("Authorization", "Basic " + basic);


                    urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                    urlConnection.setReadTimeout(15000 /* milliseconds */);
                    urlConnection.setConnectTimeout(15000 /* milliseconds */);
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);

                    OutputStream os = urlConnection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(gbData.getPostDataString(postDataParams));

                    writer.flush();
                    writer.close();
                    os.close();

                    int responseCode = urlConnection.getResponseCode();
                    Log.e("responseCode", Integer.toString(responseCode));
                    if (responseCode == HttpsURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            stringBuilder.append(line).append("\n");
                        }
                        bufferedReader.close();
                        strResponse = stringBuilder.toString();
                        Log.e("Result", strResponse);
                    } else {
                        if (responseCode == 400) {
                            Error_Message = "java.io.File Not FoundException";
                        }
                        if (responseCode == 401) {
                            Error_Message = "java.io.File Not FoundException";
                        }
                    }
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";
                } catch (Exception e) {
                    Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                    Log.e("ERROR", e.getMessage(), e);
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Error_Message = "Error: " + e.getClass().getName() + " in register profile. Please contact Nafex support team.";
                Log.e("ERROR", e.getMessage(), e);
            }

            return null;
        }
    }


    @Override
    public int getItemCount() {
        return lscomment.size();
    }

    public class ViewHolderComment extends RecyclerView.ViewHolder {
        private TextView txtName;
        private TextView txtDateDispute;
        private TextView txtComment;
        private ImageView img_more;

        public ViewHolderComment(View itemView) {
            super(itemView);
            txtName = (TextView) itemView.findViewById(R.id.txtName);
            txtDateDispute = (TextView) itemView.findViewById(R.id.txt_date_dispute);
            txtComment = (TextView) itemView.findViewById(R.id.txtComment);
            img_more = (ImageView) itemView.findViewById(R.id.img_more_option);
        }
    }


}
