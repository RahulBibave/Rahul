package com.nafex.nafex2.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.PassbookData;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sunil on 5/13/2017.
 */
public class PassbookAdapter extends RecyclerView.Adapter<PassbookAdapter.ViewHolder> {

    Context context;
    List<PassbookData> listOfPassbookData;

    public PassbookAdapter(Context context, List<PassbookData> listOfPassbookData) {
        this.context = context;
        this.listOfPassbookData = listOfPassbookData;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.lay_passbook_view_n, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.txtDate.setText(listOfPassbookData.get(position).getDate());
        holder.txt_Desc.setText(listOfPassbookData.get(position).getDesc());
        if(listOfPassbookData.get(position).getDb().equalsIgnoreCase(""))
        {

        }else
        {
            holder.txt_Db.setText(listOfPassbookData.get(position).getDb());
        }
        if(listOfPassbookData.get(position).getCr().equalsIgnoreCase(""))
        {

        }else
        {
            holder.txt_Db.setText(listOfPassbookData.get(position).getCr());
        }
        holder.txt_Passbook_PaymentMode.setText(listOfPassbookData.get(position).getTransactionMode());

    }

    @Override
    public int getItemCount() {
        return listOfPassbookData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtDate, txt_Desc, txt_Db, txt_Passbook_PaymentMode;

        public ViewHolder(View itemView) {
            super(itemView);
            txtDate = (TextView) itemView.findViewById(R.id.txt_Date_passbook);
            txt_Desc = (TextView) itemView.findViewById(R.id.txt_Passbook_desc);
            txt_Db = (TextView) itemView.findViewById(R.id.txt_passbook_Db);
            txt_Passbook_PaymentMode=(TextView)itemView.findViewById(R.id.txt_Passbook_PaymentMode);
        }
    }
}
