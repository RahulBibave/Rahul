package com.nafex.nafex2.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.BidWonArray;
import com.nafex.nafex2.data.EnquiryWon;
import com.nafex.nafex2.utilities.FontData;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Sunil on 9/13/2017.
 */
public class EnquiryWonAdapter extends RecyclerView.Adapter<EnquiryWonAdapter.ViewHolder> {
    Context context;
    ArrayList<EnquiryWon> listOfWonData;
    Calendar calendar;
    DateFormat f2 ;
    DateFormat f1;
    Date d;


    public EnquiryWonAdapter(Context context, ArrayList<EnquiryWon> listOfWonData) {
        this.context = context;
        this.listOfWonData = listOfWonData;
        calendar = Calendar.getInstance();
        f2 = new SimpleDateFormat("h:mma");;
        f1 = new SimpleDateFormat("HH:mm:ss");
    }


    @Override
    public EnquiryWonAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.lay_fragment_won_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(EnquiryWonAdapter.ViewHolder holder, int position) {

        setFonts(holder);
//        holder.txt_requestTitle.setText("Customer wanted to"+" "+listOfWonData.get(position).getRequestTypeName()+" "+listOfWonData.get(position).getRequestQuantity()+" "+listOfWonData.get(position).getRequestTargetCurrencyName()+" "+"through"+" "+listOfWonData.get(position).getRequestSourceCurrencyName());
        holder.txt_nbcNo.setText(listOfWonData.get(position).getRequestSourceRef());
      //  holder.txt_status.setText(listOfWonData.get(position).getRequestStatusName());
       // holder.txtdateNtime.setText(listOfWonData.get(position).getRequestBidAcceptedDateTime());

      /*  String []arrDateTime=listOfWonData.get(position).getRequestBidAcceptedDateTime().split(" ");
        String[] arrDate=arrDateTime[0].split("-");
     //   Log.e("Date Timeeeeeeeeeeeeeee",""+arrDate[2]+"-"+arrDate[1]+"-"+arrDate[0]+" "+arrDateTime[1]);
        holder.txtdateNtime.setText(arrDate[2]+"-"+arrDate[1]+"-"+arrDate[0]+" "+arrDateTime[1]);*/
//cmt by rahul
/*

        String dateTime[]=listOfWonData.get(position).getRequestBidAcceptedDateTime().split(" ");
        String time=dateTime[1];
        String dateSplit[]=dateTime[0].split("-");
            */
/*Log.e("Month nooooooo",""+dateSplit[1]);
            Log.e("Time*********",""+time);*//*



        calendar.set(Calendar.MONTH, Integer.parseInt(dateSplit[1])-1);
        //Log.e("Month********",""+calendar.getTime());
        String month= String.valueOf(calendar.getTime());
        String datefinalMonth[]=month.split(" ");

            */
/*Log.e("Date Splittttttttt",""+dateSplit[0]);
            Log.e("Monthhhhhhhhhh****",""+datefinalMonth[1]);*//*

        //  holder.txtRequestDate.setText(reqhistory.get(position).getCreatedOn());
        try {
            d = f1.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String finalTime= f2.format(d).toLowerCase();
        // Log.e("finalTIMEEEEEEEEEEE",""+finalTime);

        holder.txtdateNtime.setText(datefinalMonth[1]+" "+dateSplit[0].substring(2,4)+" "+finalTime);
*/
        holder.txtdateNtime.setText(listOfWonData.get(position).getRequestBidAcceptedDateTime());
        if (listOfWonData.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")){
            if (listOfWonData.get(position).getSize().equalsIgnoreCase("2")){
                holder.imgProductType.setImageResource(R.drawable.cardcash);
                Log.e("wwwww",""+listOfWonData.get(position).getSize());
//                holder.txt_requestTitle.setVisibility(View.GONE);
                holder.txt_status.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.oval_backround_green));
                holder.txt_status.setText("BID WON");
                holder.txt_priceAttherate.setText("@"+listOfWonData.get(position).getProductName()+"("+listOfWonData.get(position).getRequestBidQuantity()+"):"+listOfWonData.get(position).getRequestBidRate()+"+"+listOfWonData.get(position).getProductName1()+"("+listOfWonData.get(position).getRequestBidQuantity1()+"):"+listOfWonData.get(position).getRequestBidRate1());
                if (listOfWonData.get(position).getUserName()!=null){
                    holder.txtUserName.setText(listOfWonData.get(position).getUserName());
                }
                if (listOfWonData.get(position).getUserMobileNo()!=null){
                    holder.txtPhoneNo.setText(listOfWonData.get(position).getUserMobileNo());
                }

                if (listOfWonData.get(position).getAreaName()!=null&&listOfWonData.get(position).getCityName()!=null) {

                    holder.txtLocation.setText(listOfWonData.get(position).getAreaName() + " " + listOfWonData.get(position).getCityName()+" - "+listOfWonData.get(position).getDistance()+" Kms");
                }
                if (listOfWonData.get(position).getRequestDeliveryModeName()!=null){
                    if (listOfWonData.get(position).getRequestDeliveryModeName().equalsIgnoreCase("Home Delivery")){
                        holder.imgDelivaryType.setImageResource(R.drawable.bid_delivery_new);
                    }
                    holder.txtMode.setText(listOfWonData.get(position).getRequestDeliveryModeName());
                }
                holder.txt_inprogress_currency.setText(listOfWonData.get(position).getRequestProductTypeName()+" + "+listOfWonData.get(position).getRequestProductTypeName_2());


                DecimalFormat decimalFormat=new DecimalFormat(".##");
                double input = Double.parseDouble(listOfWonData.get(position).getCommissionAmount());

                holder.txtCommission.setText("Commission Charged-INR "+decimalFormat.format(input));
                if (listOfWonData.get(position).getRequestBidQuantity()!=null){
                    Integer Qnt= Integer.valueOf(listOfWonData.get(position).getRequestBidQuantity())+Integer.valueOf(listOfWonData.get(position).getRequestBidQuantity1());
                    if (listOfWonData.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                        holder.txt_won_bought_sell.setText("Sold " + Qnt+" "+listOfWonData.get(position).getRequestSourceCurrencyName());
                        holder.txtBought.setVisibility(View.GONE);
                        holder.txt_won_bought_sell.setVisibility(View.VISIBLE);
                        if (listOfWonData.get(position).getRequestSourceCurrencyName()!=null){
                            holder.txt_inputCurency.setText(listOfWonData.get(position).getRequestTargetCurrencyName());
                        }

                    }
                    else {
                        holder.txtBought.setText("Bought "+Qnt+" "+listOfWonData.get(position).getRequestTargetCurrencyName());
                        holder.txtBought.setVisibility(View.VISIBLE);
                        holder.txt_won_bought_sell.setVisibility(View.GONE);
                        if (listOfWonData.get(position).getRequestSourceCurrencyName() != null) {
                            holder.txt_inputCurency.setText(listOfWonData.get(position).getRequestSourceCurrencyName());
                        }
                    }



                }
                if (listOfWonData.get(position).getRequestTargetCurrencyName()!=null){
                    holder.txt_targetCurrency.setText(listOfWonData.get(position).getRequestSourceCurrencyName());
                }
                if (listOfWonData.get(position).getRequestSourceCurrencyName()!=null){
                    holder.txt_inputCurency.setText(listOfWonData.get(position).getRequestTargetCurrencyName());
                }

                if (listOfWonData.get(position).getAvarageRate()!=null){



                }

            }else {


                //  holder.txt_requestTitle.setVisibility(View.GONE);
                holder.txt_status.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.oval_backround_green));
                holder.txt_status.setText("BID WON");
                if (listOfWonData.get(position).getUserName() != null) {
                    holder.txtUserName.setText(listOfWonData.get(position).getUserName());
                }
                if (listOfWonData.get(position).getUserMobileNo() != null) {
                    holder.txtPhoneNo.setText(listOfWonData.get(position).getUserMobileNo());
                }

                if (listOfWonData.get(position).getAreaName() != null && listOfWonData.get(position).getCityName() != null) {

                    holder.txtLocation.setText(listOfWonData.get(position).getAreaName() + " " + listOfWonData.get(position).getCityName() + " - " + listOfWonData.get(position).getDistance() + " Kms");
                }
                if (listOfWonData.get(position).getRequestDeliveryModeName() != null) {
                    if (listOfWonData.get(position).getRequestDeliveryModeName().equalsIgnoreCase("Home Delivery")) {
                        holder.imgDelivaryType.setImageResource(R.drawable.bid_delivery_new);
                    }
                    holder.txtMode.setText(listOfWonData.get(position).getRequestDeliveryModeName());
                }
                holder.txt_inprogress_currency.setText(listOfWonData.get(position).getRequestProductTypeName());
                if (listOfWonData.get(position).getRequestProductTypeName().equalsIgnoreCase("Forex Card")) {
                    holder.imgProductType.setImageResource(R.drawable.demovisiting);
                }
                if (listOfWonData.get(position).getRequestProductTypeName().equalsIgnoreCase("Currency Notes")){
                    holder.imgProductType.setImageResource(R.drawable.bidproduct);
                }
                if (listOfWonData.get(position).getRequestProductTypeName().equalsIgnoreCase("Money Transfer")){
                    holder.imgProductType.setImageResource(R.drawable.moneytransfer);
                }
                try{
                    DecimalFormat decimalFormat = new DecimalFormat(".##");
                    double input = Double.parseDouble(listOfWonData.get(position).getCommissionAmount());
                    holder.txtCommission.setText("Commission Charged-INR " + decimalFormat.format(input));
                }catch (NumberFormatException e){
                    e.printStackTrace();
                }


                if (listOfWonData.get(position).getRequestQuantity() != null) {
                    if (listOfWonData.get(position).getRequestTypeName().equalsIgnoreCase("Sell")){
                        holder.txt_won_bought_sell.setText("Sold " + listOfWonData.get(position).getRequestQuantity()+" "+listOfWonData.get(position).getRequestSourceCurrencyName());
                        holder.txtBought.setVisibility(View.GONE);
                        holder.txt_won_bought_sell.setVisibility(View.VISIBLE);
                        holder.txt_won_bought_moneyTrans.setVisibility(View.GONE);
                        if (listOfWonData.get(position).getRequestTargetCurrencyName() != null) {
                            holder.txt_inputCurency.setText(listOfWonData.get(position).getRequestTargetCurrencyName());
                        }
                        if (listOfWonData.get(position).getRequestSourceRefId().equalsIgnoreCase("5")||listOfWonData.get(position).getRequestSourceRefId().equalsIgnoreCase("3")||listOfWonData.get(position).getRequestSourceRefId().equalsIgnoreCase("6")){
                            holder.txt_won_bought_sell.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_sell));
                        }
                        else {
                            holder.txt_won_bought_sell.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_for_sell_inprogess));
                        }
                    }
                    else if (listOfWonData.get(position).getRequestTypeName().equalsIgnoreCase("Buy")){
                        holder.txtBought.setText("Bought " + listOfWonData.get(position).getRequestQuantity()+" "+listOfWonData.get(position).getRequestTargetCurrencyName());
                        holder.txtBought.setVisibility(View.VISIBLE);
                        holder.txt_won_bought_sell.setVisibility(View.GONE);
                        holder.txt_won_bought_moneyTrans.setVisibility(View.GONE);
                        if (listOfWonData.get(position).getRequestSourceCurrencyName() != null) {
                            holder.txt_inputCurency.setText(listOfWonData.get(position).getRequestSourceCurrencyName());
                        }
                        if (listOfWonData.get(position).getRequestSourceRefId().equalsIgnoreCase("5")||listOfWonData.get(position).getRequestSourceRefId().equalsIgnoreCase("3")||listOfWonData.get(position).getRequestSourceRefId().equalsIgnoreCase("6")){
                            holder.txtBought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_moneychanger_buy));
                        }
                        else {
                            holder.txtBought.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.background_black_rounded));
                        }

                    }
                    else {
                        holder.txt_won_bought_moneyTrans.setText("Remitted " + listOfWonData.get(position).getRequestQuantity()+" "+listOfWonData.get(position).getRequestTargetCurrencyName());
                        holder.txtBought.setVisibility(View.GONE);
                        holder.txt_won_bought_moneyTrans.setVisibility(View.VISIBLE);
                        holder.txt_won_bought_sell.setVisibility(View.GONE);
                        if (listOfWonData.get(position).getRequestSourceCurrencyName() != null) {
                            holder.txt_inputCurency.setText(listOfWonData.get(position).getRequestSourceCurrencyName());
                        }
                    }



                }
                if (listOfWonData.get(position).getRequestTargetCurrencyName() != null) {
                    holder.txt_targetCurrency.setText(listOfWonData.get(position).getRequestSourceCurrencyName());
                }


                if (listOfWonData.get(position).getAvarageRate() != null) {
                    holder.txt_priceAttherate.setText("@ " + listOfWonData.get(position).getAvarageRate());
                }
            }


        }else {
            holder.linear_UserName.setVisibility(View.GONE);
            holder.linear_UserDetails.setVisibility(View.GONE);
            holder.linear_won_bidInfo.setVisibility(View.GONE);
            holder.txt_status.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.oval_backround_red));
            holder.txt_status.setText("LOST");
        }



    }

    @Override
    public int getItemCount() {
        return listOfWonData.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txt_nbcNo,txt_status,txtdateNtime,txtUserName,txtPhoneNo,txtLocation,txtMode,txtCommission,txt_won_bought_moneyTrans,
        txtBought,txt_targetCurrency,txt_priceAttherate,txt_inputCurency,txt_inprogress_currency,txt_won_bought_sell;
        ImageView imgDelivaryType,imgProductType;
        LinearLayout linear_UserName,linear_UserDetails,linear_won_bidInfo;
        public ViewHolder(View itemView) {
            super(itemView);
            txt_won_bought_moneyTrans= (TextView) itemView.findViewById(R.id.txt_won_bought_moneyTrans);
            txt_won_bought_sell= (TextView) itemView.findViewById(R.id.txt_won_bought_sell);
            imgDelivaryType= (ImageView) itemView.findViewById(R.id.imgDelivaryType);
          //  txt_requestTitle=(TextView)itemView.findViewById(R.id.txt_won_requestTitle);
            txt_nbcNo=(TextView)itemView.findViewById(R.id.txt_won_NBC);
            txt_status=(TextView)itemView.findViewById(R.id.txt_won_Status);
            txtdateNtime=(TextView)itemView.findViewById(R.id.txt_won_dateNtime);
            txtUserName=(TextView)itemView.findViewById(R.id.txt_won_username);
            txtPhoneNo=(TextView)itemView.findViewById(R.id.txt_won_phone);
            txtLocation=(TextView)itemView.findViewById(R.id.txt_won_location);
            txtMode=(TextView)itemView.findViewById(R.id.txt_won_mode);
            txtCommission=(TextView)itemView.findViewById(R.id.txt_won_commission);
            txt_inprogress_currency= (TextView) itemView.findViewById(R.id.txt_inprogress_currency);
            linear_UserName=(LinearLayout)itemView.findViewById(R.id.linear_id_won_user_phone);
            linear_UserDetails=(LinearLayout)itemView.findViewById(R.id.linear_won_info);
            txtBought=(TextView)itemView.findViewById(R.id.txt_won_bought);
            txt_targetCurrency=(TextView)itemView.findViewById(R.id.txt_won_target_currency);
            txt_priceAttherate=(TextView)itemView.findViewById(R.id.txt_won_attherate);
            txt_inputCurency=(TextView)itemView.findViewById(R.id.txt_won_input_currency);
            linear_won_bidInfo=(LinearLayout)itemView.findViewById(R.id.linear_won_bidInfo);
            imgProductType= (ImageView) itemView.findViewById(R.id.imgProductType);

        }
    }


    public void setFonts(ViewHolder holder){
      //  holder.txt_requestTitle.setTypeface(FontData.setFonts(context,holder.txt_requestTitle, FontData.font_robotoBold));
        holder.txt_nbcNo.setTypeface(FontData.setFonts(context,holder.txt_nbcNo, FontData.font_robotomedium));
        holder.txt_status.setTypeface(FontData.setFonts(context,holder.txt_status, FontData.font_robotolight));
        holder.txtdateNtime.setTypeface(FontData.setFonts(context,holder.txtdateNtime, FontData.font_robotomedium));
        holder.txtUserName.setTypeface(FontData.setFonts(context,holder.txtUserName,FontData.font_robotolight));
        holder.txtPhoneNo.setTypeface(FontData.setFonts(context,holder.txtPhoneNo,FontData.font_robotolight));
        holder.txtLocation.setTypeface(FontData.setFonts(context,holder.txtLocation,FontData.font_robotolight));
        holder.txtMode.setTypeface(FontData.setFonts(context,holder.txtMode,FontData.font_robotolight));
        holder.txtCommission.setTypeface(FontData.setFonts(context,holder.txtCommission,FontData.font_robotolight));

        holder.txtBought.setTypeface(FontData.setFonts(context,holder.txtBought,FontData.font_robotolight));
        holder.txt_targetCurrency.setTypeface(FontData.setFonts(context,holder.txt_targetCurrency,FontData.font_robotolight));
        holder.txt_priceAttherate.setTypeface(FontData.setFonts(context,holder.txt_priceAttherate,FontData.font_robotolight));
        holder.txt_inputCurency.setTypeface(FontData.setFonts(context,holder.txt_inputCurency,FontData.font_robotolight));

    }
}
