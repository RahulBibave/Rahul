package com.nafex.nafex2.adapters;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.activity.Activity_bidsuccesshistory;
import com.nafex.nafex2.activity.Activityrequesttracemenu;
import com.nafex.nafex2.data.RequestHistory;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by rahul on 10/2/18.
 */

public class AdapterPastHistoryNew extends RecyclerView.Adapter<AdapterPastHistoryNew.ViewHolder>{
    Context context;
    LayoutInflater inflater;
    private ArrayList<RequestHistory> reqhistory;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;

    public AdapterPastHistoryNew(Context context, ArrayList<RequestHistory> reqhistory) {
        this.context = context;
        this.reqhistory = reqhistory;
       // sharedpreferences = context.getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
    }
    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.lay_fragment_inprogress_history_n, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        try{
            holder.linear_container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    /*setRequestpref(Integer.parseInt(reqhistory.get(position).getRequestId()),reqhistory.get(position).getRequestNBC());
                    Intent int_historydetails=new Intent(context, Activityrequesttracemenu.class);
                    context.startActivity(int_historydetails);*/
                    Log.e("Inside On Click",""+reqhistory.get(position));

                    Intent int_historydetails = new Intent(context, Activity_bidsuccesshistory.class);
                    int_historydetails.putExtra("source", "history");
                    int_historydetails.putExtra("requestId", Integer.parseInt(reqhistory.get(position).requestId));
                    context.startActivity(int_historydetails);
                }
            });
            holder.txtRequestDate.setText(reqhistory.get(position).getCreatedOn());
            holder.txtNBC.setText(reqhistory.get(position).getRequestNBC());
            holder.txtStatus.setText(reqhistory.get(position).getRequestStatusName());
            holder.txtArea.setText(reqhistory.get(position).getAreaName()+", "+reqhistory.get(position).getCityName()+", "+reqhistory.get(position).getStateName());
            holder.txtqty.setText(reqhistory.get(position).getNewProductQnt());

            Log.e("wwwwwwwwqq",""+reqhistory.get(position).getRequestTypeName());
            if (reqhistory.get(position).getRequestTypeName().equalsIgnoreCase("Money Transfer")){
                Log.e("eeeeeeeeee",""+reqhistory.get(position).getRequestTypeName());
                holder.txtRequestData.setText("You have requested to remittance "+reqhistory.get(position).getRequestQuantity() + " " + reqhistory.get(position).getRequestTargetCurrencyName());
                holder.txt_hitory_cardType.setText(reqhistory.get(position).getRequestTypeName());
                holder.linear_buysell.setVisibility(View.GONE);
                holder.linear_delivary.setVisibility(View.GONE);
                holder.linear_currencyFrom.setVisibility(View.GONE);
                holder.linear_currencyTo.setVisibility(View.GONE);
                holder.linear_currency.setVisibility(View.VISIBLE);
                holder.linear_transferType.setVisibility(View.VISIBLE);
                holder.linear_purpose.setVisibility(View.VISIBLE);
                holder.linear_country.setVisibility(View.VISIBLE);
                holder.txt_currenctxt.setText(reqhistory.get(position).getRequestTargetCurrencyName());
                holder.txtCountry.setText(reqhistory.get(position).getRequestCountryName());
                holder.txt_PURPOSE.setText(reqhistory.get(position).getRequestPurposeName());
                holder.txt_transferType.setText(reqhistory.get(position).getRequestTransferTypeName());
                holder.txtqty.setText(reqhistory.get(position).getRequestQuantity());
            }else {

                holder.linear_buysell.setVisibility(View.VISIBLE);
                holder.linear_delivary.setVisibility(View.VISIBLE);
                holder.linear_currencyFrom.setVisibility(View.VISIBLE);
                holder.linear_currencyTo.setVisibility(View.VISIBLE);
                holder.linear_currency.setVisibility(View.GONE);
                holder.linear_transferType.setVisibility(View.GONE);
                holder.linear_purpose.setVisibility(View.GONE);
                holder.linear_country.setVisibility(View.GONE);
                holder.txtBUY.setText(reqhistory.get(position).getRequestTypeName());
                holder.txtDelivery.setText(reqhistory.get(position).getRequestDeliveryModeName());
                if(reqhistory.get(position).getRequestTypeName().equalsIgnoreCase("Buy")) {

                    holder.txtAbbrivationFrom.setText(reqhistory.get(position).getRequestSourceCurrencyName());
                    holder.txtAbbrivation.setText(reqhistory.get(position).getRequestTargetCurrencyName());
                    holder.txtRequestData.setText("You have requested to buy "+reqhistory.get(position).getRequestQuantity() + " " + reqhistory.get(position).getRequestTargetCurrencyName());
                    holder.txt_hitory_cardType.setText(reqhistory.get(position).getRequestProductTypeName());
                    holder.txtqty.setText(reqhistory.get(position).getRequestQuantity());
                    if (reqhistory.get(position).getNewProduct().equalsIgnoreCase("2")) {
                        holder.txtqty.setText(reqhistory.get(position).getNewProductQnt());
                    }
                }else
                {
                    if(reqhistory.get(position).getRequestTypeName().equalsIgnoreCase("Sell"))
                    {
                        holder.txt_hitory_cardType.setText(reqhistory.get(position).getRequestProductTypeName());
                        holder.txtAbbrivationFrom.setText(reqhistory.get(position).getRequestTargetCurrencyName());
                        holder.txtAbbrivation.setText(reqhistory.get(position).getRequestSourceCurrencyName());
                        holder.txtRequestData.setText("You have requested to sell "+reqhistory.get(position).getRequestQuantity() + " " + reqhistory.get(position).getRequestTargetCurrencyName());
                        holder.txtqty.setText(reqhistory.get(position).getRequestQuantity());

                    }
                }




            }

            if (reqhistory.get(position).getRequestStatusName().equalsIgnoreCase("Expired")) {
                holder.txtRequestRate.setText(reqhistory.get(position).getRequestTargetCurrencyName() + " " + reqhistory.get(position).getRequestQuantity() + "/" + reqhistory.get(position).getRequestSourceCurrencyName());
            } else {
                if (reqhistory.get(position).getRequestStatusName().equalsIgnoreCase("Accepted")) {
                    holder.txtRequestRate.setText(reqhistory.get(position).getRequestTargetCurrencyName() + " " + reqhistory.get(position).getRequestQuantity() + "/" + reqhistory.get(position).getRequestSourceCurrencyName());

                }else
                {
                    if(reqhistory.get(position).getRequestStatusName().equalsIgnoreCase("Open"))
                    {
                        holder.txtRequestRate.setText(reqhistory.get(position).getRequestTargetCurrencyName() + " " + reqhistory.get(position).getRequestQuantity() + "/" + reqhistory.get(position).getRequestSourceCurrencyName());

                    }
                }
            }






        }catch (NullPointerException e){
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        return reqhistory.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtNBC, txtStatus, txtRequestDate, txtRequestRate, txtRequestData, txtArea, txtMode, txtBUY, txtqty, txtAbbrivation, txtDelivery;
        TextView txtBuySellHead, txtCurrencyHead, txtDeliveryHead, txtQuantity, txtAreaHead, txtAbbrivationFrom,txt_hitory_cardType;
        ImageView imgInfo;
        LinearLayout linearLayoutInfo,linear_buysell,linear_delivary,linear_currencyFrom,linear_currencyTo,linear_currency,linear_transferType,linear_purpose,linear_country,linear_container;
        TextView txtCountry,txt_country_head,txt_currenctxt,txt_currency_h,txt_transferType,txt_transfer_type_head,txt_PURPOSE,txt_PURPOSE_head;

        public ViewHolder(View view) {
            super(view);

            txtNBC = (TextView)view.findViewById(R.id.txtNBC);
            linear_container= (LinearLayout) view.findViewById(R.id.linear_container);
            txtStatus = (TextView) view.findViewById(R.id.txtStatus);
            txtRequestDate = (TextView) view.findViewById(R.id.txtRequestDate);
            txtRequestRate = (TextView) view.findViewById(R.id.txtRequestRate);
            txtRequestData = (TextView) view.findViewById(R.id.txtRequestData);
            txtArea = (TextView) view.findViewById(R.id.txtArea);
            // txtMode=(TextView)holder.itemView.findViewById(R.id.txtMode);
            imgInfo = (ImageView) view.findViewById(R.id.imgInfo);
            txtBUY = (TextView) view.findViewById(R.id.txt_hitory_buysell);
            txtqty = (TextView) view.findViewById(R.id.txt_historyqty);
            txtAbbrivation = (TextView) view.findViewById(R.id.txt_historyAbbrivation);
            txtAbbrivationFrom = (TextView) view.findViewById(R.id.txt_historyAbbrivation_From);
            txtDelivery = (TextView) view.findViewById(R.id.txtDeliveryMode);
            linearLayoutInfo = (LinearLayout) view.findViewById(R.id.linear_info);

            txtBuySellHead = (TextView) view.findViewById(R.id.txt_buySell_head);
            txtCurrencyHead = (TextView) view.findViewById(R.id.txt_currency_head);
            txtQuantity = (TextView) view.findViewById(R.id.txt_qunt_head);
            txtAreaHead = (TextView) view.findViewById(R.id.txt_AREA_head);
            txtDeliveryHead = (TextView) view.findViewById(R.id.txt_delivery_head);

            txt_hitory_cardType= (TextView) view.findViewById(R.id.txt_hitory_cardType);

            linear_buysell= (LinearLayout) view.findViewById(R.id.linear_buysell);
            linear_delivary= (LinearLayout) view.findViewById(R.id.linear_delivary);
            linear_currencyFrom= (LinearLayout) view.findViewById(R.id.linear_currencyFrom);
            linear_currencyTo= (LinearLayout) view.findViewById(R.id.linear_currencyTo);
            linear_currency= (LinearLayout) view.findViewById(R.id.linear_currency);
            linear_transferType= (LinearLayout) view.findViewById(R.id.linear_transferType);
            linear_purpose= (LinearLayout) view.findViewById(R.id.linear_purpose);
            linear_country= (LinearLayout) view.findViewById(R.id.linear_country);

            txtCountry= (TextView) view.findViewById(R.id.txtCountry);
            txt_country_head= (TextView) view.findViewById(R.id.txt_country_head);
            txt_currenctxt= (TextView) view.findViewById(R.id.txt_currenctxt);
            txt_currency_h= (TextView) view.findViewById(R.id.txt_currency_h);

            txt_transferType= (TextView) view.findViewById(R.id.txt_transferType);
            txt_transfer_type_head= (TextView) view.findViewById(R.id.txt_transfer_type_head);

            txt_PURPOSE= (TextView) view.findViewById(R.id.txt_PURPOSE);
            txt_PURPOSE_head= (TextView) view.findViewById(R.id.txt_PURPOSE_head);



            txtBuySellHead.setTypeface(FontData.setFonts(context, txtBuySellHead, FontData.font_robotomedium));
            txtCurrencyHead.setTypeface(FontData.setFonts(context, txtCurrencyHead, FontData.font_robotomedium));
            txtQuantity.setTypeface(FontData.setFonts(context, txtQuantity, FontData.font_robotomedium));
            txtAreaHead.setTypeface(FontData.setFonts(context, txtAreaHead, FontData.font_robotomedium));
            txtDeliveryHead.setTypeface(FontData.setFonts(context, txtDeliveryHead, FontData.font_robotomedium));
            txt_country_head.setTypeface(FontData.setFonts(context, txt_country_head, FontData.font_robotomedium));
            txt_currency_h.setTypeface(FontData.setFonts(context, txt_currency_h, FontData.font_robotomedium));
            txt_transfer_type_head.setTypeface(FontData.setFonts(context, txt_transfer_type_head, FontData.font_robotomedium));
            txt_PURPOSE_head.setTypeface(FontData.setFonts(context, txt_PURPOSE_head, FontData.font_robotomedium));

            txt_transferType.setTypeface(FontData.setFonts(context, txt_transferType, FontData.font_robotoregular));
            txt_PURPOSE_head.setTypeface(FontData.setFonts(context, txt_PURPOSE_head, FontData.font_robotoregular));
            txtCountry.setTypeface(FontData.setFonts(context, txtCountry, FontData.font_robotoregular));
            txt_currenctxt.setTypeface(FontData.setFonts(context, txt_currenctxt, FontData.font_robotoregular));


            txtNBC.setTypeface(FontData.setFonts(context, txtNBC, FontData.font_robotoregular));
            txtStatus.setTypeface(FontData.setFonts(context, txtStatus, FontData.font_robotoregular));
            txtRequestDate.setTypeface(FontData.setFonts(context, txtRequestDate, FontData.font_robotoregular));
            txtRequestRate.setTypeface(FontData.setFonts(context, txtRequestRate, FontData.font_robotoregular));
            txtRequestData.setTypeface(FontData.setFonts(context, txtRequestData, FontData.font_robotomedium));
            txtArea.setTypeface(FontData.setFonts(context, txtArea, FontData.font_robotoregular));
            txtBUY.setTypeface(FontData.setFonts(context, txtBUY, FontData.font_robotoregular));
            txtAbbrivation.setTypeface(FontData.setFonts(context, txtAbbrivation, FontData.font_robotoregular));
            txtAbbrivationFrom.setTypeface(FontData.setFonts(context, txtAbbrivationFrom, FontData.font_robotoregular));

            txtDelivery.setTypeface(FontData.setFonts(context, txtDelivery, FontData.font_robotoregular));





        }

    }
   /* private void setRequestpref(int requestid, String nbc) {
        sharedpreferences = context.getSharedPreferences(ConstantData.MyPREFERENCES, MODE_PRIVATE);
        editor = sharedpreferences.edit();
        editor.putInt(ConstantData.KEY_requestid, requestid);
        editor.putString(ConstantData.KEY_nbc, nbc);
        editor.commit();
    }*/


}
