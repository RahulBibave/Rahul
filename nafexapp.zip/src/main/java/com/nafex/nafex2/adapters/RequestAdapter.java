package com.nafex.nafex2.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.BidRequest;
import com.nafex.nafex2.interfaces.OnRequestSelected;
import com.nafex.nafex2.utilities.AppGlobalData;

import java.util.ArrayList;

/**
 * Created by Sunil on 5/13/2017.
 */
public class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.ViewHolder> {
     Context context;
    ArrayList<BidRequest> listOfRequest;
    AppGlobalData gbData;

    OnRequestSelected objRequestSelected;

    public RequestAdapter(Context context, ArrayList<BidRequest> listOfRequest, AppGlobalData igbData,OnRequestSelected oRequestSelected) {
        this.context = context;
        this.listOfRequest = listOfRequest;
        gbData = igbData;
        this.objRequestSelected = oRequestSelected;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View itemView=inflater.inflate(R.layout.lay_fragment_inprogress_history,parent,false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        TextView txtNBC, txtStatus, txtRequestDate, txtRequestRate, txtRequestData, txtArea, txtMode;
        ImageView imgInfo;

        txtNBC=(TextView)holder.itemView.findViewById(R.id.txtNBC);
        txtStatus=(TextView)holder.itemView.findViewById(R.id.txtStatus);
        txtRequestDate=(TextView)holder.itemView.findViewById(R.id.txtRequestDate);
        txtRequestRate=(TextView)holder.itemView.findViewById(R.id.txtRequestRate);
        txtRequestData=(TextView)holder.itemView.findViewById(R.id.txtRequestData);
        txtArea=(TextView)holder.itemView.findViewById(R.id.txtArea);
        txtMode=(TextView)holder.itemView.findViewById(R.id.txtMode);
        imgInfo = (ImageView) holder.itemView.findViewById(R.id.imgInfo);

        BidRequest obj = listOfRequest.get(position);
        txtNBC.setText(obj.getNBC());
        txtStatus.setText(gbData.PrepareStatusString(obj.getreqStatus()));
        txtRequestDate.setText(obj.getRequestDate());

        if ((obj.getreqWinnerRate() != null) && (obj.getreqWinnerRate() != 0.00))
            txtRequestRate.setText("INR " + obj.getreqWinnerRate() + " / " + obj.getcurrencyAbbrivation());
        else
            txtRequestRate.setText("INR" +  " to " + obj.getcurrencyAbbrivation());

        txtRequestData.setText("You wanted to " + obj.getType() +  " " + obj.getreqQuantity() + " " + obj.getcurrencyAbbrivation() + " through INR.");
        txtArea.setText(obj.getAreaName());;
        txtMode.setText(obj.getDispMode());

        final String NBC = obj.getNBC();
        imgInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                objRequestSelected.onInfoButtonClicked(NBC);
            }
        });

    }

    @Override
    public int getItemCount() {
        return listOfRequest.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public ViewHolder(View itemView) {
            super(itemView);

        }

    }



}
