package com.nafex.nafex2.adapters;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.nafex.nafex2.R;
import com.nafex.nafex2.activity.Activity_Recharge_Queries;
import com.nafex.nafex2.data.LeadData;
import com.nafex.nafex2.data.Product;
import com.nafex.nafex2.utilities.AppGlobalData;
import com.nafex.nafex2.utilities.CommonApi;
import com.nafex.nafex2.utilities.CommonUI;
import com.nafex.nafex2.utilities.ConstantData;
import com.nafex.nafex2.utilities.FontData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by rahul on 12/10/17.
 */

public class AdapterLeads extends RecyclerView.Adapter<AdapterLeads.ViewHolderLeads> {
    private Context mContext;
    List<LeadData> justdiallist;
    private ArrayList<String> days;
    List<Product> productList;
    private boolean bproduct = false;
    private int iProduct = 0;
    Calendar calendar = Calendar.getInstance();
    ;
    String user_id, user_token, branchID;

    SimpleDateFormat dateFormat;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    int hour = calendar.get(Calendar.HOUR_OF_DAY);
    int minute = calendar.get(Calendar.MINUTE);
    private DatePickerDialog datePickerDialog;
    AppGlobalData gbData;
    TextView txtDay;
    String strLeadid, strremDay, strremDate, strremTime, strremRemark;

    public AdapterLeads(Context mContext, List<LeadData> leadlist) {
        gbData = AppGlobalData.getInstance();

        this.mContext = mContext;
        justdiallist = leadlist;
    }

    @Override
    public ViewHolderLeads onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.lay_leads_view, parent, false);
        return new ViewHolderLeads(view);
    }


    public class CallDeleteLeadAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), objdata.getString("message_text"));

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), Error_Message);
                }
                //  showProductAlertCustomDialog();

            } else
                CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), Error_Message);

            // progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.LEADDELETE);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("leadId", "1");
                postDataParams.put("reason", "3");
                postDataParams.put("otherReason", "");

                Log.e("strLeadid", strLeadid);


                byte[] auth = (user_id + ":" + user_token).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }

    }


    public void showDialog(Context activity, final int position) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = dialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.lay_reminder);

        TextView txtReportDate = (TextView) dialog.findViewById(R.id.txtReportDate);
        txtDay = (TextView) dialog.findViewById(R.id.txtDay);
        final TextView txtDate = (TextView) dialog.findViewById(R.id.txtDate);
        final TextView txtTime = (TextView) dialog.findViewById(R.id.txtTime);
        final TextView txtSelectTime = (TextView) dialog.findViewById(R.id.txtSelectTime);
        final EditText edtRemark = (EditText) dialog.findViewById(R.id.edtRemark);
        Button btnCancelRem = (Button) dialog.findViewById(R.id.btnCancelRem);
        Button btnSetRem = (Button) dialog.findViewById(R.id.btnSetRem);
        btnSetRem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (iProduct == 0) {

                } else {
                    if (txtDate.getText().toString().equalsIgnoreCase("Select Date")) {

                    } else {
                        if (txtSelectTime.getText().toString().equalsIgnoreCase("Select Time")) {

                        } else {
                            getSharedPref();
                            if (gbData.isConnected(mContext)) {

                                strLeadid = justdiallist.get(position).getId();
                                strremDay = Integer.toString(iProduct);
                                strremDate = txtDate.getText().toString().trim();
                                strremTime = txtSelectTime.getText().toString().trim();
                                strremRemark = edtRemark.getText().toString().trim();

                                CallJustDialSetReminderAPI callDisputeApi = new CallJustDialSetReminderAPI();
                                callDisputeApi.execute();
                            }
                            dialog.dismiss();

                        }
                    }
                }

            }
        });
        btnCancelRem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        txtDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bproduct == false) {

                    if (productList == null || productList.size() <= 0) {
                        if (gbData.isConnected(mContext)) {
                            bproduct = true;
                            CallProductAPI objcurrrencyAPI = new CallProductAPI();
                            objcurrrencyAPI.execute(CommonApi.CODELIST);
                        } else
                            CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), "Oops! No internet connection. Please check connection or Contact Nafex support team.");
                    } else

                        showProductAlertCustomDialog();
                }

                // showKycAlertCustomDialog();
            }
        });
        txtDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        calendar.set(year, monthOfYear, dayOfMonth);

                        txtDate.setText(dateFormat.format(calendar.getTime()));


                    }
                }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH));
                datePickerDialog.show();


            }
        });

        txtSelectTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog = new TimePickerDialog(mContext,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                txtSelectTime.setText(hourOfDay + ":" + minute);
                            }
                        }, hour, minute, false);
                timePickerDialog.show();
            }
        });

        dialog.show();

    }

    private void getSharedPref() {
        sharedpreferences = mContext.getSharedPreferences(ConstantData.MyPREFERENCES, mContext.MODE_PRIVATE);
        user_id = sharedpreferences.getString(ConstantData.KEY_USERID_LFFCMLOGIN, "");
        user_token = sharedpreferences.getString(ConstantData.KEY_USERTOKEN_LFFCMLOGIN, "");
        branchID = sharedpreferences.getString(ConstantData.KEY_FFCM_BRANCHID, "");

    }


    public class CallJustDialSetReminderAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), objdata.getString("message_text"));

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), Error_Message);
                }
                //  showProductAlertCustomDialog();

            } else
                CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), Error_Message);

            // progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.LEADDETREM);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("remLeadId", "12");
                postDataParams.put("remDay", "2");
                postDataParams.put("remDate", "09/12/2017");
                postDataParams.put("remTime", "01:34 AM");
                postDataParams.put("remRemark", "testing");

                Log.e("remLeadId", strLeadid);
                Log.e("remDay", strremDay);
                Log.e("remDate", strremDate);
                Log.e("remTime", strremTime);
                Log.e("remRemark", strremRemark);


                byte[] auth = (user_id + ":" + user_token).getBytes();
                String basic = Base64.encodeToString(auth, Base64.NO_WRAP);
                urlConnection.setRequestProperty("Authorization", "Basic " + basic);

                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }

    }


    public class CallProductAPI extends AsyncTask<String, Void, String> {

        private String strResponse = "";
        String Error_Message = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //    progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (Error_Message.equalsIgnoreCase("")) {

                try {

                    JSONArray jsonArray;
                    JSONObject jsonObj;
                    JSONObject objdata = new JSONObject(strResponse);
                    if (objdata.getString("message_code").equalsIgnoreCase("1000")) {
                        jsonArray = objdata.getJSONArray("message_text");
                        productList = new ArrayList<Product>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObj = jsonArray.getJSONObject(i);
                            Product objProduct = new Product();
                            objProduct.setCodeValue(jsonObj.getString("codeValue"));
                            objProduct.setCodeName(jsonObj.getString("codeName"));
                            objProduct.setCodeAtrribute(jsonObj.getString("codeAttribute"));

                            productList.add(objProduct);
                        }

                    } else if (objdata.getString("message_code").equalsIgnoreCase("999"))
                        CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), objdata.getString("message_text"));
                } catch (JSONException e) {
                    Log.e("***Error:", e.getMessage(), e);
                    if (strResponse.equalsIgnoreCase(""))
                        Error_Message = "Please check your network connections.";
                    else
                        Error_Message = "JSONError: Please contact Nafex support team.";

                    CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), Error_Message);
                }
                showProductAlertCustomDialog();

            } else
                CommonUI.showAlert(mContext, mContext.getResources().getString(R.string.app_name), Error_Message);

            //  progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection urlConnection = null;

            try {
                URL url = new URL(CommonApi.SERVER_URL + CommonApi.BASE_URL + CommonApi.CODELIST);
                urlConnection = (HttpURLConnection) url.openConnection();

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("codeType", "LEADREMINDERDAYS");
                urlConnection.setRequestMethod(ConstantData.METHOD_POST);
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);

                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(gbData.getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = urlConnection.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    strResponse = stringBuilder.toString();
                    Log.e("Result", strResponse);
                }
            } catch (JSONException e) {
                //Log.e("***Error:", e.getMessage() , e);
                if (strResponse.equalsIgnoreCase(""))
                    Error_Message = "Please check your network connections.";
                else
                    Error_Message = "JSONError: Please contact Nafex support team.";

            } catch (Exception e) {
                //Log.e("ERROR", e.getMessage(), e);
                Error_Message = "Error: " + e.getClass().getName() + " in area data. Please contact Nafex support team.";
            } finally {
                if (urlConnection != null)
                    urlConnection.disconnect();
            }
            return null;
        }
    }

    /*RL*/

    private void showProductAlertCustomDialog() {
        final Dialog dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.setContentView(R.layout.currency_alert_dialog_layout_n);
        TextView tvtitle = (TextView) dialog.findViewById(R.id.txtAlertTitle);
        tvtitle.setVisibility(View.GONE);
        tvtitle.setText("Select Product");
        tvtitle.setTypeface(FontData.setFonts(mContext, tvtitle, FontData.font_robotomedium));

        ListView listView = (ListView) dialog.findViewById(R.id.currency_alert_dialog_list_id);

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                bproduct = false;
            }
        });


        if (productList != null) {
            ArrayList<String> choices = new ArrayList<>();
            final ArrayAdapter<String> currencyAdapter = new ArrayAdapter<String>(mContext, android.R.layout.select_dialog_singlechoice);
            for (int i = 0; i < productList.size(); i++) {
                choices.add(productList.get(i).getCodeName());
                currencyAdapter.add(productList.get(i).getCodeName());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                    R.layout.currency_list_item_n, R.id.list_item_id, choices);


            listView.setAdapter(adapter);
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()

                                        {
                                            @Override
                                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                                iProduct = Integer.parseInt(productList.get(i).getCodeValue());

                                                txtDay.setText(productList.get(i).getCodeName());
                                                //changes for new product


                                               /* long now= SystemClock.uptimeMillis();
                                                MotionEvent myEvent = MotionEvent.obtain(now,now,MotionEvent.ACTION_DOWN, 0, 0,0);
                                                onTouch(rvCurrency, myEvent);*/

                                                bproduct = false;
                                                dialog.dismiss();
                                            }
                                        }

        );
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
    }

    @Override
    public void onBindViewHolder(ViewHolderLeads holder, final int position) {
        holder.txtLeadsCustomer.setText(justdiallist.get(position).getPersonName());
        holder.txtLeadsLocation.setText(justdiallist.get(position).getRequestLocation());
        holder.txtLeadsQnt.setText(justdiallist.get(position).getRequestQuantity());
        holder.txtLeadsCurrency.setText(justdiallist.get(position).getRequestSourceCurrencyName());
        holder.txtLeadsDate.setText(justdiallist.get(position).getCreatedOn());
        holder.imgSetRem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(mContext, position);

            }
        });
        holder.imgLeadsDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (gbData.isConnected(mContext)) {
                    getSharedPref();
                    CallDeleteLeadAPI calldelete = new CallDeleteLeadAPI();
                    calldelete.execute();
                }
            }
        });


    }

    @Override
    public int getItemCount() {
        return justdiallist.size();
    }

    public class ViewHolderLeads extends RecyclerView.ViewHolder {
        private TextView txtLeadsDate, txtLeadsCustomer, txtLeadsLocation, txtLeadsQnt, txtLeadsCurrency;
        private ImageView imgLeadsFirst, imgLeadsMiddel, imgLeadsDelete;
        ImageView imgSetRem;

        public ViewHolderLeads(View itemView) {
            super(itemView);
            txtLeadsDate = (TextView) itemView.findViewById(R.id.txtLeadsDate);
            txtLeadsCustomer = (TextView) itemView.findViewById(R.id.txtLeadsCustomer);
            txtLeadsLocation = (TextView) itemView.findViewById(R.id.txtLeadsLocation);
            txtLeadsQnt = (TextView) itemView.findViewById(R.id.txtLeadsQnt);
            txtLeadsCurrency = (TextView) itemView.findViewById(R.id.txtLeadsCurrency);
            imgLeadsFirst = (ImageView) itemView.findViewById(R.id.imgLeadsFirst);
            imgLeadsMiddel = (ImageView) itemView.findViewById(R.id.imgLeadsMiddel);
            imgLeadsDelete = (ImageView) itemView.findViewById(R.id.imgLeadsDelete);
            imgSetRem = (ImageView) itemView.findViewById(R.id.imgLeadsFirst);
        }
    }
}


