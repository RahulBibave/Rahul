package com.nafex.nafex2.adapters;

/**
 * Created by trt16 on 8/9/16.
 */

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nafex.nafex2.R;
import com.nafex.nafex2.data.BidRequest;
import com.nafex.nafex2.data.RequestBid;
import com.nafex.nafex2.interfaces.OnBidAccept;

import java.util.List;


public class BidAdapter extends BaseAdapter {

    // Declare Variables
    Context context;
    LayoutInflater inflater;

    private List<RequestBid> bidList = null;

//    private String BidStatus;
//    private int WinnerFFMCId;
//    private int Quantity;
//    private String Currency;
    private BidRequest objRequest;
    private Double BestRate;

    OnBidAccept objBidAcceptCheck;

    public BidAdapter(Context context,
                      List<RequestBid> bidList, OnBidAccept oBidAcceptCheck, BidRequest oRequest, Double dBestRate) {
        this.context = context;
        this.bidList = bidList;
        this.objBidAcceptCheck = oBidAcceptCheck;
        this.objRequest = oRequest;
        this.BestRate = dBestRate;
        inflater = LayoutInflater.from(context);

    }

    public class ViewHolder {
        TextView tv_txtRateOffered;
        TextView tv_txtAreaOffered;
        TextView tv_txtAmountOffered;
        ImageView tv_imgAccept;
        ImageView tv_imgBestRate;
        Button btnAccept;
    }

    @Override
    public int getCount() {
        return 5;

    }

    @Override
    public Object getItem(int position) {
        return bidList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View view, ViewGroup parent) {
        final ViewHolder holder;
        boolean flag = false;
        if (view == null) {
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.bid_list_item_n, null);
            // Locate the TextViews in listview_item.xml
          /*  holder.tv_txtRateOffered = (TextView) view.findViewById(R.id.txtRateOffered);
            holder.tv_txtAreaOffered = (TextView) view.findViewById(R.id.txtAreaOffered);
            holder.tv_txtAmountOffered = (TextView) view.findViewById(R.id.txtAmountOffered);
            holder.tv_imgAccept = (ImageView) view.findViewById(R.id.imgAccept);
          //  holder.tv_imgBestRate  =  (ImageView) view.findViewById(R.id.imgBestRate);
            holder.btnAccept=(Button)view.findViewById(R.id.btn_AcceptRate);

            holder.tv_imgAccept.setTag(bidList.get(position).getFFMCId());
            Log.e("FFMC ID:", "Value" + bidList.get(position).getFFMCId());

*/
            view.setTag(holder);
            flag = false;
        } else {
            holder = (ViewHolder) view.getTag();
            flag = true;
        }
        // Set the results into TextViews
      /*  holder.tv_txtRateOffered.setText("INR " + String.format("%.2f",bidList.get(position).getFFMCRate()) + "/ " + objRequest.getcurrencyAbbrivation());
        holder.tv_txtAreaOffered.setText(bidList.get(position).getAreaName() );

        Float Amount = Float.parseFloat(bidList.get(position).getFFMCRate().toString()) * objRequest.getreqQuantity();

        if (objRequest.getType().toString().equalsIgnoreCase("SELL"))
            holder.tv_txtAmountOffered.setText("INR " + String.format("%.2f", Amount));
        else
            holder.tv_txtAmountOffered.setText("INR " + String.format("%.2f", Amount));
*/

      /*  if (bidList.get(position).getBestRateYN())
            holder.tv_imgBestRate.setImageResource(android.R.drawable.star_big_off);
        else
            holder.tv_imgBestRate.setImageResource(0);*/

     /*   if (bidList.get(position).getAcceptedYN())
            holder.tv_imgAccept.setImageResource(R.drawable.check_sel_128);
        else
            holder.tv_imgAccept.setImageResource(R.drawable.check_128);*/


//        if ((flag == false) && (BestRate == Double.parseDouble(bidList.get(position).getFFMCRate().toString()))) {
////            holder.tv_imgBestRate.setVisibility(View.VISIBLE);
//            holder.tv_imgBestRate.setImageResource(android.R.drawable.star_big_off);
//        }
//        else
//            holder.tv_imgBestRate.setImageResource(0);


        if (objRequest.getreqStatus().equalsIgnoreCase("O")) {


            //final int ffmc_id = bidList.get(position).getFFMCId();



           /* holder.tv_imgAccept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //int ffmc_id = Integer.parseInt(String.valueOf(view.getTag()));
                    //Log.e("FFMCID:", "Selected " + ffmc_id);
                    objBidAcceptCheck.onAcceptButtonClicked(bidList.get(position).getFFMCId());
                    //holder.tv_imgAccept.setImageResource(R.drawable.check_sel_128);
                }
            });*/

           /* holder.btnAccept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    objBidAcceptCheck.onAcceptButtonClicked(bidList.get(position).getFFMCId());
                }
            });*/

        }

        return view;
    }


//    public void filter(String charText) {
//
//        charText = charText.toLowerCase(Locale.getDefault());
//
//        eventlist.clear();
//        if (charText.length() == 0) {
//            eventlist.addAll(eventarraylist);
//
//        } else {
//            for (EventsPojo postDetail : eventarraylist) {
//                if (charText.length() != 0 && postDetail.getEventname().toLowerCase(Locale.getDefault()).contains(charText)) {
//                    eventlist.add(postDetail);
//                } else if (charText.length() != 0 && postDetail.getEventcity().toLowerCase(Locale.getDefault()).contains(charText)) {
//                    eventlist.add(postDetail);
//                }
//            }
//        }
//        notifyDataSetChanged();
//    }
}