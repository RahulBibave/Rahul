package com.sham.demoregistration.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.util.PatternsCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.sham.demoregistration.R;
import com.sham.demoregistration.database.DBUtil;
import com.sham.demoregistration.util.CommonUI;

/**
 * Created by Sunil on 04/13/2018.
 */

public class RegistrationActivity extends AppCompatActivity{
    EditText edt_Name,edt_PhoneNo,edt_Email,edt_Password;
    Button btn_Register;
    DBUtil dbUtil;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_activity);
        init();
        dbUtil=DBUtil.getInstance(RegistrationActivity.this);

        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validation()){

                    if (dbUtil.saveUserDetail(edt_Name.getText().toString().trim(),edt_PhoneNo.getText().toString().trim(),edt_Email.getText().toString().trim(),edt_Password.getText().toString().trim())){
                        CommonUI.showAlert(RegistrationActivity.this, getResources().getString(R.string.app_name), "Registered successfully...");
                        edt_Email.getText().clear();
                        edt_Name.getText().clear();
                        edt_Password.getText().clear();
                        edt_PhoneNo.getText().clear();

                    }else {

                        CommonUI.showAlert(RegistrationActivity.this, getResources().getString(R.string.app_name), "something went wrong.");

                    }
                }
            }
        });


    }

    public void init(){

        edt_Name=(EditText)findViewById(R.id.edt_name);
        edt_PhoneNo=(EditText)findViewById(R.id.edt_Mobile_No);
        edt_Email=(EditText)findViewById(R.id.edt_email_ID);
        edt_Password=(EditText)findViewById(R.id.edt_Password);
        btn_Register=(Button)findViewById(R.id.btn_Register);

    }

    private boolean validation() {
        String sUserName = edt_Name.getText().toString();
        String sphone = edt_PhoneNo.getText().toString();
        String sEmail = edt_Email.getText().toString();
        String sUserPassword = edt_Password.getText().toString();
        if (sUserName.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter User Name.");
        else if (sphone.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter  Phone No.");
        else if (sEmail.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Email Id");

        else if (!(PatternsCompat.EMAIL_ADDRESS.matcher(sEmail).matches()))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter valid Email ID");

        else if (sUserPassword.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Password.");

        else
            return true;

        return false;
    }



}
