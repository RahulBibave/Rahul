package com.sham.demoregistration.activities;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.support.v4.util.PatternsCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.ProfileTracker;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.sham.demoregistration.R;
import com.sham.demoregistration.database.DBUtil;
import com.sham.demoregistration.model.UserData;
import com.sham.demoregistration.util.CommonUI;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    EditText edt_EmailID,edt_Password;
    Button btn_Login;
    ArrayList<UserData> listOFAllUsers;
    DBUtil dbUtil;
    TextView txt_Registration;
    LoginButton login;
    CallbackManager callbackManager;
    private String facebook_id,f_name, m_name, l_name, gender, profile_image, full_name, email_id;
    TextView details_txt;
    LinearLayout linear_FacebookLogin,linear_Google_login;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_main);
        init();

        dbUtil=DBUtil.getInstance(MainActivity.this);
        listOFAllUsers=new ArrayList<>();
        callbackManager = CallbackManager.Factory.create();
        login = (LoginButton)findViewById(R.id.login_button);
        login.setReadPermissions("public_profile email");
       // getKeyHash();
    //    Checkhashkey();

        /*if(AccessToken.getCurrentAccessToken() != null){
            RequestData();

        }
*/
        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listOFAllUsers.clear();
                listOFAllUsers=dbUtil.getAllUSerData();



                if (validation()){
                    if (listOFAllUsers.size()>=0) {

                        for (int i = 0; i < listOFAllUsers.size(); i++) {
                            if ((listOFAllUsers.get(i).getEmail().equalsIgnoreCase(edt_EmailID.getText().toString().trim())) && (listOFAllUsers.get(i).getPassword().equalsIgnoreCase(edt_Password.getText().toString().trim()))) {
                                Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                                intent.putExtra("NAME",listOFAllUsers.get(i).getName());
                                intent.putExtra("EMAIL",listOFAllUsers.get(i).getEmail());
                                intent.putExtra("PHONE",listOFAllUsers.get(i).getPhone());
                                startActivity(intent);



                                Toast.makeText(MainActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(MainActivity.this, "Invalid Credentials.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }else {
                        Toast.makeText(MainActivity.this, "No Users Available Please Register first.", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });
        txt_Registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,RegistrationActivity.class);
                startActivity(intent);
            }
        });


        linear_FacebookLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginManager.getInstance().logInWithReadPermissions(MainActivity.this, Arrays.asList("public_profile", "user_friends"));

                if(AccessToken.getCurrentAccessToken() != null) {

                }
            }
        });


        /*login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginManager.getInstance().logInWithReadPermissions(MainActivity.this, Arrays.asList("public_profile", "user_friends"));

                if(AccessToken.getCurrentAccessToken() != null) {

                }
            }
        });*/

        login.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {

            private ProfileTracker mProfileTracker;
            String fNAme;
            @Override
            public void onSuccess(LoginResult loginResult) {

                facebook_id=f_name= m_name= l_name= gender= profile_image= full_name= email_id="";

                if(AccessToken.getCurrentAccessToken() != null){
                    RequestData();
                    //Profile profile = Profile.getCurrentProfile();


                    if(Profile.getCurrentProfile() == null) {
                        mProfileTracker = new ProfileTracker() {
                            @Override
                            protected void onCurrentProfileChanged(Profile oldProfile, Profile currentProfile) {
                                Log.e("facebook - profile********", currentProfile.getFirstName());
                                fNAme= currentProfile.getFirstName();
                                mProfileTracker.stopTracking();
                            }
                        };
                        // no need to call startTracking() on mProfileTracker
                        // because it is called by its constructor, internally.
                    }
                    else {
                        Profile profile = Profile.getCurrentProfile();
                        Log.v("facebook - profile*********", profile.getFirstName());
                    }




                    /*if (profile != null) {
                        facebook_id=profile.getId();
                        Log.e("facebook_id", facebook_id);
                        f_name=profile.getFirstName();
                        Log.e("f_name", f_name);
                        m_name=profile.getMiddleName();
                        Log.e("m_name", m_name);
                        l_name=profile.getLastName();
                        Log.e("l_name", l_name);
                        full_name=profile.getName();
                        Log.e("full_name", full_name);
                        profile_image=profile.getProfilePictureUri(400, 400).toString();
                        Log.e("profile_image", profile_image);
                    }*/
                    //share.setVisibility(View.VISIBLE);
                    //details.setVisibility(View.VISIBLE);

                    Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                    intent.putExtra("NAME",fNAme);
                    startActivity(intent);

                    Toast.makeText(MainActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException exception) {
            }
        });

    }

    public void init(){
        edt_EmailID=(EditText)findViewById(R.id.edt_emailID_login);
        edt_Password=(EditText)findViewById(R.id.edt_Password_login);
        btn_Login=(Button)findViewById(R.id.btnLogin);
        txt_Registration=(TextView)findViewById(R.id.txt_Registration);
        linear_FacebookLogin=(LinearLayout)findViewById(R.id.linear_SignInFacebook);
        linear_Google_login=(LinearLayout)findViewById(R.id.linear_SignInGoogle);
    }


    public void RequestData(){
        GraphRequest request = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
            @Override
            public void onCompleted(JSONObject object, GraphResponse response) {

                JSONObject json = response.getJSONObject();
                System.out.println("Json data :"+json);
                try {
                    if(json != null){
                        String text = "<b>Name :</b> "+json.getString("name")+"<br><br><b>Email :</b> "+json.getString("email")+"<br><br><b>Profile link :</b> "+json.getString("link");
                       // details_txt.setText(Html.fromHtml(text));
                      //  profile.setProfileId(json.getString("id"));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,link,email,picture");
        request.setParameters(parameters);
        request.executeAsync();
    }


    private boolean validation() {
        String sUserName = edt_EmailID.getText().toString();
        String sUserPassword = edt_Password.getText().toString();
        if (sUserName.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Email ID");
        else if (!(PatternsCompat.EMAIL_ADDRESS.matcher(sUserName).matches()))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter valid Email ID");

        else if (sUserPassword.equalsIgnoreCase(""))
            CommonUI.showAlert(this, getResources().getString(R.string.app_name), "Please enter Password.");

        else
            return true;

        return false;
    }


    private void getKeyHash() {

        PackageInfo info;
        try {
            info = getPackageManager().getPackageInfo("com.androidlift.facebookdemo", PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md;
                md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String something = new String(Base64.encode(md.digest(), 0));
                //String something = new String(Base64.encodeBytes(md.digest()));
                Log.e("hash key**********", something);
            }
        } catch (PackageManager.NameNotFoundException e1) {
            Log.e("name not found", e1.toString());
        } catch (NoSuchAlgorithmException e) {
            Log.e("no such an algorithm", e.toString());
        } catch (Exception e) {
            Log.e("exception", e.toString());
        }
    }


    private void Checkhashkey() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo("com.sham.demoregistration", PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String sign = Base64.encodeToString(md.digest(), Base64.DEFAULT);
                Log.e("MY KEY HASH:", sign);
                Toast.makeText(getApplicationContext(), sign, Toast.LENGTH_LONG).show();
            }
        } catch (PackageManager.NameNotFoundException e) {
        } catch (NoSuchAlgorithmException e) {
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        //super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode,resultCode,data);
    }
}
