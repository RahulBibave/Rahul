package com.rahul.applink;

import android.support.v4.app.Fragment;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by rahul on 29/7/17.
 */

public class FragmentGet extends Fragment {
































    */
    mRequestQueue= Volley.newRequestQueue(getContext());

    JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
            Request.Method.GET,
            mUrl,
            new JSONObject(),
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {


                        JSONArray jsonArray=response.getJSONArray("results");
                        Log.e("length",""+jsonArray.length());

                        for (int i = 0; i < jsonArray.length(); i++) {
                            Log.e("length",String.valueOf(jsonArray.length()));
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            JSONObject jsonObject1=jsonObject.getJSONObject("geometry");
                            JSONObject jsonObject2=jsonObject1.getJSONObject("location");
                            School place=new School();
                            place.setmLong(Double.parseDouble(jsonObject2.getString("lng")));
                            place.setmLat(Double.parseDouble(jsonObject2.getString("lat")));
                            place.setmImage(jsonObject.getString("icon"));
                            place.setmName(jsonObject.getString("name"));
                            place.setmAddress(jsonObject.getString("vicinity"));
                            schoolArrayList.add(place);

                        }
                        mAdapterListView =new AdapterSchool(schoolArrayList,getContext());
                        mRecyclerView.setAdapter(mAdapterListView);
                        mAdapterListView.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

        }

    });
        mRequestQueue.add(jsonObjectRequest);















    */
}
